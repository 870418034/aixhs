@echo off
chcp 65001 >nul
title XHS AI Platform
echo.
echo  =========================================
echo    [XHS] XiaoHongShu AI Platform v1.0
echo  =========================================
echo.
python --version 2>&1 | findstr /R "^Python 3\.1[0-9]" >nul
if errorlevel 1 (
    echo  [X] Requires Python 3.10+
    pause
    exit /b 1
)
for /f "tokens=2" %%i in ('python --version 2^>^&1') do echo  [OK] Python %%i
if not exist "venv" (
    echo  [*] Creating virtual environment...
    python -m venv venv
    if errorlevel 1 ( echo  [X] Failed & pause & exit /b 1 )
)
call venv\Scripts\activate.bat
echo  [*] Installing core dependencies...
pip install fastapi uvicorn sqlalchemy aiosqlite pydantic pydantic-settings playwright apscheduler openai pyyaml python-multipart websockets httpx pillow loguru cryptography jieba openpyxl jinja2 --disable-pip-version-check
echo  [*] Trying optional dependency pyahocorasick...
pip install pyahocorasick --disable-pip-version-check 2>nul
echo  [*] Checking browser driver...
python -c "from playwright.sync_api import sync_playwright; p = sync_playwright().start(); p.stop()" >nul 2>&1
if errorlevel 1 ( echo  [*] Installing Chromium... & playwright install chromium )
if not exist "config.yaml" (
    if exist "config.example.yaml" copy config.example.yaml config.yaml >nul
    echo  [!] config.yaml created, add your AI API Key then rerun!
    notepad config.yaml
    pause
    exit /b 0
)
if not exist "data" mkdir data
if not exist "data\accounts" mkdir data\accounts
if not exist "data\materials\images" mkdir data\materials\images
if not exist "data\logs" mkdir data\logs
if not exist "data\safety" mkdir data\safety
echo.
echo  [*] Starting service...
echo  [URL] http://127.0.0.1:8080
echo.
python main.py
if errorlevel 1 ( echo  [X] Service crashed & pause )
