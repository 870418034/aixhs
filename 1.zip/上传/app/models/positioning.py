"""PositioningResult 模型 — 账号定位分析结果。"""

from __future__ import annotations

from uuid import uuid4

from sqlalchemy import Column, DateTime, ForeignKey, String, Text, func
from sqlalchemy.orm import relationship

from app.database import Base


def uuid4_str() -> str:
    return str(uuid4())


class PositioningResult(Base):
    __tablename__ = "positioning_results"

    id = Column(String(36), primary_key=True, default=uuid4_str)
    account_id = Column(String(36), ForeignKey("accounts.id"))
    niche = Column(Text, default="")
    target_audience = Column(Text, default="")
    content_style = Column(Text, default="")
    tone = Column(Text, default="")
    keywords = Column(Text, default="[]")
    strategy = Column(Text, default="")
    created_at = Column(DateTime, default=func.now())

    account = relationship("Account", back_populates="positioning_results")
