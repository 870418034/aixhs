"""内容模型。"""

from __future__ import annotations

from datetime import datetime
from uuid import uuid4

from sqlalchemy import Boolean, Column, DateTime, Float, ForeignKey, Integer, String, Text, func
from sqlalchemy.orm import relationship

from app.database import Base
from app.models._enums import ContentStatus, ContentType


def uuid4_str() -> str:
    return str(uuid4())


class Content(Base):
    __tablename__ = "contents"

    id = Column(String(36), primary_key=True, default=uuid4_str)
    account_id = Column(String(36), ForeignKey("accounts.id"), nullable=False)
    title = Column(String(200), default="")
    body = Column(Text, default="")
    tags = Column(Text, default="[]")
    topic = Column(String(100), default="")
    images = Column(Text, default="[]")
    content_type = Column(String(20), default="note")
    category = Column(String(50), default="")
    status = Column(String(20), default="draft")
    xhs_note_id = Column(String(50), default="")
    xhs_note_url = Column(Text, default="")
    publish_time = Column(DateTime, nullable=True)
    is_scheduled = Column(Boolean, default=False)
    views = Column(Integer, default=0)
    likes = Column(Integer, default=0)
    comments_count = Column(Integer, default=0)
    collects = Column(Integer, default=0)
    shares = Column(Integer, default=0)
    last_stats_refresh = Column(DateTime, nullable=True)
    ai_config_id = Column(String(36), default="")
    ai_prompt_used = Column(Text, default="")
    generation_params = Column(Text, default="{}")
    safety_score = Column(Float, default=0.0)
    safety_result = Column(Text, default="{}")
    safety_checked_at = Column(DateTime, nullable=True)
    original_body = Column(Text, default="")
    rewrite_count = Column(Integer, default=0)
    title_variants = Column(Text, default="[]")
    created_at = Column(DateTime, default=func.now())
    updated_at = Column(DateTime, default=func.now(), onupdate=func.now())

    # 关系
    account = relationship("Account", back_populates="contents")
    versions = relationship("ContentVersion", back_populates="content", lazy="dynamic")
    comments = relationship("Comment", lazy="dynamic")


class ContentVersion(Base):
    __tablename__ = "content_versions"

    id = Column(String(36), primary_key=True, default=uuid4_str)
    content_id = Column(String(36), ForeignKey("contents.id"), nullable=False)
    version = Column(Integer, default=1)
    title = Column(String(200), default="")
    body = Column(Text, default="")
    tags = Column(Text, default="[]")
    images = Column(Text, default="[]")
    created_at = Column(DateTime, default=func.now())

    # 关系
    content = relationship("Content", back_populates="versions")
