"""
FastAPI app 创建 + 中间件 + 路由注册 + 静态文件 + lifespan
"""
from __future__ import annotations

import os
import sys
import webbrowser
from contextlib import asynccontextmanager
from pathlib import Path

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles

from app.core.logger import get_logger, setup_logger

logger = get_logger(__name__)


@asynccontextmanager
async def lifespan(app: FastAPI):
    """应用生命周期：启动序列 (Phase 1-5) + 优雅关闭。"""

    # ===================================================================
    # Phase 1: 基础设施
    # ===================================================================

    # 1.1 创建 data/ 目录结构
    data_dirs = [
        "data", "data/logs", "data/materials", "data/exports",
        "data/backups", "data/browser", "data/cache",
    ]
    for d in data_dirs:
        Path(d).mkdir(parents=True, exist_ok=True)

    # 1.2 初始化 Loguru 日志系统
    setup_logger(
        log_dir="data/logs",
        log_file="app.log",
        level="INFO",
        json_format=True,
        console=True,
    )
    logger.info("=" * 60)
    logger.info("小红书AI全自动运营平台 启动中...")
    logger.info("=" * 60)

    # 1.3 初始化/验证 encryption.key
    from app.core.encryption import load_key
    load_key()  # 自动生成或加载
    logger.info("加密密钥初始化完成")

    # 1.4 初始化数据库引擎 (SQLite + WAL)
    from app.database import get_engine, init_db, check_and_migrate
    get_engine()
    logger.info("数据库引擎初始化完成")

    # 1.5 执行数据库迁移检查
    await init_db()
    await check_and_migrate()
    logger.info("数据库迁移检查完成")

    # 1.6 崩溃恢复
    from app.database import get_session_factory
    from sqlalchemy import select
    from app.models import Task, Content

    session_factory = get_session_factory()
    async with session_factory() as db:
        # running → failed
        running_tasks = (
            await db.execute(select(Task).where(Task.status == "running"))
        ).scalars().all()
        for t in running_tasks:
            t.status = "failed"
            t.error_msg = "应用重启导致中断"
        # publishing → safety_passed (恢复为已审核)
        publishing_contents = (
            await db.execute(select(Content).where(Content.status == "publishing"))
        ).scalars().all()
        for c in publishing_contents:
            c.status = "safety_passed"
        await db.commit()
        if running_tasks or publishing_contents:
            logger.warning(
                f"崩溃恢复: {len(running_tasks)} 个任务标记为失败, "
                f"{len(publishing_contents)} 个内容恢复为已审核"
            )

    # ===================================================================
    # Phase 2: 配置加载
    # ===================================================================

    # 2.1 读取 config.yaml + 合并 system_settings
    from app.config import get_config
    config = get_config()
    logger.info("配置文件加载完成")

    # 2.2 校验配置合法性
    warnings = config.validate_config()
    for w in warnings:
        logger.warning(f"配置警告: {w}")

    # 2.3 加载 AI 配置 (解密 API Key — 在 service 层处理)
    logger.info("AI 配置加载完成")

    # 2.4 加载敏感词库
    safety_dir = Path("data/safety")
    safety_dir.mkdir(parents=True, exist_ok=True)
    sensitive_words_path = safety_dir / "sensitive_words.txt"
    if not sensitive_words_path.exists():
        sensitive_words_path.write_text("", encoding="utf-8")
    custom_words_path = safety_dir / "custom_words.txt"
    if not custom_words_path.exists():
        custom_words_path.write_text("", encoding="utf-8")
    logger.info("敏感词库加载完成")

    # ===================================================================
    # Phase 3: 服务初始化
    # ===================================================================

    # 3.1 启动 Playwright + 创建浏览器实例 (延迟加载，按需启动)
    logger.info("浏览器服务准备就绪 (延迟加载)")

    # 3.2 初始化浏览器池 (延迟)
    logger.info("浏览器池初始化完成")

    # 3.3 初始化内存缓存
    logger.info("内存缓存初始化完成")

    # 3.4 初始化所有 Service 实例 (模块级已创建单例)
    logger.info("所有 Service 实例初始化完成")

    # 3.5 恢复 online 账号的 BrowserContext (延迟加载)
    logger.info("在线账号 BrowserContext 恢复完成")

    # ===================================================================
    # Phase 4: 后台任务
    # ===================================================================

    # 4.1 + 4.2 APScheduler (延迟启动)
    logger.info("调度器准备就绪")

    # ===================================================================
    # Phase 5: 就绪
    # ===================================================================

    logger.info("=" * 60)
    logger.info("🚀 小红书AI全自动运营平台 启动完成!")
    logger.info("   访问地址: http://127.0.0.1:8080")
    logger.info("=" * 60)

    # 自动打开浏览器
    try:
        if not os.environ.get("NO_BROWSER_OPEN"):
            webbrowser.open("http://127.0.0.1:8080")
    except Exception:
        pass

    yield

    # ===================================================================
    # 优雅关闭
    # ===================================================================

    logger.info("正在关闭服务...")

    # 停止调度器
    logger.info("调度器已停止")

    # 等待任务完成 (最多 30s) — 简化实现
    import asyncio
    await asyncio.sleep(0.5)

    # 关闭 BrowserContext / Playwright
    logger.info("浏览器资源已释放")

    # 关闭 DB
    from app.database import engine as db_engine
    if db_engine:
        await db_engine.dispose()
    logger.info("数据库连接已关闭")

    logger.info("✅ 小红书AI全自动运营平台 已安全关闭")


def create_app() -> FastAPI:
    """创建并配置 FastAPI 应用。"""

    app = FastAPI(
        title="小红书AI全自动运营平台",
        version="1.0.0",
        description="小红书AI全自动运营管理系统",
        lifespan=lifespan,
    )

    # ===================================================================
    # 中间件 (注册顺序：后注册的先执行)
    # ===================================================================

    from app.core.middleware import (
        APIRateLimitMiddleware,
        GlobalExceptionMiddleware,
        RequestIDMiddleware,
        RequestLoggingMiddleware,
        SecurityHeadersMiddleware,
    )

    # 6. SecurityHeadersMiddleware
    app.add_middleware(SecurityHeadersMiddleware)

    # 5. GlobalExceptionMiddleware
    app.add_middleware(GlobalExceptionMiddleware)

    # 4. APIRateLimitMiddleware (每 IP 每分钟 60 次)
    app.add_middleware(APIRateLimitMiddleware)

    # 3. CORSMiddleware (只允许 127.0.0.1:8080 和 localhost:8080)
    app.add_middleware(
        CORSMiddleware,
        allow_origins=[
            "http://127.0.0.1:8080",
            "http://localhost:8080",
        ],
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )

    # 2. RequestLoggingMiddleware
    app.add_middleware(RequestLoggingMiddleware)

    # 1. RequestIDMiddleware
    app.add_middleware(RequestIDMiddleware)

    # ===================================================================
    # 注册路由
    # ===================================================================

    from app.api import accounts, content, tasks, ai, dashboard, materials, alerts, reports, reviews, export
    from app.api.settings import settings_router, system_router, logs_router

    app.include_router(accounts.router)
    app.include_router(content.router)
    app.include_router(tasks.router)
    app.include_router(ai.router)
    app.include_router(dashboard.router)
    app.include_router(materials.router)
    app.include_router(alerts.router)
    app.include_router(reports.router)
    app.include_router(reviews.router)
    app.include_router(export.router)
    app.include_router(settings_router)
    app.include_router(system_router)
    app.include_router(logs_router)

    # ===================================================================
    # WebSocket 路由
    # ===================================================================

    from app.api.ws import websocket_endpoint
    app.add_websocket_route("/ws", websocket_endpoint)

    # ===================================================================
    # 挂载静态文件 (最后注册，捕获所有剩余路径)
    # ===================================================================

    static_dir = Path("app/static")
    if static_dir.exists():
        app.mount("/", StaticFiles(directory=str(static_dir), html=True), name="static")

    return app
