"""内存缓存：TTL 过期 + LRU 淘汰。"""

from __future__ import annotations

import asyncio
import functools
import threading
import time
from collections import OrderedDict
from typing import Any, Callable, Optional, TypeVar

from app.core.logger import get_logger

logger = get_logger(__name__)

F = TypeVar("F", bound=Callable[..., Any])


class TTLCache:
    """带 TTL 过期和 LRU 淘汰的内存缓存。"""

    def __init__(self, max_size: int = 1000, default_ttl: float = 300.0) -> None:
        self._max_size = max_size
        self._default_ttl = default_ttl
        self._cache: OrderedDict[str, tuple[Any, float]] = OrderedDict()
        self._lock = asyncio.Lock()

    async def get(self, key: str) -> Optional[Any]:
        async with self._lock:
            if key not in self._cache:
                return None
            value, expire_at = self._cache[key]
            if time.time() > expire_at:
                del self._cache[key]
                return None
            # 移到末尾 (最近使用)
            self._cache.move_to_end(key)
            return value

    async def set(self, key: str, value: Any, ttl: Optional[float] = None) -> None:
        ttl = ttl if ttl is not None else self._default_ttl
        expire_at = time.time() + ttl
        async with self._lock:
            if key in self._cache:
                self._cache.move_to_end(key)
            self._cache[key] = (value, expire_at)
            # LRU 淘汰
            while len(self._cache) > self._max_size:
                self._cache.popitem(last=False)

    async def delete(self, key: str) -> bool:
        async with self._lock:
            if key in self._cache:
                del self._cache[key]
                return True
            return False

    async def clear(self) -> None:
        async with self._lock:
            self._cache.clear()

    async def size(self) -> int:
        async with self._lock:
            # 清理过期项
            now = time.time()
            expired = [k for k, (_, exp) in self._cache.items() if now > exp]
            for k in expired:
                del self._cache[k]
            return len(self._cache)


# 全局缓存实例
_global_cache = TTLCache()
_global_sync_lock = threading.Lock()


def cached(ttl: float = 300.0, key_prefix: str = ""):
    """缓存装饰器，支持同步和异步函数。"""

    def decorator(func: F) -> F:
        if asyncio.iscoroutinefunction(func):

            @functools.wraps(func)
            async def async_wrapper(*args: Any, **kwargs: Any) -> Any:
                cache_key = f"{key_prefix}:{func.__name__}:{args}:{kwargs}"
                result = await _global_cache.get(cache_key)
                if result is not None:
                    return result
                result = await func(*args, **kwargs)
                await _global_cache.set(cache_key, result, ttl)
                return result

            return async_wrapper  # type: ignore[return-value]
        else:

            @functools.wraps(func)
            def sync_wrapper(*args: Any, **kwargs: Any) -> Any:
                cache_key = f"{key_prefix}:{func.__name__}:{args}:{kwargs}"
                with _global_sync_lock:
                    cached_data = _global_cache._cache
                    if cache_key in cached_data:
                        val, exp = cached_data[cache_key]
                        if time.time() <= exp:
                            _global_cache._cache.move_to_end(cache_key)
                            return val
                result = func(*args, **kwargs)
                expire_at = time.time() + ttl
                with _global_sync_lock:
                    _global_cache._cache[cache_key] = (result, expire_at)
                    while len(_global_cache._cache) > _global_cache._max_size:
                        _global_cache._cache.popitem(last=False)
                return result

            return sync_wrapper  # type: ignore[return-value]

    return decorator
