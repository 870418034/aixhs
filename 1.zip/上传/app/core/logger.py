"""Loguru 日志配置。"""

from __future__ import annotations

import sys
from pathlib import Path
from typing import TYPE_CHECKING, Any

from loguru import logger

if TYPE_CHECKING:
    from app.config import LoggingConfig

# 移除默认处理器
logger.remove()


def setup_logger(
    log_file: str = "data/logs/app.log",
    max_size_mb: int = 50,
    backup_count: int = 10,
    level: str = "INFO",
    json_format: bool = True,
    console: bool = True,
    log_dir: str = "",
) -> None:
    """配置 Loguru 日志。

    Args:
        log_file: 日志文件名（可以是相对路径或仅文件名）。
        log_dir: 日志目录。若提供且 log_file 为纯文件名，则拼接 log_dir/log_file。
    """
    # 如果传入了 log_dir 且 log_file 为纯文件名（无目录路径），则拼接
    if log_dir and Path(log_file).parent == Path("."):
        log_file = str(Path(log_dir) / log_file)

    # 确保日志目录存在
    Path(log_file).parent.mkdir(parents=True, exist_ok=True)

    # 日志格式
    # JSON 格式 — 用 loguru 自带 serialize 功能，避免花括号冲突
    if json_format:
        logger.add(
            log_file,
            rotation=f"{max_size_mb} MB",
            retention=backup_count,
            encoding="utf-8",
            enqueue=True,
            backtrace=True,
            diagnose=True,
            serialize=True,  # loguru 原生 JSON 输出
            level=level,
        )
    else:
        logger.add(
            log_file,
            rotation=f"{max_size_mb} MB",
            retention=backup_count,
            encoding="utf-8",
            enqueue=True,
            backtrace=True,
            diagnose=True,
            format=(
                "<green>{time:YYYY-MM-DD HH:mm:ss.SSS}</green> | "
                "<level>{level: <8}</level> | "
                "<cyan>{module}</cyan>:<cyan>{function}</cyan>:<cyan>{line}</cyan> | "
                "<level>{message}</level>"
            ),
            level=level,
        )

    # 控制台输出
    if console:
        logger.add(
            sys.stderr,
            format=(
                "<green>{time:HH:mm:ss}</green> | "
                "<level>{level: <8}</level> | "
                "<cyan>{module}</cyan> | "
                "<level>{message}</level>"
            ),
            level=level,
            backtrace=True,
            diagnose=True,
        )


def configure_logging(config: "LoggingConfig") -> None:
    """使用配置对象配置日志。"""
    setup_logger(
        log_file=config.file,
        max_size_mb=config.max_size_mb,
        backup_count=config.backup_count,
        level=config.level.upper(),
        json_format=config.json_format,
        console=config.console,
    )


def get_logger(name: str) -> Any:
    """获取带模块名的 logger 实例。"""
    return logger.bind(module=name)


# 注意：不在模块级调用 setup_logger()，由 lifespan 统一配置
