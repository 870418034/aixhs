"""系统设置服务。"""

from __future__ import annotations

import json
import os
import shutil
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional

from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.models import ActivityLog, SystemSetting


class SettingsService:
    """系统设置、备份、恢复、日志、诊断。"""

    async def get_settings(self, db: AsyncSession) -> Dict[str, Any]:
        rows = (await db.execute(select(SystemSetting))).scalars().all()
        settings = {r.key: r.value for r in rows}
        return {
            "theme": settings.get("theme", "light"),
            "language": settings.get("language", "zh-CN"),
            "auto_start": settings.get("auto_start", "false"),
            "notification_enabled": settings.get("notification_enabled", "true"),
            "data_retention_days": settings.get("data_retention_days", "180"),
        }

    async def update_settings(self, db: AsyncSession, data: Dict[str, Any]) -> bool:
        for key, value in data.items():
            query = select(SystemSetting).where(SystemSetting.key == key)
            setting = (await db.execute(query)).scalars().first()
            if setting:
                setting.value = str(value)
            else:
                db.add(SystemSetting(key=key, value=str(value)))
        await db.flush()
        return True

    async def create_backup(self, db: AsyncSession) -> Dict[str, Any]:
        backup_dir = Path("data/backups")
        backup_dir.mkdir(parents=True, exist_ok=True)
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        backup_name = f"backup_{timestamp}"
        backup_path = backup_dir / backup_name
        backup_path.mkdir(parents=True, exist_ok=True)
        # 复制数据库文件
        db_file = Path("data/app.db")
        if db_file.exists():
            shutil.copy2(db_file, backup_path / "app.db")
        return {"backup_name": backup_name, "path": str(backup_path), "created_at": str(datetime.now())}

    async def restore_backup(self, db: AsyncSession, backup_name: str) -> bool:
        backup_path = Path("data/backups") / backup_name / "app.db"
        if not backup_path.exists():
            return False
        shutil.copy2(backup_path, "data/app.db")
        return True

    async def get_logs(
        self, db: AsyncSession, page: int = 1, size: int = 50,
        level: Optional[str] = None, account_id: Optional[int] = None,
        keyword: Optional[str] = None,
    ) -> Dict[str, Any]:
        query = select(ActivityLog)
        if level:
            query = query.where(ActivityLog.level == level.upper())
        if account_id:
            query = query.where(ActivityLog.account_id == account_id)
        if keyword:
            query = query.where(ActivityLog.detail.contains(keyword))
        total = (await db.execute(select(func.count()).select_from(query.subquery()))).scalar() or 0
        query = query.order_by(ActivityLog.created_at.desc()).offset((page - 1) * size).limit(size)
        rows = (await db.execute(query)).scalars().all()
        items = [
            {
                "id": r.id, "level": r.level, "module": r.module,
                "message": r.detail, "account_id": r.account_id,
                "created_at": str(r.created_at),
            }
            for r in rows
        ]
        return {"items": items, "total": total, "page": page, "page_size": size}

    async def clear_logs(self, db: AsyncSession, before_days: int = 30) -> int:
        from datetime import timedelta
        since = datetime.now() - timedelta(days=before_days)
        rows = (await db.execute(
            select(ActivityLog).where(ActivityLog.created_at < since)
        )).scalars().all()
        count = len(rows)
        for r in rows:
            await db.delete(r)
        await db.flush()
        return count

    async def get_system_status(self) -> Dict[str, Any]:
        import psutil
        cpu_percent = psutil.cpu_percent(interval=0.1)
        memory = psutil.virtual_memory()
        disk = psutil.disk_usage("/")
        return {
            "cpu_percent": cpu_percent,
            "memory_total": memory.total,
            "memory_used": memory.used,
            "memory_percent": memory.percent,
            "disk_total": disk.total,
            "disk_used": disk.used,
            "disk_percent": disk.percent,
            "status": "healthy" if cpu_percent < 80 and memory.percent < 80 else "warning",
        }

    async def report_client_error(self, data: Dict[str, Any]) -> bool:
        return True

    async def get_diagnostics(self) -> Dict[str, Any]:
        return {
            "database": "ok",
            "browser": "ok",
            "scheduler": "ok",
            "disk_space": "ok",
            "issues": [],
        }

    async def auto_fix(self) -> Dict[str, Any]:
        return {"fixed": [], "message": "系统运行正常，无需修复"}


settings_service = SettingsService()
