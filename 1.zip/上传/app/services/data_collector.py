"""数据回采"""

import uuid
from datetime import datetime, timedelta
from typing import Dict, Any, Optional, List

from loguru import logger
from sqlalchemy import select, and_

from app.database import async_session_maker
from app.models.content import Content, ContentStatus
from app.models.daily_stat import DailyStat
from app.models.account import Account
from app.services.xiaohongshu_browser import XiaohongshuBrowser


# 发布后回采时间点
COLLECT_SCHEDULE = [
    timedelta(hours=2),
    timedelta(hours=6),
    timedelta(hours=24),
    timedelta(hours=48),
    timedelta(days=3),
    timedelta(days=5),
    timedelta(days=7),
]


class DataCollector:
    """数据回采"""

    def __init__(self):
        self.browser = XiaohongshuBrowser()

    async def collect_stats(self, content_id: str) -> Dict[str, Any]:
        """采集单篇笔记数据"""
        async with async_session_maker() as session:
            content = await session.get(Content, content_id)
            if not content:
                raise ValueError(f"Content {content_id} not found")
            if not content.xhs_note_id:
                raise ValueError("Content has no xhs_note_id")
            account_id = content.account_id

        # 从浏览器抓取数据
        stats = await self.browser.get_note_stats(content.xhs_note_id)

        async with async_session_maker() as session:
            content = await session.get(Content, content_id)
            content.views = stats.get("views", 0)
            content.likes = stats.get("likes", 0)
            content.collects = stats.get("collects", 0)
            content.comments_count = stats.get("comments", 0)
            content.shares = stats.get("shares", 0)
            content.last_stats_refresh = datetime.utcnow()
            content.updated_at = datetime.utcnow()
            await session.commit()

        logger.info(f"Stats collected for content {content_id}: {stats}")
        return stats

    async def collect_all_due(self):
        """检查并回采所有到期的内容"""
        now = datetime.utcnow()
        async with async_session_maker() as session:
            result = await session.execute(
                select(Content).where(
                    Content.status == ContentStatus.PUBLISHED,
                    Content.xhs_note_id.isnot(None),
                    Content.publish_time.isnot(None),
                )
            )
            contents = result.scalars().all()

        collected = 0
        for content in contents:
            if not content.publish_time:
                continue

            elapsed = now - content.publish_time
            last_update = content.last_stats_refresh or content.publish_time
            time_since_last = now - last_update

            # 判断是否需要回采
            should_collect = False

            # 发布后7天内的回采点
            for checkpoint in COLLECT_SCHEDULE:
                if elapsed >= checkpoint and elapsed < checkpoint + timedelta(hours=2):
                    if time_since_last >= timedelta(hours=1):
                        should_collect = True
                        break

            # 7天后每天一次
            if elapsed.days >= 7 and elapsed.days <= 14:
                if time_since_last >= timedelta(hours=23):
                    should_collect = True

            if should_collect:
                try:
                    await self.collect_stats(str(content.id))
                    collected += 1
                except Exception as e:
                    logger.error(f"Failed to collect stats for content {content.id}: {e}")

        logger.info(f"Data collection completed: {collected} contents collected")
        return collected

    async def collect_account_stats(self, account_id: str) -> Dict[str, Any]:
        """采集账号主页数据"""
        async with async_session_maker() as session:
            account = await session.get(Account, account_id)
            if not account:
                raise ValueError(f"Account {account_id} not found")

        profile_data = await self.browser.open_profile(account_id)

        async with async_session_maker() as session:
            account = await session.get(Account, account_id)
            old_followers = account.followers or 0
            account.followers = profile_data.get("followers", 0)
            account.following = profile_data.get("following", 0)
            account.notes_count = profile_data.get("notes", 0)
            account.likes = profile_data.get("liked", 0)
            account.last_data_refresh = datetime.utcnow()
            account.updated_at = datetime.utcnow()
            await session.commit()

            # 记录每日粉丝变化
            today_date = datetime.utcnow().date()
            result = await session.execute(
                select(DailyStat).where(
                    DailyStat.account_id == account_id,
                    DailyStat.date == today_date,
                )
            )
            daily_stat = result.scalar_one_or_none()
            follower_change = account.followers - old_followers
            if daily_stat:
                daily_stat.followers = account.followers
                daily_stat.followers_gain = follower_change
            else:
                daily_stat = DailyStat(
                    id=str(uuid.uuid4()),
                    account_id=account_id,
                    date=today_date,
                    followers=account.followers,
                    following=account.following,
                    notes_count=account.notes_count,
                    followers_gain=follower_change,
                )
                session.add(daily_stat)
            await session.commit()

        return {
            "account_id": account_id,
            "followers": profile_data.get("followers", 0),
            "following": profile_data.get("following", 0),
            "notes": profile_data.get("notes", 0),
            "follower_change": follower_change,
        }
data_collector = DataCollector()
