"""
内容自动续航 - 库存不足时自动补充内容
"""
from __future__ import annotations
import json
from datetime import datetime, timedelta
from typing import List, Dict
from sqlalchemy import select, and_, func
from sqlalchemy.ext.asyncio import AsyncSession
from loguru import logger

from app.models import Account, Content, StrategyOverride
from app.database import get_db_session


class ContentContinuum:
    """内容自动续航"""

    def __init__(self, content_generator=None):
        self.content_generator = content_generator

    async def check_and_fill(self):
        """每天22:30检查库存→库存不足自动补充"""
        async for db in get_db_session():
            try:
                stmt = select(Account).where(Account.operation_stage == "active")
                result = await db.execute(stmt)
                accounts = result.scalars().all()
                for account in accounts:
                    gap = await self._calculate_gap(db, account.id)
                    if gap > 0:
                        topics = await self._select_topics(db, account.id)
                        logger.info(f"账号 {account.nickname} 内容缺口 {gap}，开始补充")
                        for i in range(min(gap, len(topics))):
                            if self.content_generator:
                                try:
                                    await self.content_generator.generate(account.id, topics[i])
                                except Exception as e:
                                    logger.error(f"内容补充生成失败: {e}")
                await db.commit()
            except Exception as e:
                logger.error(f"内容续航检查失败: {e}")
                await db.rollback()

    async def _calculate_gap(self, db: AsyncSession, account_id: str) -> int:
        """计算内容缺口"""
        stmt = select(func.count()).select_from(Content).where(
            Content.account_id == account_id,
            Content.status.in_(["approved", "scheduled"])
        )
        inventory = (await db.execute(stmt)).scalar() or 0
        daily_publish = 2
        target = daily_publish * 3
        return max(0, target - inventory)

    async def _select_topics(self, db: AsyncSession, account_id: str) -> List[str]:
        """选择内容主题 - 复盘推荐 > 近期表现好 > 竞品热门 > 热点"""
        topics = []
        today = datetime.now().date()
        override_stmt = select(StrategyOverride).where(
            StrategyOverride.account_id == account_id,
            StrategyOverride.target_date >= today,
            StrategyOverride.is_used == False
        ).order_by(StrategyOverride.created_at.desc()).limit(1)
        result = await db.execute(override_stmt)
        override = result.scalar_one_or_none()
        if override:
            try:
                directions = json.loads(override.content_directions or "{}")
                topics.extend(directions.get("increase", []))
                topics.extend(directions.get("new_try", []))
            except (json.JSONDecodeError, KeyError):
                pass

        good_content_stmt = select(Content).where(
            Content.account_id == account_id,
            Content.status == "published",
            Content.views > 100
        ).order_by(Content.views.desc()).limit(5)
        result = await db.execute(good_content_stmt)
        for c in result.scalars().all():
            if c.category and c.category not in topics:
                topics.append(c.category)

        if not topics:
            topics = ["日常分享", "实用技巧", "经验总结"]
        return topics


content_continuum = ContentContinuum()
