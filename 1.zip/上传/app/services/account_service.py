"""
账号服务 - CRUD + 登录 + 运营控制
"""
from __future__ import annotations

import json
import uuid
from datetime import datetime, timedelta
from pathlib import Path
from typing import Any, Dict, List, Optional

from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession
from loguru import logger

from app.models import Account, CookieMeta
from app.database import get_db_session

DATA_DIR = Path("data")
ACCOUNTS_DIR = DATA_DIR / "accounts"


class AccountService:
    """账号CRUD + 登录 + 运营控制"""

    # ═══════════════════════════════════════════
    # 登录
    # ═══════════════════════════════════════════

    async def get_qr_code(self) -> Dict[str, Any]:
        """获取登录二维码"""
        from app.services.xiaohongshu_browser import xiaohongshu_browser
        return await xiaohongshu_browser.get_qr_code()

    async def check_qr_status(self, token: str) -> Dict[str, Any]:
        """
        检查扫码状态，成功后创建账号并保存Cookie
        """
        from app.services.xiaohongshu_browser import xiaohongshu_browser
        result = await xiaohongshu_browser.check_qr_status(token)

        if result.get("status") == "success" and result.get("cookies"):
            # 登录成功，创建账号并保存Cookie
            user_info = result.get("user_info", {})
            cookies = result["cookies"]

            async for db in get_db_session():
                # 创建新账号
                account_id = str(uuid.uuid4())
                account = Account(
                    id=account_id,
                    nickname=user_info.get("name", ""),
                    status="online",
                    login_method="qr",
                )
                db.add(account)
                await db.flush()

                # 保存Cookie到加密文件
                from app.services.cookie_manager import cookie_manager
                await cookie_manager.save_cookie_from_login(account_id, cookies)

                # 创建Cookie元数据
                meta = CookieMeta(
                    account_id=account_id,
                    created_at=datetime.now(),
                    expires_at=datetime.now() + timedelta(days=30),
                    last_verified=datetime.now(),
                    status="valid",
                )
                db.add(meta)
                await db.commit()

                # 异步获取账号详细信息
                try:
                    profile_data = await xiaohongshu_browser.open_profile(account_id)
                    account.nickname = profile_data.get("nickname") or account.nickname
                    account.bio = profile_data.get("bio", "")
                    account.avatar_url = profile_data.get("avatar_url", "")
                    account.followers = profile_data.get("followers", 0)
                    account.following = profile_data.get("following", 0)
                    account.likes = profile_data.get("likes", 0)
                    account.notes_count = profile_data.get("notes", 0)
                    account.last_active_at = datetime.now()
                    account.last_data_refresh = datetime.now()
                    await db.commit()
                except Exception as e:
                    logger.warning(f"获取账号信息失败: {e}")

                result["account_id"] = account_id
                logger.info(f"账号创建成功: {account.nickname} ({account_id})")
                break

        return result

    async def cookie_login(self, cookie_str: str, nickname: str = "") -> Dict[str, Any]:
        """Cookie登录"""
        import json as json_mod

        # 解析Cookie
        cookies = []
        try:
            if cookie_str.strip().startswith("["):
                cookies = json_mod.loads(cookie_str)
            else:
                # 解析字符串格式的Cookie
                for item in cookie_str.split(";"):
                    item = item.strip()
                    if "=" in item:
                        name, value = item.split("=", 1)
                        cookies.append({"name": name.strip(), "value": value.strip(), "domain": ".xiaohongshu.com"})
        except Exception as e:
            return {"error": f"Cookie解析失败: {e}"}

        if not cookies:
            return {"error": "Cookie为空"}

        async for db in get_db_session():
            account_id = str(uuid.uuid4())
            account = Account(
                id=account_id,
                nickname=nickname,
                status="verifying",
                login_method="cookie",
            )
            db.add(account)
            await db.flush()

            # 保存Cookie
            from app.services.cookie_manager import cookie_manager
            await cookie_manager.save_cookie_from_login(account_id, cookies)

            # 验证Cookie
            from app.services.xiaohongshu_browser import xiaohongshu_browser
            valid = await cookie_manager.verify_cookie(account_id)

            if valid:
                account.status = "online"
                # 获取账号信息
                try:
                    profile_data = await xiaohongshu_browser.open_profile(account_id)
                    account.nickname = profile_data.get("nickname") or account.nickname
                    account.bio = profile_data.get("bio", "")
                    account.avatar_url = profile_data.get("avatar_url", "")
                    account.followers = profile_data.get("followers", 0)
                    account.following = profile_data.get("following", 0)
                    account.likes = profile_data.get("likes", 0)
                    account.notes_count = profile_data.get("notes", 0)
                    account.last_active_at = datetime.now()
                    account.last_data_refresh = datetime.now()
                except Exception as e:
                    logger.warning(f"获取账号信息失败: {e}")
            else:
                account.status = "offline"
                await db.commit()
                return {"error": "Cookie无效或已过期"}

            await db.commit()
            logger.info(f"Cookie登录成功: {account.nickname} ({account_id})")
            return {"id": account_id, "nickname": account.nickname, "status": account.status}

    # ═══════════════════════════════════════════
    # CRUD
    # ═══════════════════════════════════════════

    async def list_accounts(
        self, db: AsyncSession, page: int = 1, size: int = 20,
        status: Optional[str] = None, keyword: Optional[str] = None,
    ) -> Dict[str, Any]:
        """获取账号列表"""
        query = select(Account)
        if status:
            query = query.where(Account.status == status)
        if keyword:
            query = query.where(Account.nickname.contains(keyword))
        count_q = select(func.count()).select_from(query.subquery())
        total = (await db.execute(count_q)).scalar() or 0
        query = query.order_by(Account.created_at.desc()).offset((page - 1) * size).limit(size)
        rows = (await db.execute(query)).scalars().all()
        items = [
            {
                "id": a.id, "nickname": a.nickname, "xhs_id": a.xhs_id,
                "avatar_url": a.avatar_url or "", "status": a.status,
                "operation_stage": a.operation_stage,
                "account_type": a.account_type,
                "followers": a.followers, "following": a.following,
                "likes": a.likes, "notes_count": a.notes_count,
                "health_score": a.health_score,
                "positioning": a.positioning,
                "created_at": str(a.created_at),
            }
            for a in rows
        ]
        return {"items": items, "total": total, "page": page, "page_size": size}

    async def get_account(self, db: AsyncSession, account_id: str) -> Optional[Dict[str, Any]]:
        """获取账号详情"""
        account = await db.get(Account, account_id)
        if not account:
            return None
        return {
            "id": account.id, "nickname": account.nickname, "xhs_id": account.xhs_id,
            "avatar_url": account.avatar_url, "bio": account.bio,
            "status": account.status, "login_method": account.login_method,
            "operation_stage": account.operation_stage,
            "account_type": account.account_type,
            "followers": account.followers, "following": account.following,
            "likes": account.likes, "notes_count": account.notes_count,
            "health_score": account.health_score,
            "positioning": account.positioning,
            "nurturing_day": account.nurturing_day,
            "nurturing_total_days": account.nurturing_total_days,
            "total_published": account.total_published,
            "today_actions": account.today_actions,
            "proxy": account.proxy,
            "note": account.note,
            "created_at": str(account.created_at),
            "updated_at": str(account.updated_at) if account.updated_at else None,
            "last_active_at": str(account.last_active_at) if account.last_active_at else None,
        }

    async def update_account(self, db: AsyncSession, account_id: str, data: Dict[str, Any]) -> bool:
        """更新账号"""
        account = await db.get(Account, account_id)
        if not account:
            return False
        protected = {"id", "created_at"}
        for key, value in data.items():
            if hasattr(account, key) and key not in protected:
                setattr(account, key, value)
        account.updated_at = datetime.utcnow()
        await db.flush()
        return True

    async def delete_account(self, db: AsyncSession, account_id: str) -> bool:
        """删除账号（级联清理）"""
        account = await db.get(Account, account_id)
        if not account:
            return False

        # 关闭浏览器context
        from app.services.xiaohongshu_browser import xiaohongshu_browser
        if account_id in xiaohongshu_browser._contexts:
            try:
                await xiaohongshu_browser._contexts[account_id].close()
                del xiaohongshu_browser._contexts[account_id]
            except Exception:
                pass

        # 清理Cookie文件
        import shutil
        account_dir = ACCOUNTS_DIR / account_id
        if account_dir.exists():
            try:
                shutil.rmtree(account_dir)
            except Exception:
                pass

        await db.delete(account)
        await db.flush()
        logger.info(f"账号已删除: {account_id}")
        return True

    # ═══════════════════════════════════════════
    # 运营控制
    # ═══════════════════════════════════════════

    async def start_operation(self, db: AsyncSession, account_id: str) -> bool:
        """启动运营"""
        account = await db.get(Account, account_id)
        if not account:
            return False
        if account.status != "online":
            return False
        account.operation_stage = "active"
        account.updated_at = datetime.utcnow()
        await db.flush()
        return True

    async def stop_operation(self, db: AsyncSession, account_id: str) -> bool:
        """停止运营"""
        account = await db.get(Account, account_id)
        if not account:
            return False
        account.operation_stage = "idle"
        account.updated_at = datetime.utcnow()
        await db.flush()
        return True

    async def pause_operation(self, db: AsyncSession, account_id: str) -> bool:
        """暂停运营"""
        account = await db.get(Account, account_id)
        if not account:
            return False
        account.operation_stage = "paused"
        account.updated_at = datetime.utcnow()
        await db.flush()
        return True

    async def resume_operation(self, db: AsyncSession, account_id: str) -> bool:
        """恢复运营"""
        account = await db.get(Account, account_id)
        if not account:
            return False
        account.operation_stage = "active"
        account.updated_at = datetime.utcnow()
        await db.flush()
        return True

    async def refresh_data(self, db: AsyncSession, account_id: str) -> bool:
        """刷新账号数据"""
        account = await db.get(Account, account_id)
        if not account:
            return False
        try:
            from app.services.xiaohongshu_browser import xiaohongshu_browser
            profile = await xiaohongshu_browser.open_profile(account_id)
            account.nickname = profile.get("nickname") or account.nickname
            account.bio = profile.get("bio") or account.bio
            account.avatar_url = profile.get("avatar_url") or account.avatar_url
            account.followers = profile.get("followers", account.followers)
            account.following = profile.get("following", account.following)
            account.likes = profile.get("likes", account.likes)
            account.notes_count = profile.get("notes", account.notes_count)
            account.last_data_refresh = datetime.utcnow()
            account.last_active_at = datetime.utcnow()
            await db.flush()
            return True
        except Exception as e:
            logger.error(f"刷新数据失败 {account_id}: {e}")
            return False

    async def batch_start(self, db: AsyncSession, ids: List[str]) -> int:
        count = 0
        for aid in ids:
            if await self.start_operation(db, aid):
                count += 1
        return count

    async def batch_stop(self, db: AsyncSession, ids: List[str]) -> int:
        count = 0
        for aid in ids:
            if await self.stop_operation(db, aid):
                count += 1
        return count

    async def batch_refresh(self, db: AsyncSession, ids: List[str]) -> int:
        count = 0
        for aid in ids:
            if await self.refresh_data(db, aid):
                count += 1
        return count

    async def get_stats(self, db: AsyncSession, account_id: str, days: int = 30) -> List[Dict[str, Any]]:
        """获取统计数据"""
        from app.models import DailyStat
        query = (
            select(DailyStat)
            .where(DailyStat.account_id == account_id)
            .order_by(DailyStat.date.desc())
            .limit(days)
        )
        rows = (await db.execute(query)).scalars().all()
        return [
            {
                "date": str(s.date), "followers": s.followers, "followers_gain": s.followers_gain,
                "likes": s.likes, "likes_gain": s.likes_gain,
                "views": s.total_views, "comments": s.comment_count,
                "collects": s.collect_count, "publish_count": s.publish_count,
            }
            for s in rows
        ]

    async def get_contents(self, db: AsyncSession, account_id: str, page: int = 1, size: int = 20) -> Dict[str, Any]:
        """获取账号内容"""
        from app.models import Content
        query = select(Content).where(Content.account_id == account_id)
        total = (await db.execute(select(func.count()).select_from(query.subquery()))).scalar() or 0
        query = query.order_by(Content.created_at.desc()).offset((page - 1) * size).limit(size)
        rows = (await db.execute(query)).scalars().all()
        items = [
            {"id": c.id, "title": c.title, "status": c.status,
             "views": c.views, "likes": c.likes, "collects": c.collects,
             "created_at": str(c.created_at)}
            for c in rows
        ]
        return {"items": items, "total": total, "page": page, "page_size": size}

    async def get_tasks(self, db: AsyncSession, account_id: str, page: int = 1, size: int = 20) -> Dict[str, Any]:
        """获取账号任务"""
        from app.models import Task
        query = select(Task).where(Task.account_id == account_id)
        total = (await db.execute(select(func.count()).select_from(query.subquery()))).scalar() or 0
        query = query.order_by(Task.created_at.desc()).offset((page - 1) * size).limit(size)
        rows = (await db.execute(query)).scalars().all()
        items = [
            {"id": t.id, "task_type": t.task_type, "status": t.status,
             "progress": t.progress, "created_at": str(t.created_at)}
            for t in rows
        ]
        return {"items": items, "total": total, "page": page, "page_size": size}


account_service = AccountService()
