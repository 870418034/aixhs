"""AI内容生成"""

import asyncio
import os
import uuid
import json
from datetime import datetime, timedelta
from typing import Optional, List, Dict, Any
from difflib import SequenceMatcher

from loguru import logger
from sqlalchemy import select, func, desc

from app.core.config import settings
from app.database import async_session_maker
from app.models.account import Account
from app.models.content import Content, ContentStatus, ContentType
from app.services.ai_service import AIService


class ContentGenerationResult:
    """内容生成结果"""
    def __init__(self, content: Content, titles: List[str], images: List[str]):
        self.content = content
        self.titles = titles
        self.images = images


class ContentGenerator:
    """AI内容生成"""

    def __init__(self):
        self.ai_service = AIService()

    async def generate(
        self,
        account_id: str,
        topic: Optional[str] = None,
        content_type: str = "image_text",
    ) -> ContentGenerationResult:
        """生成内容

        流程: 读取定位+历史→确定主题→AI生成5标题+正文+标签+配图描述→去重检查→配图获取→质量自检→安全审核→保存
        """
        # Step1: 读取定位和历史
        async with async_session_maker() as session:
            account = await session.get(Account, account_id)
            if not account:
                raise ValueError(f"Account {account_id} not found")

            # 获取历史内容
            result = await session.execute(
                select(Content)
                .where(Content.account_id == account_id)
                .order_by(desc(Content.created_at))
                .limit(20)
            )
            existing_contents = result.scalars().all()

        # 解析定位
        positioning = {}
        if account.positioning:
            positioning = json.loads(account.positioning)

        # Step2: 确定主题
        if not topic:
            topic = await self.suggest_topics(account_id)
            if topic:
                topic = topic[0] if isinstance(topic, list) else topic
            else:
                topic = positioning.get("niche", "生活分享")

        # Step3: AI生成内容
        prompt = self._build_content_prompt(account, positioning, topic, content_type)
        system_prompt = self._load_prompt("content_generation.txt")

        ai_response = await self.ai_service.call(
            prompt=prompt,
            system_prompt=system_prompt,
            temperature=0.8,
            max_tokens=4096,
        )
        content_data = self.ai_service.parse_json_response(ai_response)

        # Step4: 去重检查
        title = content_data.get("best_title", content_data.get("titles", [""])[0])
        body = content_data.get("body", "")
        if self._check_duplicate(title, body, existing_contents):
            logger.warning(f"Duplicate content detected, regenerating with variation")
            prompt += "\n\n请确保内容与以下主题有明显区别：另辟蹊径"
            ai_response = await self.ai_service.call(
                prompt=prompt,
                system_prompt=system_prompt,
                temperature=1.0,
                max_tokens=4096,
            )
            content_data = self.ai_service.parse_json_response(ai_response)
            title = content_data.get("best_title", content_data.get("titles", [""])[0])
            body = content_data.get("body", "")

        # Step5: 配图获取
        image_prompts = content_data.get("image_prompts", [])
        images = await self._get_images(account_id, image_prompts)

        # Step6: 质量自检
        quality_check = self._quality_check(content_data)
        if not quality_check["passed"]:
            logger.warning(f"Quality check failed: {quality_check['issues']}")

        # Step7: 安全审核
        from app.services.content_safety import ContentSafetyService
        safety_service = ContentSafetyService()
        safety_result = await safety_service.check({
            "title": title,
            "body": body,
        })

        # Step8: 保存
        async with async_session_maker() as session:
            content = Content(
                id=str(uuid.uuid4()),
                account_id=account_id,
                title=title,
                body=body,
                content_type=ContentType.note if content_type == "image_text" else ContentType.video,
                status=ContentStatus.DRAFT,
                tags=json.dumps(content_data.get("tags", []), ensure_ascii=False),
                topic=topic,
                images=json.dumps(images, ensure_ascii=False),
                generation_params=json.dumps({
                    "image_prompts": image_prompts,
                    "ai_generated_data": content_data,
                }, ensure_ascii=False),
                safety_score=float(quality_check.get("score", 0)),
                safety_result=json.dumps(safety_result, ensure_ascii=False),
                created_at=datetime.utcnow(),
                updated_at=datetime.utcnow(),
            )
            session.add(content)
            await session.commit()
            await session.refresh(content)

        titles = content_data.get("titles", [title])
        logger.info(f"Content generated: {content.id} for account {account_id}")
        return ContentGenerationResult(content, titles, images)

    async def regenerate(self, content_id: str) -> ContentGenerationResult:
        """重新生成内容"""
        async with async_session_maker() as session:
            content = await session.get(Content, content_id)
            if not content:
                raise ValueError(f"Content {content_id} not found")
            account_id = content.account_id
            topic = content.topic
            content_type = "image_text" if content.content_type == ContentType.note else "video"

        return await self.generate(account_id, topic=topic, content_type=content_type)

    async def suggest_topics(self, account_id: str) -> List[str]:
        """AI推荐主题"""
        async with async_session_maker() as session:
            account = await session.get(Account, account_id)
            positioning = {}
            if account and account.positioning:
                positioning = json.loads(account.positioning)

            # 获取近期热门内容
            result = await session.execute(
                select(Content.topic, func.count(Content.id))
                .where(
                    Content.account_id == account_id,
                    Content.created_at >= datetime.utcnow() - timedelta(days=30),
                )
                .group_by(Content.topic)
                .order_by(desc(func.count(Content.id)))
                .limit(5)
            )
            recent_topics = [row[0] for row in result.all() if row[0]]

        prompt = f"""根据以下账号定位，推荐5个适合今天发布的小红书内容主题：

领域：{positioning.get('niche', '生活分享')}
目标受众：{positioning.get('target_audience', '年轻人')}
关键词：{', '.join(positioning.get('keywords', []))}
近期已发主题：{', '.join(recent_topics) if recent_topics else '无'}

请以JSON数组格式返回，例如：["主题1", "主题2", "主题3", "主题4", "主题5"]"""

        ai_response = await self.ai_service.call(prompt=prompt, temperature=0.8, max_tokens=512)
        try:
            topics = self.ai_service.parse_json_response(ai_response)
            if isinstance(topics, list):
                return topics
        except Exception:
            pass
        # 提取主题列表
        import re
        matches = re.findall(r'"([^"]+)"', ai_response)
        return matches[:5] if matches else [positioning.get("niche", "生活分享")]

    async def get_trending(self, category: Optional[str] = None) -> List[Dict[str, Any]]:
        """热点追踪"""
        from app.services.xiaohongshu_browser import XiaohongshuBrowser
        browser = XiaohongshuBrowser()
        try:
            # 搜索热门笔记
            keyword = category or "热门"
            results = await browser.search_notes(keyword)
            return [
                {
                    "title": r.get("title", ""),
                    "likes": r.get("likes", 0),
                    "topic": keyword,
                }
                for r in results[:10]
            ]
        except Exception as e:
            logger.error(f"Failed to get trending: {e}")
            return []

    async def batch_generate(
        self,
        account_id: str,
        topics: List[str],
        count: int = 1,
    ) -> List[ContentGenerationResult]:
        """批量生成"""
        results = []
        for i, topic in enumerate(topics[:count]):
            try:
                result = await self.generate(account_id, topic=topic)
                results.append(result)
                if i < len(topics) - 1:
                    await asyncio.sleep(2)  # 避免请求过快
            except Exception as e:
                logger.error(f"Failed to generate content for topic '{topic}': {e}")
        return results

    def _check_duplicate(
        self,
        title: str,
        body: str,
        existing_contents: List[Content],
    ) -> bool:
        """去重检查（标题相似度>70%,正文重叠>50%）"""
        for existing in existing_contents:
            # 标题相似度
            title_similarity = SequenceMatcher(None, title, existing.title or "").ratio()
            if title_similarity > 0.7:
                return True

            # 正文重叠度
            body_similarity = SequenceMatcher(None, body[:500], (existing.body or "")[:500]).ratio()
            if body_similarity > 0.5:
                return True

        return False

    async def _get_images(
        self, account_id: str, image_prompts: List[str]
    ) -> List[str]:
        """获取配图：素材库匹配→AI生成→参考热门笔记"""
        if not image_prompts:
            return []

        images = []
        for prompt in image_prompts[:6]:  # 最多6张图
            # 优先从素材库查找
            from app.services.material_manager import MaterialManager
            material_mgr = MaterialManager()
            try:
                suggestions = await material_mgr.suggest_materials_by_keyword(account_id, prompt)
                if suggestions:
                    images.append(suggestions[0].file_path)
                    continue
            except Exception:
                pass

            # 暂时使用占位图
            images.append(f"placeholder_{len(images) + 1}.jpg")

        return images

    def _quality_check(self, content_data: Dict[str, Any]) -> Dict[str, Any]:
        """内容质量自检"""
        issues = []
        score = 100

        body = content_data.get("body", "")
        title = content_data.get("best_title", "")

        # 标题检查
        if len(title) < 5:
            issues.append("标题过短")
            score -= 20
        if len(title) > 30:
            issues.append("标题过长")
            score -= 10

        # 正文检查
        if len(body) < 100:
            issues.append("正文内容过少")
            score -= 20
        if len(body) > 2000:
            issues.append("正文可能过长")
            score -= 5

        # 标签检查
        tags = content_data.get("tags", [])
        if len(tags) < 3:
            issues.append("标签数量不足")
            score -= 10

        # Emoji检查
        import emoji
        emoji_count = len([c for c in body if c in emoji.EMOJI_DATA])
        if emoji_count == 0:
            issues.append("缺少emoji")
            score -= 5

        return {
            "passed": score >= 60,
            "score": max(0, score),
            "issues": issues,
        }

    def _build_content_prompt(
        self,
        account: Account,
        positioning: Dict[str, Any],
        topic: str,
        content_type: str,
    ) -> str:
        """构建内容生成提示词"""
        niche = positioning.get("niche", "生活分享")
        style = positioning.get("content_style", "轻松自然")
        tone = positioning.get("tone", "亲切随和")
        keywords = positioning.get("keywords", [])

        return f"""请为以下小红书账号生成一篇优质内容：

账号领域：{niche}
内容风格：{style}
语言调性：{tone}
关键词：{', '.join(keywords)}
今日主题：{topic}
内容类型：{"图文笔记" if content_type == "image_text" else "视频笔记"}

要求：
1. 生成5个吸引人的标题（包含emoji）
2. 选择最佳标题作为best_title
3. 生成正文（500-1000字，自然口语化，包含emoji，有个人体验感）
4. 生成8-12个相关标签
5. 生成3-6个配图描述（用于AI生成配图）

请以JSON格式返回：
{{
    "titles": ["标题1", "标题2", "标题3", "标题4", "标题5"],
    "best_title": "最佳标题",
    "body": "正文内容",
    "tags": ["标签1", "标签2"],
    "image_prompts": ["配图描述1", "配图描述2"]
}}"""

    def _load_prompt(self, filename: str) -> str:
        """加载提示词模板"""
        prompt_path = os.path.join(settings.PROMPT_DIR, filename)
        if os.path.exists(prompt_path):
            with open(prompt_path, "r", encoding="utf-8") as f:
                return f.read()
        return "你是一个小红书内容创作专家，擅长创作吸引人的内容。"
