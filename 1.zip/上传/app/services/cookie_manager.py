"""
Cookie自动维护 - 验证/刷新/过期预警
"""
from __future__ import annotations

import json
import os
from datetime import datetime, timedelta
from typing import List, Optional, Dict, Any
from pathlib import Path

from sqlalchemy import select, and_
from sqlalchemy.ext.asyncio import AsyncSession
from loguru import logger

from app.models import Account, CookieMeta
from app.database import get_db_session

DATA_DIR = Path("data")
ACCOUNTS_DIR = DATA_DIR / "accounts"


class CookieManager:
    """Cookie管理器"""

    async def verify_cookie(self, account_id: str) -> bool:
        """验证Cookie有效性（通过浏览器访问小红书检查登录态）"""
        from app.services.xiaohongshu_browser import xiaohongshu_browser
        try:
            context = await xiaohongshu_browser._get_context(account_id)
            page = await context.new_page()
            try:
                await page.goto("https://www.xiaohongshu.com", wait_until="networkidle", timeout=15000)
                # 检查是否有登录态（查看页面元素）
                is_logged_in = False
                try:
                    profile_el = page.locator('[class*="profile"], [class*="avatar"], [class*="user"]').first
                    is_logged_in = await profile_el.is_visible(timeout=3000)
                except Exception:
                    pass

                if is_logged_in:
                    await self._update_meta(account_id, "valid")
                    return True
                else:
                    await self._update_meta(account_id, "expired")
                    return False
            finally:
                await page.close()
        except Exception as e:
            logger.error(f"Cookie验证失败 {account_id}: {e}")
            await self._update_meta(account_id, "invalid")
            return False

    async def daily_check(self):
        """每日检查所有online账号Cookie（定时任务6:00调用）"""
        async for db in get_db_session():
            try:
                stmt = select(Account).where(Account.status == "online")
                result = await db.execute(stmt)
                accounts = result.scalars().all()

                for account in accounts:
                    valid = await self.verify_cookie(account.id)
                    if not valid:
                        account.status = "offline"
                        logger.warning(f"Cookie已过期: {account.nickname}")
                    else:
                        await self._check_expiry(db, account.id)

                await db.commit()
            except Exception as e:
                logger.error(f"每日Cookie检查失败: {e}")
                await db.rollback()
            break

    async def get_expiring_cookies(self, db: AsyncSession, days: int = 3) -> List[CookieMeta]:
        """获取即将过期的Cookie"""
        expiry_date = datetime.now() + timedelta(days=days)
        stmt = select(CookieMeta).where(
            CookieMeta.status == "valid",
            CookieMeta.expires_at <= expiry_date,
            CookieMeta.expires_at > datetime.now(),
        )
        result = await db.execute(stmt)
        return list(result.scalars().all())

    async def _update_meta(self, account_id: str, status: str):
        """更新Cookie元数据"""
        async for db in get_db_session():
            meta = await db.get(CookieMeta, account_id)
            if meta:
                meta.status = status
                meta.last_verified = datetime.now()
            else:
                meta = CookieMeta(
                    account_id=account_id,
                    created_at=datetime.now(),
                    expires_at=datetime.now() + timedelta(days=30),
                    last_verified=datetime.now(),
                    status=status,
                )
                db.add(meta)
            await db.commit()
            break

    async def _check_expiry(self, db: AsyncSession, account_id: str):
        """检查Cookie是否即将过期"""
        meta = await db.get(CookieMeta, account_id)
        if meta and meta.expires_at:
            days_left = (meta.expires_at - datetime.now()).days
            if days_left <= 3 and not meta.warning_sent:
                logger.warning(f"Cookie将在{days_left}天后过期: {account_id}")
                meta.warning_sent = True
                await db.commit()

    async def save_cookie_from_login(self, account_id: str, cookies: list):
        """从登录成功的Cookie保存到加密文件"""
        from app.core.encryption import encrypt

        account_dir = ACCOUNTS_DIR / account_id
        account_dir.mkdir(parents=True, exist_ok=True)
        cookie_path = account_dir / "cookies.enc"

        cookie_json = json.dumps(cookies, ensure_ascii=False)
        encrypted = encrypt(cookie_json)

        with open(cookie_path, "w", encoding="utf-8") as f:
            f.write(encrypted)

        # 更新数据库
        async for db in get_db_session():
            account = await db.get(Account, account_id)
            if account:
                account.cookie_path = str(cookie_path)
                account.status = "online"

            meta = await db.get(CookieMeta, account_id)
            if meta:
                meta.created_at = datetime.now()
                meta.expires_at = datetime.now() + timedelta(days=30)
                meta.last_verified = datetime.now()
                meta.refresh_count += 1
                meta.status = "valid"
                meta.warning_sent = False
            else:
                meta = CookieMeta(
                    account_id=account_id,
                    created_at=datetime.now(),
                    expires_at=datetime.now() + timedelta(days=30),
                    last_verified=datetime.now(),
                    status="valid",
                )
                db.add(meta)
            await db.commit()
            break

        logger.info(f"Cookie已保存: {account_id}")


cookie_manager = CookieManager()
