"""每日AI复盘"""

import uuid
import json
from datetime import datetime, timedelta
from typing import Dict, Any, Optional, List

from loguru import logger
from sqlalchemy import select, func, desc, and_

from app.core.config import settings
from app.database import async_session_maker
from app.models.account import Account, AccountStatus
from app.models.content import Content, ContentStatus
from app.models.daily_stat import DailyStat
from app.models.daily_review import DailyReview
from app.models.strategy_override import StrategyOverride
from app.models.task import Task, TaskStatus
from app.services.ai_service import AIService


class DailyReviewService:
    """每日AI复盘"""

    def __init__(self):
        self.ai_service = AIService()

    async def review_account(self, account_id: str) -> Dict[str, Any]:
        """账号每日复盘

        Step1: 收集今日数据
        Step2: 获取昨天复盘结果
        Step3: 调用AI深度分析
        Step4: AI输出策略调整
        Step5: 生成复盘报告
        Step6: 推送通知
        """
        today = datetime.utcnow().strftime("%Y-%m-%d")
        yesterday = (datetime.utcnow() - timedelta(days=1)).strftime("%Y-%m-%d")

        # Step1: 收集今日数据
        today_data = await self._collect_today_data(account_id, today)

        # Step2: 获取昨天复盘
        async with async_session_maker() as session:
            result = await session.execute(
                select(DailyReview).where(
                    DailyReview.account_id == account_id,
                    DailyReview.review_date == yesterday,
                )
            )
            yesterday_review = result.scalar_one_or_none()
            if yesterday_review:
                yesterday_data = {
                    "summary": yesterday_review.today_summary,
                    "score": yesterday_review.today_score,
                    "highlights": json.loads(yesterday_review.highlights or "[]"),
                    "issues": json.loads(yesterday_review.issues or "[]"),
                }
            else:
                yesterday_data = None

        # Step3: AI深度分析
        prompt = self._build_review_prompt(account_id, today_data, yesterday_data)
        system_prompt = self._load_prompt("daily_review.txt")

        try:
            ai_response = await self.ai_service.call(
                prompt=prompt,
                system_prompt=system_prompt,
                temperature=0.5,
                max_tokens=3072,
            )
            review_data = self.ai_service.parse_json_response(ai_response)
        except Exception as e:
            logger.error(f"AI review failed for {account_id}: {e}")
            review_data = {
                "summary": "复盘分析暂时不可用",
                "highlights": [],
                "issues": [],
                "recommendations": [],
                "strategy_adjustments": {},
            }

        # Step4: 策略调整写入
        strategy_adjustments = review_data.get("strategy_adjustments", {})
        if strategy_adjustments:
            async with async_session_maker() as session:
                override = StrategyOverride(
                    id=str(uuid.uuid4()),
                    account_id=account_id,
                    target_date=datetime.strptime(today, "%Y-%m-%d").date(),
                    content_directions=json.dumps(strategy_adjustments.get("content_directions", []), ensure_ascii=False),
                    schedule_adjustments=json.dumps(strategy_adjustments.get("schedule_adjustments", []), ensure_ascii=False),
                    intensity_adjustments=json.dumps(strategy_adjustments.get("intensity_adjustments", []), ensure_ascii=False),
                    created_at=datetime.utcnow(),
                )
                session.add(override)
                await session.commit()

        # Step5: 生成复盘报告
        async with async_session_maker() as session:
            review = DailyReview(
                id=str(uuid.uuid4()),
                account_id=account_id,
                review_date=datetime.strptime(today, "%Y-%m-%d").date(),
                today_score=review_data.get("overall_score", 0),
                today_summary=review_data.get("summary", ""),
                highlights=json.dumps(review_data.get("highlights", []), ensure_ascii=False),
                issues=json.dumps(review_data.get("issues", []), ensure_ascii=False),
                strategy_updates=json.dumps(review_data.get("recommendations", []), ensure_ascii=False),
                created_at=datetime.utcnow(),
            )
            session.add(review)
            await session.commit()
            await session.refresh(review)

        # Step6: 推送WebSocket通知
        await self._push_notification(account_id, review_data)

        logger.info(f"Daily review completed for account {account_id}")
        return {
            "account_id": account_id,
            "date": today,
            "review_data": review_data,
            "today_data": today_data,
        }

    async def review_all_active(self):
        """为所有活跃账号执行复盘"""
        async with async_session_maker() as session:
            result = await session.execute(
                select(Account).where(
                    Account.status.in_([
                        AccountStatus.running,
                        AccountStatus.online,
                    ])
                )
            )
            accounts = result.scalars().all()

        for account in accounts:
            try:
                await self.review_account(str(account.id))
            except Exception as e:
                logger.error(f"Failed to review account {account.id}: {e}")

    async def _collect_today_data(
        self, account_id: str, date: str
    ) -> Dict[str, Any]:
        """收集今日数据"""
        async with async_session_maker() as session:
            # 操作统计
            result = await session.execute(
                select(func.count(Task.id)).where(
                    Task.account_id == account_id,
                    Task.status == TaskStatus.COMPLETED,
                    Task.created_at >= datetime.strptime(date, "%Y-%m-%d"),
                )
            )
            tasks_completed = result.scalar()

            # 发布内容数据
            result = await session.execute(
                select(Content).where(
                    Content.account_id == account_id,
                    Content.publish_time >= datetime.strptime(date, "%Y-%m-%d"),
                )
            )
            published_contents = result.scalars().all()

            content_stats = []
            total_views = 0
            total_likes = 0
            total_collects = 0
            total_comments = 0
            for content in published_contents:
                stats = {
                    "id": str(content.id),
                    "title": content.title,
                    "views": content.views or 0,
                    "likes": content.likes or 0,
                    "collects": content.collects or 0,
                    "comments": content.comments_count or 0,
                }
                content_stats.append(stats)
                total_views += stats["views"]
                total_likes += stats["likes"]
                total_collects += stats["collects"]
                total_comments += stats["comments"]

            # 账号数据
            account = await session.get(Account, account_id)
            account_data = {
                "followers": account.followers or 0,
                "following": account.following or 0,
                "notes": account.notes_count or 0,
                "today_actions": account.today_actions or 0,
            }

            # 每日统计
            today_date = datetime.strptime(date, "%Y-%m-%d").date()
            result = await session.execute(
                select(DailyStat).where(
                    DailyStat.account_id == account_id,
                    DailyStat.date == today_date,
                )
            )
            daily_stats = result.scalars().all()
            follower_change = 0
            for stat in daily_stats:
                follower_change += stat.followers_gain or 0

            return {
                "date": date,
                "tasks_completed": tasks_completed,
                "published_count": len(published_contents),
                "content_stats": content_stats,
                "total_views": total_views,
                "total_likes": total_likes,
                "total_collects": total_collects,
                "total_comments": total_comments,
                "follower_change": follower_change,
                "account": account_data,
                "engagement_rate": (
                    (total_likes + total_comments) / max(total_views, 1)
                ),
            }

    def _build_review_prompt(
        self,
        account_id: str,
        today_data: Dict[str, Any],
        yesterday_data: Optional[Dict[str, Any]],
    ) -> str:
        """构建复盘提示词"""
        content_summary = "\n".join([
            f"  - {c['title']}: 阅读{c['views']} 点赞{c['likes']} 收藏{c['collects']} 评论{c['comments']}"
            for c in today_data.get("content_stats", [])
        ]) or "  今日未发布内容"

        yesterday_summary = "无昨日数据"
        if yesterday_data:
            ai_yesterday = yesterday_data.get("ai_analysis", {})
            yesterday_summary = f"""
- 昨日总结：{ai_yesterday.get('summary', '无')}
- 昨日评分：{ai_yesterday.get('overall_score', '无')}
- 昨日建议：{', '.join(ai_yesterday.get('recommendations', []))}"""

        return f"""请对以下小红书运营数据进行深度复盘分析：

今日数据：
- 完成任务数：{today_data['tasks_completed']}
- 发布内容数：{today_data['published_count']}
- 内容表现：
{content_summary}
- 总阅读：{today_data['total_views']}
- 总点赞：{today_data['total_likes']}
- 总收藏：{today_data['total_collects']}
- 总评论：{today_data['total_comments']}
- 粉丝变化：{today_data['follower_change']}
- 互动率：{today_data['engagement_rate']:.2%}
- 今日操作数：{today_data['account']['today_actions']}

昨日复盘对比：
{yesterday_summary}

请以JSON格式返回：
{{
    "overall_score": 0-100,
    "summary": "今日运营总结",
    "highlights": ["亮点1", "亮点2"],
    "issues": ["问题1", "问题2"],
    "best_content": "表现最好的内容标题",
    "worst_content": "表现最差的内容标题",
    "time_analysis": "时段分析",
    "intensity_analysis": "操作强度分析",
    "yesterday_comparison": "与昨日对比分析",
    "recommendations": ["建议1", "建议2", "建议3"],
    "strategy_adjustments": {{
        "content_focus": "内容方向调整",
        "timing_adjust": "时段调整",
        "intensity_change": 1.0
    }}
}}"""

    async def _push_notification(
        self, account_id: str, review_data: Dict[str, Any]
    ):
        """推送WebSocket通知"""
        try:
            from app.api.ws import manager
            await manager.broadcast("daily_review", {
                "account_id": account_id,
                "score": review_data.get("overall_score", 0),
                "summary": review_data.get("summary", ""),
                "timestamp": datetime.utcnow().isoformat(),
            })
        except Exception as e:
            logger.debug(f"WebSocket notification failed: {e}")

    def _load_prompt(self, filename: str) -> str:
        """加载提示词模板"""
        import os
        prompt_path = os.path.join(settings.PROMPT_DIR, filename)
        if os.path.exists(prompt_path):
            with open(prompt_path, "r", encoding="utf-8") as f:
                return f.read()
        return "你是一个小红书运营数据分析专家，请对运营数据进行深度复盘分析。"
