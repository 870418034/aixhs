"""仪表盘数据聚合服务。"""

from __future__ import annotations

from datetime import datetime, timedelta
from typing import Any, Dict, List, Optional

from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.models import Account, AccountStatus, Content, DailyStat, Task, TaskStatus


class DashboardService:
    """仪表盘数据聚合：概览、趋势、对比、内容表现、粉丝分析。"""

    async def get_overview(self, db: AsyncSession) -> Dict[str, Any]:
        total_accounts = (await db.execute(select(func.count()).select_from(Account))).scalar() or 0
        online_accounts = (await db.execute(
            select(func.count()).where(Account.status == AccountStatus.online)
        )).scalar() or 0
        running_accounts = (await db.execute(
            select(func.count()).where(Account.operation_stage == "running")
        )).scalar() or 0

        total_contents = (await db.execute(select(func.count()).select_from(Content))).scalar() or 0
        published_contents = (await db.execute(
            select(func.count()).where(Content.status == "published")
        )).scalar() or 0

        total_tasks = (await db.execute(select(func.count()).select_from(Task))).scalar() or 0
        running_tasks = (await db.execute(
            select(func.count()).where(Task.status == TaskStatus.running)
        )).scalar() or 0

        total_followers = (await db.execute(select(func.sum(Account.followers)))).scalar() or 0
        total_likes = (await db.execute(select(func.sum(Account.likes)))).scalar() or 0
        total_notes = (await db.execute(select(func.sum(Account.notes_count)))).scalar() or 0

        return {
            "accounts": {
                "total": total_accounts, "online": online_accounts,
                "running": running_accounts,
            },
            "contents": {
                "total": total_contents, "published": published_contents,
                "draft": total_contents - published_contents,
            },
            "tasks": {
                "total": total_tasks, "running": running_tasks,
                "pending": total_tasks - running_tasks,
            },
            "followers": {"total": total_followers, "growth_today": 0},
            "engagement": {
                "total_likes": total_likes, "total_notes": total_notes,
                "avg_engagement_rate": 0.0,
            },
            "ai_usage": {"total_tokens": 0, "total_cost": 0.0},
            "system": {"status": "healthy", "uptime_hours": 0},
        }

    async def get_trends(self, db: AsyncSession, days: int = 30) -> Dict[str, Any]:
        end_date = datetime.now().date()
        start_date = end_date - timedelta(days=days)
        query = (
            select(DailyStat)
            .where(DailyStat.date >= str(start_date))
            .order_by(DailyStat.date.asc())
        )
        rows = (await db.execute(query)).scalars().all()
        dates = list({r.date for r in rows})
        dates.sort()
        return {
            "dates": dates,
            "followers": [sum(r.followers for r in rows if r.date == d) for d in dates],
            "likes": [sum(r.likes for r in rows if r.date == d) for d in dates],
            "views": [sum(r.views for r in rows if r.date == d) for d in dates],
        }

    async def get_account_comparison(self, db: AsyncSession) -> List[Dict[str, Any]]:
        rows = (await db.execute(select(Account).order_by(Account.followers.desc()).limit(10))).scalars().all()
        return [
            {
                "id": a.id, "nickname": a.nickname, "followers": a.followers,
                "likes": a.likes, "notes_count": a.notes_count,
                "status": a.status,
            }
            for a in rows
        ]

    async def get_content_performance(self, db: AsyncSession) -> List[Dict[str, Any]]:
        query = (
            select(Content)
            .where(Content.status == "published")
            .order_by(Content.views.desc())
            .limit(10)
        )
        rows = (await db.execute(query)).scalars().all()
        return [
            {
                "id": c.id, "title": c.title, "views": c.views,
                "likes": c.likes, "comments": c.comments_count, "collects": c.collects,
            }
            for c in rows
        ]

    async def get_follower_analysis(self, db: AsyncSession) -> Dict[str, Any]:
        accounts = (await db.execute(select(Account))).scalars().all()
        return {
            "total": sum(a.followers for a in accounts),
            "by_account": [
                {"id": a.id, "nickname": a.nickname, "followers": a.followers}
                for a in accounts
            ],
            "growth_7d": 0,
            "growth_30d": 0,
        }

    async def get_today_review(self, db: AsyncSession, account_id: Optional[int] = None) -> Dict[str, Any]:
        today = datetime.now().strftime("%Y-%m-%d")
        query = select(DailyStat).where(DailyStat.date == today)
        if account_id:
            query = query.where(DailyStat.account_id == account_id)
        rows = (await db.execute(query)).scalars().all()
        return {
            "date": today,
            "stats": [
                {
                    "account_id": r.account_id, "followers": r.followers,
                    "followers_gain": r.followers_gain, "views": r.views,
                    "likes": r.likes, "engagement_rate": r.engagement_rate,
                }
                for r in rows
            ],
        }


dashboard_service = DashboardService()
