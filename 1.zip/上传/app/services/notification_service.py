"""通知/预警服务。"""

from __future__ import annotations

from typing import Any, Dict, List, Optional

from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.models import Notification


class NotificationService:
    """通知 CRUD + 未读计数。"""

    async def list_notifications(
        self, db: AsyncSession, page: int = 1, size: int = 20,
    ) -> Dict[str, Any]:
        query = select(Notification)
        total = (await db.execute(select(func.count()).select_from(query.subquery()))).scalar() or 0
        query = query.order_by(Notification.created_at.desc()).offset((page - 1) * size).limit(size)
        rows = (await db.execute(query)).scalars().all()
        items = [
            {
                "id": n.id, "title": n.title, "message": n.message,
                "level": n.level, "is_read": n.is_read,
                "created_at": str(n.created_at),
            }
            for n in rows
        ]
        return {"items": items, "total": total, "page": page, "page_size": size}

    async def mark_read(self, db: AsyncSession, notification_id: int) -> bool:
        n = await db.get(Notification, notification_id)
        if not n:
            return False
        n.is_read = True
        await db.flush()
        return True

    async def mark_all_read(self, db: AsyncSession) -> int:
        rows = (await db.execute(select(Notification).where(Notification.is_read == False))).scalars().all()
        for n in rows:
            n.is_read = True
        await db.flush()
        return len(rows)

    async def delete_notification(self, db: AsyncSession, notification_id: int) -> bool:
        n = await db.get(Notification, notification_id)
        if not n:
            return False
        await db.delete(n)
        await db.flush()
        return True

    async def get_unread_count(self, db: AsyncSession) -> int:
        count = (await db.execute(
            select(func.count()).where(Notification.is_read == False)
        )).scalar() or 0
        return count


notification_service = NotificationService()
