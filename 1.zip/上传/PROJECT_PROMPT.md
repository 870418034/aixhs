# 小红书AI全自动运营平台 - 完整项目生成提示词 v3 (最终版)

> **版本: v3 Final | 本文件为唯一权威源，替代所有之前的版本。**
> **总计: ~85个文件，~18000行代码，23个章节，完整可运行。**

---

## 项目概述

请生成一个完整的、可直接运行的 **小红书AI全自动运营平台** 项目。
技术栈：Python后端（FastAPI）+ 现代化前端（单页应用，CDN引入ECharts，无需Node.js构建）。
目标平台：Windows桌面端，通过浏览器访问管理界面。

**核心卖点：用户只需导入账号（扫码/Cookie）+ 一键开启，AI全自动完成从定位→养号→内容生成→发布→数据回收的完整闭环。**

---

## 一、技术栈 & 目录结构

### 1.1 技术栈

| 层级 | 技术 | 说明 |
|------|------|------|
| 后端框架 | FastAPI 0.115+ | 异步高性能 |
| ASGI服务器 | Uvicorn | 支持WebSocket |
| 前端 | HTML + CSS + 原生JS | SPA路由，CDN引入ECharts |
| 数据库 | SQLite + SQLAlchemy 2.0 | 单文件，WAL模式 |
| 浏览器自动化 | Playwright | Chromium内核 |
| 任务调度 | APScheduler 3.10 | 后台定时任务 |
| AI集成 | OpenAI SDK | 兼容所有OpenAI-compatible API |
| 实时通信 | WebSocket | 状态推送 + 断线重连 + 消息历史 |
| 日志 | Loguru | 结构化日志 + 轮转 |
| 加密 | cryptography (Fernet) | Cookie/APIKey加密存储 |
| 敏感词 | pyahocorasick | 多模式匹配（纯Python，跨平台） |
| 中文分词 | jieba | 敏感词变体检测 |
| Excel | openpyxl | 数据导出 |
| 图片处理 | Pillow | 图片检查/缩略图/裁剪 |

### 1.2 项目目录结构（最终版）

```
xiaohongshu-ai-platform/
├── main.py                                    # 启动入口：lifespan管理+启动序列+优雅关闭
├── requirements.txt                           # 所有依赖（固定版本）
├── config.yaml                                # 全局配置
├── config.example.yaml                        # 配置模板（首次运行自动复制）
├── start.bat                                  # Windows一键启动（含环境检查）
├── README.md
├── pyproject.toml                             # 项目元数据
│
├── app/
│   ├── __init__.py
│   ├── main.py                                # FastAPI app创建+中间件+路由注册+静态文件
│   ├── config.py                              # Pydantic Settings，读取config.yaml+校验
│   ├── database.py                            # 引擎创建+WAL配置+Session工厂+迁移检查
│   ├── models.py                              # 所有17个SQLAlchemy模型（最终版，唯一权威）
│   ├── schemas.py                             # 所有Pydantic请求/响应模型
│   │
│   ├── api/                                   # 路由层（参数校验→调service→返回统一格式）
│   │   ├── __init__.py
│   │   ├── accounts.py                        # 账号CRUD+登录+运营控制+分析+优化+批量
│   │   ├── content.py                         # 内容生成/编辑/发布/调度/重生成/版本管理
│   │   ├── tasks.py                           # 任务列表/详情/取消/重试/批量/统计
│   │   ├── ai.py                              # AI配置CRUD+测试+提示词管理+用量统计
│   │   ├── dashboard.py                       # 仪表盘聚合数据（概览/趋势/对比/内容表现）
│   │   ├── settings.py                        # 系统设置+备份恢复+日志查询+系统状态
│   │   ├── ws.py                              # WebSocket端点+连接管理+消息广播
│   │   ├── materials.py                       # 素材库上传/列表/删除/AI打标签/推荐匹配
│   │   ├── alerts.py                          # 预警通知列表/已读/删除/未读数
│   │   ├── reports.py                         # 运营报告列表/详情/手动生成/下载
│   │   ├── reviews.py                         # 🆕 复盘历史/详情/手动触发/最新复盘
│   │   └── export.py                          # 数据导出（账号统计/内容数据/操作日志）
│   │
│   ├── services/                              # 业务逻辑层
│   │   ├── __init__.py
│   │   ├── ai_service.py                      # LLM调用封装（三层容错：重试→熔断→降级+Token预算）
│   │   ├── account_service.py                 # 账号增删改查+登录态管理+级联删除
│   │   ├── account_analyzer.py                # 账号分析→AI生成报告→自动触发定位
│   │   ├── account_positioner.py              # 空账号定位→AI生成策略+运营计划
│   │   ├── profile_optimizer.py               # 资料自动修改（昵称/简介/头像）
│   │   ├── content_generator.py               # AI内容生成（标题+正文+标签+去重+配图处理）
│   │   ├── content_publisher.py               # 浏览器自动发布+定时发布调度
│   │   ├── account_nurturer.py                # 养号执行引擎（7天计划+日常运营）
│   │   ├── data_collector.py                  # 已发布内容数据回采
│   │   ├── strategy_engine.py                 # 运营策略生成+每日计划+任务依赖管理
│   │   ├── daily_review_service.py             # 🆕 每日AI复盘+策略自适应调整
│   │   ├── scheduler_service.py               # APScheduler封装+定时任务注册
│   │   ├── xiaohongshu_browser.py             # Playwright操作小红书（核心浏览器操作）
│   │   ├── content_safety.py                  # 内容安全审核主服务（pipeline调度）
│   │   ├── rule_engine.py                     # 规则引擎（敏感词+正则+格式检查）
│   │   ├── ai_content_review.py               # AI内容审核（语义+去AI化处理）
│   │   ├── task_executor.py                   # 任务执行引擎（依赖检查+并发锁+超时+重试）
│   │   ├── cookie_manager.py                  # Cookie自动维护（验证/刷新/过期预警）
│   │   ├── interaction_manager.py             # 自动回复评论互动
│   │   ├── alert_system.py                    # 智能预警系统（涨粉/爆文/风控/运营预警）
│   │   ├── report_generator.py                # 运营报告自动生成（周报/月报）
│   │   ├── image_safety.py                    # 图片安全检查（清晰度/水印/尺寸/内容）
│   │   ├── material_manager.py                # 素材库管理（上传/分类/AI标签/匹配推荐）
│   │   ├── ab_test.py                         # A/B标题测试
│   │   ├── competitor_monitor.py              # 竞品账号监控+分析
│   │   ├── content_continuum.py               # 内容自动续航（库存不足自动补充）
│   │   ├── weekly_planner.py                  # 一键生成本周运营计划
│   │   └── system_service.py                  # 系统服务（备份恢复/数据清理/VACUUM/安全巡检）
│   │
│   ├── core/                                  # 基础设施
│   │   ├── __init__.py
│   │   ├── browser_pool.py                    # 多账号浏览器实例池（LRU淘汰+Context隔离）
│   │   ├── fingerprint_spoof.py               # 浏览器指纹伪装（UA/WebGL/Canvas/Audio/Screen/时区）
│   │   ├── behavior_simulator.py              # 人类行为模拟（鼠标轨迹/滚动/打字/延迟）
│   │   ├── anti_ban.py                        # 防封总控制器（协调指纹+行为+频率+风控）
│   │   ├── risk_monitor.py                    # 实时风控监控（页面扫描/信号检测/自动响应）
│   │   ├── captcha_detector.py                # 验证码检测与处理（滑块轨迹生成）
│   │   ├── rate_limiter.py                    # 滑动窗口频率限制+每日上限+延迟矩阵+时间段权重
│   │   ├── encryption.py                      # Fernet对称加密（Cookie/APIKey）
│   │   ├── exceptions.py                      # 自定义异常体系（全部BusinessError子类）
│   │   ├── cache.py                           # 内存缓存（TTL+LRU+装饰器）
│   │   ├── sensitive_words.py                 # 敏感词库管理（Aho-Corasick自动机）
│   │   ├── logger.py                          # Loguru配置（轮转+分级+文件+控制台）
│   │   └── diagnostics.py                     # 🆕 启动自检+运行时诊断+错误定位
│   │
│   └── static/                                # 前端资源
│       ├── index.html                         # SPA主页面（含全部11个<template>）
│       ├── css/
│       │   ├── variables.css                  # CSS变量（含深色模式）
│       │   ├── base.css                       # 重置+基础样式
│       │   ├── layout.css                     # 侧边栏(可折叠)+顶栏+主内容区
│       │   ├── components.css                 # 按钮/卡片/表单/表格/模态框/Toast/骨架屏/进度条/空状态
│       │   ├── dashboard.css                  # 仪表盘专用（统计卡片/图表/时间线/热力图/库存条）
│       │   ├── accounts.css                   # 账号管理专用（卡片网格/详情抽屉/登录模态框）
│       │   ├── content.css                    # 内容管理专用（表格/AI生成器/预览/日历/版本历史）
│       │   └── tasks.css                      # 任务中心专用（看板列/任务卡片/详情面板）
│       ├── js/
│       │   ├── app.js                         # SPA路由+全局状态Store+WebSocket管理+快捷键+深色模式
│       │   ├── api.js                         # fetch封装（统一错误处理+超时+Toast+429处理）
│       │   ├── utils.js                       # 日期格式化/中文数字缩写/防抖节流/复制/颜色工具
│       │   ├── components.js                  # Toast/Modal/Confirm/Loading/DataTable/Skeleton/EmptyState/Progress
│       │   ├── dashboard.js                   # 仪表盘（8个区域全部渲染+ECharts图表+WebSocket实时更新）
│       │   ├── accounts.js                    # 账号管理（卡片列表/搜索筛选/扫码+Cookie登录/详情抽屉5个Tab）
│       │   ├── content.js                     # 内容管理（表格/AI生成器3种模式/结果预览/编辑/发布/版本历史）
│       │   ├── tasks.js                       # 任务中心（看板4列/列表视图/详情/批量操作/进度实时更新）
│       │   ├── ai-settings.js                 # AI配置（模型CRUD/测试连接/提示词编辑器/用量统计图表）
│       │   ├── materials.js                   # 素材库（网格/拖拽上传/分类/AI标签/详情/使用统计）
│       │   ├── reports.js                     # 运营报告（列表/详情/生成/导出PDF）
│       │   ├── settings.js                    # 系统设置（运营参数/强度选择/反检测/代理/数据管理）
│       │   ├── logs.js                        # 运行日志（表格/筛选/分页/搜索/导出）
│       │   └── alerts.js                      # 通知面板（实时推送/列表/已读/删除）
│       └── img/
│           └── logo.svg
│
├── prompts/                                   # AI提示词模板（11个文件）
│   ├── account_analysis.txt
│   ├── account_positioning.txt
│   ├── profile_optimization.txt
│   ├── content_strategy.txt
│   ├── content_generation.txt
│   ├── title_generation.txt
│   ├── comment_generation.txt
│   ├── nurturing_strategy.txt
│   ├── trending_analysis.txt
│   ├── safety_check.txt
│   └── daily_review.txt                       # 🆕 每日复盘分析
│
├── data/                                      # 运行时数据（自动创建）
│   ├── app.db                                 # SQLite数据库（WAL模式）
│   ├── encryption.key                         # Fernet密钥（首次运行自动生成）
│   ├── accounts/{id}/                         # 每账号独立目录
│   │   ├── cookies.enc                        # 加密Cookie
│   │   ├── fingerprint.json                   # 浏览器指纹参数
│   │   ├── cookie_meta.json                   # Cookie元数据
│   │   ├── positioning.json                   # 账号定位方案
│   │   └── generated/{date}/                  # 每日生成内容备份
│   ├── materials/images/                      # 素材库
│   ├── safety/                                # 安全词库
│   │   ├── sensitive_words.txt                # 系统敏感词库
│   │   └── custom_words.txt                   # 用户自定义词库
│   ├── logs/                                  # 日志（按日期轮转）
│   │   └── screenshots/                       # 异常截图
│   ├── backups/                               # 备份文件
│   └── temp/                                  # 临时文件（每日清理）
│
└── tests/                                     # 测试
    ├── conftest.py                            # pytest fixtures
    ├── test_rule_engine.py                    # 规则引擎测试（最重要）
    ├── test_rate_limiter.py                   # 频率限制测试
    ├── test_anti_ban.py                       # 防封测试
    ├── test_content_safety.py                 # 内容安全测试
    ├── test_api_accounts.py                   # 账号API测试
    ├── test_api_content.py                    # 内容API测试
    ├── test_task_executor.py                  # 任务执行器测试
    └── test_e2e_workflow.py                   # E2E工作流测试
```

---

## 二、数据库模型（最终版，唯一权威定义）

> **⚠️ 本节为所有模型的唯一定义。禁止在其他章节重复定义或修改模型。所有字段、类型、默认值、约束以本节为准。**

### 2.1 账号表（accounts）

```python
class Account(Base):
    __tablename__ = "accounts"

    id = Column(String(36), primary_key=True, default=uuid4_str)
    # 基本信息（从网页抓取）
    nickname = Column(String(100), default="")
    xhs_id = Column(String(50), default="")
    avatar_url = Column(Text, default="")
    bio = Column(Text, default="")
    gender = Column(Integer, default=0)          # 0未知 1男 2女
    ip_location = Column(String(50), default="")
    # 数据指标（定期刷新）
    followers = Column(Integer, default=0)
    following = Column(Integer, default=0)
    likes = Column(Integer, default=0)
    notes_count = Column(Integer, default=0)
    # 运营状态
    account_type = Column(String(20), default="unknown")  # unknown/new/nurturing/active/growing/mature
    positioning = Column(Text, default="{}")     # JSON: {category, persona, audience, ...}
    operation_stage = Column(String(20), default="idle")  # idle/analyzing/positioning/preparing/nurturing/active/paused
    nurturing_day = Column(Integer, default=0)   # 当前养号第几天
    nurturing_total_days = Column(Integer, default=7)
    # 登录相关（status只反映与小红书平台的连接状态）
    status = Column(String(20), default="offline")  # offline/online/verifying/banned
    login_method = Column(String(20), default="")   # qr/cookie
    cookie_path = Column(String(255), default="")
    proxy = Column(String(200), default="")
    user_agent = Column(Text, default="")        # 该账号绑定的UA
    # 统计
    total_published = Column(Integer, default=0)
    today_actions = Column(Integer, default=0)   # 今日操作次数（每日重置）
    # 风控字段
    health_score = Column(Integer, default=100)           # 账号健康度 0-100
    fingerprint = Column(Text, default="{}")              # 绑定的指纹参数JSON
    risk_history = Column(Text, default="[]")             # 风控事件历史JSON
    captcha_count_today = Column(Integer, default=0)      # 今日验证码触发次数
    last_captcha_at = Column(DateTime, nullable=True)     # 最后一次验证码时间
    banned_reason = Column(Text, default="")              # 封号原因
    # 备注
    note = Column(Text, default="")                       # 用户备注
    # 时间戳
    created_at = Column(DateTime, default=func.now())
    updated_at = Column(DateTime, default=func.now(), onupdate=func.now())
    last_active_at = Column(DateTime, nullable=True)
    last_data_refresh = Column(DateTime, nullable=True)

    # 关系
    contents = relationship("Content", back_populates="account", cascade="all, delete-orphan")
    tasks = relationship("Task", back_populates="account", cascade="all, delete-orphan")
    daily_stats = relationship("DailyStat", back_populates="account", cascade="all, delete-orphan")
    competitors = relationship("CompetitorAccount", back_populates="account", cascade="all, delete-orphan")
    cookie_meta = relationship("CookieMeta", back_populates="account", uselist=False, cascade="all, delete-orphan")
    daily_reviews = relationship("DailyReview", cascade="all, delete-orphan")
    strategy_overrides = relationship("StrategyOverride", cascade="all, delete-orphan")
```

**Account.status 状态机（仅反映与小红书平台的连接状态）：**
```
offline → verifying → online → offline（登出/Cookie过期）
                              → banned（检测到封禁，终态）
注意：active/paused 是 operation_stage 的状态，不是 status 的状态。
```

**Account.operation_stage 状态机（运营生命周期阶段）：**
```
idle → analyzing → positioning → preparing → nurturing → active
                                                        ↘ paused → active
analyzing → active（非空账号分析完直接运营）
任何阶段 → paused（手动暂停/健康度过低）
paused → 恢复到之前的阶段
```

### 2.2 内容表（contents）

```python
class Content(Base):
    __tablename__ = "contents"

    id = Column(String(36), primary_key=True, default=uuid4_str)
    account_id = Column(String(36), ForeignKey("accounts.id"), nullable=False)
    # 内容数据
    title = Column(String(200), default="")
    body = Column(Text, default="")
    tags = Column(Text, default="[]")            # JSON数组
    topic = Column(String(100), default="")      # #话题
    images = Column(Text, default="[]")          # JSON: [{path, prompt, source}]
    content_type = Column(String(20), default="image_text")  # image_text/video
    category = Column(String(50), default="")
    # 状态
    status = Column(String(20), default="draft") # draft/generated/safety_passed/safety_blocked/scheduled/publishing/published/removed
    xhs_note_id = Column(String(50), default="")
    xhs_note_url = Column(Text, default="")
    # 发布
    publish_time = Column(DateTime, nullable=True)
    is_scheduled = Column(Boolean, default=False)
    # 数据回收
    views = Column(Integer, default=0)
    likes = Column(Integer, default=0)
    comments_count = Column(Integer, default=0)   # 注意：字段名避免与relationship冲突
    collects = Column(Integer, default=0)
    shares = Column(Integer, default=0)
    last_stats_refresh = Column(DateTime, nullable=True)
    # 元数据
    ai_config_id = Column(String(36), default="")
    ai_prompt_used = Column(Text, default="")
    generation_params = Column(Text, default="{}")
    # 安全审核字段
    safety_score = Column(Float, default=0)              # 安全评分 0-10
    safety_result = Column(Text, default="{}")           # 审核结果JSON
    safety_checked_at = Column(DateTime, nullable=True)  # 审核时间
    original_body = Column(Text, default="")             # 原始正文（去AI化前备份）
    rewrite_count = Column(Integer, default=0)           # 重写次数
    # A/B测试
    title_variants = Column(Text, default="[]")          # JSON: [{title, score, published}]
    # 时间戳
    created_at = Column(DateTime, default=func.now())
    updated_at = Column(DateTime, default=func.now(), onupdate=func.now())

    # 关系
    account = relationship("Account", back_populates="contents")
    versions = relationship("ContentVersion", back_populates="content", order_by="ContentVersion.version")
```

**Content.status 状态机：**
```
draft → generated → safety_passed → scheduled → publishing → published
                    → safety_blocked → (重写→generated)
                                      → (用户编辑→重新审核)
published → removed（被平台删除）
publishing → safety_passed（发布失败，可重试）
任何状态 → draft（用户手动重置）
```

### 2.3 任务表（tasks）

```python
class Task(Base):
    __tablename__ = "tasks"

    id = Column(String(36), primary_key=True, default=uuid4_str)
    account_id = Column(String(36), ForeignKey("accounts.id"), nullable=False)
    # 任务定义
    task_type = Column(String(30), nullable=False)
    # 完整类型枚举:
    # analyze_account     - 账号分析
    # position_account    - 账号定位
    # optimize_profile    - 资料优化
    # optimize_avatar     - 头像生成/上传
    # nurture_browse      - 养号-浏览
    # nurture_like        - 养号-点赞
    # nurture_collect     - 养号-收藏
    # nurture_comment     - 养号-评论
    # nurture_follow      - 养号-关注
    # nurture_share       - 养号-分享
    # generate_content    - 内容生成
    # safety_check        - 内容安全审核
    # publish_content     - 内容发布
    # collect_stats       - 数据回收
    # interact_reply      - 回复互动
    # check_login         - 登录检查
    # refresh_data        - 数据刷新
    # check_competitor    - 竞品数据采集
    # generate_report     - 报告生成
    priority = Column(Integer, default=5)        # 1最高 10最低
    params = Column(Text, default="{}")
    # 执行状态
    status = Column(String(20), default="pending")  # pending/queued/running/paused/completed/failed/cancelled
    progress = Column(Integer, default=0)        # 0-100
    result = Column(Text, default="{}")
    error_msg = Column(Text, default="")
    retry_count = Column(Integer, default=0)
    max_retries = Column(Integer, default=3)
    # 时间
    scheduled_at = Column(DateTime, nullable=True)
    started_at = Column(DateTime, nullable=True)
    completed_at = Column(DateTime, nullable=True)
    created_at = Column(DateTime, default=func.now())

    account = relationship("Account", back_populates="tasks")
```

**Task.status 状态机：**
```
pending → queued → running → completed
                         → failed → pending（重试，延迟）
                                  → cancelled（放弃重试）
                         → paused → pending（用户处理后恢复）
                                  → cancelled
pending → cancelled（用户取消）
```

### 2.4 每日统计表（daily_stats）

```python
class DailyStat(Base):
    __tablename__ = "daily_stats"

    id = Column(String(36), primary_key=True, default=uuid4_str)
    account_id = Column(String(36), ForeignKey("accounts.id"), nullable=False)
    date = Column(Date, nullable=False)
    followers = Column(Integer, default=0)
    following = Column(Integer, default=0)
    likes = Column(Integer, default=0)
    notes_count = Column(Integer, default=0)
    # 当日增量
    followers_gain = Column(Integer, default=0)
    likes_gain = Column(Integer, default=0)
    # 当日操作
    browse_count = Column(Integer, default=0)
    like_count = Column(Integer, default=0)
    collect_count = Column(Integer, default=0)
    comment_count = Column(Integer, default=0)
    follow_count = Column(Integer, default=0)
    publish_count = Column(Integer, default=0)
    # 当日内容表现
    total_views = Column(Integer, default=0)
    total_content_likes = Column(Integer, default=0)
    total_content_collects = Column(Integer, default=0)
    total_content_shares = Column(Integer, default=0)   # 补充：shares字段

    account = relationship("Account", back_populates="daily_stats")
    __table_args__ = (UniqueConstraint('account_id', 'date'),)
```

### 2.5 AI配置表（ai_configs）

```python
class AIConfig(Base):
    __tablename__ = "ai_configs"

    id = Column(String(36), primary_key=True, default=uuid4_str)
    name = Column(String(100), nullable=False)
    provider = Column(String(30), default="custom")  # openai/deepseek/zhipu/moonshot/ollama/custom
    api_key_encrypted = Column(Text, default="")      # Fernet加密
    base_url = Column(String(500), default="")
    model = Column(String(100), default="")
    max_tokens = Column(Integer, default=4096)
    temperature = Column(Float, default=0.7)
    is_default = Column(Boolean, default=False)
    total_requests = Column(Integer, default=0)
    total_tokens = Column(Integer, default=0)
    last_used = Column(DateTime, nullable=True)
    created_at = Column(DateTime, default=func.now())

    token_usage = relationship("TokenUsage", back_populates="ai_config", cascade="all, delete-orphan")
```

### 2.6 操作日志表（activity_logs）

```python
class ActivityLog(Base):
    __tablename__ = "activity_logs"

    id = Column(String(36), primary_key=True, default=uuid4_str)
    account_id = Column(String(36), default="")  # 空=系统级
    level = Column(String(10), default="info")   # info/warning/error
    action = Column(String(50), nullable=False)
    detail = Column(Text, default="")
    extra_data = Column(Text, default="{}")
    created_at = Column(DateTime, default=func.now())
```

### 2.7 系统设置表（system_settings）

```python
class SystemSetting(Base):
    __tablename__ = "system_settings"

    key = Column(String(100), primary_key=True)
    value = Column(Text, default="")
    updated_at = Column(DateTime, default=func.now(), onupdate=func.now())
```

### 2.8 通知表（notifications）

```python
class Notification(Base):
    __tablename__ = "notifications"

    id = Column(String(36), primary_key=True, default=uuid4_str)
    level = Column(String(10), nullable=False)     # info/warning/critical
    title = Column(String(200), nullable=False)
    message = Column(Text, nullable=False)
    account_id = Column(String(36), default="")    # 空=系统级（不设ForeignKey）
    related_type = Column(String(30), default="")  # content/task/account/system
    related_id = Column(String(36), default="")
    action_url = Column(String(200), default="")
    is_read = Column(Boolean, default=False)
    created_at = Column(DateTime, default=func.now())
```

### 2.9 素材表（materials）

```python
class Material(Base):
    __tablename__ = "materials"

    id = Column(String(36), primary_key=True, default=uuid4_str)
    file_path = Column(String(500), nullable=False)
    file_type = Column(String(20), default="image")  # image/video
    thumbnail_path = Column(String(500), default="")
    category = Column(String(50), default="未分类")
    tags = Column(Text, default="[]")
    ai_description = Column(Text, default="")
    usage_count = Column(Integer, default=0)
    width = Column(Integer, default=0)
    height = Column(Integer, default=0)
    file_size = Column(Integer, default=0)
    created_at = Column(DateTime, default=func.now())
```

### 2.10 竞品账号表（competitor_accounts）

```python
class CompetitorAccount(Base):
    __tablename__ = "competitor_accounts"

    id = Column(String(36), primary_key=True, default=uuid4_str)
    account_id = Column(String(36), ForeignKey("accounts.id"), nullable=False)
    competitor_xhs_id = Column(String(50), nullable=False)
    competitor_nickname = Column(String(100), default="")
    avatar_url = Column(Text, default="")
    category = Column(String(50), default="")
    followers = Column(Integer, default=0)
    notes_count = Column(Integer, default=0)
    likes = Column(Integer, default=0)
    latest_notes = Column(Text, default="[]")
    insight = Column(Text, default="{}")
    last_check = Column(DateTime, nullable=True)
    is_auto_discovered = Column(Boolean, default=False)
    created_at = Column(DateTime, default=func.now())

    account = relationship("Account", back_populates="competitors")
```

### 2.11 运营报告表（reports）

```python
class Report(Base):
    __tablename__ = "reports"

    id = Column(String(36), primary_key=True, default=uuid4_str)
    report_type = Column(String(20), nullable=False)  # weekly/monthly/custom
    account_id = Column(String(36), default="")       # 空=全账号汇总（不设ForeignKey）
    period_start = Column(Date, nullable=False)
    period_end = Column(Date, nullable=False)
    summary = Column(Text, default="{}")
    ai_analysis = Column(Text, default="")
    suggestions = Column(Text, default="[]")
    highlights = Column(Text, default="{}")
    file_path = Column(String(500), default="")
    created_at = Column(DateTime, default=func.now())
```

### 2.12 Cookie元数据表（cookie_metas）

```python
class CookieMeta(Base):
    __tablename__ = "cookie_metas"

    account_id = Column(String(36), ForeignKey("accounts.id"), primary_key=True)
    created_at = Column(DateTime, nullable=False)
    expires_at = Column(DateTime, nullable=True)
    last_verified = Column(DateTime, nullable=True)
    refresh_count = Column(Integer, default=0)
    status = Column(String(20), default="valid")     # valid/expired/refreshing/invalid
    warning_sent = Column(Boolean, default=False)

    account = relationship("Account", back_populates="cookie_meta")
```

### 2.13 Token使用记录表（token_usage）

```python
class TokenUsage(Base):
    __tablename__ = "token_usage"

    id = Column(String(36), primary_key=True, default=uuid4_str)
    ai_config_id = Column(String(36), ForeignKey("ai_configs.id"), nullable=False)
    date = Column(Date, nullable=False)
    purpose = Column(String(50), default="")          # analyze/generate/comment/safety
    request_count = Column(Integer, default=0)
    prompt_tokens = Column(Integer, default=0)
    completion_tokens = Column(Integer, default=0)
    total_tokens = Column(Integer, default=0)
    estimated_cost = Column(Float, default=0.0)

    ai_config = relationship("AIConfig", back_populates="token_usage")
    __table_args__ = (UniqueConstraint('ai_config_id', 'date', 'purpose'),)
```

### 2.14 内容版本表（content_versions）

```python
class ContentVersion(Base):
    __tablename__ = "content_versions"

    id = Column(String(36), primary_key=True, default=uuid4_str)
    content_id = Column(String(36), ForeignKey("contents.id"), nullable=False)
    version = Column(Integer, default=1)
    title = Column(String(200))
    body = Column(Text)
    tags = Column(Text)
    change_type = Column(String(20), default="ai_generated")  # ai_generated/user_edited/safety_rewritten
    created_at = Column(DateTime, default=func.now())

    content = relationship("Content", back_populates="versions")
```

### 2.15 A/B测试记录表（ab_test_records）

```python
class ABTestRecord(Base):
    __tablename__ = "ab_test_records"

    id = Column(String(36), primary_key=True, default=uuid4_str)
    account_id = Column(String(36), nullable=False)
    original_content_id = Column(String(36), nullable=False)
    variant_title = Column(String(200), nullable=False)
    variant_content_id = Column(String(36), default="")
    test_status = Column(String(20), default="pending")  # pending/running/completed/winner/loser
    views = Column(Integer, default=0)
    likes = Column(Integer, default=0)
    collects = Column(Integer, default=0)
    score = Column(Float, default=0.0)
    created_at = Column(DateTime, default=func.now())
```

### 2.16 每日复盘记录表（daily_reviews）

```python
class DailyReview(Base):
    """
    每日AI复盘记录
    每个active账号每天一条，记录复盘分析结果和策略调整
    """
    __tablename__ = "daily_reviews"

    id = Column(String(36), primary_key=True, default=uuid4_str)
    account_id = Column(String(36), ForeignKey("accounts.id"), nullable=False)
    review_date = Column(Date, nullable=False)
    # 复盘数据
    today_score = Column(Integer, default=0)                # AI评分 1-10
    today_summary = Column(Text, default="")                # 一句话总结
    highlights = Column(Text, default="[]")                 # JSON: 亮点列表
    issues = Column(Text, default="[]")                     # JSON: 问题列表
    # 今日数据快照
    followers_start = Column(Integer, default=0)            # 今日开始粉丝数
    followers_end = Column(Integer, default=0)              # 今日结束粉丝数
    followers_gain = Column(Integer, default=0)             # 今日涨粉
    content_published = Column(Integer, default=0)          # 今日发布数
    total_views = Column(Integer, default=0)                # 今日内容总阅读
    total_engagement = Column(Integer, default=0)           # 今日内容总互动
    tasks_completed = Column(Integer, default=0)
    tasks_failed = Column(Integer, default=0)
    health_score = Column(Integer, default=100)
    # 策略调整
    strategy_updates = Column(Text, default="{}")           # JSON: 完整策略调整
    tomorrow_tasks = Column(Text, default="[]")             # JSON: 明天建议任务
    # 趋势分析
    trend_analysis = Column(Text, default="{}")             # JSON: 长期趋势判断
    # 是否已应用到明天计划
    applied_to_plan = Column(Boolean, default=False)
    # 时间戳
    created_at = Column(DateTime, default=func.now())

    account = relationship("Account")
    __table_args__ = (UniqueConstraint('account_id', 'review_date'),)
```

### 2.17 策略覆盖表（strategy_overrides）

```python
class StrategyOverride(Base):
    """
    策略覆盖：复盘结果写入此表，明天7:30计划生成时优先使用
    用完即删（或标记已使用）
    """
    __tablename__ = "strategy_overrides"

    id = Column(String(36), primary_key=True, default=uuid4_str)
    account_id = Column(String(36), ForeignKey("accounts.id"), nullable=False)
    target_date = Column(Date, nullable=False)              # 生效日期（明天）
    # 覆盖内容
    content_directions = Column(Text, default="{}")         # JSON: 内容方向调整
    schedule_adjustments = Column(Text, default="{}")       # JSON: 发布时间调整
    intensity_adjustments = Column(Text, default="{}")      # JSON: 操作强度调整
    interaction_adjustments = Column(Text, default="{}")    # JSON: 互动策略调整
    suggested_tasks = Column(Text, default="[]")            # JSON: 建议任务列表
    # 来源
    review_id = Column(String(36), default="")              # 关联的复盘记录
    # 状态
    is_used = Column(Boolean, default=False)
    created_at = Column(DateTime, default=func.now())
    used_at = Column(DateTime, nullable=True)
```

---

## 三、前端页面详细设计

### 3.1 全局布局 & 导航

```
┌──────────────────────────────────────────────────────────────────┐
│  🔴 XHS-AI        搜索...                     🔔 3  ⚙️  ▶ 运行中  │
├──────────┬───────────────────────────────────────────────────────┤
│          │                                                       │
│ 📊 仪表盘  │  ← 当前选中高亮（左侧红色竖条 + 红色文字）             │
│ 📱 账号管理 │                                                       │
│ ✍️ 内容管理 │         主内容区域                                    │
│ 📅 内容日历 │         (路由切换，无刷新)                             │
│ 📋 任务中心 │                                                       │
│ ────────  │                                                       │
│ 🤖 AI 配置  │                                                       │
│ 🖼️ 素材库   │                                                       │
│ 📈 运营报告 │                                                       │
│ ────────  │                                                       │
│ ⚙️ 系统设置 │                                                       │
│ 📜 运行日志 │                                                       │
│          │                                                       │
│ ────────  │                                                       │
│ ● 离线     │ ← 底部状态栏                                          │
│ 在线: 2/3  │                                                       │
│ 今日: 47次  │                                                       │
└──────────┴───────────────────────────────────────────────────────┘

侧边栏宽度：220px，可折叠为64px（只显示图标），快捷键 Ctrl+B
顶部栏高度：56px
全局字体：14px，行高1.6
深色模式：CSS变量切换，跟随系统/手动选择
```

### 3.2 页面1：仪表盘 Dashboard

仪表盘包含11个区域，完整数据结构见 API 定义：

```
┌─────────────────────────────────────────────────────────────┐
│  仪表盘                          时间范围: [7天▾] [30天] [全部] │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│  ┌──────────┐ ┌──────────┐ ┌──────────┐ ┌──────────┐       │
│  │ 📱 账号   │ │ ✍️ 今日发布│ │ 👥 总粉丝  │ │ ❤️ 总获赞  │       │
│  │    5     │ │   2/5    │ │ 15,847   │ │ 42,560   │       │
│  │ 在线: 3  │ │ 库存: 8篇 │ │ ↑127今天  │ │ ↑89今天   │       │
│  │ 运营中:2  │ │ 库存充足✅ │ │  ↑42.7%  │ │ 率3.2%   │       │
│  └──────────┘ └──────────┘ └──────────┘ └──────────┘       │
│                                                             │
│  ┌──────────────────────┐ ┌────────────────────┐           │
│  │ 📈 数据趋势（ECharts） │ │ 📊 账号状态（环形图）│           │
│  │ 折线：粉丝/获赞/收藏/阅读│ │ 运营中:2 养号中:1  │           │
│  │ 面积渐变+tooltip联动   │ │ 暂停:1 离线:1      │           │
│  └──────────────────────┘ └────────────────────┘           │
│                                                             │
│  ┌──────────────────────┐ ┌────────────────────┐           │
│  │ 🔥 内容表现TOP5       │ │ 🕐 最佳发布时间     │           │
│  │ 排名/标题/数据/互动率  │ │ 热力图 7天×24小时   │           │
│  └──────────────────────┘ └────────────────────┘           │
│                                                             │
│  ┌──────────────────────┐ ┌────────────────────┐           │
│  │ 📅 今日任务时间线      │ │ 📜 最近操作日志     │           │
│  │ 09:30 养号浏览 ✅     │ │ 14:25 点赞成功     │           │
│  │ 14:00 发布笔记 🔄60%  │ │ 14:20 评论成功     │           │
│  └──────────────────────┘ └────────────────────┘           │
│                                                             │
│  ┌──────────────────────────────────────────────┐          │
│  │ 📊 各账号数据对比（分组柱状图）                   │          │
│  │ X轴: 账号A / B / C  Y轴: 粉丝/获赞/笔记/收藏   │          │
│  └──────────────────────────────────────────────┘          │
│                                                             │
│  ┌──────────────────────────────────────────────┐          │
│  │ 📦 内容库存状态                                │          │
│  │ 美妆达人 ████████ 5篇 可用至后天   ✅          │          │
│  │ 穿搭日记 ██ 1篇 可用至明天         ⚠️ [生成]  │          │
│  └──────────────────────────────────────────────┘          │
│                                                             │
│  ┌──────────────────────────────────────────────┐          │
│  │ 🤖 AI用量  今日¥0.38 / 本月¥7.02              │          │
│  │ 预算剩余: ████████████████░░░░ 76.5%          │          │
│  │ 内容生成65k | 安全审核23k | 评论28k | 分析12k   │          │
│  └──────────────────────────────────────────────┘          │
│                                                             │
│  ┌──────────────────────────────────────────────┐          │
│  │ ⚠️ 预警横幅（如有）                            │          │
│  │ 🟡 账号"穿搭日记"Cookie将在2天后过期  [查看]    │          │
│  └──────────────────────────────────────────────┘          │
│                                                             │
│  ┌──────────────────────────────────────────────┐          │
│  │ 📊 今日复盘 · 美妆小达人          评分: 8/10 ⭐ │          │
│  │ 总结：粉丝↑33（本周新高），面霜测评互动率25%🔥   │          │
│  │ ✅ 亮点：互动率是平均3倍 / 18点发布最佳 / 健康度↑3│          │
│  │ ⚠️ 待改进：评论偏少(4条→建议6-8条) / 14点数据差  │          │
│  │ 💡 明天：加大测评 / 重点18:00+21:00 / 点赞→22   │          │
│  │ [查看完整复盘]                                   │          │
│  └──────────────────────────────────────────────┘          │
└─────────────────────────────────────────────────────────────┘
```

**数据刷新策略**：
- WebSocket实时推送关键变化（任务完成、粉丝变动、预警）
- 断线重连后补发离线消息（最近20条）
- 降级方案：无WebSocket时30秒轮询

**ECharts图表配置要求**：
- 折线图：平滑曲线(smooth)，面积渐变填充，tooltip联动，支持切换时间范围
- 环形图：中心显示总数，hover放大
- 柱状图：圆角顶部，hover加深
- 热力图：7天×24小时，颜色从浅到深表示数据好坏
- 所有图表支持自适应窗口大小（window.resize）

### 3.3 页面2：账号管理

```
┌─────────────────────────────────────────────────────────────┐
│  账号管理        [➕ 添加账号] [🔄 刷新全部]    🔍搜索  [状态▾] │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│  账号卡片（网格视图，每行2-3个）：                             │
│  ┌──────────────────────┐ ┌──────────────────────┐          │
│  │ [头像] 美妆小达人  🟢 │ │ [头像] 穿搭日记   🟡 │          │
│  │ ID: xhs_001          │ │ ID: xhs_002          │          │
│  │ 👥 1.2k  ❤️ 5.6k    │ │ 👥 356   ❤️ 890     │          │
│  │ 📝 48    ➕ 234     │ │ 📝 12    ➕ 89      │          │
│  │ 🏷️ 美妆护肤          │ │ 🏷️ 待定位           │          │
│  │ 📊 运营中 · 第12天   │ │ 📊 养号中 · 第3/7天  │          │
│  │ ⏰ 下次: 14:30发布   │ │ ⏰ 下次: 11:00浏览   │          │
│  │ [分析] [编辑] [⏸停]  │ │ [分析] [定位] [⏸停]  │          │
│  └──────────────────────┘ └──────────────────────┘          │
│                                                             │
│  点击卡片 → 右侧抽屉滑入（5个Tab）：                          │
│  [基本信息] [分析报告] [运营数据] [内容列表] [任务历史]         │
│                                                             │
│  抽屉内含 ECharts 迷你趋势图（近7天粉丝/获赞）                │
└─────────────────────────────────────────────────────────────┘
```

**添加账号流程**：

扫码登录：
1. 后端启动Playwright → 打开小红书 → 截取二维码 → base64返回
2. 前端展示二维码，每2秒轮询 `GET /api/accounts/qr-status`
3. 扫码成功 → 自动保存Cookie → 获取账号信息 → Toast成功
4. 二维码过期自动刷新，超时5分钟提示重试

Cookie登录：
1. 用户粘贴Cookie或上传JSON
2. 后端验证 → 成功则保存+获取信息 → 失败提示"Cookie无效"

### 3.4 页面3：内容管理

```
┌─────────────────────────────────────────────────────────────┐
│  内容管理        [🤖 AI生成] [📥 素材库]        [账号▾] [状态▾] │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│  内容表格：                                                  │
│  封面 | 标题 | 账号 | 状态 | 阅读 | 点赞 | 收藏 | 评论 | 操作  │
│                                                             │
│  ── AI内容生成器（点击展开）──                                │
│  目标账号 / 内容类型(图文/视频) / 生成方式                     │
│    ● 输入主题关键词                                          │
│    ○ AI推荐主题（根据定位推荐）                               │
│    ○ 热点追踪（实时热点+领域匹配）                            │
│  高级设置：字数/语气/标题备选/配图prompt/话题标签/AI模型       │
│  [🤖 开始生成] → 进度动画 → 生成结果预览                      │
│                                                             │
│  生成结果预览：                                               │
│  5个备选标题（可点击切换）                                     │
│  正文（可编辑文本域）                                          │
│  标签 / 话题 / 配图描述                                       │
│  小红书样式预览卡片（模拟手机端展示）                           │
│  版本历史（v1 AI生成 / v2 安全重写 / v3 用户编辑）              │
│  [💾 保存草稿] [📅 定时发布] [▶ 立即发布]                     │
└─────────────────────────────────────────────────────────────┘
```

### 3.5 页面4：内容日历

月视图/周视图切换，日期格内显示已发布📝/定时⏰/计划📋 + 篇数。
点击日期格展开当日详情 + 可添加内容。
新增 [📅 生成本周计划] 一键按钮。

### 3.6 页面5：任务中心

看板视图（4列：待执行/执行中/已完成/失败）+ 列表视图切换。
任务卡片显示类型/账号/时间/优先级/进度条。
点击卡片弹出详情（含执行日志实时滚动）。

### 3.7 页面6：AI配置

3个Tab：模型配置（CRUD+测试连接）/ 提示词管理（代码编辑器+变量高亮）/ 使用统计（ECharts图表+表格）。

### 3.8 页面7：素材库

网格展示/拖拽上传/分类筛选/AI自动打标签/详情弹窗/使用统计。

### 3.9 页面8：运营报告

报告列表/详情弹窗（总览/爆文TOP/AI点评/下周建议）/手动生成/导出PDF。

### 3.10 页面9：系统设置

运营参数/运营强度选择（保守/标准/激进/自定义）/反检测设置/活跃时段/代理/数据管理（备份恢复清除）/关于。

### 3.11 页面10：运行日志

表格（时间/级别/账号/操作/详情）+ 筛选（级别/账号/关键词搜索）+ 分页 + 导出。

---

## 四、后端API设计（完整）

### 4.1 统一响应格式

```json
// 成功
{ "code": 0, "message": "success", "data": { ... } }

// 分页
{ "code": 0, "message": "success", "data": { "items": [...], "total": 42, "page": 1, "page_size": 20 } }

// 错误
{ "code": 4001, "message": "账号不存在", "data": null }
```

**错误码体系**：
```
0     成功
1001  参数校验失败
1002  未授权
2001-2005  账号相关错误
3001-3004  内容相关错误
4001-4004  任务相关错误
5001-5004  AI相关错误
6001-6003  浏览器相关错误
7001-7002  防封相关错误
9001-9002  系统错误
```

### 4.2 完整API路由表

```
# ══ 账号 ══
POST   /api/accounts                          # 添加账号（扫码）
GET    /api/accounts?page=&size=&status=&keyword=  # 列表
GET    /api/accounts/{id}                     # 详情
PUT    /api/accounts/{id}                     # 更新
DELETE /api/accounts/{id}                     # 删除（级联清理）
GET    /api/accounts/qr                       # 获取二维码
GET    /api/accounts/qr-status?token=         # 轮询扫码状态
POST   /api/accounts/cookie-login             # Cookie登录
POST   /api/accounts/{id}/start               # 启动运营
POST   /api/accounts/{id}/stop                # 停止运营
POST   /api/accounts/{id}/pause               # 暂停
POST   /api/accounts/{id}/resume              # 恢复
POST   /api/accounts/{id}/refresh             # 刷新数据
POST   /api/accounts/{id}/analyze             # 触发分析
GET    /api/accounts/{id}/analysis            # 获取分析报告
POST   /api/accounts/{id}/optimize-profile    # 优化资料
GET    /api/accounts/{id}/optimize-preview    # 预览方案
GET    /api/accounts/{id}/stats?days=30       # 历史统计
GET    /api/accounts/{id}/contents            # 该账号内容
GET    /api/accounts/{id}/tasks               # 该账号任务
POST   /api/accounts/batch-start              # 批量启动
POST   /api/accounts/batch-stop               # 批量停止
POST   /api/accounts/batch-refresh            # 批量刷新

# ══ 内容 ══
POST   /api/contents/generate                 # AI生成
GET    /api/contents?page=&account_id=&status=  # 列表
GET    /api/contents/{id}                     # 详情
PUT    /api/contents/{id}                     # 更新（触发重审）
DELETE /api/contents/{id}                     # 删除（清理文件）
POST   /api/contents/{id}/publish             # 立即发布
POST   /api/contents/{id}/schedule            # 定时发布
POST   /api/contents/{id}/cancel-schedule     # 取消定时
POST   /api/contents/{id}/regenerate          # 重新生成
GET    /api/contents/{id}/stats               # 内容数据
GET    /api/contents/{id}/versions            # 版本历史
POST   /api/contents/{id}/restore-version     # 恢复版本
GET    /api/contents/suggest-topics?account_id=  # 推荐主题
GET    /api/contents/trending?category=       # 热点追踪
POST   /api/contents/batch-generate            # 批量生成
POST   /api/contents/batch-schedule            # 批量定时
POST   /api/contents/generate-weekly-plan      # 一键周计划

# ══ 任务 ══
GET    /api/tasks?page=&account_id=&type=&status=  # 列表
GET    /api/tasks/{id}                        # 详情（含执行日志）
POST   /api/tasks/{id}/cancel                 # 取消
POST   /api/tasks/{id}/retry                  # 重试
POST   /api/tasks/{id}/pause                  # 暂停
POST   /api/tasks/{id}/resume                 # 恢复
POST   /api/tasks/batch-action                # 批量操作
GET    /api/tasks/stats                       # 统计
GET    /api/tasks/today                       # 今日时间线

# ══ AI ══
GET    /api/ai/configs                        # 配置列表
POST   /api/ai/configs                        # 添加配置
PUT    /api/ai/configs/{id}                   # 更新配置
DELETE /api/ai/configs/{id}                   # 删除配置
POST   /api/ai/configs/{id}/test              # 测试连接
POST   /api/ai/configs/{id}/set-default       # 设为默认
GET    /api/ai/prompts                        # 提示词列表
GET    /api/ai/prompts/{name}                 # 提示词详情
PUT    /api/ai/prompts/{name}                 # 更新提示词
GET    /api/ai/usage-stats                    # 用量统计

# ══ 仪表盘 ══
GET    /api/dashboard/overview                # 概览数据（11个区域全部数据）
GET    /api/dashboard/trends?days=30          # 趋势数据
GET    /api/dashboard/account-comparison      # 账号对比
GET    /api/dashboard/content-performance     # 内容表现分析
GET    /api/dashboard/follower-analysis       # 粉丝分析
GET    /api/dashboard/today-review?account_id=  # 今日复盘结果

# ══ 复盘 ══
GET    /api/reviews?account_id=&date=         # 复盘历史列表
GET    /api/reviews/{id}                      # 复盘详情
POST   /api/reviews/trigger?account_id=       # 手动触发复盘
GET    /api/reviews/latest?account_id=        # 最新一次复盘

# ══ 素材库 ══
POST   /api/materials/upload                  # 上传（多文件+拖拽）
GET    /api/materials?page=&category=         # 列表
DELETE /api/materials/{id}                    # 删除
POST   /api/materials/{id}/tag                # AI自动打标签
GET    /api/materials/suggest?content_id=     # AI推荐匹配素材

# ══ 预警通知 ══
GET    /api/notifications                     # 列表
PUT    /api/notifications/{id}/read           # 标记已读
POST   /api/notifications/read-all            # 全部已读
DELETE /api/notifications/{id}                # 删除
GET    /api/notifications/unread-count        # 未读数

# ══ 报告 ══
GET    /api/reports                           # 列表
GET    /api/reports/{id}                      # 详情
POST   /api/reports/generate                  # 手动生成
GET    /api/reports/{id}/download             # 下载

# ══ 导出 ══
POST   /api/export/accounts-stats?fmt=xlsx    # 导出账号统计
POST   /api/export/content-stats?fmt=xlsx     # 导出内容数据
POST   /api/export/operation-logs?days=30     # 导出操作日志

# ══ 系统 ══
GET    /api/settings                          # 获取设置
PUT    /api/settings                          # 更新设置
POST   /api/settings/backup                   # 备份
POST   /api/settings/restore                  # 恢复
GET    /api/logs?page=&level=&account_id=     # 日志查询
DELETE /api/logs?before_days=30               # 清除旧日志
GET    /api/system/status                     # 系统状态
POST   /api/system/client-error               # 前端错误上报
GET    /api/system/diagnostics                # 🆕 完整诊断报告
POST   /api/system/diagnostics/fix            # 🆕 自动修复常见问题
GET    /api/system/diagnostics/startup        # 🆕 启动检查报告

# ══ WebSocket ══
WS     /ws                                    # 实时通信
```

### 4.3 WebSocket事件类型

```
# 任务相关
{ "event": "task_updated", "data": { "task_id", "status", "progress" } }

# 账号相关
{ "event": "account_updated", "data": { "account_id", "followers", "status" } }

# 内容相关
{ "event": "content_published", "data": { "content_id", "account_id", "title" } }
{ "event": "safety_check", "data": { "content_id", "passed", "score" } }
{ "event": "safety_blocked", "data": { "content_id", "reason", "suggestions" } }

# 操作日志
{ "event": "activity_log", "data": { "level", "action", "detail", "account_id" } }

# 系统告警
{ "event": "system_alert", "data": { "level", "message" } }
{ "event": "alert", "data": { "level", "title", "message", "account_id" } }

# 验证码
{ "event": "captcha_detected", "data": { "account_id", "type", "screenshot" } }
{ "event": "captcha_resolved", "data": { "account_id" } }

# Cookie
{ "event": "cookie_expiring", "data": { "account_id", "expires_in_days" } }
{ "event": "cookie_expired", "data": { "account_id" } }

# 报告
{ "event": "report_ready", "data": { "report_type", "account_id", "url" } }

# 计划
{ "event": "plan_generated", "data": { "account_id", "count" } }
```

---

## 五、核心业务逻辑详细设计

### 5.1 账号分析流程

AccountAnalyzer.analyze(account_id) → AnalysisReport:
1. 浏览器打开账号主页 → 抓取完整数据（昵称/简介/粉丝/笔记等）
2. 更新数据库Account记录
3. 判断账号类型：笔记<3且粉丝<50 → "new"；粉丝>10000 → "mature"；等等
4. 调用AI生成分析报告（使用 account_analysis.txt 提示词）
5. 保存分析报告
6. 如果是空账号 → 自动触发定位流程
7. 返回结果

### 5.2 账号定位流程

AccountPositioner.position(account_id) → PositioningResult:
1. 获取账号基础信息 + 小红书热门赛道数据
2. 调用AI生成定位方案（category/persona/audience/nicknames/bios/content_themes等）
3. 保存到 Account.positioning + positioning.json
4. 生成养号阶段计划

### 5.3 资料优化流程

ProfileOptimizer.optimize(account_id):
1. 读取定位信息 → AI选择最佳昵称/简介
2. 浏览器打开设置页 → 修改昵称（检查重复后重试）→ 修改简介 → 上传头像
3. 每步验证修改成功 → 更新数据库

### 5.4 养号流程（7天计划）

```
Day 1 观察日:      6次浏览，总时长~115分钟，零互动
Day 2 轻度互动日:   6次浏览+点赞3-5次+收藏1-2次+关注2-3个
Day 3 互动加深日:   6次浏览+点赞+评论1-2次+关注
Day 4 深度互动日:   6次浏览+点赞+评论+收藏+关注（全部增加）
Day 5 准备发布日:   浏览减少+生成第一篇内容+发布+互动
Day 6 稳定发布日:   正常浏览+发布1篇+适量互动
Day 7 养号完成日:   简短浏览+发布+转入日常运营

日常运营（养号完成后）：
- 每天发布1-3篇内容
- 浏览推荐页2-3次（每次10-15分钟）
- 适量互动（点赞10-15，评论2-3）
- 回复自己笔记的评论
- 数据回收（发布后2h/6h/24h/48h，持续7天）
```

**行为模拟规则**：
- 浏览：自然滚动（速度不均匀，偶尔回滚，偶尔停留看笔记）
- 点赞：先阅读3-8秒再点赞，间隔10-60秒，5%概率取消
- 收藏：比点赞更低频，需阅读完整内容
- 评论：AI生成15-40字自然评论，含1-2个emoji，间隔30-120秒
- 关注：优先关注同领域+粉丝量相近的，每天≤5个

### 5.5 内容生成流程

ContentGenerator.generate(account_id, topic) → ContentGenerationResult:
1. 读取账号定位 + 历史内容（避免重复）+ 近期数据表现
2. 确定主题（用户指定/AI推荐/热点追踪）
3. AI生成5个备选标题（数字型/悬念型/痛点型/对比型/合集型）
4. AI生成正文（开头Hook + 分点主体 + 结尾互动引导）
5. AI生成5-8个标签（大流量+精准+长尾混合）
6. AI生成配图描述prompt
7. 去重检查（标题相似度>70%则换标题，正文重叠>50%则重新生成）
8. 配图获取：素材库匹配 → AI生成 → 从热门笔记参考风格
9. 质量自检（自然度/信息量/互动潜力/关键词整合）
10. 安全审核 → 通过则保存，不通过则自动重写（最多2次）

### 5.6 内容发布流程

ContentPublisher.publish(content_id):
1. 读取Content + 获取账号浏览器Context
2. 打开小红书发布页
3. 上传图片 → 填写标题 → 填写正文（模拟键盘输入）→ 添加标签/话题
4. 截图预览 → 点击发布 → 检测错误 → 获取笔记URL/ID
5. 更新Content记录 → 创建数据回收定时任务

### 5.7 数据回收

DataCollector.collect_stats(content_id):
触发时机：发布后 2h/6h/24h/48h，此后每天1次（持续7天）
流程：打开笔记详情页 → 抓取阅读/点赞/收藏/评论/分享 → 更新Content + DailyStat

### 5.8 运营策略引擎

StrategyEngine.generate_daily_plan(account_id, date) → DailyPlan:
1. ★ 先检查 strategy_overrides 表有没有今天的覆盖（来自昨晚复盘）
   - 有 → 使用复盘优化后的策略和任务列表
   - 没有 → 使用默认策略
2. 检查昨日未完成任务（取消低优先级过期任务，保留发布任务）
3. 检查今日已有任务数（>10则跳过生成，防堆积）
4. 根据账号阶段 + 活跃时间段 + 周末/工作日 + 复盘建议 生成任务列表
5. 智能调整：昨日操作少→今日适当增加；检测到异常→降低强度

### 5.9 内容安全审核（完整pipeline）

```
Step 1: 规则引擎（<10ms）
  - 敏感词检查（Aho-Corasick自动机）
  - 正则规则（微信号/QQ号/外链/绝对化用语/恶意贬低）
  - 格式检查（字数/emoji比例/重复字符）
  - 结果：banned→拦截 / high_risk→进入AI审核 / safe→继续

Step 2: AI审核（2-5秒）
  - 合规性语义分析 / 引流检测 / 真实性判断 / AI痕迹检测
  - 结果：score<4→拦截 / 4-6→警告 / 6-8→通过并去AI化 / >8→直接通过

Step 3: 去AI化处理（如果AI痕迹分>6）
  - 去除排比句式、书面化连接词、过于工整的结构
  - 添加个人体验、口语化表达、主观偏见
  - 再次AI审核确认

Step 4: 结果持久化
  - content.safety_score = 评分
  - content.safety_result = JSON(审核详情)
  - content.safety_checked_at = 当前时间
  - content.status = safety_passed 或 safety_blocked
  - ★ 必须commit到数据库
```

### 5.10 内容自动续航

ContentContinuum.check_and_fill():
1. 每天22:30检查所有active账号的内容库存（status=safety_passed/scheduled的未发布数）
2. ★ 读取当天的复盘结果（strategy_updates.tomorrow_strategy.content_adjustments）
3. 如果库存 < 未来3天的发布计划数 → 自动生成补充
4. 选题策略：复盘推荐方向 > 近期表现好的类型 > 竞品热门方向 > 热点
5. 自动生成 → 安全审核 → 进入库存

### 5.11 一键周计划

WeeklyPlanner.generate_weekly_plan(account_id):
1. 分析近7天数据 → AI生成本周主题 → 分配每天发布时间
2. 逐日生成内容 → 安全审核 → 创建定时发布任务
3. 前端日历视图自动填充

### 5.12 每日AI复盘与策略自适应（核心闭环）

```python
"""
DailyReview - 每日AI复盘 + 策略自适应

问题：当前策略引擎每天7:30生成固定计划，但不会根据昨天的表现调整。
     内容数据好的方向没有加大投入，数据差的方向没有减少。
     发布时间效果好的没有固化，差的没有淘汰。
解决：每晚22:00自动复盘当天表现，AI分析并调整明天策略。

这是整个"全自动"的核心闭环：
  生成策略 → 执行 → 收集数据 → 复盘分析 → 优化策略 → 生成新策略 → ...
  ↑_______________________________________________________________|
"""

class DailyReviewService:
    """
    每日复盘流程（每个active账号执行一次）：

    Step 1: 数据汇总（22:00执行）
      - 今日操作统计（浏览/点赞/评论/关注/发布次数）
      - 今日发布的内容数据（阅读/点赞/收藏/评论/分享）
      - 粉丝变化（涨了多少/掉了多少）
      - 任务执行情况（完成了几个/失败了几个）
      - 风控事件（验证码/健康度变化/限流）

    Step 2: AI深度分析（调用daily_review.txt提示词）
      - 哪篇内容数据最好？为什么？
      - 哪篇内容数据最差？为什么？
      - 什么时间段发布的数据最好？
      - 什么类型的内容互动率最高？
      - 今天的操作强度是否合适？（有没有触发风控）
      - 养号进度是否正常？
      - 与昨天/上周同期对比如何？

    Step 3: 策略调整（AI输出调整建议 → 写入数据库）
      - 明天的内容主题方向调整（增加什么/减少什么）
      - 明天的发布时间优化（哪个时段效果好就多用）
      - 明天的操作强度调整（健康度低就降低/高就适当增加）
      - 明天的互动策略调整（点赞比例/评论风格/关注目标）
      - 养号阶段的特殊调整（即将结束养号的准备事项）

    Step 4: 自动生成明天的优化计划
      - 将AI建议转化为具体的明天任务列表
      - 写入策略引擎，明天7:30执行时使用优化后的策略

    Step 5: 生成复盘报告（前端展示）
      - 简洁的今日总结卡片
      - AI点评（一句话总结 + 关键数据）
      - 明天的优化方向
      - 存入 daily_reviews 表
    """

    async def review_account(self, account_id: str) -> DailyReviewResult:
        """
        对单个账号执行每日复盘

        完整流程：
        1. 收集今日数据 → today_data
        2. 获取昨天的复盘结果 → yesterday_review（用于对比）
        3. 获取该账号的历史策略 → current_strategy
        4. 调用AI分析 → ai_analysis
        5. AI输出策略调整 → strategy_updates
        6. 写入策略引擎的明日计划 → update tomorrow's plan
        7. 保存复盘记录 → daily_reviews 表
        8. 推送复盘通知 → WebSocket
        """
        pass

    async def review_all_active(self):
        """为所有active账号执行复盘（定时任务调用）"""
        pass
```

**复盘数据采集项**：

```python
TODAY_DATA_SCHEMA = {
    # 操作统计
    "operations": {
        "browse_minutes": 45,
        "likes_given": 18,
        "comments_given": 4,
        "collects_given": 3,
        "follows_given": 2,
        "tasks_total": 8,
        "tasks_completed": 7,
        "tasks_failed": 1,
        "task_fail_reasons": ["Cookie过期导致发布失败"],
    },

    # 发布内容数据（今天发布的）
    "published_content": [
        {
            "title": "秋冬面霜测评",
            "publish_time": "18:00",
            "hours_since_publish": 4,
            "views": 320,
            "likes": 45,
            "collects": 28,
            "comments": 8,
            "shares": 2,
            "engagement_rate": 25.3,  # (likes+collects+comments)/views %
        },
    ],

    # 已发布内容的今日新增数据（之前发布的，今天的数据变化）
    "historical_content_today": [
        {
            "title": "学生党护肤攻略",
            "publish_date": "昨天",
            "today_new_views": 580,
            "today_new_likes": 67,
            "trend": "rising",  # rising/stable/declining
        },
    ],

    # 账号数据
    "account": {
        "followers_start": 1234,
        "followers_end": 1267,
        "followers_gain": 33,
        "likes_start": 5600,
        "likes_end": 5689,
        "health_score_start": 85,
        "health_score_end": 88,
        "captcha_triggered": False,
        "risk_events": [],
    },

    # 竞品动态（如有）
    "competitor_updates": [
        {"nickname": "竞品A", "new_followers": 150, "new_notes": 2},
    ],
}
```

**AI复盘输出（strategy_updates）**：

```python
STRATEGY_UPDATE_SCHEMA = {
    # 今日总结
    "today_summary": "今天整体表现良好，粉丝增长33个创本周新高。面霜测评内容数据爆发，互动率25%远超平均。",

    # 数据评分
    "today_score": 8,  # 1-10分

    # 亮点
    "highlights": [
        "面霜测评互动率25%，是平均水平的3倍",
        "晚间18点发布的内容数据最好",
        "养号阶段进展顺利，健康度提升3分",
    ],

    # 问题
    "issues": [
        "评论互动偏少，只有4条，建议增加到6-8条",
        "下午14点发布的内容数据一般，考虑调整时间",
    ],

    # 明天策略调整
    "tomorrow_strategy": {
        # 内容方向调整
        "content_adjustments": {
            "increase": ["面霜/精华测评类内容", "含价格对比的合集"],
            "decrease": ["纯日常分享（数据表现差）"],
            "new_try": ["成分党分析类内容（近期热门）"],
            "avoid": [],
        },

        # 发布时间调整
        "schedule_adjustments": {
            "best_times": ["18:00", "21:00"],  # 根据今天数据调整
            "avoid_times": ["14:00"],           # 今天14点数据差
            "reason": "今天18点发布的内容互动率最高，建议重点使用",
        },

        # 操作强度调整
        "intensity_adjustments": {
            "likes": {"current": 18, "suggested": 22, "reason": "健康度良好，可以适当增加"},
            "comments": {"current": 4, "suggested": 6, "reason": "评论互动率高，多评论有助于涨粉"},
            "follows": {"current": 2, "suggested": 2, "reason": "保持不变"},
            "browse_minutes": {"current": 45, "suggested": 45, "reason": "合适"},
        },

        # 互动策略调整
        "interaction_adjustments": {
            "focus_on": "回复提问型评论（今天这类评论最多）",
            "comment_style": "多用'我也觉得'、'对对对'等认同型回复",
            "follow_target": "关注今天点赞过的同领域账号",
        },

        # 养号特殊调整（仅养号阶段有效）
        "nurturing_adjustments": {
            "next_day_plan": "明天是养号第6天，可以开始准备第二篇内容",
            "transition_prep": "养号即将完成，明天生成2篇内容储备",
        },
    },

    # 长期趋势判断
    "trend_analysis": {
        "follower_trend": "连续3天增长加速，处于上升期",
        "content_trend": "测评类内容持续强势，建议深耕",
        "risk_assessment": "健康度稳定，无风控事件，可以适当提频",
    },

    # 明天具体任务建议（写入策略引擎）
    "tomorrow_tasks": [
        {"time": "09:30", "action": "browse", "duration": 20, "note": "浏览推荐页"},
        {"time": "11:00", "action": "browse", "duration": 15, "likes": "4-6"},
        {"time": "14:00", "action": "search", "keywords": ["面霜测评", "成分分析"]},
        {"time": "16:00", "action": "browse", "duration": 15, "comments": "2-3"},
        {"time": "18:00", "action": "publish", "content_type": "面霜/精华测评", "note": "最佳时段"},
        {"time": "20:00", "action": "interact", "note": "回复今日评论"},
        {"time": "21:00", "action": "publish", "content_type": "合集/攻略", "note": "第二最佳时段"},
    ],
}
```

**前端展示 - 复盘卡片**（在仪表盘新增区域12）：

```
┌─────────────────────────────────────────────────────────────┐
│  📊 今日复盘 · 美妆小达人                    评分: 8/10 ⭐    │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│  今日总结：粉丝↑33（本周新高），面霜测评互动率25%爆发🔥       │
│                                                             │
│  ✅ 亮点：                                                   │
│  · 面霜测评互动率25%，是平均的3倍                             │
│  · 18点发布数据最佳                                          │
│  · 健康度提升3分 → 88                                        │
│                                                             │
│  ⚠️ 待改进：                                                 │
│  · 评论互动偏少（4条），建议增至6-8条                         │
│  · 14点发布数据一般，考虑调整                                 │
│                                                             │
│  💡 明天优化：                                               │
│  · 内容方向：加大测评类，尝试成分分析                          │
│  · 发布时间：重点用18:00和21:00，避开14:00                    │
│  · 操作强度：点赞18→22，评论4→6                               │
│                                                             │
│  [查看完整复盘报告]                                           │
└─────────────────────────────────────────────────────────────┘
```

**复盘与计划生成的协作流程**：

```
每天 22:00  daily_review.review_all_active()
  → AI复盘今日表现
  → 输出 tomorrow_strategy + tomorrow_tasks
  → 写入 strategy_overrides 表（覆盖明天的默认策略）

每天 7:30   strategy_engine.generate_all_daily_plans()
  → 先检查 strategy_overrides 表有没有今天的覆盖
  → 有 → 使用复盘优化后的策略生成任务
  → 没有 → 使用默认策略生成任务
  → 这样复盘的建议就能直接影响明天的执行

每天 22:30  content_continuum.check_and_fill()
  → 结合复盘的内容方向建议
  → 优先生成复盘推荐的内容类型
```

### 5.13 自动回复评论

InteractionManager.check_all_comments():
1. 获取所有active账号最近7天发布的笔记
2. 检查每个笔记的新评论（增量检查，每小时最多1次）
3. 过滤：跳过自己的评论 + 跳过广告/恶意评论
4. 逐条生成回复（AI）→ 安全审核 → 浏览器回复
5. 回复间隔30-120秒

### 5.14 错误自检诊断系统

```python
"""
Diagnostics - 启动自检 + 运行时诊断 + 错误定位 + 自动修复

核心目标：用户遇到问题时不需要看日志、不需要懂技术，
         系统自动检测问题所在，给出中文描述和修复建议。
"""

class Diagnostics:
    """
    三级诊断体系：

    Level 1: 启动前自检（pre-flight check）
      系统启动前全面检查环境和配置，有问题直接输出报告并停止启动
      → 避免"启动了但不知道为什么跑不起来"

    Level 2: 运行时健康检查（runtime health check）
      持续监控系统各模块状态，异常时自动诊断根因
      → 避免"运行中突然卡住不知道哪里出了问题"

    Level 3: 用户手动诊断（on-demand diagnostic）
      用户点击"诊断"按钮，全面扫描并输出报告
      → 避免"不知道怎么排查问题"
    """

    # ═══════════════════════════════════════════════════
    # Level 1: 启动前自检（lifespan Phase 0.5 执行）
    # ═══════════════════════════════════════════════════

    STARTUP_CHECKS = [
        {
            "name": "Python版本",
            "check": "sys.version_info >= (3, 10)",
            "fail_msg": "Python版本过低：当前 {current}，需要 3.10+。请访问 https://www.python.org/downloads/ 升级。",
            "severity": "critical",
            "auto_fix": False,
        },
        {
            "name": "依赖包完整性",
            "check": "逐个import requirements.txt中的包",
            "fail_msg": "缺少依赖包：{missing}。请运行：pip install -r requirements.txt",
            "severity": "critical",
            "auto_fix": True,
            "fix_cmd": "pip install -r requirements.txt -q",
        },
        {
            "name": "Playwright浏览器",
            "check": "playwright同步API能启动Chromium",
            "fail_msg": "Playwright浏览器未安装。请运行：playwright install chromium",
            "severity": "critical",
            "auto_fix": True,
            "fix_cmd": "playwright install chromium",
        },
        {
            "name": "data目录权限",
            "check": "能创建data/目录并写入测试文件",
            "fail_msg": "无法创建data目录或写入文件。请检查磁盘空间和目录权限。",
            "severity": "critical",
            "auto_fix": False,
        },
        {
            "name": "config.yaml",
            "check": "文件存在且格式合法",
            "fail_msg": "config.yaml不存在或格式错误：{error}。请复制config.example.yaml并填写配置。",
            "severity": "critical",
            "auto_fix": True,
            "fix_cmd": "copy config.example.yaml config.yaml",
        },
        {
            "name": "AI API配置",
            "check": "config中至少有一个有效的AI provider配置",
            "fail_msg": "未配置AI服务。请在config.yaml中填写AI API Key。",
            "severity": "critical",
            "auto_fix": False,
        },
        {
            "name": "AI API连通性",
            "check": "尝试调用AI API发送测试请求",
            "fail_msg": "AI API连接失败：{error}。可能原因：API Key错误 / 网络不通 / Base URL错误。",
            "severity": "critical",
            "auto_fix": False,
        },
        {
            "name": "数据库文件",
            "check": "能打开data/app.db并读取schema",
            "fail_msg": "数据库损坏：{error}。请删除data/app.db重新启动（会丢失数据），或从备份恢复。",
            "severity": "critical",
            "auto_fix": False,
        },
        {
            "name": "端口占用",
            "check": "config中的端口未被占用",
            "fail_msg": "端口 {port} 已被占用。请关闭占用该端口的程序，或在config.yaml中修改端口。",
            "severity": "critical",
            "auto_fix": False,
        },
        {
            "name": "加密密钥",
            "check": "encryption.key存在且可读",
            "fail_msg": "加密密钥缺失。首次运行会自动生成，如果之前有数据则无法解密。",
            "severity": "warning",
            "auto_fix": False,
        },
        {
            "name": "磁盘空间",
            "check": "剩余空间 > 500MB",
            "fail_msg": "磁盘空间不足：仅剩 {free_mb}MB。建议清理至少500MB空间。",
            "severity": "warning",
            "auto_fix": False,
        },
        {
            "name": "敏感词库",
            "check": "data/safety/sensitive_words.txt存在且可加载",
            "fail_msg": "敏感词库缺失。内容安全审核将无法工作。文件位置：data/safety/sensitive_words.txt",
            "severity": "warning",
            "auto_fix": True,
            "fix_cmd": "创建默认敏感词库",
        },
        {
            "name": "网络连通性",
            "check": "能访问 xiaohongshu.com",
            "fail_msg": "无法访问小红书网站。请检查网络连接或代理设置。",
            "severity": "warning",
            "auto_fix": False,
        },
    ]

    async def run_startup_checks(self) -> StartupReport:
        """
        启动前自检，返回诊断报告。

        如果有 critical 级别问题 → 返回 passed=False，系统不应启动
        如果有 warning 级别问题 → 返回 passed=True 但带警告，系统可以启动但功能受限

        输出格式：
        ╔══════════════════════════════════════════════════╗
        ║  🔍 启动自检报告                                  ║
        ╠══════════════════════════════════════════════════╣
        ║  ✅ Python 3.12.1                                 ║
        ║  ✅ 依赖包完整 (22/22)                             ║
        ║  ✅ Playwright Chromium 已安装                     ║
        ║  ✅ data目录可写                                   ║
        ║  ✅ config.yaml 格式正确                           ║
        ║  ❌ AI API连接失败                                 ║
        ║     错误: Connection refused                       ║
        ║     原因: Base URL http://localhost:11434 无法访问  ║
        ║     建议: 检查Ollama是否启动，或修改config中的base_url║
        ║  ⚠️ 磁盘空间: 剩余 230MB (建议 > 500MB)            ║
        ╠══════════════════════════════════════════════════╣
        ║  结果: ❌ 启动失败 (1个致命错误)                     ║
        ║  请修复上述 ❌ 标记的问题后重新启动                   ║
        ╚══════════════════════════════════════════════════╝
        """
        pass

    # ═══════════════════════════════════════════════════
    # Level 2: 运行时健康检查
    # ═══════════════════════════════════════════════════

    RUNTIME_CHECKS = {
        "database": {
            "name": "数据库连接",
            "check_fn": "尝试执行 SELECT 1",
            "fail_msg": "数据库连接断开。可能原因：磁盘满 / 文件被锁定 / 数据库损坏。",
            "diagnose": [
                "检查data/app.db文件大小",
                "检查磁盘剩余空间",
                "尝试PRAGMA integrity_check",
            ],
        },
        "browser": {
            "name": "Playwright浏览器",
            "check_fn": "检查browser实例是否可用",
            "fail_msg": "浏览器进程已退出。可能原因：内存不足 / Chromium崩溃。",
            "diagnose": [
                "检查系统内存使用",
                "检查Chromium进程是否存在",
                "查看最近的浏览器错误日志",
            ],
        },
        "ai_service": {
            "name": "AI服务",
            "check_fn": "发送最小测试请求",
            "fail_msg": "AI服务不可用：{error}",
            "diagnose": [
                "检查API Key是否过期",
                "检查Base URL是否可达",
                "检查是否触发了速率限制",
                "检查Token预算是否耗尽",
            ],
        },
        "scheduler": {
            "name": "任务调度器",
            "check_fn": "检查APScheduler是否运行",
            "fail_msg": "调度器已停止。后台任务将不会执行。",
            "diagnose": [
                "检查调度器进程状态",
                "查看最近的调度错误日志",
            ],
        },
        "websocket": {
            "name": "WebSocket连接",
            "check_fn": "检查是否有活跃的WS连接",
            "fail_msg": "前端WebSocket断开。实时更新功能不可用。",
            "diagnose": [
                "检查前端页面是否打开",
                "检查网络连接",
                "检查是否有防火墙阻止WS",
            ],
        },
        "accounts": {
            "name": "账号状态",
            "check_fn": "检查所有online账号的Cookie和健康度",
            "fail_msg": "{count}个账号存在问题：{details}",
            "diagnose": [
                "检查Cookie是否过期",
                "检查健康度是否低于阈值",
                "检查是否有被封禁的账号",
            ],
        },
        "tasks": {
            "name": "任务执行",
            "check_fn": "检查是否有长时间卡住的任务",
            "fail_msg": "发现{count}个任务执行超过预期时间。",
            "diagnose": [
                "检查任务状态和错误信息",
                "检查对应的浏览器Context是否正常",
                "检查是否有死锁",
            ],
        },
        "disk": {
            "name": "磁盘空间",
            "check_fn": "检查data/目录所在分区的剩余空间",
            "fail_msg": "磁盘空间不足：仅剩 {free_mb}MB。",
            "diagnose": [
                "清理data/logs/下的旧日志",
                "清理data/backups/下的旧备份",
                "清理data/temp/临时文件",
            ],
        },
    }

    async def run_health_check(self) -> HealthReport:
        """
        运行时健康检查，返回各模块状态。

        输出格式（通过 /api/system/diagnostics 获取）：
        {
          "status": "healthy",  // healthy / degraded / critical
          "checks": [
            {"module": "数据库", "status": "ok", "detail": "响应时间 2ms"},
            {"module": "浏览器", "status": "ok", "detail": "3个Context活跃"},
            {"module": "AI服务", "status": "degraded", "detail": "DeepSeek熔断中，已降级到OpenAI"},
            {"module": "账号", "status": "warning", "detail": "1个账号Cookie即将过期"},
            {"module": "磁盘", "status": "ok", "detail": "剩余 12.3 GB"},
          ],
          "issues": [
            {
              "module": "AI服务",
              "severity": "warning",
              "problem": "DeepSeek API连续失败5次，已自动熔断",
              "cause": "可能原因：API Key过期 / 余额不足 / 服务端故障",
              "fix": "请检查DeepSeek API状态，或在AI配置中切换到其他模型",
              "auto_fixed": false,
            }
          ]
        }
        """
        pass

    # ═══════════════════════════════════════════════════
    # Level 3: 错误诊断（出错时自动触发）
    # ═══════════════════════════════════════════════════

    ERROR_DIAGNOSIS = {
        # 浏览器相关
        "BrowserError": {
            "diagnose": [
                "检查Chromium进程是否还在",
                "检查是否有足够的内存",
                "检查目标页面URL是否可达",
                "检查是否有验证码弹窗",
            ],
            "common_causes": {
                "Target page closed": "页面被关闭，可能是小红书检测到异常跳转了",
                "Timeout": "页面加载超时，可能是网络慢或页面结构变化",
                "Navigation failed": "导航失败，可能是Cookie过期或被封禁",
            },
        },

        # 任务相关
        "TaskFailed": {
            "diagnose": [
                "查看任务的error_msg字段",
                "检查该账号的健康度和状态",
                "检查是否有前置任务失败",
                "检查是否在活跃时段内",
            ],
        },

        # AI相关
        "AIServiceError": {
            "diagnose": [
                "检查API Key是否有效",
                "检查Base URL是否正确",
                "检查账户余额/Token配额",
                "检查是否触发速率限制（429）",
                "检查网络是否能访问API地址",
            ],
            "common_causes": {
                "401 Unauthorized": "API Key错误或已过期",
                "429 Too Many Requests": "请求频率过高，请稍后重试",
                "500 Server Error": "AI服务端故障，请稍后重试",
                "Connection refused": "无法连接到AI服务，请检查网络和Base URL",
                "timeout": "请求超时，可能是网络慢或模型响应慢",
            },
        },

        # Cookie相关
        "CookieExpiredError": {
            "diagnose": [
                "检查cookie_meta.json中的expires_at",
                "尝试手动打开小红书确认登录状态",
                "检查是否在其他设备上退出了登录",
            ],
            "fix": "需要用户重新扫码或更新Cookie",
        },

        # 验证码
        "CaptchaDetectedError": {
            "diagnose": [
                "查看截图了解验证码类型",
                "检查该账号今日验证码触发次数",
                "检查操作频率是否过高",
                "检查健康度是否下降",
            ],
            "fix": "如果是滑块验证码，系统会尝试自动处理。如果失败，需要用户手动处理。",
        },

        # 数据库
        "DatabaseError": {
            "diagnose": [
                "检查data/app.db文件是否存在",
                "检查磁盘空间是否充足",
                "检查文件是否被其他进程锁定",
                "尝试PRAGMA integrity_check检查数据完整性",
            ],
            "fix": "如果数据库损坏，可从data/backups/恢复最近的备份",
        },
    }

    async def diagnose_error(self, error: Exception, context: dict) -> DiagnosisResult:
        """
        错误发生时自动诊断。

        输入：异常对象 + 上下文（哪个账号、什么操作、什么时间）
        输出：人类可读的诊断报告

        输出格式：
        ╔══════════════════════════════════════════════════╗
        ║  🔴 错误诊断                                      ║
        ╠══════════════════════════════════════════════════╣
        ║  时间: 2026-04-17 14:30:25                       ║
        ║  模块: 浏览器自动化                                ║
        ║  账号: 美妆小达人                                  ║
        ║  操作: 发布内容《秋冬面霜测评》                      ║
        ║                                                  ║
        ║  ❌ 错误: TimeoutError: 页面加载超时 (30s)          ║
        ║                                                  ║
        ║  🔍 诊断结果:                                      ║
        ║  1. 小红书发布页面加载缓慢                          ║
        ║  2. 该账号Cookie状态: 有效 (剩余23天)               ║
        ║  3. 网络延迟: 156ms (正常)                         ║
        ║  4. 最近5次操作: 4成功1失败 (失败率20%)              ║
        ║                                                  ║
        ║  💡 可能原因:                                     ║
        ║  · 小红书服务器临时繁忙                             ║
        ║  · 网络波动导致页面加载慢                           ║
        ║                                                  ║
        ║  🔧 建议操作:                                     ║
        ║  · 系统将在5分钟后自动重试                          ║
        ║  · 如果连续失败3次，请检查网络连接                   ║
        ╚══════════════════════════════════════════════════╝
        """
        pass

    # ═══════════════════════════════════════════════════
    # 自动修复
    # ═══════════════════════════════════════════════════

    AUTO_FIXABLE = {
        "依赖包缺失": {
            "detect": "ImportError / ModuleNotFoundError",
            "fix": "pip install <missing_package>",
            "safe": True,
        },
        "Playwright未安装": {
            "detect": "playwright._impl._errors.Error: Executable doesn't exist",
            "fix": "playwright install chromium",
            "safe": True,
        },
        "config.yaml不存在": {
            "detect": "FileNotFoundError: config.yaml",
            "fix": "复制config.example.yaml",
            "safe": True,
        },
        "敏感词库缺失": {
            "detect": "FileNotFoundError: sensitive_words.txt",
            "fix": "创建默认敏感词库文件",
            "safe": True,
        },
        "数据库表缺失": {
            "detect": "no such table",
            "fix": "自动创建缺失的表",
            "safe": True,
        },
        "数据库列缺失": {
            "detect": "no such column",
            "fix": "自动ADD COLUMN",
            "safe": True,
        },
        "任务卡死": {
            "detect": "任务状态running超过超时时间",
            "fix": "标记failed + 创建重试任务",
            "safe": True,
        },
        "临时文件堆积": {
            "detect": "data/temp/超过100MB",
            "fix": "自动清理",
            "safe": True,
        },
    }

    async def try_auto_fix(self, issue: dict) -> FixResult:
        """
        尝试自动修复问题。
        只修复 safe=True 的问题，需要用户确认的不自动修。
        """
        pass
```

**前端 - 诊断页面**（新增，可从系统设置或侧边栏进入）：

```
┌─────────────────────────────────────────────────────────────┐
│  🔍 系统诊断                                      [🔄 重新检查] │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│  系统状态: ✅ 健康                                          │
│                                                             │
│  ┌───────────────────────────────────────────────────────┐ │
│  │ 模块              状态       详情                      │ │
│  │ ✅ 数据库          正常       响应 2ms, 2.3MB          │ │
│  │ ✅ 浏览器          正常       Chromium运行中, 2个Context│ │
│  │ ✅ AI服务          正常       DeepSeek 可用            │ │
│  │ ✅ 任务调度        正常       运行中, 队列0个待执行     │ │
│  │ ⚠️ 账号           警告       1个Cookie 2天后过期       │ │
│  │ ✅ 磁盘空间        正常       剩余 12.3 GB             │ │
│  │ ✅ 网络            正常       小红书可达, 延迟 45ms     │ │
│  │ ✅ WebSocket       正常       1个活跃连接              │ │
│  └───────────────────────────────────────────────────────┘ │
│                                                             │
│  ┌───────────────────────────────────────────────────────┐ │
│  │ ⚠️ 问题1: 账号"穿搭日记"Cookie即将过期                  │ │
│  │ 原因: Cookie有效期30天，已过28天                       │ │
│  │ 建议: 请尽快更新Cookie，否则该账号的操作将全部失败      │ │
│  │ [立即更新Cookie]                                       │ │
│  └───────────────────────────────────────────────────────┘ │
│                                                             │
│  ┌───────────────────────────────────────────────────────┐ │
│  │ 📋 最近错误 (过去24小时)                                │ │
│  │                                                       │ │
│  │ 14:30 发布失败 - TimeoutError (已自动重试成功)         │ │
│  │ 09:15 Cookie验证失败 - 账号"美食号" (已标记离线)        │ │
│  │ 03:00 数据库VACUUM完成                                │ │
│  └───────────────────────────────────────────────────────┘ │
│                                                             │
│  [📥 导出完整诊断报告]  [🔧 自动修复所有问题]                │
└─────────────────────────────────────────────────────────────┘
```

**启动失败时的控制台输出**：

```
╔══════════════════════════════════════════════════════════╗
║  🔍 小红书AI运营平台 - 启动自检                           ║
╠══════════════════════════════════════════════════════════╣
║  ✅ Python 3.12.1                                        ║
║  ✅ 依赖包完整 (22/22)                                    ║
║  ✅ Playwright Chromium 已安装                            ║
║  ✅ data目录可写                                          ║
║  ✅ config.yaml 格式正确                                   ║
║  ❌ AI API连接失败                                        ║
║                                                          ║
║  ┌────────────────────────────────────────────────────┐  ║
║  │  ❌ AI API连接失败                                   │  ║
║  │                                                    │  ║
║  │  配置: DeepSeek (deepseek-chat)                     │  ║
║  │  URL: https://api.deepseek.com/v1                  │  ║
║  │  错误: ConnectionRefusedError: [WinError 10061]     │  ║
║  │        无法连接，因为目标计算机积极拒绝               │  ║
║  │                                                    │  ║
║  │  🔍 诊断:                                           │  ║
║  │  1. API Key格式正确 (sk-xxxxxxxx)                   │  ║
║  │  2. DNS解析成功 (api.deepseek.com → 47.xx.xx.xx)   │  ║
║  │  3. TCP连接被拒绝 (端口443)                         │  ║
║  │                                                    │  ║
║  │  💡 可能原因:                                       │  ║
║  │  · 代理设置问题：系统代理指向了不存在的代理服务器     │  ║
║  │  · 防火墙阻止了HTTPS连接                            │  ║
║  │  · DeepSeek服务临时维护                             │  ║
║  │                                                    │  ║
║  │  🔧 建议:                                           │  ║
║  │  · 检查系统代理设置（设置→网络→代理）                 │  ║
║  │  · 尝试在浏览器中访问 https://api.deepseek.com      │  ║
║  │  · 如果使用VPN，检查VPN是否正常连接                  │  ║
║  │  · 在config.yaml中配置proxy字段                     │  ║
║  └────────────────────────────────────────────────────┘  ║
║                                                          ║
║  ⚠️ 磁盘空间: 剩余 230MB (建议 > 500MB)                   ║
║                                                          ║
╠══════════════════════════════════════════════════════════╣
║  ❌ 启动失败：发现 1 个致命错误                            ║
║  请修复上述问题后重新运行 start.bat                         ║
╚══════════════════════════════════════════════════════════╝
```

---

## 六、AI提示词模板

### 6.1 账号分析提示词（account_analysis.txt）

```
#ROLE: 你是一位拥有5年经验的小红书运营专家，操盘过多个百万粉丝账号。
#TASK: 请分析以下小红书账号的现状，并给出专业的运营建议。

## 账号数据
- 昵称：{{nickname}} / 简介：{{bio}} / 粉丝：{{followers}}
- 关注：{{following}} / 获赞：{{likes}} / 笔记：{{notes_count}}
- IP归属地：{{ip_location}}
## 近期笔记数据
{{recent_notes_data}}

请以纯JSON格式返回（不要包裹代码块）：
{
  "score": 7,  // 1-10分
  "score_breakdown": {"positioning": 6, "content_quality": 7, "data_performance": 8, "profile_completeness": 5},
  "assessment": "2-3句话整体评估",
  "account_type": "new/active/growing/mature",
  "positioning_clarity": "清晰/模糊/缺失",
  "current_category": "当前领域",
  "strengths": ["优势1", "优势2"],
  "weaknesses": ["不足1", "不足2"],
  "suggestions": [{"priority": 1, "action": "具体建议", "reason": "原因"}],
  "quick_wins": ["立即可做的改善"],
  "long_term_strategy": "长期策略建议"
}
注意：评分客观公正，建议具体可执行，空账号特别标注。
```

### 6.2 账号定位提示词（account_positioning.txt）

```
#ROLE: 你是一位小红书赛道分析师+个人品牌策略师。
#TASK: 为一个新注册的小红书账号设计完整的定位方案。

## 已知信息
- 性别：{{gender}} / 地区：{{location}} / 兴趣：{{interests|default:"未提供"}}

## 热门赛道参考（按变现潜力排序）
1.美妆护肤 2.穿搭时尚 3.美食探店 4.家居装修 5.健身运动
6.学习考试 7.职场干货 8.母婴育儿 9.数码科技 10.旅行攻略 11.宠物 12.手工DIY

请以纯JSON返回：
{
  "recommended_tracks": [{"category": "", "sub_category": "", "competition_level": "高/中/低", "monetization_potential": "高/中/低", "content_difficulty": "高/中/低", "reason": ""}],
  "best_track": {
    "category": "", "persona": "一句话人设", "differentiator": "差异化定位",
    "target_audience": {"age_range": "", "gender_ratio": "", "interests": [], "pain_points": [], "consumption_habit": ""},
    "nicknames": [{"name": "", "reason": ""}],  // 5个
    "bios": [{"bio": "", "style": ""}],  // 3个
    "avatar_style": "",
    "content_themes": [{"theme": "", "example_title": "", "frequency": ""}],  // 10个
    "posting_schedule": {"frequency": "", "best_times": [], "weekly_plan": ""},
    "growth_milestones": {"first_100_followers": "", "first_1000_followers": "", "monetization_ready": ""},
    "competitor_analysis": {"top_accounts": [], "what_to_learn": "", "how_to_differentiate": ""}
  }
}
要求：昵称2-6字好记有辨识度，简介≤80字含emoji，主题具体可持续3个月+。
```

### 6.3 内容生成提示词（content_generation.txt）

```
#ROLE: 你是一位小红书爆款内容创作者，擅长写出点赞过万的笔记。
#TASK: 根据以下信息创作一篇高质量小红书笔记。

## 账号定位
- 领域：{{category}} / 人设：{{persona}} / 受众：{{target_audience}} / 风格：{{content_style}}
## 本次内容
- 主题：{{topic}} / 类型：{{content_type}} / 关键词：{{keywords}} / 字数：{{word_count}}
## 已发布标题（避免重复）
{{recent_titles}}

## 创作要求
### 标题（5个）
- 含数字或emoji，制造好奇心/痛点，12-20字
- 类型混合：数字型/悬念型/痛点型/对比型/合集型

### 正文结构
【开头Hook】1-2句抓住注意力（提问/数据/反转/共鸣）
【主体】短句为主（≤20字），emoji分段标记(1️⃣2️⃣3️⃣)，信息增量+个人体验，自然植入关键词
【结尾】引导评论（提问式）

### 标签 5-8个（2大流量+3精准+2长尾）

请以纯JSON返回：
{
  "titles": [{"title": "", "type": "数字型/悬念型/痛点型/对比型/合集型"}],
  "recommended_title": "",
  "body": "完整正文（含emoji分段）",
  "tags": ["#标签"],
  "topic": "#话题",
  "image_prompts": ["第1张图描述", "第2张图描述"],
  "seo_keywords": ["关键词"],
  "quality_self_check": {"naturalness_score": 8, "information_value": 7, "engagement_potential": 8, "keyword_integration": 9, "issues": []},
  "best_publish_time": "建议时间"
}
禁止：AI痕迹词（"作为AI"/"根据分析"）、书面化表达、堆砌关键词、夸大宣传、敏感领域建议。
```

### 6.4 评论生成提示词（comment_generation.txt）

```
#ROLE: 你是小红书活跃用户，喜欢在评论区互动。
#TASK: 为以下笔记写一条真实自然的评论。

笔记标题：{{note_title}} / 内容摘要：{{note_content}} / 领域：{{category}}

要求：15-40字，1-2个emoji，像真人写的。
类型随机选一种：认同型/提问型/分享型/补充型/具体夸赞型
禁止：暴露AI身份、常见套话。
直接返回评论文本，不要解释。
```

### 6.5 每日复盘提示词（daily_review.txt）

```
#ROLE: 你是一位数据驱动的小红书运营总监，擅长从数据中发现规律并制定优化策略。
#TASK: 基于今天的运营数据，进行深度复盘分析，并给出明天的优化策略。

## 账号信息
- 昵称：{{nickname}}
- 领域：{{category}}
- 人设：{{persona}}
- 运营阶段：{{operation_stage}}（养号第{{nurturing_day}}天 / 共{{nurturing_total_days}}天）
- 健康度：{{health_score}}/100

## 今日运营数据
### 操作统计
- 浏览：{{browse_minutes}}分钟 / 点赞：{{likes_given}}次 / 评论：{{comments_given}}条
- 收藏：{{collects_given}}次 / 关注：{{follows_given}}个
- 任务完成：{{tasks_completed}}/{{tasks_total}}（失败原因：{{task_fail_reasons}}）

### 今日发布内容表现
{{published_content_data}}

### 已发布内容今日数据变化
{{historical_content_today_data}}

### 账号数据变化
- 粉丝：{{followers_start}} → {{followers_end}}（{{followers_gain}}）
- 获赞：{{likes_start}} → {{likes_end}}
- 健康度：{{health_score_start}} → {{health_score_end}}
- 风控事件：{{risk_events}}

### 昨天复盘的策略调整（如有）
{{yesterday_strategy_updates}}

### 上周同期数据（如有）
{{last_week_same_day_data}}

## 分析要求

请从以下维度深度分析：

### 1. 内容分析
- 哪篇内容数据最好？具体好在哪里？（标题吸引力/发布时间/内容类型/标签效果）
- 哪篇内容数据差？差在哪里？如何改进？
- 什么类型的内容互动率最高？
- 什么类型的内容涨粉效果最好？
- 内容方向是否需要调整？

### 2. 时间分析
- 今天各个发布时间的数据对比
- 哪个时段效果最好/最差？
- 与历史最佳时段是否一致？

### 3. 互动分析
- 点赞/评论/关注的比例是否合理？
- 评论内容的质量如何？
- 互动是否带来了粉丝增长？

### 4. 风控分析
- 健康度变化趋势
- 是否有风控信号？
- 操作强度是否合适？

### 5. 对比分析
- 与昨天相比：进步/退步/持平？
- 与上周同期相比？
- 是否在正确的趋势上？

### 6. 明天策略
- 基于以上分析，明天应该如何调整？
- 具体到：内容方向/发布时间/操作强度/互动策略

## 返回格式（纯JSON）

```json
{
  "today_summary": "一句话总结今天表现",
  "today_score": 8,
  "highlights": ["亮点1", "亮点2"],
  "issues": ["问题1", "问题2"],
  "tomorrow_strategy": {
    "content_adjustments": {
      "increase": ["增加什么内容方向"],
      "decrease": ["减少什么内容方向"],
      "new_try": ["可以尝试的新方向"],
      "avoid": ["需要避免的"]
    },
    "schedule_adjustments": {
      "best_times": ["最佳发布时间"],
      "avoid_times": ["效果差的时间"],
      "reason": "原因说明"
    },
    "intensity_adjustments": {
      "likes": {"current": 18, "suggested": 22, "reason": "原因"},
      "comments": {"current": 4, "suggested": 6, "reason": "原因"},
      "follows": {"current": 2, "suggested": 2, "reason": "原因"},
      "browse_minutes": {"current": 45, "suggested": 45, "reason": "原因"}
    },
    "interaction_adjustments": {
      "focus_on": "互动重点",
      "comment_style": "评论风格建议",
      "follow_target": "关注目标建议"
    },
    "nurturing_adjustments": {
      "next_day_plan": "养号下一天计划（仅养号阶段有效）",
      "transition_prep": "养号转运营准备（仅养号最后2天有效）"
    }
  },
  "trend_analysis": {
    "follower_trend": "粉丝趋势判断",
    "content_trend": "内容趋势判断",
    "risk_assessment": "风控评估"
  },
  "tomorrow_tasks": [
    {"time": "09:30", "action": "browse", "duration": 20},
    {"time": "18:00", "action": "publish", "content_type": "测评类"}
  ]
}
```

## 重要原则
1. 数据驱动，不要凭感觉给建议
2. 建议要具体可执行（具体到数字和时间）
3. 如果今天数据不好，要诚实分析原因，不要粉饰
4. 长期趋势比单天数据更重要
5. 安全第一：如果健康度下降或有风控事件，优先降低强度
6. 返回纯JSON，不要包裹在markdown代码块中
```

### 6.6 其他提示词模板

剩余6个提示词模板（profile_optimization.txt / content_strategy.txt / title_generation.txt / nurturing_strategy.txt / trending_analysis.txt / safety_check.txt）请参照前面章节中的对应定义，格式与上述一致，每个提示词都需要包含明确的ROLE、TASK、输入变量、输出JSON Schema、注意事项。

**safety_check.txt 特别重要**，必须包含：合规性检查、引流检测、真实性检查、AI痕迹检测、质量评估，返回包含 overall_score/passed/compliance/ai痕迹/rewrites 的JSON。---

## 七、防封安全体系

### 7.1 架构分工（无重叠）

| 模块 | 职责 | 何时调用 |
|------|------|---------|
| `fingerprint_spoof.py` | 静态指纹伪装（UA/WebGL/Canvas/Audio/Screen/时区） | 创建Context时注入一次 |
| `behavior_simulator.py` | 动态行为模拟（鼠标轨迹/滚动/打字/延迟） | 每次浏览器操作时 |
| `rate_limiter.py` | 纯频率计算（每日上限/操作间隔/延迟矩阵/时间段权重） | 操作前检查 |
| `anti_ban.py` | 总控制器（协调以上三者 + 风控监控） | 每次操作前后 |
| `risk_monitor.py` | 页面风控信号扫描 + 自动响应策略 | 操作后扫描 |
| `captcha_detector.py` | 验证码检测 + 滑块轨迹生成 | 检测到验证码时 |

### 7.2 浏览器指纹伪装

每个账号绑定固定指纹（创建时生成，永不变更）：
- **Navigator**: webdriver=false, platform, hardware_concurrency, deviceMemory, plugins
- **Screen**: 分辨率(常见8种随机), colorDepth=24, pixel_ratio
- **WebGL**: renderer+vendor(常见7+3组合随机)
- **Canvas**: toBlob/toDataURL时注入微小噪声（固定种子）
- **AudioContext**: getChannelData注入噪声
- **WebRTC**: 阻止泄露本地IP
- **chrome对象**: 模拟chrome.runtime
- **通知权限**: 返回prompt状态

**Playwright注入方式**：`context.add_init_script(js_code)` — 在每个页面的任何脚本执行前注入。

**浏览器启动参数**（关键）：
```python
BROWSER_LAUNCH_ARGS = [
    "--disable-blink-features=AutomationControlled",  # 最关键！
    "--disable-infobars", "--no-sandbox", "--disable-setuid-sandbox",
    "--disable-dev-shm-usage", "--disable-gpu", "--window-size=1280,800",
    "--lang=zh-CN", "--no-first-run", "--no-default-browser-check",
]
```

### 7.3 人类行为模拟

完整配置包含9套行为参数（鼠标/滚动/浏览/点赞/收藏/评论/关注/搜索/杂项）。

关键参数示例：
- 鼠标轨迹：贝塞尔曲线2-5个控制点，每段100-600ms，抖动±1.5px
- 滚动：150-500px/次，减速曲线，12%概率回滚
- 点赞前阅读：3-10秒，点赞间隔：10-90秒，4%概率取消
- 评论前深度阅读：10-30秒，打字速度：3-8字符/秒，8%概率打错修正
- 关注前查看主页：70%概率，停留5-20秒

### 7.4 频率控制

三层限制：全局 > 账号 > 操作类型
- 每日上限：浏览60min/点赞30/收藏10/评论8/关注5/发布3
- 操作间延迟矩阵：不同操作组合不同延迟范围+分布类型（uniform/log_normal/normal）
- 时间段权重：0-7点=禁止，9-12/14-17/19-22=高频，12-14/17-19/22-24=低频
- 周末×1.3倍

### 7.5 风控监控

页面信号检测（验证码弹窗/风险警告/登录过期/限流/页面错误/内容被删）。
账号信号检测（粉丝突降/笔记减少/被封）。
自动响应策略（暂停并通知/退避/重试/停止并通知）。
健康度评分：初始100，验证码-20，限流-10，操作失败-2；每次成功+0.5，每小时无操作+1。
阈值：<30暂停所有操作，<50降低50%频率。

### 7.6 验证码处理

滑块验证码：自动识别轨道 → 贝塞尔曲线拖拽轨迹（起步快→匀速→减速→回弹，800-2000ms）。
图片验证码：全部通知用户手动处理。
通用策略：检测到→停止→截图→通知用户→等待5分钟→检测是否消失→恢复并降频50%持续2h。
同账号24h内触发3次→暂停该账号24h。

---

## 八、中间件 & 基础设施

### 8.1 FastAPI中间件（注册顺序）

1. **RequestIDMiddleware**: 为每个请求生成UUID，注入request.state + 响应头X-Request-ID
2. **RequestLoggingMiddleware**: 记录方法/路径/状态码/耗时，慢请求(>2s)标记warning，静态文件不记录
3. **CORSMiddleware**: 只允许127.0.0.1:8080和localhost:8080
4. **APIRateLimitMiddleware**: 每IP每分钟最多60次，超限返回429
5. **GlobalExceptionMiddleware**: 捕获BusinessError→统一JSON响应；未知异常→记录日志+通用错误
6. **SecurityHeadersMiddleware**: 注入X-Content-Type-Options/X-Frame-Options/X-XSS-Protection，API不缓存

### 8.2 自定义异常体系

所有业务异常继承BusinessError(code, message)。中间件自动捕获并转为统一JSON。

异常类：AccountNotFoundError(2001) / ContentGenerateError(3001) / CaptchaDetectedError(6002) / CookieExpiredError(6003) / AccountHealthLowError(7001) / RateLimitError(7002) / 等共20+个。

### 8.3 AI服务容错

三层容错：
1. **自动重试**：max_retries=3，指数退避，只重试timeout/rate_limit/server_error
2. **熔断器**：连续失败5次→open状态→5分钟后half_open试探
3. **配置降级**：主配置失败→尝试备配置（按优先级链）

Token预算控制：全局每日/每月上限 + 每个配置独立上限，双重检查。

JSON输出：自动解析 + 处理markdown代码块包裹 + 解析失败自动重试。

### 8.4 数据库配置

SQLite WAL模式 + busy_timeout=30s + synchronous=NORMAL + foreign_keys=ON + cache_size=10MB。
写入锁：asyncio.Lock包装所有写操作，防止并发冲突。
迁移检查：首次运行create_all；后续运行检测缺失表/列，自动ADD COLUMN。

### 8.5 内存缓存

TTL过期 + LRU淘汰 + 最大1000条 + @cached装饰器。

### 8.6 前端状态管理

全局Store对象（类Redux），支持：状态订阅/变更通知/持久化偏好到localStorage。
WebSocket客户端：指数退避重连（1s→30s）+ 心跳(30s) + 消息去重 + 离线消息队列 + 断线补发历史。
全局错误处理：window.onerror + unhandledrejection + fetch拦截（超时/429/500统一处理）。

---

## 九、定时任务注册表

```python
SCHEDULED_JOBS = {
    # 账号维护
    "daily_cookie_check":     "cron 6:00 - CookieManager.daily_check",
    "daily_account_refresh":  "cron 7:00 - AccountService.refresh_all_online",
    "daily_plan_generator":   "cron 7:30 - StrategyEngine.generate_all_daily_plans",
    "daily_action_counter_reset": "cron 0:00 - AccountService.reset_daily_counters",
    "daily_security_scan":    "cron 5:00 - SystemService.daily_security_scan",

    # 任务调度
    "task_dispatcher":        "interval 10s - TaskExecutor.dispatch_pending_tasks",

    # 内容
    "scheduled_content_publisher": "interval 1min - ContentPublisher.publish_scheduled",
    "content_idea_generator": "cron 21:00 - ContentGenerator.batch_generate_ideas",
    "auto_content_continuum": "cron 22:30 - ContentContinuum.check_and_fill",

    # 复盘
    "daily_review":             "cron 22:00 - DailyReviewService.review_all_active",

    # 数据
    "content_stats_collector": "interval 2h - DataCollector.collect_all_due",

    # 互动
    "comment_reply_checker":  "interval 3h - InteractionManager.check_all_comments",

    # 监控
    "alert_checker":          "interval 1h - AlertSystem.check_all_alerts",
    "competitor_checker":     "cron 23:00 - CompetitorMonitor.check_all",

    # 报告
    "weekly_report":          "cron Sunday 22:15 - ReportGenerator.generate_weekly",
    "monthly_report":         "cron 28th 22:15 - ReportGenerator.generate_monthly",

    # 清理
    "data_cleanup":           "cron 3:00 - SystemService.cleanup_old_data",
    "database_vacuum":        "cron Sunday 4:00 - SystemService.vacuum_database",
}
```

---

## 十、启动序列 & 崩溃恢复

### 10.1 启动时序

```
Phase 0 - 预检（lifespan进入前，最先执行）:
  0.1  Diagnostics.run_startup_checks() → 输出诊断报告
  0.2  如果有 critical 错误 → 输出报告 → 退出（不进入lifespan）
  0.3  如果有 warning → 输出警告 → 继续启动
  0.4  尝试自动修复 safe=True 的问题（依赖包/Playwright/config）

Phase 1 - 基础设施:
  1.1 创建data/目录结构
  1.2 初始化Loguru日志系统
  1.3 初始化/验证encryption.key
  1.4 初始化数据库引擎（SQLite+WAL）
  1.5 执行数据库迁移检查（新表/新列自动添加）
  1.6 崩溃恢复（见10.2）

Phase 2 - 配置加载:
  2.1 读取config.yaml + 合并数据库system_settings
  2.2 校验配置合法性（必填项/格式/范围/冲突）
  2.3 加载AI配置（解密API Key）
  2.4 加载敏感词库（构建Aho-Corasick自动机）

Phase 3 - 服务初始化:
  3.1 启动Playwright + 创建浏览器实例（含反检测参数）
  3.2 初始化浏览器池
  3.3 初始化内存缓存
  3.4 初始化所有Service实例
  3.5 为每个online账号恢复BrowserContext

Phase 4 - 后台任务:
  4.1 初始化APScheduler + 注册所有定时任务
  4.2 启动调度器

Phase 5 - 就绪:
  5.1 挂载静态文件 + 注册路由
  5.2 打开浏览器 http://127.0.0.1:8080
  5.3 打印启动完成日志
```

### 10.2 崩溃恢复

```
场景1: 上次有running任务 → 标记pending(5分钟后重试)/failed(重试耗尽)
场景2: 上次有online账号 → 标记offline(需重新验证)
场景3: 上次有publishing内容 → 标记safety_passed(可重新发布)
场景4: 上次有paused任务(验证码) → 检查是否超24h → 超过则恢复pending
```

### 10.3 优雅关闭

```
1. 停止APScheduler
2. 等待运行中任务完成（最多30s）
3. 超时→标记paused
4. 关闭所有BrowserContext（保存Cookie）
5. 关闭Playwright
6. 关闭数据库连接
7. 刷新日志
```

---

## 十一、配置文件（config.example.yaml）

```yaml
server:
  host: "127.0.0.1"
  port: 8080
  debug: false
  auto_open_browser: true

ai:
  default_config_id: ""
  fallback:
    provider: "deepseek"
    api_key: ""
    base_url: "https://api.deepseek.com/v1"
    model: "deepseek-chat"
    max_tokens: 4096
    temperature: 0.7

browser:
  headless: false
  timeout_ms: 30000
  viewport: { width: 1280, height: 800 }
  max_concurrent_contexts: 3
  context_idle_timeout: 30

operation:
  max_concurrent_accounts: 3
  max_concurrent_tasks_per_account: 1
  intensity: "standard"  # conservative/standard/aggressive/custom
  nurturing:
    enabled: true
    total_days: 7
  publishing:
    daily_limit: 3
    min_interval_hours: 4
    recommended_times: ["07:30", "12:00", "18:00", "21:00"]
  action_delay:
    min: 15
    max: 120
    consecutive_multiplier: 1.2
  active_hours:
    - { start: "09:00", end: "12:00", intensity: "high" }
    - { start: "12:00", end: "14:00", intensity: "low" }
    - { start: "14:00", end: "17:00", intensity: "high" }
    - { start: "17:00", end: "20:00", intensity: "low" }
    - { start: "20:00", end: "23:00", intensity: "high" }
  daily_limits:
    browse_minutes: 45
    likes: 20
    collects: 5
    comments: 5
    follows: 3
    publishes: 3

anti_detection:
  enabled: true
  mouse_simulation: true
  scroll_simulation: true
  fingerprint_spoofing: true
  ua_pool_size: 50

proxy:
  enabled: false
  global_proxy: ""

content_safety:
  enabled: true
  pipeline: { rule_engine: true, ai_review: true, auto_dehumanize: true, require_manual_review: false }
  thresholds: { rule_block: "high_risk", ai_pass_score: 5, ai_humanize_score: 6, max_rewrite_retries: 2 }

interaction:
  auto_reply_enabled: true
  reply_check_interval_hours: 3
  max_replies_per_day: 15
  reply_delay_range: [30, 120]
  ignore_ad_comments: true

alerts:
  enabled: true
  channels: [websocket, log]
  rules:
    follower_surge_threshold: 200
    follower_drop_threshold: 5
    viral_content_threshold: 300
    content_tank_view_threshold: 100
    cookie_expire_warning_days: 3

reports:
  weekly_report: { enabled: true, day: "sunday", time: "22:00" }
  monthly_report: { enabled: true, day: 28, time: "22:00" }

competitor:
  enabled: true
  auto_discover: true
  max_competitors: 10
  check_interval_hours: 24

ab_test:
  enabled: false
  min_title_variants: 3
  test_duration_hours: 48

data_collection:
  schedule_after_publish: [2, 6, 24, 48]
  continue_days: 7

logging:
  level: "INFO"
  file: "data/logs/app.log"
  max_size_mb: 50
  backup_count: 10
  screenshots_on_error: true
```

---

## 十二、requirements.txt

```
fastapi==0.115.6
uvicorn[standard]==0.34.0
sqlalchemy==2.0.36
aiosqlite==0.20.0
pydantic==2.10.0
pydantic-settings==2.7.0
playwright==1.49.0
apscheduler==3.10.4
openai==1.58.0
pyyaml==6.0.2
python-multipart==0.0.19
websockets==14.1
httpx==0.28.0
pillow==11.0.0
loguru==0.7.3
cryptography==44.0.0
pyahocorasick==2.1.0       # 纯Python Aho-Corasick，跨平台无需编译
jieba==0.42.1
openpyxl==3.1.5
jinja2==3.1.4
```

---

## 十三、start.bat

```batch
@echo off
chcp 65001 >nul
title 小红书AI全自动运营平台

echo.
echo  ╔══════════════════════════════════════╗
echo  ║   🔴 小红书AI全自动运营平台 v1.0      ║
echo  ╚══════════════════════════════════════╝
echo.

python --version 2>&1 | findstr /R "^Python 3\.1[0-9]" >nul
if errorlevel 1 (
    echo  [❌] 需要 Python 3.10+
    echo  下载: https://www.python.org/downloads/
    echo  安装时请勾选 "Add Python to PATH"
    pause & exit /b 1
)
for /f "tokens=2" %%i in ('python --version 2^>^&1') do echo  [✓] Python %%i

if not exist "venv" (
    echo  [⏳] 创建虚拟环境...
    python -m venv venv
    if errorlevel 1 ( echo  [❌] 虚拟环境创建失败 & pause & exit /b 1 )
)
call venv\Scripts\activate.bat

echo  [⏳] 检查依赖...
pip install -r requirements.txt -q --disable-pip-version-check 2>nul
if errorlevel 1 (
    echo  [⏳] 安装依赖中（首次较慢）...
    pip install -r requirements.txt --disable-pip-version-check
)

echo  [⏳] 检查浏览器驱动...
python -c "from playwright.sync_api import sync_playwright; p = sync_playwright().start(); p.stop()" 2>nul
if errorlevel 1 ( echo  [⏳] 安装 Chromium... & playwright install chromium )

if not exist "config.yaml" (
    if exist "config.example.yaml" ( copy config.example.yaml config.yaml >nul )
    echo  [⚠️] 已创建 config.yaml，请编辑填入 AI API Key 后重新运行！
    notepad config.yaml & pause & exit /b 0
)

if not exist "data" mkdir data
if not exist "data\accounts" mkdir data\accounts
if not exist "data\materials\images" mkdir data\materials\images
if not exist "data\logs" mkdir data\logs
if not exist "data\safety" mkdir data\safety

echo.
echo  [🚀] 启动服务中...
echo  [🌐] 访问地址: http://127.0.0.1:8080
echo.
python main.py
if errorlevel 1 ( echo  [❌] 服务异常退出 & pause )
```

---

## 十四、开发硬性要求

### 14.1 代码质量
1. 每个模块有docstring，复杂逻辑有行内注释
2. 所有函数参数和返回值使用typing
3. 每个可能失败的操作都有try/except（使用BusinessError子类）
4. 所有API输入使用Pydantic Schema校验
5. 100%使用ORM，禁止拼接SQL

### 14.2 安全性
1. API Key + Cookie使用Fernet加密存储
2. 只绑定127.0.0.1，不暴露外网
3. CORS只允许本域
4. 日志不记录敏感信息
5. 上传文件类型白名单 + 验证magic bytes

### 14.3 稳定性
1. 浏览器Context崩溃自动重建
2. 失败任务自动重试3次（指数退避）
3. Ctrl+C优雅退出（清理浏览器）
4. 关键操作立即commit，不依赖内存状态
5. 崩溃恢复（running→pending, publishing→safety_passed）

### 14.4 用户体验
1. 首次启动自动安装依赖+创建配置+打开浏览器
2. 所有异步操作有loading状态
3. 用户友好的错误信息
4. 删除/批量操作需要二次确认
5. WebSocket断开时顶部显示横幅

### 14.5 Windows兼容
1. 全部使用pathlib.Path
2. 文件读写统一UTF-8
3. 子进程使用CREATE_NO_WINDOW

### 14.6 防封硬性要求
1. 每个账号绑定独立指纹（UA/WebGL/Canvas/屏幕分辨率），创建时生成，永不变更
2. 任何浏览器操作前后必须有随机延迟（对数正态分布）
3. 检测到验证码/风控弹窗/操作被拒时，必须立即停止并通知用户
4. 健康度<30自动停止，<50降低50%频率
5. 0:00-7:00禁止所有浏览器操作
6. 不同账号的BrowserContext完全隔离

### 14.7 内容安全硬性要求
1. 发布前必须通过规则引擎+AI双重审核
2. 敏感词库覆盖政治/色情/暴力/医疗/金融/引流6大类
3. AI生成内容必须经过去AI化处理
4. 禁止绝对化用语（最好/第一/100%有效）
5. 自动检测并拦截微信号/QQ号/手机号/外链
6. 审核不通过的内容自动重写，最多2次

---

## 十五、生成指令

请按以下顺序逐文件生成完整代码：

```
Phase 0 - 项目骨架: requirements.txt, config.example.yaml, config.yaml, start.bat, README.md, pyproject.toml
Phase 1 - 数据层: config.py, database.py, models.py(全部17个模型), schemas.py
Phase 2 - 基础设施: core/ 全部13个文件
Phase 3 - 业务服务: services/ 全部28个文件
Phase 4 - API层: api/ 全部13个文件
Phase 5 - 应用入口: app/main.py, main.py
Phase 6 - 前端: css/8个文件, index.html, js/14个文件
Phase 7 - 提示词: prompts/ 11个文件
Phase 8 - 测试: tests/ 9个文件
```

**硬性约束**：
1. 禁止使用 pass / # TODO / # 实现省略 / ... 作为函数体
2. 每个函数必须有完整逻辑实现
3. 状态转换必须在代码中强制校验
4. 安全审核必须在发布前执行（不可跳过）
5. 所有模型字段必须与第二节一致（唯一权威定义）
6. 所有service方法必须与定时任务注册表一致
7. 前端每个<template>必须包含完整HTML
8. 前端每个JS文件必须包含完整函数实现
9. CSS不使用硬编码颜色/间距（全部用CSS变量）
10. API路由必须与第四节完全一致
