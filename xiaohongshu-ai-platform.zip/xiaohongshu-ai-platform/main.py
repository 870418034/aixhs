"""
启动入口：lifespan管理 + 启动序列 + 优雅关闭
"""
import uvicorn
from app.main import create_app

# Phase 0: 预检 — 由 lifespan 启动序列完成
# Phase 1-5: 在 app/main.py 的 lifespan 中执行

if __name__ == "__main__":
    uvicorn.run(
        "app.main:create_app",
        host="127.0.0.1",
        port=8080,
        factory=True,
        log_level="info",
    )
