# 小红书AI全自动运营平台

基于 AI 驱动的小红书自动化运营工具，支持多账号管理、智能内容创作、定时发布、数据分析等功能。

## 技术栈

- **后端框架**: FastAPI + Uvicorn
- **数据库**: SQLite (异步, SQLAlchemy 2.0 + aiosqlite)
- **浏览器自动化**: Playwright (Chromium)
- **AI 集成**: OpenAI 兼容 API (支持 DeepSeek 等)
- **任务调度**: APScheduler
- **前端**: Web 管理面板 (WebSocket 实时通信)
- **内容安全**: 自定义规则引擎 + AI 审查

## 快速开始

### 环境要求

- Python 3.10+
- Windows / Linux / macOS

### 安装与启动

**Windows (一键启动)**:
```batch
start.bat
```

**手动启动**:
```bash
# 创建虚拟环境
python -m venv venv
source venv/bin/activate  # Linux/macOS
# venv\Scripts\activate   # Windows

# 安装依赖
pip install -r requirements.txt

# 安装浏览器驱动
playwright install chromium

# 配置
cp config.example.yaml config.yaml
# 编辑 config.yaml，填入 AI API Key

# 启动
python main.py
```

启动后访问: **http://127.0.0.1:8080**

## 目录结构

```
xiaohongshu-ai-platform/
├── main.py                  # 应用入口
├── config.example.yaml      # 配置模板
├── config.yaml              # 运行配置 (gitignore)
├── requirements.txt         # Python 依赖
├── pyproject.toml           # 项目元数据
├── start.bat                # Windows 一键启动
├── app/
│   ├── __init__.py
│   ├── server.py            # FastAPI 服务
│   ├── database.py          # 数据库模型与初始化
│   ├── browser/
│   │   ├── __init__.py
│   │   ├── manager.py       # Playwright 上下文管理
│   │   ├── anti_detection.py # 反检测策略
│   │   └── xiaohongshu.py   # 小红书页面交互
│   ├── ai/
│   │   ├── __init__.py
│   │   ├── llm.py           # LLM 调用封装
│   │   ├── content_gen.py   # 内容生成
│   │   └── safety.py        # 内容安全审查
│   ├── operation/
│   │   ├── __init__.py
│   │   ├── account.py       # 账号管理
│   │   ├── nurturing.py     # 养号逻辑
│   │   ├── publisher.py     # 发布逻辑
│   │   └── interaction.py   # 互动管理
│   ├── scheduler/
│   │   ├── __init__.py
│   │   └── jobs.py          # 定时任务
│   ├── analysis/
│   │   ├── __init__.py
│   │   ├── collector.py     # 数据采集
│   │   └── reports.py       # 报表生成
│   ├── alerts/
│   │   ├── __init__.py
│   │   └── monitor.py       # 告警监控
│   └── web/
│       ├── __init__.py
│       ├── router.py        # API 路由
│       ├── websocket.py     # WebSocket 管理
│       └── static/          # 前端静态资源
│           ├── index.html
│           ├── css/
│           └── js/
├── data/                    # 运行数据 (gitignore)
│   ├── accounts/            # 账号数据与 Cookie
│   ├── materials/           # 素材库
│   │   └── images/          # 图片素材
│   ├── logs/                # 日志文件
│   └── safety/              # 内容安全数据库
└── templates/               # 内容模板
```

## 功能特性

### 🤖 AI 智能内容创作
- 支持多模型切换（DeepSeek、GPT 等 OpenAI 兼容 API）
- 自动生成标题、正文、话题标签
- 内容安全审查（规则引擎 + AI 双重审核）
- 自动人性化改写，降低 AI 检测风险

### 📱 多账号管理
- 支持同时管理多个小红书账号
- Cookie 自动保存与恢复
- 账号隔离，独立调度

### ⏰ 智能发布调度
- 自定义发布时段与推荐时间
- 发布间隔自动随机化
- 每日发布数量控制
- 养号期模拟真实用户行为

### 🔍 反检测策略
- 模拟真实鼠标轨迹与滚动行为
- 浏览器指纹伪装
- UA 池随机切换
- 操作延迟模拟人类节奏

### 📊 数据分析
- 发布后自动采集数据（阅读、点赞、收藏、评论）
- 竞品自动发现与监控
- 周报 / 月报自动生成
- A/B 测试支持

### 💬 自动互动
- 自动回复评论
- 智能筛选广告评论
- 回复间隔随机化

### 🚨 命警系统
- 粉丝数暴涨 / 暴跌告警
- 爆款内容提醒
- Cookie 过期预警
- WebSocket 实时推送

## 配置说明

编辑 `config.yaml` 进行配置，主要字段说明：

### AI 配置
```yaml
ai:
  fallback:
    api_key: "your-api-key"       # AI API 密钥
    base_url: "https://..."       # API 端点
    model: "deepseek-chat"        # 模型名称
```

### 运营参数
```yaml
operation:
  publishing:
    daily_limit: 3                # 每日最大发布数
    recommended_times: ["07:30", "12:00", "18:00", "21:00"]
  daily_limits:
    likes: 20                     # 每日最大点赞数
    comments: 5                   # 每日最大评论数
```

### 反检测
```yaml
anti_detection:
  enabled: true
  ua_pool_size: 50                # UA 池大小
```

更多配置项请参考 `config.example.yaml` 中的注释。

## 常见问题

### Q: 安装依赖报错？
确保 Python 版本 >= 3.10，建议使用虚拟环境。

### Q: Playwright 安装失败？
```bash
playwright install chromium
# 或手动下载
python -m playwright install chromium
```

### Q: 浏览器无法启动？
检查是否有 Chromium 相关进程残留，或尝试设置 `browser.headless: true`。

### Q: AI 生成质量不佳？
- 调整 `ai.fallback.temperature`（降低更稳定）
- 检查 `ai.fallback.max_tokens` 是否足够
- 尝试更换模型

### Q: 如何添加新的 AI 模型？
通过 Web 面板的「AI 配置」页面添加，支持任何 OpenAI 兼容 API。

### Q: 数据存储在哪里？
所有数据存储在 `data/` 目录下，包括账号、日志、素材等。

## License

Private - All rights reserved.
