"""Cookie元数据模型。"""

from __future__ import annotations

from datetime import datetime
from uuid import uuid4

from sqlalchemy import Boolean, Column, DateTime, ForeignKey, Integer, String, func
from sqlalchemy.orm import relationship

from app.database import Base


def uuid4_str() -> str:
    return str(uuid4())


class CookieMeta(Base):
    __tablename__ = "cookie_meta"

    account_id = Column(String(36), ForeignKey("accounts.id"), primary_key=True)
    created_at = Column(DateTime, default=func.now())
    expires_at = Column(DateTime, nullable=True)
    last_verified = Column(DateTime, nullable=True)
    refresh_count = Column(Integer, default=0)
    status = Column(String(20), default="valid")
    warning_sent = Column(Integer, default=0)

    # 关系
    account = relationship("Account", back_populates="cookie_meta")
