"""每日复盘模型。"""

from __future__ import annotations

from datetime import date, datetime
from uuid import uuid4

from sqlalchemy import Boolean, Column, Date, DateTime, ForeignKey, Integer, String, Text, UniqueConstraint, func
from sqlalchemy.orm import relationship

from app.database import Base


def uuid4_str() -> str:
    return str(uuid4())


class DailyReview(Base):
    __tablename__ = "daily_reviews"
    __table_args__ = (UniqueConstraint("account_id", "review_date", name="uq_account_review_date"),)

    id = Column(String(36), primary_key=True, default=uuid4_str)
    account_id = Column(String(36), ForeignKey("accounts.id"), nullable=False)
    review_date = Column(Date, nullable=False)
    today_score = Column(Integer, default=0)
    today_summary = Column(Text, default="")
    highlights = Column(Text, default="[]")
    issues = Column(Text, default="[]")
    followers_start = Column(Integer, default=0)
    followers_end = Column(Integer, default=0)
    followers_gain = Column(Integer, default=0)
    content_published = Column(Integer, default=0)
    total_views = Column(Integer, default=0)
    total_engagement = Column(Integer, default=0)
    tasks_completed = Column(Integer, default=0)
    tasks_failed = Column(Integer, default=0)
    health_score = Column(Integer, default=100)
    strategy_updates = Column(Text, default="[]")
    tomorrow_tasks = Column(Text, default="[]")
    trend_analysis = Column(Text, default="[]")
    applied_to_plan = Column(Integer, default=0)
    created_at = Column(DateTime, default=func.now())

    # 关系
    account = relationship("Account", back_populates="daily_reviews")
