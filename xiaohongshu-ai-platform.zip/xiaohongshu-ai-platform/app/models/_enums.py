"""枚举类型定义。"""

from __future__ import annotations

import enum


class AccountStatus(str, enum.Enum):
    offline = "offline"
    online = "online"
    verifying = "verifying"
    banned = "banned"
    paused = "paused"
    error = "error"


class OperationStatus(str, enum.Enum):
    idle = "idle"
    analyzing = "analyzing"
    positioning = "positioning"
    preparing = "preparing"
    nurturing = "nurturing"
    active = "active"
    paused = "paused"


class ContentType(str, enum.Enum):
    note = "note"
    video = "video"
    image = "image"


class ContentStatus(str, enum.Enum):
    draft = "draft"
    reviewing = "reviewing"
    rejected = "rejected"
    approved = "approved"
    publishing = "publishing"
    published = "published"
    failed = "failed"
    scheduled = "scheduled"


class TaskType(str, enum.Enum):
    publish = "publish"
    like = "like"
    comment = "comment"
    collect = "collect"
    follow = "follow"
    browse = "browse"
    analyze = "analyze"
    generate = "generate"
    review = "review"


class TaskStatus(str, enum.Enum):
    pending = "pending"
    running = "running"
    completed = "completed"
    failed = "failed"
    cancelled = "cancelled"
    paused = "paused"


class NotificationLevel(str, enum.Enum):
    info = "info"
    warning = "warning"
    error = "error"
    success = "success"


class ReportType(str, enum.Enum):
    daily = "daily"
    weekly = "weekly"
    monthly = "monthly"
