"""AI配置模型。"""

from __future__ import annotations

from datetime import datetime
from uuid import uuid4

from sqlalchemy import Boolean, Column, DateTime, Float, Integer, String, Text, func
from sqlalchemy.orm import relationship

from app.database import Base


def uuid4_str() -> str:
    return str(uuid4())


class AIConfig(Base):
    __tablename__ = "ai_configs"

    id = Column(String(36), primary_key=True, default=uuid4_str)
    name = Column(String(100), default="")
    provider = Column(String(30), default="")
    api_key_encrypted = Column(Text, default="")
    base_url = Column(String(500), default="")
    model = Column(String(100), default="")
    max_tokens = Column(Integer, default=4096)
    temperature = Column(Float, default=0.7)
    is_default = Column(Integer, default=0)
    total_requests = Column(Integer, default=0)
    total_tokens = Column(Integer, default=0)
    last_used = Column(DateTime, nullable=True)
    created_at = Column(DateTime, default=func.now())

    # 关系
    token_usage = relationship("TokenUsage", back_populates="ai_config", lazy="dynamic")
