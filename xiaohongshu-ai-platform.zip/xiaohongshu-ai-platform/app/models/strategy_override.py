"""策略覆盖模型。"""

from __future__ import annotations

from datetime import date, datetime
from uuid import uuid4

from sqlalchemy import Boolean, Column, Date, DateTime, ForeignKey, Integer, String, Text, func
from sqlalchemy.orm import relationship

from app.database import Base


def uuid4_str() -> str:
    return str(uuid4())


class StrategyOverride(Base):
    __tablename__ = "strategy_overrides"

    id = Column(String(36), primary_key=True, default=uuid4_str)
    account_id = Column(String(36), ForeignKey("accounts.id"), nullable=False)
    target_date = Column(Date, nullable=False)
    content_directions = Column(Text, default="[]")
    schedule_adjustments = Column(Text, default="[]")
    intensity_adjustments = Column(Text, default="[]")
    interaction_adjustments = Column(Text, default="[]")
    suggested_tasks = Column(Text, default="[]")
    review_id = Column(String(36), default="")
    is_used = Column(Integer, default=0)
    created_at = Column(DateTime, default=func.now())
    used_at = Column(DateTime, nullable=True)

    # 关系
    account = relationship("Account", back_populates="strategy_overrides")
