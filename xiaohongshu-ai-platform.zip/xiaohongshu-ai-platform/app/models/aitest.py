"""A/B测试记录模型。"""

from __future__ import annotations

from datetime import datetime
from uuid import uuid4

from sqlalchemy import Column, DateTime, Float, Integer, String, Text, func

from app.database import Base


def uuid4_str() -> str:
    return str(uuid4())


class ABTestRecord(Base):
    __tablename__ = "ab_test_records"

    id = Column(String(36), primary_key=True, default=uuid4_str)
    account_id = Column(String(36), default="")
    original_content_id = Column(String(36), default="")
    variant_title = Column(String(200), default="")
    variant_content_id = Column(String(36), default="")
    test_status = Column(String(20), default="running")
    views = Column(Integer, default=0)
    likes = Column(Integer, default=0)
    collects = Column(Integer, default=0)
    score = Column(Float, default=0.0)
    created_at = Column(DateTime, default=func.now())
