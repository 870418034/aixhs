"""Comment 模型 — 评论记录。"""

from __future__ import annotations

from sqlalchemy import Column, DateTime, ForeignKey, Integer, String, Text, func
from sqlalchemy.orm import relationship

from app.database import Base


class Comment(Base):
    __tablename__ = "comments"

    id = Column(Integer, primary_key=True, autoincrement=True)
    account_id = Column(Integer, ForeignKey("accounts.id"))
    content_id = Column(Integer, ForeignKey("contents.id"), nullable=True)
    note_id = Column(String(50), default="")
    comment_text = Column(Text, default="")
    reply_text = Column(Text, default="")
    is_replied = Column(Integer, default=0)
    created_at = Column(DateTime, default=func.now())

    account = relationship("Account", back_populates="comments")
    content = relationship("Content", back_populates="comments")
