"""素材模型。"""

from __future__ import annotations

from datetime import datetime
from uuid import uuid4

from sqlalchemy import Column, DateTime, Integer, String, Text, func

from app.database import Base


def uuid4_str() -> str:
    return str(uuid4())


class Material(Base):
    __tablename__ = "materials"

    id = Column(String(36), primary_key=True, default=uuid4_str)
    file_path = Column(String(500), default="")
    file_type = Column(String(20), default="")
    thumbnail_path = Column(String(500), default="")
    category = Column(String(50), default="")
    tags = Column(Text, default="[]")
    ai_description = Column(Text, default="")
    usage_count = Column(Integer, default=0)
    width = Column(Integer, default=0)
    height = Column(Integer, default=0)
    file_size = Column(Integer, default=0)
    created_at = Column(DateTime, default=func.now())
