"""PositioningResult 模型 — 账号定位分析结果。"""

from __future__ import annotations

from sqlalchemy import Column, DateTime, ForeignKey, Integer, String, Text, func
from sqlalchemy.orm import relationship

from app.database import Base


class PositioningResult(Base):
    __tablename__ = "positioning_results"

    id = Column(Integer, primary_key=True, autoincrement=True)
    account_id = Column(Integer, ForeignKey("accounts.id"))
    niche = Column(Text, default="")
    target_audience = Column(Text, default="")
    content_style = Column(Text, default="")
    tone = Column(Text, default="")
    keywords = Column(Text, default="[]")
    strategy = Column(Text, default="")
    created_at = Column(DateTime, default=func.now())

    account = relationship("Account", back_populates="positioning_results")
