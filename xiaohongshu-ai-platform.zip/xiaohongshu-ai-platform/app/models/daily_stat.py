"""每日统计模型。"""

from __future__ import annotations

from datetime import date, datetime
from uuid import uuid4

from sqlalchemy import Column, Date, DateTime, ForeignKey, Integer, String, UniqueConstraint, func
from sqlalchemy.orm import relationship

from app.database import Base


def uuid4_str() -> str:
    return str(uuid4())


class DailyStat(Base):
    __tablename__ = "daily_stats"
    __table_args__ = (UniqueConstraint("account_id", "date", name="uq_account_date"),)

    id = Column(String(36), primary_key=True, default=uuid4_str)
    account_id = Column(String(36), ForeignKey("accounts.id"), nullable=False)
    date = Column(Date, nullable=False)
    followers = Column(Integer, default=0)
    following = Column(Integer, default=0)
    likes = Column(Integer, default=0)
    notes_count = Column(Integer, default=0)
    followers_gain = Column(Integer, default=0)
    likes_gain = Column(Integer, default=0)
    browse_count = Column(Integer, default=0)
    like_count = Column(Integer, default=0)
    collect_count = Column(Integer, default=0)
    comment_count = Column(Integer, default=0)
    follow_count = Column(Integer, default=0)
    publish_count = Column(Integer, default=0)
    total_views = Column(Integer, default=0)
    total_content_likes = Column(Integer, default=0)
    total_content_collects = Column(Integer, default=0)
    total_content_shares = Column(Integer, default=0)
    created_at = Column(DateTime, default=func.now())

    # 关系
    account = relationship("Account", back_populates="daily_stats")
