"""任务模型。"""

from __future__ import annotations

from datetime import datetime
from uuid import uuid4

from sqlalchemy import Column, DateTime, ForeignKey, Integer, String, Text, func
from sqlalchemy.orm import relationship

from app.database import Base


def uuid4_str() -> str:
    return str(uuid4())


class Task(Base):
    __tablename__ = "tasks"

    id = Column(String(36), primary_key=True, default=uuid4_str)
    account_id = Column(String(36), ForeignKey("accounts.id"), nullable=False)
    task_type = Column(String(30), default="")
    priority = Column(Integer, default=0)
    params = Column(Text, default="{}")
    status = Column(String(20), default="pending")
    progress = Column(Integer, default=0)
    result = Column(Text, default="{}")
    error_msg = Column(Text, default="")
    retry_count = Column(Integer, default=0)
    max_retries = Column(Integer, default=3)
    scheduled_at = Column(DateTime, nullable=True)
    started_at = Column(DateTime, nullable=True)
    completed_at = Column(DateTime, nullable=True)
    created_at = Column(DateTime, default=func.now())

    # 关系
    account = relationship("Account", back_populates="tasks")
