"""系统模型：ActivityLog, SystemSetting, TokenUsage。"""

from __future__ import annotations

from datetime import date, datetime
from uuid import uuid4

from sqlalchemy import Column, Date, DateTime, Float, ForeignKey, Integer, String, Text, UniqueConstraint, func
from sqlalchemy.orm import relationship

from app.database import Base


def uuid4_str() -> str:
    return str(uuid4())


class ActivityLog(Base):
    __tablename__ = "activity_logs"

    id = Column(String(36), primary_key=True, default=uuid4_str)
    account_id = Column(String(36), default="")
    level = Column(String(10), default="info")
    action = Column(String(50), default="")
    detail = Column(Text, default="")
    extra_data = Column(Text, default="{}")
    created_at = Column(DateTime, default=func.now())


class SystemSetting(Base):
    __tablename__ = "system_settings"

    key = Column(String(100), primary_key=True)
    value = Column(Text, default="")
    updated_at = Column(DateTime, default=func.now(), onupdate=func.now())


class TokenUsage(Base):
    __tablename__ = "token_usage"
    __table_args__ = (UniqueConstraint("ai_config_id", "date", "purpose", name="uq_config_date_purpose"),)

    id = Column(String(36), primary_key=True, default=uuid4_str)
    ai_config_id = Column(String(36), ForeignKey("ai_configs.id"), nullable=False)
    date = Column(Date, nullable=False)
    purpose = Column(String(50), default="")
    request_count = Column(Integer, default=0)
    prompt_tokens = Column(Integer, default=0)
    completion_tokens = Column(Integer, default=0)
    total_tokens = Column(Integer, default=0)
    estimated_cost = Column(Float, default=0.0)
    created_at = Column(DateTime, default=func.now())

    # 关系
    ai_config = relationship("AIConfig", back_populates="token_usage")
