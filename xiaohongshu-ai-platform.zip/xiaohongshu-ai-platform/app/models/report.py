"""报告模型。"""

from __future__ import annotations

from datetime import date, datetime
from uuid import uuid4

from sqlalchemy import Column, Date, DateTime, String, Text, func

from app.database import Base


def uuid4_str() -> str:
    return str(uuid4())


class Report(Base):
    __tablename__ = "reports"

    id = Column(String(36), primary_key=True, default=uuid4_str)
    report_type = Column(String(20), default="daily")
    account_id = Column(String(36), default="")
    period_start = Column(Date, nullable=True)
    period_end = Column(Date, nullable=True)
    summary = Column(Text, default="{}")
    ai_analysis = Column(Text, default="")
    suggestions = Column(Text, default="[]")
    highlights = Column(Text, default="[]")
    file_path = Column(String(500), default="")
    created_at = Column(DateTime, default=func.now())
