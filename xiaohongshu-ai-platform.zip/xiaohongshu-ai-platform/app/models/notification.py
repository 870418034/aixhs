"""通知模型。"""

from __future__ import annotations

from datetime import datetime
from uuid import uuid4

from sqlalchemy import Boolean, Column, DateTime, Integer, String, Text, func

from app.database import Base


def uuid4_str() -> str:
    return str(uuid4())


class Notification(Base):
    __tablename__ = "notifications"

    id = Column(String(36), primary_key=True, default=uuid4_str)
    level = Column(String(10), default="info")
    title = Column(String(200), default="")
    message = Column(Text, default="")
    account_id = Column(String(36), default="")
    related_type = Column(String(30), default="")
    related_id = Column(String(36), default="")
    action_url = Column(String(200), default="")
    is_read = Column(Integer, default=0)
    created_at = Column(DateTime, default=func.now())
