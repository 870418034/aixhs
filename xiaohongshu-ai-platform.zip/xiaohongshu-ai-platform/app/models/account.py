"""账号模型。"""

from __future__ import annotations

from datetime import datetime
from uuid import uuid4

from sqlalchemy import Column, DateTime, Float, Integer, String, Text, func
from sqlalchemy.orm import relationship

from app.database import Base


def uuid4_str() -> str:
    return str(uuid4())


class Account(Base):
    __tablename__ = "accounts"

    id = Column(String(36), primary_key=True, default=uuid4_str)
    nickname = Column(String(100), default="")
    xhs_id = Column(String(50), default="")
    avatar_url = Column(Text, default="")
    bio = Column(Text, default="")
    gender = Column(Integer, default=0)
    ip_location = Column(String(50), default="")
    followers = Column(Integer, default=0)
    following = Column(Integer, default=0)
    likes = Column(Integer, default=0)
    notes_count = Column(Integer, default=0)
    account_type = Column(String(20), default="unknown")
    positioning = Column(Text, default="{}")
    operation_stage = Column(String(20), default="idle")
    nurturing_day = Column(Integer, default=0)
    nurturing_total_days = Column(Integer, default=7)
    status = Column(String(20), default="offline")
    login_method = Column(String(20), default="")
    cookie_path = Column(String(255), default="")
    proxy = Column(String(200), default="")
    user_agent = Column(Text, default="")
    total_published = Column(Integer, default=0)
    today_actions = Column(Integer, default=0)
    health_score = Column(Integer, default=100)
    fingerprint = Column(Text, default="{}")
    risk_history = Column(Text, default="[]")
    captcha_count_today = Column(Integer, default=0)
    last_captcha_at = Column(DateTime, nullable=True)
    banned_reason = Column(Text, default="")
    note = Column(Text, default="")
    created_at = Column(DateTime, default=func.now())
    updated_at = Column(DateTime, default=func.now(), onupdate=func.now())
    last_active_at = Column(DateTime, nullable=True)
    last_data_refresh = Column(DateTime, nullable=True)

    # 关系
    contents = relationship("Content", back_populates="account", lazy="dynamic")
    tasks = relationship("Task", back_populates="account", lazy="dynamic")
    daily_stats = relationship("DailyStat", back_populates="account", lazy="dynamic")
    competitors = relationship("CompetitorAccount", back_populates="account", lazy="dynamic")
    cookie_meta = relationship("CookieMeta", back_populates="account", uselist=False, lazy="select")
    daily_reviews = relationship("DailyReview", back_populates="account", lazy="dynamic")
    strategy_overrides = relationship("StrategyOverride", back_populates="account", lazy="dynamic")
