"""竞品账号模型。"""

from __future__ import annotations

from datetime import datetime
from uuid import uuid4

from sqlalchemy import Boolean, Column, DateTime, ForeignKey, Integer, String, Text, func
from sqlalchemy.orm import relationship

from app.database import Base


def uuid4_str() -> str:
    return str(uuid4())


class CompetitorAccount(Base):
    __tablename__ = "competitor_accounts"

    id = Column(String(36), primary_key=True, default=uuid4_str)
    account_id = Column(String(36), ForeignKey("accounts.id"), nullable=False)
    competitor_xhs_id = Column(String(50), default="")
    competitor_nickname = Column(String(100), default="")
    avatar_url = Column(Text, default="")
    category = Column(String(50), default="")
    followers = Column(Integer, default=0)
    notes_count = Column(Integer, default=0)
    likes = Column(Integer, default=0)
    latest_notes = Column(Text, default="[]")
    insight = Column(Text, default="{}")
    last_check = Column(DateTime, nullable=True)
    is_auto_discovered = Column(Integer, default=0)
    created_at = Column(DateTime, default=func.now())

    # 关系
    account = relationship("Account", back_populates="competitors")
