"""AI 配置管理路由。"""

from __future__ import annotations

from typing import Optional

from fastapi import APIRouter, Depends, Query
from pydantic import BaseModel
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.response import error, success
from app.database import get_db_session
from app.services.ai_service import ai_service

router = APIRouter(prefix="/api/ai", tags=["AI配置"])


# ---------------------------------------------------------------------------
# 请求模型
# ---------------------------------------------------------------------------

class CreateConfigRequest(BaseModel):
    name: str
    provider: str = "openai"
    model: str = "gpt-4o"
    api_key: str = ""
    base_url: str = ""
    max_tokens: int = 4096
    temperature: float = 0.7


class UpdateConfigRequest(BaseModel):
    name: Optional[str] = None
    provider: Optional[str] = None
    model: Optional[str] = None
    api_key: Optional[str] = None
    base_url: Optional[str] = None
    max_tokens: Optional[int] = None
    temperature: Optional[float] = None
    is_active: Optional[bool] = None


class UpdatePromptRequest(BaseModel):
    content: str


# ---------------------------------------------------------------------------
# AI 模型配置 CRUD
# ---------------------------------------------------------------------------

@router.get("/configs")
async def list_configs(db: AsyncSession = Depends(get_db_session)):
    """获取 AI 模型配置列表。"""
    configs = await ai_service.list_configs(db)
    return success(data=configs)


@router.post("/configs")
async def create_config(req: CreateConfigRequest, db: AsyncSession = Depends(get_db_session)):
    """创建 AI 模型配置。"""
    result = await ai_service.create_config(db, req.model_dump())
    return success(data=result, message="配置创建成功")


@router.put("/configs/{config_id}")
async def update_config(
    config_id: int, req: UpdateConfigRequest,
    db: AsyncSession = Depends(get_db_session),
):
    """更新 AI 模型配置。"""
    data = {k: v for k, v in req.model_dump().items() if v is not None}
    updated = await ai_service.update_config(db, config_id, data)
    if not updated:
        error(404, "配置不存在")
    return success(message="配置更新成功")


@router.delete("/configs/{config_id}")
async def delete_config(config_id: int, db: AsyncSession = Depends(get_db_session)):
    """删除 AI 模型配置。"""
    deleted = await ai_service.delete_config(db, config_id)
    if not deleted:
        error(404, "配置不存在")
    return success(message="配置已删除")


@router.post("/configs/{config_id}/test")
async def test_connection(config_id: int, db: AsyncSession = Depends(get_db_session)):
    """测试 AI 模型连接。"""
    result = await ai_service.test_connection(db, config_id)
    return success(data=result)


@router.post("/configs/{config_id}/set-default")
async def set_default(config_id: int, db: AsyncSession = Depends(get_db_session)):
    """设置默认模型。"""
    ok = await ai_service.set_default(db, config_id)
    if not ok:
        error(404, "配置不存在")
    return success(message="默认模型设置成功")


# ---------------------------------------------------------------------------
# 提示词管理
# ---------------------------------------------------------------------------

@router.get("/prompts")
async def list_prompts():
    """获取提示词列表。"""
    prompts = await ai_service.list_prompts()
    return success(data=prompts)


@router.get("/prompts/{name}")
async def get_prompt(name: str):
    """获取指定提示词。"""
    prompt = await ai_service.get_prompt(name)
    if not prompt:
        error(404, f"提示词 '{name}' 不存在")
    return success(data=prompt)


@router.put("/prompts/{name}")
async def update_prompt(name: str, req: UpdatePromptRequest):
    """更新提示词。"""
    updated = await ai_service.update_prompt(name, req.content)
    if not updated:
        error(404, f"提示词 '{name}' 不存在")
    return success(message="提示词更新成功")


# ---------------------------------------------------------------------------
# 用量统计
# ---------------------------------------------------------------------------

@router.get("/usage-stats")
async def get_usage_stats(
    days: int = Query(30, ge=1, le=365),
    db: AsyncSession = Depends(get_db_session),
):
    """获取 AI 用量统计。"""
    result = await ai_service.get_usage_stats(db, days=days)
    return success(data=result)
