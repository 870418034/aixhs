"""素材库管理路由。"""

from __future__ import annotations

from typing import Optional

from fastapi import APIRouter, Depends, File, Query, UploadFile
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.response import error, paginated, success
from app.database import get_db_session
from app.services.material_service import material_service

router = APIRouter(prefix="/api/materials", tags=["素材库"])


@router.post("/upload")
async def upload_file(
    file: UploadFile = File(...),
    category: str = Query("general"),
    db: AsyncSession = Depends(get_db_session),
):
    """上传素材文件。"""
    if not file.filename:
        error(400, "文件名不能为空")
    content = await file.read()
    if len(content) == 0:
        error(400, "文件内容为空")
    file_info = await material_service.save_file(file.filename, content, category)
    result = await material_service.create_material(db, file_info)
    return success(data=result, message="上传成功")


@router.get("")
async def list_materials(
    page: int = Query(1, ge=1),
    size: int = Query(20, ge=1, le=100),
    category: Optional[str] = Query(None),
    db: AsyncSession = Depends(get_db_session),
):
    """获取素材列表。"""
    result = await material_service.list_materials(db, page=page, size=size, category=category)
    return paginated(**result)


@router.delete("/{material_id}")
async def delete_material(material_id: int, db: AsyncSession = Depends(get_db_session)):
    """删除素材。"""
    deleted = await material_service.delete_material(db, material_id)
    if not deleted:
        error(404, "素材不存在")
    return success(message="删除成功")


@router.post("/{material_id}/tag")
async def auto_tag(material_id: int, db: AsyncSession = Depends(get_db_session)):
    """自动标签。"""
    result = await material_service.auto_tag(db, material_id)
    if not result.get("tags"):
        error(404, "素材不存在")
    return success(data=result)


@router.get("/suggest")
async def suggest_materials(
    content_id: Optional[int] = Query(None),
    db: AsyncSession = Depends(get_db_session),
):
    """推荐素材。"""
    result = await material_service.suggest_materials(db, content_id)
    return success(data=result)
