"""系统设置路由（/api/settings + /api/system + /api/logs）。"""

from __future__ import annotations

from typing import Optional

from fastapi import APIRouter, Depends, Query
from pydantic import BaseModel
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.response import error, paginated, success
from app.database import get_db_session
from app.services.settings_service import settings_service

# ---------------------------------------------------------------------------
# Settings 路由
# ---------------------------------------------------------------------------

settings_router = APIRouter(prefix="/api/settings", tags=["系统设置"])


@settings_router.get("")
async def get_settings(db: AsyncSession = Depends(get_db_session)):
    """获取系统设置。"""
    result = await settings_service.get_settings(db)
    return success(data=result)


@settings_router.put("")
async def update_settings(
    data: dict,
    db: AsyncSession = Depends(get_db_session),
):
    """更新系统设置。"""
    ok = await settings_service.update_settings(db, data)
    return success(message="设置更新成功")


@settings_router.post("/backup")
async def create_backup(db: AsyncSession = Depends(get_db_session)):
    """创建备份。"""
    result = await settings_service.create_backup(db)
    return success(data=result, message="备份创建成功")


class RestoreRequest(BaseModel):
    backup_name: str


@settings_router.post("/restore")
async def restore_backup(req: RestoreRequest, db: AsyncSession = Depends(get_db_session)):
    """恢复备份。"""
    ok = await settings_service.restore_backup(db, req.backup_name)
    if not ok:
        error(404, "备份不存在")
    return success(message="恢复成功")


# ---------------------------------------------------------------------------
# System 路由
# ---------------------------------------------------------------------------

system_router = APIRouter(prefix="/api/system", tags=["系统管理"])


@system_router.get("/status")
async def get_system_status():
    """获取系统状态。"""
    result = await settings_service.get_system_status()
    return success(data=result)


class ClientErrorRequest(BaseModel):
    message: str
    stack: str = ""
    url: str = ""


@system_router.post("/client-error")
async def report_client_error(req: ClientErrorRequest):
    """上报客户端错误。"""
    await settings_service.report_client_error(req.model_dump())
    return success(message="已记录")


@system_router.get("/diagnostics")
async def get_diagnostics():
    """获取系统诊断信息。"""
    result = await settings_service.get_diagnostics()
    return success(data=result)


@system_router.post("/diagnostics/fix")
async def auto_fix():
    """自动修复。"""
    result = await settings_service.auto_fix()
    return success(data=result)


# ---------------------------------------------------------------------------
# Logs 路由
# ---------------------------------------------------------------------------

logs_router = APIRouter(prefix="/api/logs", tags=["系统日志"])


@logs_router.get("")
async def get_logs(
    page: int = Query(1, ge=1),
    size: int = Query(50, ge=1, le=200),
    level: Optional[str] = Query(None),
    account_id: Optional[int] = Query(None),
    keyword: Optional[str] = Query(None),
    db: AsyncSession = Depends(get_db_session),
):
    """获取系统日志。"""
    result = await settings_service.get_logs(
        db, page=page, size=size, level=level,
        account_id=account_id, keyword=keyword,
    )
    return paginated(**result)


@logs_router.delete("")
async def clear_logs(
    before_days: int = Query(30, ge=1, le=365),
    db: AsyncSession = Depends(get_db_session),
):
    """清除日志。"""
    count = await settings_service.clear_logs(db, before_days=before_days)
    return success(data={"cleared": count}, message=f"已清除 {count} 条日志")


# 统一导出 router（用于 main.py 注册）
router = settings_router
