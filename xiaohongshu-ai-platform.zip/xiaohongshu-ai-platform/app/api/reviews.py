"""每日复盘路由。"""

from __future__ import annotations

from typing import Optional

from fastapi import APIRouter, Depends, Query
from pydantic import BaseModel
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.response import error, paginated, success
from app.database import get_db_session
from app.services.review_service import review_service

router = APIRouter(prefix="/api/reviews", tags=["每日复盘"])


class TriggerReviewRequest(BaseModel):
    account_id: int


@router.get("")
async def list_reviews(
    account_id: Optional[int] = Query(None),
    date: Optional[str] = Query(None),
    page: int = Query(1, ge=1),
    size: int = Query(20, ge=1, le=100),
    db: AsyncSession = Depends(get_db_session),
):
    """获取复盘列表。"""
    result = await review_service.list_reviews(
        db, account_id=account_id, date=date, page=page, size=size,
    )
    return paginated(**result)


@router.get("/latest")
async def get_latest_review(
    account_id: int = Query(...),
    db: AsyncSession = Depends(get_db_session),
):
    """获取最新复盘。"""
    result = await review_service.get_latest_review(db, account_id)
    if not result:
        error(404, "暂无复盘记录")
    return success(data=result)


@router.get("/{review_id}")
async def get_review(review_id: int, db: AsyncSession = Depends(get_db_session)):
    """获取复盘详情。"""
    result = await review_service.get_review(db, review_id)
    if not result:
        error(404, "复盘记录不存在")
    return success(data=result)


@router.post("/trigger")
async def trigger_review(
    req: TriggerReviewRequest,
    db: AsyncSession = Depends(get_db_session),
):
    """触发复盘。"""
    result = await review_service.trigger_review(db, req.account_id)
    return success(data=result, message="复盘已生成")
