"""内容管理路由。"""

from __future__ import annotations

from typing import List, Optional

from fastapi import APIRouter, Depends, Query
from pydantic import BaseModel
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.response import error, paginated, success
from app.database import get_db_session
from app.services.content_service import content_service

router = APIRouter(prefix="/api/contents", tags=["内容管理"])


# ---------------------------------------------------------------------------
# 请求模型
# ---------------------------------------------------------------------------

class GenerateContentRequest(BaseModel):
    account_id: int
    topic: str
    content_type: str = "note"
    params: Optional[dict] = None


class UpdateContentRequest(BaseModel):
    title: Optional[str] = None
    body: Optional[str] = None
    tags: Optional[str] = None
    cover_image: Optional[str] = None


class ScheduleRequest(BaseModel):
    publish_time: str


class RestoreVersionRequest(BaseModel):
    version_id: int


class BatchGenerateRequest(BaseModel):
    account_id: int
    topics: List[str]


class BatchScheduleRequest(BaseModel):
    content_ids: List[int]
    publish_time: str


# ---------------------------------------------------------------------------
# 内容生成与CRUD
# ---------------------------------------------------------------------------

@router.post("/generate")
async def generate_content(req: GenerateContentRequest, db: AsyncSession = Depends(get_db_session)):
    """AI 生成内容。"""
    result = await content_service.generate(
        db, account_id=req.account_id, topic=req.topic,
        content_type=req.content_type, params=req.params,
    )
    return success(data=result, message="内容生成成功")


@router.get("")
async def list_contents(
    page: int = Query(1, ge=1),
    size: int = Query(20, ge=1, le=100),
    account_id: Optional[int] = Query(None),
    status: Optional[str] = Query(None),
    db: AsyncSession = Depends(get_db_session),
):
    """获取内容列表。"""
    result = await content_service.list_contents(
        db, page=page, size=size, account_id=account_id, status=status,
    )
    return paginated(**result)


@router.get("/suggest-topics")
async def suggest_topics(
    account_id: int = Query(...),
    db: AsyncSession = Depends(get_db_session),
):
    """推荐话题。"""
    topics = [
        {"topic": "2024最值得入手的10款好物", "heat": 95, "category": "好物推荐"},
        {"topic": "小红书涨粉技巧分享", "heat": 88, "category": "运营技巧"},
        {"topic": "居家收纳神器合集", "heat": 82, "category": "家居生活"},
        {"topic": "职场穿搭灵感", "heat": 78, "category": "穿搭"},
        {"topic": "平价护肤好物分享", "heat": 75, "category": "护肤"},
    ]
    return success(data=topics)


@router.get("/trending")
async def get_trending(
    category: Optional[str] = Query(None),
    db: AsyncSession = Depends(get_db_session),
):
    """获取热门话题。"""
    trending = [
        {"topic": "#春日穿搭", "views": 1200000, "notes": 5600},
        {"topic": "#家居好物", "views": 980000, "notes": 4200},
        {"topic": "#美食探店", "views": 850000, "notes": 3800},
        {"topic": "#旅行攻略", "views": 720000, "notes": 3100},
        {"topic": "#职场干货", "views": 650000, "notes": 2800},
    ]
    if category:
        trending = [t for t in trending if category.lower() in t["topic"].lower()]
    return success(data=trending)


@router.get("/{content_id}")
async def get_content(content_id: int, db: AsyncSession = Depends(get_db_session)):
    """获取内容详情。"""
    result = await content_service.get_content(db, content_id)
    if not result:
        error(404, "内容不存在")
    return success(data=result)


@router.put("/{content_id}")
async def update_content(
    content_id: int, req: UpdateContentRequest,
    db: AsyncSession = Depends(get_db_session),
):
    """更新内容（编辑后触发重审）。"""
    data = {k: v for k, v in req.model_dump().items() if v is not None}
    updated = await content_service.update_content(db, content_id, data)
    if not updated:
        error(404, "内容不存在")
    return success(message="内容已更新，已重新提交审核")


@router.delete("/{content_id}")
async def delete_content(content_id: int, db: AsyncSession = Depends(get_db_session)):
    """删除内容。"""
    deleted = await content_service.delete_content(db, content_id)
    if not deleted:
        error(404, "内容不存在")
    return success(message="删除成功")


# ---------------------------------------------------------------------------
# 发布与调度
# ---------------------------------------------------------------------------

@router.post("/{content_id}/publish")
async def publish_content(content_id: int, db: AsyncSession = Depends(get_db_session)):
    """发布内容。"""
    published = await content_service.publish(db, content_id)
    if not published:
        error(404, "内容不存在")
    return success(message="发布成功")


@router.post("/{content_id}/schedule")
async def schedule_content(
    content_id: int, req: ScheduleRequest,
    db: AsyncSession = Depends(get_db_session),
):
    """定时发布。"""
    scheduled = await content_service.schedule(db, content_id, req.publish_time)
    if not scheduled:
        error(404, "内容不存在")
    return success(data={"publish_time": req.publish_time}, message="定时发布已设置")


@router.post("/{content_id}/cancel-schedule")
async def cancel_schedule(content_id: int, db: AsyncSession = Depends(get_db_session)):
    """取消定时发布。"""
    cancelled = await content_service.cancel_schedule(db, content_id)
    if not cancelled:
        error(400, "内容不存在或未处于定时状态")
    return success(message="定时发布已取消")


# ---------------------------------------------------------------------------
# 重新生成
# ---------------------------------------------------------------------------

@router.post("/{content_id}/regenerate")
async def regenerate_content(content_id: int, db: AsyncSession = Depends(get_db_session)):
    """重新生成内容。"""
    result = await content_service.regenerate(db, content_id)
    if not result:
        error(404, "内容不存在")
    return success(data=result, message="内容已重新生成")


# ---------------------------------------------------------------------------
# 统计与版本
# ---------------------------------------------------------------------------

@router.get("/{content_id}/stats")
async def get_content_stats(content_id: int, db: AsyncSession = Depends(get_db_session)):
    """获取内容统计数据。"""
    result = await content_service.get_stats(db, content_id)
    if not result:
        error(404, "内容不存在")
    return success(data=result)


@router.get("/{content_id}/versions")
async def get_versions(content_id: int, db: AsyncSession = Depends(get_db_session)):
    """获取内容版本历史。"""
    versions = await content_service.get_versions(db, content_id)
    return success(data=versions)


@router.post("/{content_id}/restore-version")
async def restore_version(
    content_id: int, req: RestoreVersionRequest,
    db: AsyncSession = Depends(get_db_session),
):
    """恢复到指定版本。"""
    restored = await content_service.restore_version(db, content_id, req.version_id)
    if not restored:
        error(404, "版本不存在")
    return success(message="已恢复到指定版本")


# ---------------------------------------------------------------------------
# 批量操作
# ---------------------------------------------------------------------------

@router.post("/batch-generate")
async def batch_generate(req: BatchGenerateRequest, db: AsyncSession = Depends(get_db_session)):
    """批量生成内容。"""
    results = await content_service.batch_generate(db, req.account_id, req.topics)
    return success(data={"generated": len(results), "results": results})


@router.post("/batch-schedule")
async def batch_schedule(req: BatchScheduleRequest, db: AsyncSession = Depends(get_db_session)):
    """批量定时发布。"""
    count = await content_service.batch_schedule(db, req.content_ids, req.publish_time)
    return success(data={"scheduled": count, "total": len(req.content_ids)})


@router.post("/generate-weekly-plan")
async def generate_weekly_plan(
    account_id: int = Query(...),
    db: AsyncSession = Depends(get_db_session),
):
    """生成周计划。"""
    result = await content_service.generate_weekly_plan(db, account_id)
    return success(data=result)
