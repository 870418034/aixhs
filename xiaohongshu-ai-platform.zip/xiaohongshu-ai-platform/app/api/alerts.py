"""通知/预警管理路由。"""

from __future__ import annotations

from fastapi import APIRouter, Depends, Query
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.response import error, paginated, success
from app.database import get_db_session
from app.services.notification_service import notification_service

router = APIRouter(prefix="/api/notifications", tags=["通知管理"])


@router.get("")
async def list_notifications(
    page: int = Query(1, ge=1),
    size: int = Query(20, ge=1, le=100),
    db: AsyncSession = Depends(get_db_session),
):
    """获取通知列表。"""
    result = await notification_service.list_notifications(db, page=page, size=size)
    return paginated(**result)


@router.put("/{notification_id}/read")
async def mark_read(notification_id: int, db: AsyncSession = Depends(get_db_session)):
    """标记已读。"""
    ok = await notification_service.mark_read(db, notification_id)
    if not ok:
        error(404, "通知不存在")
    return success(message="已标记为已读")


@router.post("/read-all")
async def mark_all_read(db: AsyncSession = Depends(get_db_session)):
    """全部标记已读。"""
    count = await notification_service.mark_all_read(db)
    return success(data={"marked": count}, message=f"已将 {count} 条通知标记为已读")


@router.delete("/{notification_id}")
async def delete_notification(notification_id: int, db: AsyncSession = Depends(get_db_session)):
    """删除通知。"""
    deleted = await notification_service.delete_notification(db, notification_id)
    if not deleted:
        error(404, "通知不存在")
    return success(message="删除成功")


@router.get("/unread-count")
async def get_unread_count(db: AsyncSession = Depends(get_db_session)):
    """获取未读数量。"""
    count = await notification_service.get_unread_count(db)
    return success(data={"unread_count": count})
