"""
账号管理路由 - CRUD + 登录 + 运营控制
"""
from __future__ import annotations

from typing import List, Optional

from fastapi import APIRouter, Depends, Query
from pydantic import BaseModel
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.response import error, paginated, success
from app.database import get_db_session
from app.services.account_service import account_service
from app.services.account_analyzer import account_analyzer
from app.services.profile_optimizer import profile_optimizer
from app.services.data_collector import data_collector

router = APIRouter(prefix="/api/accounts", tags=["账号管理"])


# ── 请求模型 ──────────────────────────────────

class CookieLoginRequest(BaseModel):
    cookie: str
    nickname: str = ""

class UpdateAccountRequest(BaseModel):
    nickname: Optional[str] = None
    bio: Optional[str] = None
    note: Optional[str] = None

class BatchRequest(BaseModel):
    account_ids: List[str]


# ── 登录 ──────────────────────────────────────

@router.get("/qr")
async def get_qr_code():
    """获取登录二维码"""
    result = await account_service.get_qr_code()
    if result.get("error"):
        return error(6001, result["error"])
    return success(data=result)


@router.get("/qr-status")
async def check_qr_status(token: str = Query(...)):
    """轮询扫码状态"""
    result = await account_service.check_qr_status(token)
    if result.get("status") == "expired":
        return success(data={"status": "expired", "message": result.get("message", "已过期")})
    if result.get("status") == "success":
        return success(data={
            "status": "success",
            "account_id": result.get("account_id"),
            "message": "登录成功",
        })
    return success(data={"status": result.get("status", "pending"), "message": result.get("message", "")})


@router.post("/cookie-login")
async def cookie_login(req: CookieLoginRequest):
    """Cookie登录"""
    result = await account_service.cookie_login(req.cookie, req.nickname)
    if result.get("error"):
        return error(2001, result["error"])
    return success(data=result, message="Cookie登录成功")


# ── 账号CRUD ──────────────────────────────────

@router.get("")
async def list_accounts(
    page: int = Query(1, ge=1),
    size: int = Query(20, ge=1, le=100),
    status: Optional[str] = Query(None),
    keyword: Optional[str] = Query(None),
    db: AsyncSession = Depends(get_db_session),
):
    """获取账号列表"""
    result = await account_service.list_accounts(db, page=page, size=size, status=status, keyword=keyword)
    return paginated(items=result["items"], total=result["total"], page=result["page"], page_size=result["page_size"])


@router.get("/{account_id}")
async def get_account(account_id: str, db: AsyncSession = Depends(get_db_session)):
    """获取账号详情"""
    result = await account_service.get_account(db, account_id)
    if not result:
        return error(2001, "账号不存在")
    return success(data=result)


@router.put("/{account_id}")
async def update_account(account_id: str, req: UpdateAccountRequest, db: AsyncSession = Depends(get_db_session)):
    """更新账号"""
    data = {k: v for k, v in req.model_dump().items() if v is not None}
    ok = await account_service.update_account(db, account_id, data)
    if not ok:
        return error(2001, "账号不存在")
    return success(message="更新成功")


@router.delete("/{account_id}")
async def delete_account(account_id: str, db: AsyncSession = Depends(get_db_session)):
    """删除账号"""
    ok = await account_service.delete_account(db, account_id)
    if not ok:
        return error(2001, "账号不存在")
    return success(message="删除成功")


# ── 运营控制 ──────────────────────────────────

@router.post("/{account_id}/start")
async def start_operation(account_id: str, db: AsyncSession = Depends(get_db_session)):
    """启动运营"""
    ok = await account_service.start_operation(db, account_id)
    if not ok:
        return error(2002, "无法启动（账号不在线或不存在）")
    return success(message="运营已启动")


@router.post("/{account_id}/stop")
async def stop_operation(account_id: str, db: AsyncSession = Depends(get_db_session)):
    """停止运营"""
    ok = await account_service.stop_operation(db, account_id)
    if not ok:
        return error(2001, "账号不存在")
    return success(message="运营已停止")


@router.post("/{account_id}/pause")
async def pause_operation(account_id: str, db: AsyncSession = Depends(get_db_session)):
    """暂停运营"""
    ok = await account_service.pause_operation(db, account_id)
    if not ok:
        return error(2001, "账号不存在")
    return success(message="运营已暂停")


@router.post("/{account_id}/resume")
async def resume_operation(account_id: str, db: AsyncSession = Depends(get_db_session)):
    """恢复运营"""
    ok = await account_service.resume_operation(db, account_id)
    if not ok:
        return error(2001, "账号不存在")
    return success(message="运营已恢复")


@router.post("/{account_id}/refresh")
async def refresh_data(account_id: str, db: AsyncSession = Depends(get_db_session)):
    """刷新数据"""
    ok = await account_service.refresh_data(db, account_id)
    if not ok:
        return error(2002, "刷新失败")
    return success(message="数据已刷新")


@router.post("/{account_id}/analyze")
async def analyze_account(account_id: str, db: AsyncSession = Depends(get_db_session)):
    """触发分析"""
    try:
        result = await account_analyzer.analyze(account_id)
        return success(data=result)
    except Exception as e:
        return error(2004, f"分析失败: {e}")


@router.get("/{account_id}/analysis")
async def get_analysis(account_id: str, db: AsyncSession = Depends(get_db_session)):
    """获取分析报告"""
    account = await account_service.get_account(db, account_id)
    if not account:
        return error(2001, "账号不存在")
    return success(data={"positioning": account.get("positioning", "{}")})


@router.post("/{account_id}/optimize-profile")
async def optimize_profile(account_id: str):
    """优化资料"""
    try:
        result = await profile_optimizer.optimize(account_id)
        return success(data=result)
    except Exception as e:
        return error(2004, f"优化失败: {e}")


@router.get("/{account_id}/optimize-preview")
async def get_optimize_preview(account_id: str):
    """预览优化方案"""
    result = await profile_optimizer.preview(account_id)
    return success(data=result)


@router.get("/{account_id}/stats")
async def get_stats(account_id: str, days: int = Query(30, ge=1, le=365), db: AsyncSession = Depends(get_db_session)):
    """历史统计"""
    result = await account_service.get_stats(db, account_id, days)
    return success(data=result)


@router.get("/{account_id}/contents")
async def get_contents(account_id: str, page: int = Query(1, ge=1), size: int = Query(20, ge=1, le=100), db: AsyncSession = Depends(get_db_session)):
    """该账号内容"""
    result = await account_service.get_contents(db, account_id, page, size)
    return paginated(items=result["items"], total=result["total"], page=result["page"], page_size=result["page_size"])


@router.get("/{account_id}/tasks")
async def get_tasks(account_id: str, page: int = Query(1, ge=1), size: int = Query(20, ge=1, le=100), db: AsyncSession = Depends(get_db_session)):
    """该账号任务"""
    result = await account_service.get_tasks(db, account_id, page, size)
    return paginated(items=result["items"], total=result["total"], page=result["page"], page_size=result["page_size"])


# ── 批量操作 ──────────────────────────────────

@router.post("/batch-start")
async def batch_start(req: BatchRequest, db: AsyncSession = Depends(get_db_session)):
    """批量启动"""
    count = await account_service.batch_start(db, req.account_ids)
    return success(data={"count": count}, message=f"已启动 {count} 个账号")


@router.post("/batch-stop")
async def batch_stop(req: BatchRequest, db: AsyncSession = Depends(get_db_session)):
    """批量停止"""
    count = await account_service.batch_stop(db, req.account_ids)
    return success(data={"count": count}, message=f"已停止 {count} 个账号")


@router.post("/batch-refresh")
async def batch_refresh(req: BatchRequest, db: AsyncSession = Depends(get_db_session)):
    """批量刷新"""
    count = await account_service.batch_refresh(db, req.account_ids)
    return success(data={"count": count}, message=f"已刷新 {count} 个账号")
