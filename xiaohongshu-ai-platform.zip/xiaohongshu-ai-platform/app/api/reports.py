"""运营报告路由。"""

from __future__ import annotations

from typing import Optional

from fastapi import APIRouter, Depends, Query
from fastapi.responses import FileResponse
from pydantic import BaseModel
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.response import error, paginated, success
from app.database import get_db_session
from app.services.report_service import report_service

router = APIRouter(prefix="/api/reports", tags=["运营报告"])


class GenerateReportRequest(BaseModel):
    report_type: str = "daily"
    account_id: Optional[int] = None


@router.get("")
async def list_reports(
    page: int = Query(1, ge=1),
    size: int = Query(20, ge=1, le=100),
    db: AsyncSession = Depends(get_db_session),
):
    """获取报告列表。"""
    result = await report_service.list_reports(db, page=page, size=size)
    return paginated(**result)


@router.get("/{report_id}")
async def get_report(report_id: int, db: AsyncSession = Depends(get_db_session)):
    """获取报告详情。"""
    result = await report_service.get_report(db, report_id)
    if not result:
        error(404, "报告不存在")
    return success(data=result)


@router.post("/generate")
async def generate_report(
    req: GenerateReportRequest,
    db: AsyncSession = Depends(get_db_session),
):
    """生成报告。"""
    result = await report_service.generate_report(
        db, report_type=req.report_type, account_id=req.account_id,
    )
    return success(data=result, message="报告生成成功")


@router.get("/{report_id}/download")
async def download_report(report_id: int, db: AsyncSession = Depends(get_db_session)):
    """下载报告。"""
    filepath = await report_service.download_report(db, report_id)
    if not filepath:
        error(404, "报告文件不存在")
    return FileResponse(filepath, filename=f"report_{report_id}.pdf")
