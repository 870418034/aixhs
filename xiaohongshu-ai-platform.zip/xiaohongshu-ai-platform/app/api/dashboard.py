"""仪表盘路由。"""

from __future__ import annotations

from typing import Optional

from fastapi import APIRouter, Depends, Query
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.response import success
from app.database import get_db_session
from app.services.dashboard_service import dashboard_service

router = APIRouter(prefix="/api/dashboard", tags=["仪表盘"])


@router.get("/overview")
async def get_overview(db: AsyncSession = Depends(get_db_session)):
    """获取仪表盘概览（11个区域数据）。"""
    result = await dashboard_service.get_overview(db)
    return success(data=result)


@router.get("/trends")
async def get_trends(
    days: int = Query(30, ge=1, le=365),
    db: AsyncSession = Depends(get_db_session),
):
    """获取趋势数据。"""
    result = await dashboard_service.get_trends(db, days=days)
    return success(data=result)


@router.get("/account-comparison")
async def get_account_comparison(db: AsyncSession = Depends(get_db_session)):
    """获取账号对比数据。"""
    result = await dashboard_service.get_account_comparison(db)
    return success(data=result)


@router.get("/content-performance")
async def get_content_performance(db: AsyncSession = Depends(get_db_session)):
    """获取内容表现数据。"""
    result = await dashboard_service.get_content_performance(db)
    return success(data=result)


@router.get("/follower-analysis")
async def get_follower_analysis(db: AsyncSession = Depends(get_db_session)):
    """获取粉丝分析数据。"""
    result = await dashboard_service.get_follower_analysis(db)
    return success(data=result)


@router.get("/today-review")
async def get_today_review(
    account_id: Optional[int] = Query(None),
    db: AsyncSession = Depends(get_db_session),
):
    """获取今日运营回顾。"""
    result = await dashboard_service.get_today_review(db, account_id=account_id)
    return success(data=result)
