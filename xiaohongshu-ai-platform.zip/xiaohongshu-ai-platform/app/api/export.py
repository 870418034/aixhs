"""数据导出路由。"""

from __future__ import annotations

from fastapi import APIRouter, Depends, Query
from pydantic import BaseModel
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.response import success
from app.database import get_db_session
from app.services.export_service import export_service

router = APIRouter(prefix="/api/export", tags=["数据导出"])


class ExportAccountsRequest(BaseModel):
    account_ids: list[int] = []
    fmt: str = "xlsx"


class ExportContentRequest(BaseModel):
    content_ids: list[int] = []
    fmt: str = "xlsx"


class ExportLogsRequest(BaseModel):
    days: int = 30


@router.post("/accounts-stats")
async def export_accounts_stats(
    req: ExportAccountsRequest,
    db: AsyncSession = Depends(get_db_session),
):
    """导出账号统计数据。"""
    result = await export_service.export_accounts_stats(db, fmt=req.fmt)
    return success(data=result, message="导出成功")


@router.post("/content-stats")
async def export_content_stats(
    req: ExportContentRequest,
    db: AsyncSession = Depends(get_db_session),
):
    """导出内容统计数据。"""
    result = await export_service.export_content_stats(db, fmt=req.fmt)
    return success(data=result, message="导出成功")


@router.post("/operation-logs")
async def export_operation_logs(
    req: ExportLogsRequest,
    db: AsyncSession = Depends(get_db_session),
):
    """导出操作日志。"""
    result = await export_service.export_operation_logs(db, days=req.days)
    return success(data=result, message="导出成功")
