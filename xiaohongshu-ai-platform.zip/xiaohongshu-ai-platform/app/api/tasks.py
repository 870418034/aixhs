"""任务管理路由。"""

from __future__ import annotations

from typing import List, Optional

from fastapi import APIRouter, Depends, Query
from pydantic import BaseModel
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.response import error, paginated, success
from app.database import get_db_session
from app.services.task_service import task_service

router = APIRouter(prefix="/api/tasks", tags=["任务管理"])


# ---------------------------------------------------------------------------
# 请求模型
# ---------------------------------------------------------------------------

class BatchActionRequest(BaseModel):
    task_ids: List[int]
    action: str  # cancel / pause / resume / retry


# ---------------------------------------------------------------------------
# 任务查询
# ---------------------------------------------------------------------------

@router.get("")
async def list_tasks(
    page: int = Query(1, ge=1),
    size: int = Query(20, ge=1, le=100),
    account_id: Optional[int] = Query(None),
    task_type: Optional[str] = Query(None),
    status: Optional[str] = Query(None),
    db: AsyncSession = Depends(get_db_session),
):
    """获取任务列表。"""
    result = await task_service.list_tasks(
        db, page=page, size=size,
        account_id=account_id, task_type=task_type, status=status,
    )
    return paginated(**result)


@router.get("/stats")
async def get_task_stats(db: AsyncSession = Depends(get_db_session)):
    """获取任务统计。"""
    result = await task_service.get_stats(db)
    return success(data=result)


@router.get("/today")
async def get_today_timeline(db: AsyncSession = Depends(get_db_session)):
    """获取今日任务时间线。"""
    result = await task_service.get_today_timeline(db)
    return success(data=result)


@router.get("/{task_id}")
async def get_task_detail(task_id: int, db: AsyncSession = Depends(get_db_session)):
    """获取任务详情（含执行日志）。"""
    result = await task_service.get_task_detail(db, task_id)
    if not result:
        error(404, "任务不存在")
    return success(data=result)


# ---------------------------------------------------------------------------
# 任务操作
# ---------------------------------------------------------------------------

@router.post("/{task_id}/cancel")
async def cancel_task(task_id: int, db: AsyncSession = Depends(get_db_session)):
    """取消任务。"""
    from app.models import TaskStatus
    ok = await task_service.set_status(db, task_id, TaskStatus.cancelled)
    if not ok:
        error(404, "任务不存在")
    return success(message="任务已取消")


@router.post("/{task_id}/retry")
async def retry_task(task_id: int, db: AsyncSession = Depends(get_db_session)):
    """重试任务。"""
    from app.models import TaskStatus
    ok = await task_service.set_status(db, task_id, TaskStatus.pending)
    if not ok:
        error(404, "任务不存在")
    return success(message="任务已重新加入队列")


@router.post("/{task_id}/pause")
async def pause_task(task_id: int, db: AsyncSession = Depends(get_db_session)):
    """暂停任务。"""
    from app.models import TaskStatus
    ok = await task_service.set_status(db, task_id, TaskStatus.paused)
    if not ok:
        error(404, "任务不存在")
    return success(message="任务已暂停")


@router.post("/{task_id}/resume")
async def resume_task(task_id: int, db: AsyncSession = Depends(get_db_session)):
    """恢复任务。"""
    from app.models import TaskStatus
    ok = await task_service.set_status(db, task_id, TaskStatus.pending)
    if not ok:
        error(404, "任务不存在")
    return success(message="任务已恢复")


# ---------------------------------------------------------------------------
# 批量操作
# ---------------------------------------------------------------------------

@router.post("/batch-action")
async def batch_action(req: BatchActionRequest, db: AsyncSession = Depends(get_db_session)):
    """批量操作任务。"""
    valid_actions = {"cancel", "pause", "resume", "retry"}
    if req.action not in valid_actions:
        error(400, f"无效的操作类型，支持: {', '.join(valid_actions)}")
    count = await task_service.batch_action(db, req.task_ids, req.action)
    return success(data={"affected": count, "total": len(req.task_ids)})
