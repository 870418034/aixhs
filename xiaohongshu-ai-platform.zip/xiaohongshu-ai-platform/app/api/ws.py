"""WebSocket 端点：实时推送 + 心跳 + 断线重连 + 消息去重 + 历史消息。"""

from __future__ import annotations

import asyncio
import hashlib
import json
import time
import uuid
from collections import deque
from datetime import datetime
from typing import Any, Dict, List, Set

from fastapi import WebSocket, WebSocketDisconnect

from app.core.logger import get_logger

logger = get_logger(__name__)


class ConnectionManager:
    """WebSocket 连接管理器。"""

    def __init__(self):
        self.active_connections: Dict[str, WebSocket] = {}
        self.message_history: deque = deque(maxlen=20)
        self.recent_message_hashes: Set[str] = set()
        self._hash_max = 500

    async def connect(self, websocket: WebSocket) -> str:
        """接受 WebSocket 连接并返回连接 ID。"""
        await websocket.accept()
        conn_id = str(uuid.uuid4())
        self.active_connections[conn_id] = websocket
        logger.info(f"WebSocket 连接建立: {conn_id}, 当前活跃连接数: {len(self.active_connections)}")
        # 发送历史消息
        if self.message_history:
            try:
                await websocket.send_json({
                    "event": "history",
                    "data": list(self.message_history),
                    "timestamp": datetime.now().isoformat(),
                })
            except Exception:
                pass
        return conn_id

    def disconnect(self, conn_id: str) -> None:
        """移除 WebSocket 连接。"""
        if conn_id in self.active_connections:
            del self.active_connections[conn_id]
            logger.info(f"WebSocket 连接断开: {conn_id}, 当前活跃连接数: {len(self.active_connections)}")

    async def send_to(self, conn_id: str, data: Dict[str, Any]) -> bool:
        """发送消息给指定连接。"""
        ws = self.active_connections.get(conn_id)
        if not ws:
            return False
        try:
            await ws.send_json(data)
            return True
        except Exception:
            self.disconnect(conn_id)
            return False

    async def broadcast(self, event: str, data: Any) -> int:
        """广播消息给所有连接，返回发送成功数。"""
        message = {
            "event": event,
            "data": data,
            "timestamp": datetime.now().isoformat(),
        }

        # 消息去重
        msg_hash = hashlib.md5(json.dumps(data, sort_keys=True, default=str).encode()).hexdigest()
        if msg_hash in self.recent_message_hashes:
            return 0
        self.recent_message_hashes.add(msg_hash)
        if len(self.recent_message_hashes) > self._hash_max:
            # 清理旧 hash（简单重置）
            self.recent_message_hashes.clear()

        # 保存到历史
        self.log_history(event, data)

        # 广播
        sent = 0
        disconnected = []
        for conn_id, ws in self.active_connections.items():
            try:
                await ws.send_json(message)
                sent += 1
            except Exception:
                disconnected.append(conn_id)

        for conn_id in disconnected:
            self.disconnect(conn_id)

        return sent

    def log_history(self, event: str, data: Any) -> None:
        """保存消息到历史队列（最近20条）。"""
        self.message_history.append({
            "event": event,
            "data": data,
            "timestamp": datetime.now().isoformat(),
        })


# 全局连接管理器
manager = ConnectionManager()


async def _heartbeat_loop(ws: WebSocket, conn_id: str) -> None:
    """心跳循环：每 30 秒发送 ping。"""
    try:
        while True:
            await asyncio.sleep(30)
            if conn_id not in manager.active_connections:
                break
            try:
                await ws.send_json({
                    "event": "ping",
                    "timestamp": datetime.now().isoformat(),
                })
            except Exception:
                break
    except asyncio.CancelledError:
        pass


async def websocket_endpoint(websocket: WebSocket) -> None:
    """WebSocket 端点：支持心跳 + 消息处理 + 断线重连。"""
    conn_id = await manager.connect(websocket)
    heartbeat_task = asyncio.create_task(_heartbeat_loop(websocket, conn_id))

    try:
        while True:
            try:
                raw = await websocket.receive_text()
                message = json.loads(raw)
            except (json.JSONDecodeError, ValueError):
                await websocket.send_json({
                    "event": "error",
                    "data": {"message": "无效的 JSON 格式"},
                    "timestamp": datetime.now().isoformat(),
                })
                continue

            event = message.get("event", "")
            data = message.get("data", {})

            # 处理 pong 心跳响应
            if event == "pong":
                continue

            # 处理 ping → pong
            if event == "ping":
                await websocket.send_json({
                    "event": "pong",
                    "timestamp": datetime.now().isoformat(),
                })
                continue

            # 处理订阅
            if event == "subscribe":
                channels = data.get("channels", [])
                await websocket.send_json({
                    "event": "subscribed",
                    "data": {"channels": channels},
                    "timestamp": datetime.now().isoformat(),
                })
                continue

            # 处理取消订阅
            if event == "unsubscribe":
                channels = data.get("channels", [])
                await websocket.send_json({
                    "event": "unsubscribed",
                    "data": {"channels": channels},
                    "timestamp": datetime.now().isoformat(),
                })
                continue

            # 未知事件回显
            await websocket.send_json({
                "event": "ack",
                "data": {"original_event": event},
                "timestamp": datetime.now().isoformat(),
            })

    except WebSocketDisconnect:
        logger.info(f"WebSocket 客户端主动断开: {conn_id}")
    except Exception as e:
        logger.error(f"WebSocket 异常: {conn_id} - {e}")
    finally:
        heartbeat_task.cancel()
        manager.disconnect(conn_id)
