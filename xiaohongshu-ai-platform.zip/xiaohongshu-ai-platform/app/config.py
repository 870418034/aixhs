"""Pydantic Settings 配置管理，读取 config.yaml 并校验。"""

from __future__ import annotations

import os
from pathlib import Path
from typing import Any, Dict, List, Optional

import yaml
from pydantic import BaseModel, Field, field_validator
from pydantic_settings import BaseSettings, SettingsConfigDict

# ---------------------------------------------------------------------------
# 子配置模型
# ---------------------------------------------------------------------------


class ServerConfig(BaseModel):
    host: str = "0.0.0.0"
    port: int = 8000
    workers: int = 1
    debug: bool = False
    reload: bool = False
    cors_origins: List[str] = Field(default_factory=lambda: ["*"])
    allowed_hosts: List[str] = Field(default_factory=lambda: ["*"])
    base_url: str = "http://localhost:8000"


class AIModelConfig(BaseModel):
    provider: str = "openai"
    model: str = "gpt-4o"
    api_key: str = ""
    base_url: str = ""
    max_tokens: int = 4096
    temperature: float = 0.7
    timeout: int = 60
    max_retries: int = 3


class AIConfig(BaseModel):
    default_model: str = "gpt-4o"
    models: Dict[str, AIModelConfig] = Field(default_factory=dict)
    embedding_model: str = "text-embedding-3-small"
    max_content_tokens: int = 8000
    request_interval: float = 1.0


class BrowserConfig(BaseModel):
    headless: bool = True
    max_contexts: int = 5
    context_timeout_minutes: int = 30
    viewport_width: int = 1280
    viewport_height: int = 800
    slow_mo_ms: int = 50
    default_timeout_ms: int = 30000
    user_data_dir: str = "data/browser"


class NurturingConfig(BaseModel):
    enabled: bool = True
    min_days: int = 7
    max_days: int = 14
    daily_browse_minutes: int = 30
    daily_likes: int = 20
    daily_collects: int = 10
    daily_comments: int = 5


class PublishingConfig(BaseModel):
    min_interval_hours: int = 4
    max_per_day: int = 3
    preferred_times: List[str] = Field(default_factory=lambda: ["09:00", "12:00", "19:00"])
    auto_publish: bool = False


class ActionDelayConfig(BaseModel):
    min_seconds: float = 2.0
    max_seconds: float = 8.0
    like_min: float = 3.0
    like_max: float = 10.0
    comment_min: float = 10.0
    comment_max: float = 30.0
    collect_min: float = 2.0
    collect_max: float = 6.0
    follow_min: float = 3.0
    follow_max: float = 8.0


class ActiveHoursConfig(BaseModel):
    start: int = 8
    end: int = 23
    disabled_hours: List[int] = Field(default_factory=lambda: [0, 1, 2, 3, 4, 5, 6, 7])


class DailyLimitsConfig(BaseModel):
    browse_minutes: int = 60
    likes: int = 50
    collects: int = 30
    comments: int = 15
    follows: int = 10
    publishes: int = 3


class OperationConfig(BaseModel):
    nurturing: NurturingConfig = Field(default_factory=NurturingConfig)
    publishing: PublishingConfig = Field(default_factory=PublishingConfig)
    action_delay: ActionDelayConfig = Field(default_factory=ActionDelayConfig)
    active_hours: ActiveHoursConfig = Field(default_factory=ActiveHoursConfig)
    daily_limits: DailyLimitsConfig = Field(default_factory=DailyLimitsConfig)


class AntiDetectionConfig(BaseModel):
    enabled: bool = True
    fingerprint_rotation: bool = True
    randomize_viewport: bool = True
    spoof_canvas: bool = True
    spoof_webgl: bool = True
    spoof_audio: bool = True
    spoof_webrtc: bool = True
    human_like_mouse: bool = True
    human_like_typing: bool = True
    scroll_rollback_percent: int = 12


class ProxyConfig(BaseModel):
    enabled: bool = False
    type: str = "socks5"
    host: str = ""
    port: int = 0
    username: str = ""
    password: str = ""
    rotation: bool = False
    proxy_list: List[str] = Field(default_factory=list)


class ContentSafetyThresholds(BaseModel):
    political: float = 0.8
    sexual: float = 0.7
    violent: float = 0.8
    advertising: float = 0.6
    overall: float = 0.7


class ContentSafetyConfig(BaseModel):
    enabled: bool = True
    pipeline: List[str] = Field(default_factory=lambda: [
        "sensitive_words", "ai_review", "rule_check"
    ])
    thresholds: ContentSafetyThresholds = Field(default_factory=ContentSafetyThresholds)
    block_on_fail: bool = True


class InteractionConfig(BaseModel):
    auto_reply: bool = False
    reply_delay_seconds: int = 60
    max_replies_per_day: int = 20
    reply_style: str = "friendly"
    keywords_blacklist: List[str] = Field(default_factory=list)


class AlertRuleConfig(BaseModel):
    name: str = ""
    condition: str = ""
    threshold: float = 0.0
    channels: List[str] = Field(default_factory=lambda: ["system"])


class AlertsConfig(BaseModel):
    enabled: bool = True
    rules: List[AlertRuleConfig] = Field(default_factory=list)
    webhook_url: str = ""
    email_to: str = ""


class ReportsConfig(BaseModel):
    auto_generate: bool = True
    daily_report_time: str = "23:00"
    weekly_report_day: str = "sunday"
    retention_days: int = 90


class CompetitorConfig(BaseModel):
    enabled: bool = True
    max_competitors: int = 20
    check_interval_hours: int = 24
    auto_discover: bool = False


class ABTestConfig(BaseModel):
    enabled: bool = True
    min_sample_size: int = 100
    confidence_level: float = 0.95


class DataCollectionConfig(BaseModel):
    collect_comments: bool = True
    collect_likes: bool = True
    collect_views: bool = True
    retention_days: int = 180
    export_formats: List[str] = Field(default_factory=lambda: ["csv", "json"])


class LoggingConfig(BaseModel):
    level: str = "INFO"
    file: str = "data/logs/app.log"
    max_size_mb: int = 50
    backup_count: int = 10
    json_format: bool = True
    console: bool = True


# ---------------------------------------------------------------------------
# 主配置
# ---------------------------------------------------------------------------

def _deep_merge(base: dict, override: dict) -> dict:
    """递归合并字典，override 覆盖 base。"""
    merged = base.copy()
    for key, value in override.items():
        if key in merged and isinstance(merged[key], dict) and isinstance(value, dict):
            merged[key] = _deep_merge(merged[key], value)
        else:
            merged[key] = value
    return merged


def _load_yaml_config(config_path: str | Path | None = None) -> dict:
    """加载 YAML 配置文件。"""
    if config_path is None:
        config_path = os.environ.get("APP_CONFIG", "config.yaml")
    path = Path(config_path)
    if path.exists():
        with open(path, "r", encoding="utf-8") as f:
            data = yaml.safe_load(f) or {}
        return data
    return {}


class AppConfig(BaseSettings):
    """应用主配置，支持 YAML 文件 + 环境变量。"""

    model_config = SettingsConfigDict(
        env_prefix="APP_",
        env_nested_delimiter="__",
        case_sensitive=False,
    )

    server: ServerConfig = Field(default_factory=ServerConfig)
    ai: AIConfig = Field(default_factory=AIConfig)
    browser: BrowserConfig = Field(default_factory=BrowserConfig)
    operation: OperationConfig = Field(default_factory=OperationConfig)
    anti_detection: AntiDetectionConfig = Field(default_factory=AntiDetectionConfig)
    proxy: ProxyConfig = Field(default_factory=ProxyConfig)
    content_safety: ContentSafetyConfig = Field(default_factory=ContentSafetyConfig)
    interaction: InteractionConfig = Field(default_factory=InteractionConfig)
    alerts: AlertsConfig = Field(default_factory=AlertsConfig)
    reports: ReportsConfig = Field(default_factory=ReportsConfig)
    competitor: CompetitorConfig = Field(default_factory=CompetitorConfig)
    ab_test: ABTestConfig = Field(default_factory=ABTestConfig)
    data_collection: DataCollectionConfig = Field(default_factory=DataCollectionConfig)
    logging: LoggingConfig = Field(default_factory=LoggingConfig)

    @classmethod
    def from_yaml(cls, config_path: str | Path | None = None) -> "AppConfig":
        """从 YAML 文件创建配置实例。"""
        yaml_data = _load_yaml_config(config_path)
        return cls(**yaml_data)

    def validate_config(self) -> List[str]:
        """校验配置，返回警告列表。"""
        warnings: List[str] = []
        if self.operation.active_hours.start >= self.operation.active_hours.end:
            warnings.append("active_hours: start 应小于 end")
        if self.operation.daily_limits.publishes > 10:
            warnings.append("daily publishes 超过 10 可能触发风控")
        if self.browser.max_contexts > 10:
            warnings.append("max_contexts > 10 可能导致内存不足")
        if self.ai.models and not any(m.api_key for m in self.ai.models.values()):
            warnings.append("未配置任何 AI 模型的 API Key")
        if self.proxy.enabled and not self.proxy.host:
            warnings.append("启用了代理但未配置 host")
        return warnings


# 全局配置实例（惰性加载）
_config: Optional[AppConfig] = None


def get_config() -> AppConfig:
    """获取全局配置实例。"""
    global _config
    if _config is None:
        _config = AppConfig.from_yaml()
    return _config


def reload_config(config_path: str | Path | None = None) -> AppConfig:
    """重新加载配置。"""
    global _config
    _config = AppConfig.from_yaml(config_path)
    return _config
