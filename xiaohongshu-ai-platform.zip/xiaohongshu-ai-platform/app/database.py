"""SQLAlchemy 2.0 异步数据库配置，支持 aiosqlite + WAL 模式。"""

from __future__ import annotations

import os
from contextlib import asynccontextmanager
from pathlib import Path
from typing import AsyncGenerator, Optional

from sqlalchemy import event, text
from sqlalchemy.ext.asyncio import (
    AsyncEngine,
    AsyncSession,
    async_sessionmaker,
    create_async_engine,
)
from sqlalchemy.orm import DeclarativeBase

from app.core.logger import get_logger

logger = get_logger(__name__)

# ---------------------------------------------------------------------------
# Declarative Base
# ---------------------------------------------------------------------------


class Base(DeclarativeBase):
    pass


# ---------------------------------------------------------------------------
# 引擎 & Session
# ---------------------------------------------------------------------------

DATABASE_URL = os.environ.get("DATABASE_URL", "sqlite+aiosqlite:///data/app.db")

engine: Optional[AsyncEngine] = None
async_session_factory: Optional[async_sessionmaker[AsyncSession]] = None


def _ensure_data_dir() -> None:
    db_path = DATABASE_URL.replace("sqlite+aiosqlite:///", "")
    Path(db_path).parent.mkdir(parents=True, exist_ok=True)


def get_engine() -> AsyncEngine:
    global engine
    if engine is None:
        _ensure_data_dir()
        engine = create_async_engine(
            DATABASE_URL,
            echo=False,
            future=True,
            pool_pre_ping=True,
            connect_args={
                "timeout": 30,
            },
        )

        @event.listens_for(engine.sync_engine, "connect")
        def _set_sqlite_pragma(dbapi_conn, connection_record):
            cursor = dbapi_conn.cursor()
            cursor.execute("PRAGMA journal_mode=WAL")
            cursor.execute("PRAGMA busy_timeout=30000")
            cursor.execute("PRAGMA synchronous=NORMAL")
            cursor.execute("PRAGMA foreign_keys=ON")
            cursor.execute("PRAGMA cache_size=-10240")  # 10MB
            cursor.close()

    return engine


def get_session_factory() -> async_sessionmaker[AsyncSession]:
    global async_session_factory
    if async_session_factory is None:
        async_session_factory = async_sessionmaker(
            get_engine(),
            class_=AsyncSession,
            expire_on_commit=False,
        )
    return async_session_factory


# 兼容旧代码: async_session_maker 等价于 get_session_factory()()
def async_session_maker():
    """返回一个新的 AsyncSession 上下文管理器。"""
    return get_session_factory()()


@asynccontextmanager
async def get_db_session() -> AsyncGenerator[AsyncSession, None]:
    """获取数据库会话的异步上下文管理器。"""
    session_factory = get_session_factory()
    async with session_factory() as session:
        try:
            yield session
            await session.commit()
        except Exception:
            await session.rollback()
            raise
        finally:
            await session.close()


# ---------------------------------------------------------------------------
# 初始化 & 迁移
# ---------------------------------------------------------------------------


async def init_db() -> None:
    """创建所有表。"""
    from app.models import (
        Account,
        AIConfig,
        ABTestRecord,
        ActivityLog,
        Content,
        ContentVersion,
        CookieMeta,
        CompetitorAccount,
        DailyReview,
        DailyStat,
        Material,
        Notification,
        Report,
        StrategyOverride,
        SystemSetting,
        Task,
        TokenUsage,
    )

    eng = get_engine()
    async with eng.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
    logger.info("数据库表创建完成")


async def check_and_migrate() -> None:
    """检测缺失列并自动 ADD COLUMN 迁移。缺失表由 init_db 的 create_all 处理。"""
    eng = get_engine()
    async with eng.connect() as conn:
        # 获取已有表
        result = await conn.execute(
            text("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'")
        )
        existing_tables = {row[0] for row in result.fetchall()}

        # 获取所有模型的表定义
        for table_name, table in Base.metadata.tables.items():
            if table_name not in existing_tables:
                logger.warning(f"缺失表 {table_name}，将在下次 init_db 创建")
                continue

            # 检查缺失列
            col_result = await conn.execute(
                text(f"PRAGMA table_info({table_name})")
            )
            existing_cols = {row[1] for row in col_result.fetchall()}

            for column in table.columns:
                if column.name not in existing_cols:
                    col_type = column.type.compile(dialect=eng.dialect)
                    default = ""
                    if column.server_default is not None:
                        default = f" DEFAULT {column.server_default}"
                    nullable = "" if column.nullable else " NOT NULL"
                    alter_sql = (
                        f"ALTER TABLE {table_name} ADD COLUMN "
                        f"{column.name} {col_type}{nullable}{default}"
                    )
                    logger.info(f"迁移: {alter_sql}")
                    try:
                        await conn.execute(text(alter_sql))
                    except Exception as e:
                        logger.warning(f"添加列失败 {table_name}.{column.name}: {e}")

        await conn.commit()
    logger.info("数据库迁移检查完成")
