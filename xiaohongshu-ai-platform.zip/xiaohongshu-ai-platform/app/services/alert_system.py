"""
智能预警系统 - 检测涨粉/爆文/风控/运营异常并发送预警
"""
from __future__ import annotations
import asyncio
from datetime import datetime, timedelta
from typing import Optional, List, Dict, Any
from sqlalchemy import select, func, and_
from sqlalchemy.ext.asyncio import AsyncSession
from loguru import logger

from app.models import Account, Content, DailyStat, Notification, CookieMeta
from app.database import get_db_session


class AlertSystem:
    """智能预警系统"""

    def __init__(self):
        self._alert_handlers: Dict[str, callable] = {}

    async def check_all_alerts(self):
        """检查所有预警规则（定时任务每小时调用）"""
        async for db in get_db_session():
            try:
                await self.check_cookie_expiring(db)
                await self.check_account_health(db)
                stmt = select(Account).where(Account.status == "online", Account.operation_stage == "active")
                result = await db.execute(stmt)
                accounts = result.scalars().all()
                for account in accounts:
                    await self.check_follower_surge(db, account)
                    await self.check_follower_drop(db, account)
                    await self.check_viral_content(db, account)
                    await self.check_content_tank(db, account)
                await db.commit()
            except Exception as e:
                logger.error(f"预警检查失败: {e}")
                await db.rollback()

    async def check_follower_surge(self, db: AsyncSession, account: Account):
        """检测涨粉突增"""
        threshold = 200
        today = datetime.now().date()
        stmt = select(DailyStat).where(
            DailyStat.account_id == account.id,
            DailyStat.date == today
        )
        result = await db.execute(stmt)
        stat = result.scalar_one_or_none()
        if stat and stat.followers_gain >= threshold:
            await self.send_alert(
                db, level="info",
                title=f"📈 {account.nickname} 涨粉爆发",
                message=f"今日涨粉 {stat.followers_gain} 人，超过阈值 {threshold}",
                account_id=account.id
            )

    async def check_follower_drop(self, db: AsyncSession, account: Account):
        """检测掉粉"""
        threshold = 5
        today = datetime.now().date()
        stmt = select(DailyStat).where(
            DailyStat.account_id == account.id,
            DailyStat.date == today
        )
        result = await db.execute(stmt)
        stat = result.scalar_one_or_none()
        if stat and stat.followers_gain < -threshold:
            await self.send_alert(
                db, level="warning",
                title=f"📉 {account.nickname} 掉粉预警",
                message=f"今日掉粉 {abs(stat.followers_gain)} 人，可能原因：内容质量下降/平台限流",
                account_id=account.id
            )

    async def check_viral_content(self, db: AsyncSession, account: Account):
        """检测爆文"""
        threshold = 300
        stmt = select(Content).where(
            Content.account_id == account.id,
            Content.status == "published",
            Content.views >= threshold
        ).order_by(Content.created_at.desc()).limit(5)
        result = await db.execute(stmt)
        for content in result.scalars().all():
            engagement_rate = (content.likes + content.collects + content.comments_count) / max(content.views, 1) * 100
            if engagement_rate > 15:
                await self.send_alert(
                    db, level="info",
                    title=f"🔥 {account.nickname} 爆文出现",
                    message=f"《{content.title}》阅读 {content.views}，互动率 {engagement_rate:.1f}%",
                    account_id=account.id,
                    related_type="content",
                    related_id=content.id
                )

    async def check_content_tank(self, db: AsyncSession, account: Account):
        """检测内容数据差"""
        threshold = 100
        cutoff = datetime.now() - timedelta(hours=48)
        stmt = select(Content).where(
            Content.account_id == account.id,
            Content.status == "published",
            Content.created_at >= cutoff,
            Content.views < threshold
        )
        result = await db.execute(stmt)
        low_performers = result.scalars().all()
        if len(low_performers) >= 2:
            await self.send_alert(
                db, level="warning",
                title=f"⚠️ {account.nickname} 内容表现不佳",
                message=f"最近 {len(low_performers)} 篇内容阅读量低于 {threshold}，建议调整内容方向",
                account_id=account.id
            )

    async def check_cookie_expiring(self, db: AsyncSession):
        """检测Cookie过期"""
        warning_days = 3
        expiry_date = datetime.now() + timedelta(days=warning_days)
        stmt = select(CookieMeta).where(
            CookieMeta.status == "valid",
            CookieMeta.expires_at <= expiry_date,
            CookieMeta.expires_at > datetime.now(),
            CookieMeta.warning_sent == False
        )
        result = await db.execute(stmt)
        for meta in result.scalars().all():
            days_left = (meta.expires_at - datetime.now()).days
            account = await db.get(Account, meta.account_id)
            name = account.nickname if account else meta.account_id
            await self.send_alert(
                db, level="warning",
                title=f"🔑 {name} Cookie即将过期",
                message=f"Cookie将在 {days_left} 天后过期，请尽快更新",
                account_id=meta.account_id
            )
            meta.warning_sent = True

    async def check_account_health(self, db: AsyncSession):
        """检测健康度过低"""
        stmt = select(Account).where(
            Account.status == "online",
            Account.health_score < 50
        )
        result = await db.execute(stmt)
        for account in result.scalars().all():
            level = "critical" if account.health_score < 30 else "warning"
            await self.send_alert(
                db, level=level,
                title=f"🚨 {account.nickname} 健康度过低",
                message=f"健康度: {account.health_score}/100，{'已自动暂停操作' if account.health_score < 30 else '已降低50%操作频率'}",
                account_id=account.id
            )

    async def send_alert(
        self, db: AsyncSession,
        level: str,
        title: str,
        message: str,
        account_id: str = "",
        related_type: str = "",
        related_id: str = ""
    ):
        """发送预警通知"""
        notification = Notification(
            level=level,
            title=title,
            message=message,
            account_id=account_id,
            related_type=related_type,
            related_id=related_id,
        )
        db.add(notification)
        await db.flush()
        logger.log(
            "WARNING" if level in ("warning", "critical") else "INFO",
            f"预警: [{level}] {title} - {message}"
        )


alert_system = AlertSystem()
