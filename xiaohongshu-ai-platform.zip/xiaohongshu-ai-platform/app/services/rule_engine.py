"""规则引擎 - Aho-Corasick敏感词检测 + 正则规则 + 格式检查"""

import re
from typing import List, Dict, Any, Optional
from dataclasses import dataclass, field

from loguru import logger


@dataclass
class Match:
    """敏感词匹配结果"""
    word: str
    position: int
    category: str


@dataclass
class Violation:
    """正则违规"""
    rule_name: str
    description: str
    matched_text: str
    position: int


@dataclass
class Issue:
    """格式问题"""
    type: str
    description: str
    severity: str  # warning, error


class AhoCorasickNode:
    """Aho-Corasick树节点"""
    def __init__(self):
        self.children: Dict[str, AhoCorasickNode] = {}
        self.fail: Optional[AhoCorasickNode] = None
        self.output: List[str] = []
        self.is_end = False


class AhoCorasick:
    """Aho-Corasick多模式匹配"""

    def __init__(self):
        self.root = AhoCorasickNode()
        self._built = False

    def add_word(self, word: str, category: str = "default"):
        """添加敏感词"""
        node = self.root
        for char in word:
            if char not in node.children:
                node.children[char] = AhoCorasickNode()
            node = node.children[char]
        node.is_end = True
        node.output.append((word, category))
        self._built = False

    def build(self):
        """构建失败指针"""
        from collections import deque
        queue = deque()

        for child in self.root.children.values():
            child.fail = self.root
            queue.append(child)

        while queue:
            current = queue.popleft()
            for char, child in current.children.items():
                queue.append(child)
                fail_node = current.fail
                while fail_node and char not in fail_node.children:
                    fail_node = fail_node.fail
                child.fail = fail_node.children.get(char) if fail_node else self.root
                if child.fail and child.fail != child:
                    child.output.extend(child.fail.output)
        self._built = True

    def search(self, text: str) -> List[tuple]:
        """搜索文本中的敏感词"""
        if not self._built:
            self.build()

        results = []
        node = self.root
        for i, char in enumerate(text):
            while node and char not in node.children:
                node = node.fail
            if not node:
                node = self.root
                continue
            node = node.children[char]
            for word, category in node.output:
                results.append((word, i - len(word) + 1, category))
        return results


class RuleEngine:
    """规则引擎"""

    def __init__(self):
        self._ac = AhoCorasick()
        self._load_sensitive_words()

    def _load_sensitive_words(self):
        """加载敏感词库"""
        # 违禁词（政治/暴力/色情相关）
        banned_words = [
            ("涉政敏感词1", "politics"),
            ("涉政敏感词2", "politics"),
            ("暴力词汇1", "violence"),
            ("色情词汇1", "sex"),
            ("赌博", "gambling"),
            ("毒品", "drug"),
        ]

        # 营销敏感词
        marketing_words = [
            ("加微信", "marketing"),
            ("加V", "marketing"),
            ("私聊", "marketing"),
            ("代购", "marketing"),
            ("免费领", "marketing"),
            ("扫码", "marketing"),
            ("vx", "marketing"),
            ("weixin", "marketing"),
        ]

        for word, category in banned_words + marketing_words:
            self._ac.add_word(word, category)
        self._ac.build()

    def check_sensitive_words(self, text: str) -> List[Match]:
        """敏感词检查"""
        results = self._ac.search(text)
        return [
            Match(word=word, position=pos, category=cat)
            for word, pos, cat in results
        ]

    def check_regex_rules(self, text: str) -> List[Violation]:
        """正则规则检查"""
        violations = []

        rules = [
            {
                "name": "微信号",
                "pattern": r'(?:微信号?|wechat|wx)[:：\s]*[a-zA-Z0-9_-]{5,}',
                "description": "内容包含微信号引流信息",
            },
            {
                "name": "QQ号",
                "pattern": r'(?:(?:Q|q){2}|QQ)[:：\s]*\d{5,12}',
                "description": "内容包含QQ号引流信息",
            },
            {
                "name": "外链",
                "pattern": r'https?://(?!xiaohongshu\.com)[^\s]+',
                "description": "内容包含外部链接",
            },
            {
                "name": "绝对化用语",
                "pattern": r'(?:最好的|第一的|最顶级|绝对安全|100%有效|必定|肯定)',
                "description": "内容包含绝对化用语（违反广告法）",
            },
            {
                "name": "恶意贬低",
                "pattern": r'(?:垃圾|废物|脑残|智障|傻[逼比Bb])',
                "description": "内容包含恶意贬低/辱骂",
            },
            {
                "name": "手机号",
                "pattern": r'1[3-9]\d{9}',
                "description": "内容包含手机号码",
            },
        ]

        for rule in rules:
            for match in re.finditer(rule["pattern"], text):
                violations.append(Violation(
                    rule_name=rule["name"],
                    description=rule["description"],
                    matched_text=match.group(),
                    position=match.start(),
                ))

        return violations

    def check_format(self, text: str) -> List[Issue]:
        """格式检查"""
        issues = []

        # 字数检查
        if len(text) < 50:
            issues.append(Issue(
                type="length",
                description="正文内容过少（少于50字）",
                severity="warning",
            ))
        if len(text) > 3000:
            issues.append(Issue(
                type="length",
                description="正文内容过长（超过3000字）",
                severity="warning",
            ))

        # emoji比例检查
        import emoji
        emoji_count = len([c for c in text if c in emoji.EMOJI_DATA])
        total_chars = len(text)
        if total_chars > 0:
            emoji_ratio = emoji_count / total_chars
            if emoji_ratio > 0.3:
                issues.append(Issue(
                    type="emoji",
                    description="Emoji比例过高（超过30%）",
                    severity="warning",
                ))
            if emoji_ratio == 0 and total_chars > 100:
                issues.append(Issue(
                    type="emoji",
                    description="缺少emoji表情",
                    severity="warning",
                ))

        # 重复字符检查
        repeat_pattern = re.compile(r'(.)\1{4,}')
        if repeat_pattern.search(text):
            issues.append(Issue(
                type="repeat",
                description="存在连续重复字符",
                severity="warning",
            ))

        return issues

    def overall_result(
        self,
        matches: List[Match],
        violations: List[Violation],
        issues: List[Issue],
    ) -> str:
        """综合判定结果"""
        # 有任何banned类别的敏感词 → banned
        banned_categories = {"politics", "violence", "sex", "drug", "gambling"}
        for match in matches:
            if match.category in banned_categories:
                return "banned"

        # 有营销违规 → high_risk
        marketing_violations = [v for v in violations if v.rule_name in ("微信号", "QQ号", "手机号", "外链")]
        if marketing_violations:
            return "high_risk"

        # 有违规词 → high_risk
        if matches:
            return "high_risk"

        # 有绝对化用语 → high_risk
        ad_violations = [v for v in violations if v.rule_name in ("绝对化用语", "恶意贬低")]
        if ad_violations:
            return "high_risk"

        # 有格式问题 → high_risk
        error_issues = [i for i in issues if i.severity == "error"]
        if error_issues:
            return "high_risk"

        return "safe"
