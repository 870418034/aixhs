"""APScheduler定时任务封装"""

from datetime import datetime
from typing import Optional

from loguru import logger
from apscheduler.schedulers.asyncio import AsyncIOScheduler
from apscheduler.triggers.cron import CronTrigger
from apscheduler.triggers.interval import IntervalTrigger


class SchedulerService:
    """定时任务调度服务"""

    def __init__(self):
        self.scheduler: Optional[AsyncIOScheduler] = None

    def init_scheduler(self):
        """创建调度器"""
        self.scheduler = AsyncIOScheduler(
            job_defaults={
                "coalesce": True,
                "max_instances": 1,
                "misfire_grace_time": 300,
            }
        )
        logger.info("Scheduler initialized")
        return self.scheduler

    def register_all_jobs(self):
        """注册所有定时任务"""
        if not self.scheduler:
            raise RuntimeError("Scheduler not initialized")

        # 每日Cookie检查 6:00
        self.scheduler.add_job(
            self._daily_cookie_check,
            CronTrigger(hour=6, minute=0),
            id="daily_cookie_check",
            name="每日Cookie检查",
        )

        # 每日账号刷新 7:00
        self.scheduler.add_job(
            self._daily_account_refresh,
            CronTrigger(hour=7, minute=0),
            id="daily_account_refresh",
            name="每日账号刷新",
        )

        # 每日计划生成 7:30
        self.scheduler.add_job(
            self._daily_plan_generator,
            CronTrigger(hour=7, minute=30),
            id="daily_plan_generator",
            name="每日计划生成",
        )

        # 每日操作计数重置 0:00
        self.scheduler.add_job(
            self._daily_action_counter_reset,
            CronTrigger(hour=0, minute=0),
            id="daily_action_counter_reset",
            name="每日计数重置",
        )

        # 每日安全扫描 5:00
        self.scheduler.add_job(
            self._daily_security_scan,
            CronTrigger(hour=5, minute=0),
            id="daily_security_scan",
            name="每日安全扫描",
        )

        # 任务分发器 每10秒
        self.scheduler.add_job(
            self._task_dispatcher,
            IntervalTrigger(seconds=10),
            id="task_dispatcher",
            name="任务分发器",
        )

        # 定时内容发布 每1分钟
        self.scheduler.add_job(
            self._scheduled_content_publisher,
            IntervalTrigger(minutes=1),
            id="scheduled_content_publisher",
            name="定时内容发布",
        )

        # 内容创意生成 21:00
        self.scheduler.add_job(
            self._content_idea_generator,
            CronTrigger(hour=21, minute=0),
            id="content_idea_generator",
            name="内容创意生成",
        )

        # 内容自动续航 22:30
        self.scheduler.add_job(
            self._auto_content_continuum,
            CronTrigger(hour=22, minute=30),
            id="auto_content_continuum",
            name="内容自动续航",
        )

        # 每日复盘 22:00
        self.scheduler.add_job(
            self._daily_review,
            CronTrigger(hour=22, minute=0),
            id="daily_review",
            name="每日复盘",
        )

        # 内容数据采集 每2小时
        self.scheduler.add_job(
            self._content_stats_collector,
            IntervalTrigger(hours=2),
            id="content_stats_collector",
            name="内容数据采集",
        )

        # 评论回复检查 每3小时
        self.scheduler.add_job(
            self._comment_reply_checker,
            IntervalTrigger(hours=3),
            id="comment_reply_checker",
            name="评论回复检查",
        )

        # 预警检查 每1小时
        self.scheduler.add_job(
            self._alert_checker,
            IntervalTrigger(hours=1),
            id="alert_checker",
            name="预警检查",
        )

        # 竞品检查 23:00
        self.scheduler.add_job(
            self._competitor_checker,
            CronTrigger(hour=23, minute=0),
            id="competitor_checker",
            name="竞品检查",
        )

        # 周报 周日22:15
        self.scheduler.add_job(
            self._weekly_report,
            CronTrigger(day_of_week="sun", hour=22, minute=15),
            id="weekly_report",
            name="周报生成",
        )

        # 月报 每月28日22:15
        self.scheduler.add_job(
            self._monthly_report,
            CronTrigger(day=28, hour=22, minute=15),
            id="monthly_report",
            name="月报生成",
        )

        # 数据清理 3:00
        self.scheduler.add_job(
            self._data_cleanup,
            CronTrigger(hour=3, minute=0),
            id="data_cleanup",
            name="数据清理",
        )

        # 数据库VACUUM 周日4:00
        self.scheduler.add_job(
            self._database_vacuum,
            CronTrigger(day_of_week="sun", hour=4, minute=0),
            id="database_vacuum",
            name="数据库优化",
        )

        logger.info(f"All {len(self.scheduler.get_jobs())} jobs registered")

    def start(self):
        """启动调度器"""
        if not self.scheduler:
            self.init_scheduler()
            self.register_all_jobs()
        self.scheduler.start()
        logger.info("Scheduler started")

    def shutdown(self):
        """关闭调度器"""
        if self.scheduler and self.scheduler.running:
            self.scheduler.shutdown(wait=False)
            logger.info("Scheduler shutdown")

    # ========== 定时任务实现 ==========

    async def _daily_cookie_check(self):
        """每日Cookie检查"""
        try:
            from app.services.cookie_manager import CookieManager
            mgr = CookieManager()
            await mgr.daily_check()
        except Exception as e:
            logger.error(f"daily_cookie_check failed: {e}")

    async def _daily_account_refresh(self):
        """每日账号刷新"""
        try:
            from app.services.account_service import AccountService
            svc = AccountService()
            await svc.refresh_all_online()
        except Exception as e:
            logger.error(f"daily_account_refresh failed: {e}")

    async def _daily_plan_generator(self):
        """每日计划生成"""
        try:
            from app.services.strategy_engine import StrategyEngine
            engine = StrategyEngine()
            await engine.generate_all_daily_plans()
        except Exception as e:
            logger.error(f"daily_plan_generator failed: {e}")

    async def _daily_action_counter_reset(self):
        """每日操作计数重置"""
        try:
            from app.services.account_service import AccountService
            svc = AccountService()
            await svc.reset_daily_counters()
        except Exception as e:
            logger.error(f"daily_action_counter_reset failed: {e}")

    async def _daily_security_scan(self):
        """每日安全扫描"""
        try:
            from app.services.system_service import SystemService
            svc = SystemService()
            await svc.daily_security_scan()
        except Exception as e:
            logger.error(f"daily_security_scan failed: {e}")

    async def _task_dispatcher(self):
        """任务分发器"""
        try:
            from app.services.task_executor import TaskExecutor
            executor = TaskExecutor()
            await executor.dispatch_pending_tasks()
        except Exception as e:
            logger.error(f"task_dispatcher failed: {e}")

    async def _scheduled_content_publisher(self):
        """定时内容发布"""
        try:
            from app.services.content_publisher import ContentPublisher
            publisher = ContentPublisher()
            await publisher.publish_scheduled()
        except Exception as e:
            logger.error(f"scheduled_content_publisher failed: {e}")

    async def _content_idea_generator(self):
        """内容创意生成"""
        try:
            from app.services.content_continuum import ContentContinuum
            continuum = ContentContinuum()
            await continuum.check_and_fill()
        except Exception as e:
            logger.error(f"content_idea_generator failed: {e}")

    async def _auto_content_continuum(self):
        """内容自动续航"""
        try:
            from app.services.content_continuum import ContentContinuum
            continuum = ContentContinuum()
            await continuum.check_and_fill()
        except Exception as e:
            logger.error(f"auto_content_continuum failed: {e}")

    async def _daily_review(self):
        """每日复盘"""
        try:
            from app.services.daily_review_service import DailyReviewService
            svc = DailyReviewService()
            await svc.review_all_active()
        except Exception as e:
            logger.error(f"daily_review failed: {e}")

    async def _content_stats_collector(self):
        """内容数据采集"""
        try:
            from app.services.data_collector import DataCollector
            collector = DataCollector()
            await collector.collect_all_due()
        except Exception as e:
            logger.error(f"content_stats_collector failed: {e}")

    async def _comment_reply_checker(self):
        """评论回复检查"""
        try:
            from app.services.interaction_manager import InteractionManager
            mgr = InteractionManager()
            await mgr.check_all_comments()
        except Exception as e:
            logger.error(f"comment_reply_checker failed: {e}")

    async def _alert_checker(self):
        """预警检查"""
        try:
            from app.services.alert_system import AlertSystem
            system = AlertSystem()
            await system.check_all_alerts()
        except Exception as e:
            logger.error(f"alert_checker failed: {e}")

    async def _competitor_checker(self):
        """竞品检查"""
        try:
            from app.services.competitor_monitor import CompetitorMonitor
            monitor = CompetitorMonitor()
            await monitor.check_all()
        except Exception as e:
            logger.error(f"competitor_checker failed: {e}")

    async def _weekly_report(self):
        """周报生成"""
        try:
            from app.services.report_generator import ReportGenerator
            generator = ReportGenerator()
            await generator.generate_weekly()
        except Exception as e:
            logger.error(f"weekly_report failed: {e}")

    async def _monthly_report(self):
        """月报生成"""
        try:
            from app.services.report_generator import ReportGenerator
            generator = ReportGenerator()
            await generator.generate_monthly()
        except Exception as e:
            logger.error(f"monthly_report failed: {e}")

    async def _data_cleanup(self):
        """数据清理"""
        try:
            from app.services.system_service import SystemService
            svc = SystemService()
            await svc.cleanup_old_data()
        except Exception as e:
            logger.error(f"data_cleanup failed: {e}")

    async def _database_vacuum(self):
        """数据库VACUUM"""
        try:
            from app.services.system_service import SystemService
            svc = SystemService()
            await svc.vacuum_database()
        except Exception as e:
            logger.error(f"database_vacuum failed: {e}")
