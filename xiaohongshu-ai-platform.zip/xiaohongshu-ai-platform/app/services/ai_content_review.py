"""AI内容审核"""

import os
from datetime import datetime
from typing import Dict, Any, Optional, List

from loguru import logger

from app.core.config import settings
from app.services.ai_service import AIService


class AIContentReview:
    """AI内容审核"""

    def __init__(self):
        self.ai_service = AIService()

    async def review(
        self,
        title: str,
        body: str,
        category: str = "general",
    ) -> Dict[str, Any]:
        """AI内容审核

        合规性语义分析 / 引流检测 / 真实性判断 / AI痕迹检测
        返回: score(0-10)/passed/compliance/ai_trace/rewrites_suggestions
        """
        system_prompt = self._load_prompt("safety_check.txt")
        prompt = self._build_review_prompt(title, body, category)

        try:
            ai_response = await self.ai_service.call(
                prompt=prompt,
                system_prompt=system_prompt,
                temperature=0.3,
                max_tokens=2048,
            )
            result = self.ai_service.parse_json_response(ai_response)
        except Exception as e:
            logger.error(f"AI content review failed: {e}")
            result = {
                "score": 5,
                "passed": True,
                "compliance": {"status": "unknown", "issues": []},
                "ai_trace": 3,
                "drainage_risk": 0,
                "authenticity": 7,
                "rewrites_suggestions": [],
            }

        result["passed"] = result.get("score", 0) >= 4
        return result

    async def dehumanize(self, text: str) -> str:
        """去AI化处理

        去除排比句式/书面化连接词/过于工整结构
        添加个人体验/口语化表达/主观偏见
        """
        prompt = f"""请对以下文字进行"去AI化"处理，使其更像真实用户写的：

原文：
{text}

处理要求：
1. 去除排比句式（不要连续3句以上结构相似）
2. 去除书面化连接词（如"首先...其次...最后"、"综上所述"、"总而言之"）
3. 打破过于工整的结构（不要每段长度相近）
4. 添加个人体验感受（如"我之前试过..."、"说实话..."）
5. 使用口语化表达（如"真的是"、"绝了"、"姐妹们"）
6. 添加一些主观偏见（如"我觉得"、"个人认为"）
7. 可以有一些小的不完美（如偶尔用错标点、短句）

直接返回处理后的文字，不要解释。"""

        try:
            result = await self.ai_service.call(
                prompt=prompt,
                temperature=0.8,
                max_tokens=4096,
            )
            return result.strip()
        except Exception as e:
            logger.error(f"Dehumanize failed: {e}")
            return text

    def _build_review_prompt(self, title: str, body: str, category: str) -> str:
        """构建审核提示词"""
        return f"""请对以下小红书内容进行全面审核：

标题：{title}
正文：{body}
分类：{category}

请从以下维度进行分析并以JSON格式返回：

1. 合规性检查（0-10分，10为最合规）：
   - 是否违反广告法（绝对化用语、虚假宣传）
   - 是否包含违规内容（色情、暴力、政治敏感）
   - 是否有版权风险

2. 引流检测（0-10分，0为无风险，10为高风险）：
   - 是否有微信号/QQ号/手机号
   - 是否有外部链接
   - 是否有明显的引流话术

3. 真实性判断（0-10分，10为最真实）：
   - 内容是否真实可信
   - 是否有夸大/编造成分

4. AI痕迹检测（0-10分，0为无人工痕迹，10为强烈AI痕迹）：
   - 是否有排比句式
   - 是否有书面化连接词
   - 是否结构过于工整
   - 是否缺乏个人体验

5. 改进建议（如果需要修改）

返回格式：
{{
    "score": 综合评分(0-10),
    "compliance": {{
        "score": 合规评分,
        "issues": ["问题1", "问题2"]
    }},
    "drainage_risk": 引流风险评分,
    "authenticity": 真实性评分,
    "ai_trace": AI痕迹评分,
    "rewrites_suggestions": ["建议1", "建议2"]
}}"""

    def _load_prompt(self, filename: str) -> str:
        """加载提示词模板"""
        prompt_path = os.path.join(settings.PROMPT_DIR, filename)
        if os.path.exists(prompt_path):
            with open(prompt_path, "r", encoding="utf-8") as f:
                return f.read()
        return "你是一个专业的内容审核专家，负责审核小红书平台的内容合规性。请客观、公正地评估每篇内容。"
