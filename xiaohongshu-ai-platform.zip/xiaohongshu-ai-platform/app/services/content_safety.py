"""内容安全审核主服务 - pipeline调度"""

import uuid
from datetime import datetime
from typing import Dict, Any, Optional

from loguru import logger
from sqlalchemy import select

from app.database import async_session_maker
from app.models.content import Content, ContentStatus


class SafetyResult:
    """安全审核结果"""
    def __init__(
        self,
        score: float = 10.0,
        result: str = "safe",
        details: Optional[Dict] = None,
        suggestions: Optional[list] = None,
    ):
        self.score = score
        self.result = result  # safe, warning, banned
        self.details = details or {}
        self.suggestions = suggestions or []

    def to_dict(self) -> Dict[str, Any]:
        return {
            "score": self.score,
            "result": self.result,
            "details": self.details,
            "suggestions": self.suggestions,
        }


class ContentSafetyService:
    """内容安全审核 - Pipeline调度

    Step1: 规则引擎(<10ms) → banned→拦截 / high_risk→AI审核 / safe→继续
    Step2: AI审核(2-5秒) → score<4→拦截 / 4-6→警告 / 6-8→通过并去AI化 / >8→直接通过
    Step3: 去AI化处理（如果AI痕迹>6）→ 再次AI审核
    Step4: 结果持久化
    """

    async def check(self, content_data: Dict[str, Any]) -> Dict[str, Any]:
        """安全审核Pipeline"""
        title = content_data.get("title", "")
        body = content_data.get("body", "")
        full_text = f"{title}\n{body}"

        # Step1: 规则引擎
        from app.services.rule_engine import RuleEngine
        engine = RuleEngine()

        sensitive_matches = engine.check_sensitive_words(full_text)
        regex_violations = engine.check_regex_rules(full_text)
        format_issues = engine.check_format(full_text)
        rule_result = engine.overall_result(sensitive_matches, regex_violations, format_issues)

        if rule_result == "banned":
            return SafetyResult(
                score=0,
                result="banned",
                details={
                    "rule_result": rule_result,
                    "sensitive_words": [m.word for m in sensitive_matches],
                    "violations": [v.description for v in regex_violations],
                },
                suggestions=["内容包含违规词，请修改后重新提交"],
            ).to_dict()

        if rule_result == "safe":
            return SafetyResult(
                score=10,
                result="safe",
                details={"rule_result": rule_result},
            ).to_dict()

        # Step2: AI审核 (high_risk)
        from app.services.ai_content_review import AIContentReview
        reviewer = AIContentReview()
        ai_review = await reviewer.review(title=title, body=body, category="general")

        ai_score = ai_review.get("score", 5)

        # Step3: 去AI化处理
        ai_trace = ai_review.get("ai_trace", 0)
        if ai_trace > 6 and ai_score >= 4:
            logger.info(f"High AI trace ({ai_trace}), dehumanizing content")
            dehumanized_body = await reviewer.dehumanize(body)

            # 再次审核
            ai_review_2 = await reviewer.review(
                title=title, body=dehumanized_body, category="general"
            )
            ai_score = ai_review_2.get("score", 5)

            if ai_score >= 4:
                # 更新content_data
                content_data["body"] = dehumanized_body
                content_data["dehumanized"] = True

        # Step4: 判定结果
        if ai_score < 4:
            result = "banned"
            suggestions = ai_review.get("rewrites_suggestions", ["内容不合规，请修改"])
        elif ai_score < 6:
            result = "warning"
            suggestions = ai_review.get("rewrites_suggestions", ["建议修改部分内容"])
        elif ai_score < 8:
            result = "safe"
            suggestions = ai_review.get("rewrites_suggestions", [])
        else:
            result = "safe"
            suggestions = []

        return SafetyResult(
            score=ai_score,
            result=result,
            details={
                "rule_result": rule_result,
                "ai_score": ai_score,
                "ai_trace": ai_trace,
                "compliance": ai_review.get("compliance", {}),
            },
            suggestions=suggestions,
        ).to_dict()

    async def persist_result(
        self, content_id: str, safety_result: Dict[str, Any]
    ):
        """持久化审核结果"""
        async with async_session_maker() as session:
            content = await session.get(Content, content_id)
            if content:
                content.safety_score = safety_result.get("score", 0)
                content.safety_result = safety_result.get("result", "safe")
                content.safety_checked_at = datetime.utcnow()
                content.safety_details = str(safety_result.get("details", {}))

                if safety_result.get("result") == "banned":
                    content.status = ContentStatus.REJECTED

                content.updated_at = datetime.utcnow()
                await session.commit()
