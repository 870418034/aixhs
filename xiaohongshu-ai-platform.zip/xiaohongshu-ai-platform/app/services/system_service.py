"""
系统服务 - 备份恢复/数据清理/VACUUM/安全巡检/设置管理
"""
from __future__ import annotations
import json
import os
import shutil
import sqlite3
from datetime import datetime, timedelta
from pathlib import Path
from typing import Optional, List, Dict, Any, Tuple
from sqlalchemy import select, func, and_, text, delete
from sqlalchemy.ext.asyncio import AsyncSession
from loguru import logger

from app.models import ActivityLog, SystemSetting, Account
from app.database import get_db_session

DATA_DIR = Path("data")
BACKUP_DIR = DATA_DIR / "backups"
LOGS_DIR = DATA_DIR / "logs"
TEMP_DIR = DATA_DIR / "temp"


class SystemService:
    """系统服务"""

    def __init__(self):
        BACKUP_DIR.mkdir(parents=True, exist_ok=True)
        LOGS_DIR.mkdir(parents=True, exist_ok=True)
        TEMP_DIR.mkdir(parents=True, exist_ok=True)

    async def backup(self) -> Dict[str, Any]:
        """备份数据库+配置+Cookie"""
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        backup_name = f"backup_{timestamp}"
        backup_path = BACKUP_DIR / backup_name
        backup_path.mkdir(parents=True, exist_ok=True)
        db_path = DATA_DIR / "app.db"
        if db_path.exists():
            shutil.copy2(db_path, backup_path / "app.db")
        config_path = Path("config.yaml")
        if config_path.exists():
            shutil.copy2(config_path, backup_path / "config.yaml")
        enc_path = DATA_DIR / "encryption.key"
        if enc_path.exists():
            shutil.copy2(enc_path, backup_path / "encryption.key")
        accounts_dir = DATA_DIR / "accounts"
        if accounts_dir.exists():
            shutil.copytree(accounts_dir, backup_path / "accounts", dirs_exist_ok=True)
        archive = shutil.make_archive(str(BACKUP_DIR / backup_name), "zip", str(backup_path))
        shutil.rmtree(backup_path)
        logger.info(f"备份完成: {archive}")
        return {"backup_file": archive, "timestamp": timestamp}

    async def restore(self, backup_file: str) -> Dict[str, Any]:
        """恢复备份"""
        if not os.path.exists(backup_file):
            return {"error": "备份文件不存在"}
        temp_restore = TEMP_DIR / "restore"
        if temp_restore.exists():
            shutil.rmtree(temp_restore)
        shutil.unpack_archive(backup_file, str(temp_restore))
        db_backup = temp_restore / "app.db"
        if db_backup.exists():
            shutil.copy2(db_backup, DATA_DIR / "app.db")
        logger.info(f"恢复完成: {backup_file}")
        return {"restored": backup_file}

    async def cleanup_old_data(self):
        """清理旧日志/临时文件/过期备份"""
        log_days = 30
        cutoff = datetime.now() - timedelta(days=log_days)
        async for db in get_db_session():
            stmt = delete(ActivityLog).where(ActivityLog.created_at < cutoff)
            result = await db.execute(stmt)
            deleted = result.rowcount
            await db.commit()
            logger.info(f"清理了 {deleted} 条旧日志")
        if TEMP_DIR.exists():
            for f in TEMP_DIR.iterdir():
                if f.is_file():
                    age = datetime.now() - datetime.fromtimestamp(f.stat().st_mtime)
                    if age.days > 1:
                        f.unlink()
        if BACKUP_DIR.exists():
            backups = sorted(BACKUP_DIR.glob("backup_*.zip"), key=os.path.getmtime)
            while len(backups) > 10:
                backups.pop(0).unlink()

    async def vacuum_database(self):
        """SQLite VACUUM"""
        db_path = DATA_DIR / "app.db"
        if db_path.exists():
            conn = sqlite3.connect(str(db_path))
            conn.execute("VACUUM")
            conn.close()
            logger.info("数据库VACUUM完成")

    async def get_system_status(self) -> Dict[str, Any]:
        """获取系统状态"""
        db_path = DATA_DIR / "app.db"
        db_size = db_path.stat().st_size if db_path.exists() else 0
        import psutil
        disk = psutil.disk_usage(str(DATA_DIR))
        return {
            "database_size": db_size,
            "disk_free": disk.free,
            "disk_total": disk.total,
            "disk_percent": disk.percent,
            "data_dir": str(DATA_DIR),
            "uptime": "running",
        }

    async def daily_security_scan(self):
        """安全巡检"""
        logger.info("执行每日安全巡检")
        async for db in get_db_session():
            stmt = select(Account).where(Account.status == "online", Account.health_score < 30)
            result = await db.execute(stmt)
            at_risk = result.scalars().all()
            for account in at_risk:
                account.operation_stage = "paused"
                logger.warning(f"安全巡检: {account.nickname} 健康度过低，已暂停运营")
            await db.commit()

    async def get_logs(
        self, db: AsyncSession, page: int = 1, size: int = 50,
        level: str = "", account_id: str = "", keyword: str = ""
    ) -> Tuple[List[ActivityLog], int]:
        """获取日志"""
        stmt = select(ActivityLog)
        if level:
            stmt = stmt.where(ActivityLog.level == level)
        if account_id:
            stmt = stmt.where(ActivityLog.account_id == account_id)
        if keyword:
            stmt = stmt.where(ActivityLog.detail.contains(keyword))
        stmt = stmt.order_by(ActivityLog.created_at.desc())
        count_stmt = select(func.count()).select_from(ActivityLog)
        total = (await db.execute(count_stmt)).scalar()
        result = await db.execute(stmt.offset((page - 1) * size).limit(size))
        return list(result.scalars().all()), total

    async def clear_logs(self, db: AsyncSession, before_days: int = 30) -> int:
        """清除旧日志"""
        cutoff = datetime.now() - timedelta(days=before_days)
        stmt = delete(ActivityLog).where(ActivityLog.created_at < cutoff)
        result = await db.execute(stmt)
        await db.commit()
        return result.rowcount

    async def get_settings(self, db: AsyncSession) -> Dict[str, str]:
        """获取设置"""
        stmt = select(SystemSetting)
        result = await db.execute(stmt)
        return {s.key: s.value for s in result.scalars().all()}

    async def update_settings(self, db: AsyncSession, data: Dict[str, str]):
        """更新设置"""
        for key, value in data.items():
            setting = await db.get(SystemSetting, key)
            if setting:
                setting.value = value
            else:
                db.add(SystemSetting(key=key, value=value))
        await db.commit()


system_service = SystemService()
