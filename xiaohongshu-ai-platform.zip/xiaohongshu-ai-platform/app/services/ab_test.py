"""
A/B标题测试 - 多标题对比选择最优
"""
from __future__ import annotations
import json
from datetime import datetime, timedelta
from typing import Optional, List, Dict
from sqlalchemy import select, and_
from sqlalchemy.ext.asyncio import AsyncSession
from loguru import logger

from app.models import ABTestRecord, Content
from app.database import get_db_session


class ABTestService:
    """A/B标题测试服务"""

    async def create_test(
        self, db: AsyncSession,
        account_id: str,
        original_content_id: str,
        variants: List[str]
    ) -> List[ABTestRecord]:
        """创建A/B测试"""
        records = []
        for title in variants:
            record = ABTestRecord(
                account_id=account_id,
                original_content_id=original_content_id,
                variant_title=title,
                test_status="pending",
            )
            db.add(record)
            records.append(record)
        await db.flush()
        logger.info(f"A/B测试已创建: {len(variants)}个标题变体")
        return records

    async def check_test_results(self, db: AsyncSession, test_id: str) -> Optional[ABTestRecord]:
        """检查测试结果"""
        record = await db.get(ABTestRecord, test_id)
        if not record:
            return None
        if record.variant_content_id:
            content = await db.get(Content, record.variant_content_id)
            if content:
                record.views = content.views
                record.likes = content.likes
                record.collects = content.collects
                record.score = (content.likes * 3 + content.collects * 2 + content.views) / 100
        return record

    async def pick_winner(self, db: AsyncSession, original_content_id: str) -> Optional[ABTestRecord]:
        """选择胜出版本"""
        stmt = select(ABTestRecord).where(
            ABTestRecord.original_content_id == original_content_id,
            ABTestRecord.test_status.in_(["running", "pending"])
        )
        result = await db.execute(stmt)
        records = result.scalars().all()
        if not records:
            return None
        best = max(records, key=lambda r: r.score)
        best.test_status = "winner"
        for r in records:
            if r.id != best.id:
                r.test_status = "loser"
        await db.flush()
        return best

    async def list_tests(self, db: AsyncSession, account_id: str, page: int = 1, size: int = 20):
        """列出测试"""
        stmt = select(ABTestRecord).where(
            ABTestRecord.account_id == account_id
        ).order_by(ABTestRecord.created_at.desc())
        result = await db.execute(stmt.offset((page - 1) * size).limit(size))
        return list(result.scalars().all())


ab_test_service = ABTestService()
