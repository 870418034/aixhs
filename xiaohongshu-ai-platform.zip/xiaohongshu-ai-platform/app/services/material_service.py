"""素材库管理服务。"""

from __future__ import annotations

import hashlib
import os
from pathlib import Path
from typing import Any, Dict, List, Optional

from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.models import Material


class MaterialService:
    """素材上传、查询、删除、自动打标。"""

    UPLOAD_DIR = "data/materials"

    async def save_file(self, filename: str, content: bytes, category: str = "general") -> Dict[str, Any]:
        Path(self.UPLOAD_DIR).mkdir(parents=True, exist_ok=True)
        file_hash = hashlib.md5(content).hexdigest()[:12]
        ext = os.path.splitext(filename)[1]
        stored_name = f"{file_hash}{ext}"
        filepath = os.path.join(self.UPLOAD_DIR, stored_name)
        with open(filepath, "wb") as f:
            f.write(content)
        file_type = ext.lstrip(".").lower()
        return {
            "filename": filename,
            "filepath": filepath,
            "category": category,
            "file_type": file_type,
            "file_size": len(content),
        }

    async def create_material(self, db: AsyncSession, file_info: Dict[str, Any]) -> Dict[str, Any]:
        material = Material(**file_info)
        db.add(material)
        await db.flush()
        await db.refresh(material)
        return {"id": material.id, "filename": material.filename, "filepath": material.filepath}

    async def list_materials(
        self, db: AsyncSession, page: int = 1, size: int = 20,
        category: Optional[str] = None,
    ) -> Dict[str, Any]:
        query = select(Material)
        if category:
            query = query.where(Material.category == category)
        total = (await db.execute(select(func.count()).select_from(query.subquery()))).scalar() or 0
        query = query.order_by(Material.created_at.desc()).offset((page - 1) * size).limit(size)
        rows = (await db.execute(query)).scalars().all()
        items = [
            {
                "id": m.id, "filename": m.filename, "category": m.category,
                "file_type": m.file_type, "file_size": m.file_size,
                "tags": m.tags, "created_at": str(m.created_at),
            }
            for m in rows
        ]
        return {"items": items, "total": total, "page": page, "page_size": size}

    async def delete_material(self, db: AsyncSession, material_id: int) -> bool:
        material = await db.get(Material, material_id)
        if not material:
            return False
        if os.path.exists(material.filepath):
            os.remove(material.filepath)
        await db.delete(material)
        await db.flush()
        return True

    async def auto_tag(self, db: AsyncSession, material_id: int) -> Dict[str, Any]:
        material = await db.get(Material, material_id)
        if not material:
            return {"tags": []}
        tags = []
        if material.file_type in ("jpg", "png", "jpeg", "gif", "webp"):
            tags.extend(["图片", "视觉素材"])
        elif material.file_type in ("mp4", "mov", "avi"):
            tags.extend(["视频", "视频素材"])
        material.tags = ",".join(tags)
        await db.flush()
        return {"id": material.id, "tags": tags}

    async def suggest_materials(self, db: AsyncSession, content_id: Optional[int] = None) -> List[Dict[str, Any]]:
        query = select(Material).order_by(Material.created_at.desc()).limit(10)
        rows = (await db.execute(query)).scalars().all()
        return [
            {"id": m.id, "filename": m.filename, "category": m.category, "file_type": m.file_type}
            for m in rows
        ]


material_service = MaterialService()
