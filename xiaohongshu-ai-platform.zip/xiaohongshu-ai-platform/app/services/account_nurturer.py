"""养号执行引擎"""

import uuid
import random
import asyncio
from datetime import datetime, timedelta
from typing import Dict, Any, List, Optional

from loguru import logger
from sqlalchemy import select, func, desc

from app.database import async_session_maker
from app.models.account import Account
from app.models.task import Task, TaskType, TaskStatus
from app.models.content import Content
from app.services.ai_service import AIService
from app.services.xiaohongshu_browser import XiaohongshuBrowser


# 7天养号计划配置
NURTURE_PLANS: Dict[int, Dict[str, Any]] = {
    1: {
        "browse_count": 6,
        "browse_duration_min": 100,
        "browse_duration_max": 130,
        "like_min": 0, "like_max": 0,
        "collect_min": 0, "collect_max": 0,
        "comment_min": 0, "comment_max": 0,
        "follow_min": 0, "follow_max": 0,
        "publish": False,
        "focus": "纯浏览，熟悉平台",
    },
    2: {
        "browse_count": 6,
        "browse_duration_min": 100,
        "browse_duration_max": 130,
        "like_min": 3, "like_max": 5,
        "collect_min": 1, "collect_max": 2,
        "comment_min": 0, "comment_max": 0,
        "follow_min": 2, "follow_max": 3,
        "publish": False,
        "focus": "开始互动，建立兴趣标签",
    },
    3: {
        "browse_count": 6,
        "browse_duration_min": 90,
        "browse_duration_max": 120,
        "like_min": 4, "like_max": 6,
        "collect_min": 1, "collect_max": 2,
        "comment_min": 1, "comment_max": 2,
        "follow_min": 2, "follow_max": 3,
        "publish": False,
        "focus": "增加评论互动",
    },
    4: {
        "browse_count": 6,
        "browse_duration_min": 90,
        "browse_duration_max": 120,
        "like_min": 5, "like_max": 8,
        "collect_min": 2, "collect_max": 3,
        "comment_min": 2, "comment_max": 3,
        "follow_min": 3, "follow_max": 5,
        "publish": False,
        "focus": "全面互动，提升活跃度",
    },
    5: {
        "browse_count": 4,
        "browse_duration_min": 60,
        "browse_duration_max": 90,
        "like_min": 3, "like_max": 5,
        "collect_min": 1, "collect_max": 2,
        "comment_min": 1, "comment_max": 2,
        "follow_min": 1, "follow_max": 2,
        "publish": True,
        "focus": "首次发布，开启内容创作",
    },
    6: {
        "browse_count": 4,
        "browse_duration_min": 60,
        "browse_duration_max": 80,
        "like_min": 3, "like_max": 5,
        "collect_min": 1, "collect_max": 2,
        "comment_min": 1, "comment_max": 2,
        "follow_min": 1, "follow_max": 2,
        "publish": True,
        "focus": "稳定发布，保持互动",
    },
    7: {
        "browse_count": 3,
        "browse_duration_min": 30,
        "browse_duration_max": 60,
        "like_min": 2, "like_max": 3,
        "collect_min": 0, "collect_max": 1,
        "comment_min": 0, "comment_max": 1,
        "follow_min": 0, "follow_max": 1,
        "publish": True,
        "focus": "简短浏览，转入日常运营",
    },
}


class AccountNurturer:
    """养号执行引擎"""

    def __init__(self):
        self.ai_service = AIService()
        self.browser = XiaohongshuBrowser()

    async def execute_nurture_day(self, account_id: str) -> Dict[str, Any]:
        """执行当天养号任务"""
        async with async_session_maker() as session:
            account = await session.get(Account, account_id)
            if not account:
                raise ValueError(f"Account {account_id} not found")

        # 计算养号天数
        if not account.operation_started_at:
            raise ValueError("Account operation not started")

        days_since_start = (datetime.utcnow() - account.operation_started_at).days + 1
        day = min(days_since_start, 7)

        logger.info(f"Executing nurture day {day} for account {account_id}")

        # 生成任务列表
        tasks = await self.generate_nurture_tasks(account_id, day)

        # 执行任务
        completed = 0
        failed = 0
        results = []

        for task in tasks:
            try:
                await self._execute_task(account_id, task)
                completed += 1
                results.append({"task": task.task_name, "status": "completed"})
            except Exception as e:
                failed += 1
                results.append({"task": task.task_name, "status": "failed", "error": str(e)})
                logger.error(f"Task {task.task_name} failed: {e}")

            # 任务间隔
            await asyncio.sleep(random.uniform(30, 120))

        # 养号第7天结束转入日常运营
        if day == 7 and completed > 0:
            async with async_session_maker() as session:
                account = await session.get(Account, account_id)
                account.nurture_completed = True
                account.updated_at = datetime.utcnow()
                await session.commit()
            logger.info(f"Account {account_id} nurture completed, transitioning to daily operation")

        return {
            "account_id": account_id,
            "day": day,
            "completed": completed,
            "failed": failed,
            "results": results,
        }

    async def generate_nurture_tasks(
        self, account_id: str, day: int
    ) -> List[Task]:
        """生成养号任务列表"""
        plan = NURTURE_PLANS.get(day, NURTURE_PLANS[7])
        tasks = []

        async with async_session_maker() as session:
            # 浏览任务
            browse_count = plan["browse_count"]
            duration_range = (plan["browse_duration_min"], plan["browse_duration_max"])
            for i in range(browse_count):
                task = Task(
                    id=str(uuid.uuid4()),
                    account_id=account_id,
                    task_type=TaskType.BROWSE,
                    task_name=f"浏览推荐 #{i + 1}",
                    status=TaskStatus.PENDING,
                    priority=5,
                    task_data={
                        "duration_min": duration_range[0] // browse_count,
                        "duration_max": duration_range[1] // browse_count,
                    },
                    created_at=datetime.utcnow(),
                    updated_at=datetime.utcnow(),
                )
                session.add(task)
                tasks.append(task)

            # 点赞任务
            like_count = random.randint(plan["like_min"], plan["like_max"])
            for i in range(like_count):
                task = Task(
                    id=str(uuid.uuid4()),
                    account_id=account_id,
                    task_type=TaskType.LIKE,
                    task_name=f"点赞 #{i + 1}",
                    status=TaskStatus.PENDING,
                    priority=4,
                    depends_on=[t.id for t in tasks[:1]] if tasks else [],
                    created_at=datetime.utcnow(),
                    updated_at=datetime.utcnow(),
                )
                session.add(task)
                tasks.append(task)

            # 收藏任务
            collect_count = random.randint(plan["collect_min"], plan["collect_max"])
            for i in range(collect_count):
                task = Task(
                    id=str(uuid.uuid4()),
                    account_id=account_id,
                    task_type=TaskType.COLLECT,
                    task_name=f"收藏 #{i + 1}",
                    status=TaskStatus.PENDING,
                    priority=3,
                    depends_on=[t.id for t in tasks[:1]] if tasks else [],
                    created_at=datetime.utcnow(),
                    updated_at=datetime.utcnow(),
                )
                session.add(task)
                tasks.append(task)

            # 评论任务
            comment_count = random.randint(plan["comment_min"], plan["comment_max"])
            for i in range(comment_count):
                task = Task(
                    id=str(uuid.uuid4()),
                    account_id=account_id,
                    task_type=TaskType.COMMENT,
                    task_name=f"评论 #{i + 1}",
                    status=TaskStatus.PENDING,
                    priority=3,
                    depends_on=[t.id for t in tasks[:1]] if tasks else [],
                    created_at=datetime.utcnow(),
                    updated_at=datetime.utcnow(),
                )
                session.add(task)
                tasks.append(task)

            # 关注任务
            follow_count = random.randint(plan["follow_min"], plan["follow_max"])
            for i in range(min(follow_count, 5)):  # 每天最多5个
                task = Task(
                    id=str(uuid.uuid4()),
                    account_id=account_id,
                    task_type=TaskType.FOLLOW,
                    task_name=f"关注 #{i + 1}",
                    status=TaskStatus.PENDING,
                    priority=2,
                    depends_on=[t.id for t in tasks[:1]] if tasks else [],
                    created_at=datetime.utcnow(),
                    updated_at=datetime.utcnow(),
                )
                session.add(task)
                tasks.append(task)

            # 发布任务
            if plan.get("publish"):
                task = Task(
                    id=str(uuid.uuid4()),
                    account_id=account_id,
                    task_type=TaskType.PUBLISH,
                    task_name="发布笔记",
                    status=TaskStatus.PENDING,
                    priority=6,
                    created_at=datetime.utcnow(),
                    updated_at=datetime.utcnow(),
                )
                session.add(task)
                tasks.append(task)

            await session.commit()

        return tasks

    async def _execute_task(self, account_id: str, task: Task):
        """执行单个任务"""
        async with async_session_maker() as session:
            task_db = await session.get(Task, task.id)
            task_db.status = TaskStatus.RUNNING
            task_db.started_at = datetime.utcnow()
            await session.commit()

        try:
            if task.task_type == TaskType.BROWSE:
                config = task.task_data or {}
                await self._browse_recommend(account_id, config)
            elif task.task_type == TaskType.LIKE:
                note = await self._get_random_note(account_id)
                if note:
                    await self._like_note(account_id, note)
            elif task.task_type == TaskType.COLLECT:
                note = await self._get_random_note(account_id)
                if note:
                    await self._collect_note(account_id, note)
            elif task.task_type == TaskType.COMMENT:
                note = await self._get_random_note(account_id)
                if note:
                    await self._comment_note(account_id, note)
            elif task.task_type == TaskType.FOLLOW:
                user = await self._get_random_user(account_id)
                if user:
                    await self._follow_user(account_id, user)
            elif task.task_type == TaskType.PUBLISH:
                from app.services.content_generator import ContentGenerator
                from app.services.content_publisher import ContentPublisher
                generator = ContentGenerator()
                publisher = ContentPublisher()
                result = await generator.generate(account_id)
                await publisher.publish(result.content.id)

            async with async_session_maker() as session:
                task_db = await session.get(Task, task.id)
                task_db.status = TaskStatus.COMPLETED
                task_db.completed_at = datetime.utcnow()
                await session.commit()

        except Exception as e:
            async with async_session_maker() as session:
                task_db = await session.get(Task, task.id)
                task_db.status = TaskStatus.FAILED
                task_db.error = str(e)
                task_db.updated_at = datetime.utcnow()
                await session.commit()
            raise

    async def _browse_recommend(self, account_id: str, config: Dict[str, Any]):
        """浏览推荐页 - 自然滚动"""
        duration = random.uniform(
            config.get("duration_min", 10) * 60,
            config.get("duration_max", 20) * 60,
        )
        logger.info(f"Browsing recommend for {duration / 60:.1f} minutes")
        await self.browser.browse_recommend(duration)
        # 更新操作计数
        await self._increment_action_count(account_id)

    async def _like_note(self, account_id: str, note: Dict[str, Any]):
        """点赞 - 先阅读3-8秒"""
        read_time = random.uniform(3, 8)
        await asyncio.sleep(read_time)
        await self.browser.like_note(note.get("page"))
        # 取消概率5%
        if random.random() < 0.05:
            await asyncio.sleep(random.uniform(5, 15))
            await self.browser.like_note(note.get("page"))  # 再次点击取消
        await asyncio.sleep(random.uniform(10, 60))
        await self._increment_action_count(account_id)

    async def _collect_note(self, account_id: str, note: Dict[str, Any]):
        """收藏 - 需完整阅读"""
        read_time = random.uniform(8, 15)
        await asyncio.sleep(read_time)
        await self.browser.collect_note(note.get("page"))
        await asyncio.sleep(random.uniform(15, 45))
        await self._increment_action_count(account_id)

    async def _comment_note(self, account_id: str, note: Dict[str, Any]):
        """AI生成15-40字自然评论"""
        prompt = f"""请为以下小红书笔记生成一条自然的评论，要求：
- 15-40字
- 含1-2个emoji
- 口语化，像真实用户
- 积极正面

笔记标题：{note.get('title', '')}
笔记内容摘要：{note.get('content', '')[:200]}

直接返回评论文字，不要引号或其他格式。"""

        comment = await self.ai_service.call(prompt=prompt, temperature=0.9, max_tokens=100)
        comment = comment.strip().strip('"').strip("'")

        read_time = random.uniform(5, 12)
        await asyncio.sleep(read_time)
        await self.browser.comment_note(note.get("page"), comment)
        await asyncio.sleep(random.uniform(20, 60))
        await self._increment_action_count(account_id)

    async def _follow_user(self, account_id: str, user: Dict[str, Any]):
        """关注 - 优先同领域"""
        await self.browser.follow_user(user.get("page"))
        await asyncio.sleep(random.uniform(15, 45))
        await self._increment_action_count(account_id)

    async def _get_random_note(self, account_id: str) -> Optional[Dict[str, Any]]:
        """获取随机笔记（从推荐页）"""
        try:
            notes = await self.browser.search_notes("")  # 使用默认推荐
            if notes:
                return random.choice(notes)
        except Exception as e:
            logger.error(f"Failed to get random note: {e}")
        return None

    async def _get_random_user(self, account_id: str) -> Optional[Dict[str, Any]]:
        """获取随机用户"""
        note = await self._get_random_note(account_id)
        if note:
            return {"page": note.get("page"), "user_id": note.get("author_id")}
        return None

    async def _increment_action_count(self, account_id: str):
        """更新操作计数"""
        async with async_session_maker() as session:
            account = await session.get(Account, account_id)
            if account:
                account.today_actions = (account.today_actions or 0) + 1
                account.total_actions = (account.total_actions or 0) + 1
                account.updated_at = datetime.utcnow()
                await session.commit()
