"""运营策略引擎"""

import uuid
import json
from datetime import datetime, time, timedelta
from typing import Dict, Any, List, Optional

from loguru import logger
from sqlalchemy import select, and_, desc, func

from app.database import async_session_maker
from app.models.account import Account, AccountStatus
from app.models.task import Task, TaskStatus, TaskType
from app.models.strategy_override import StrategyOverride
from app.models.daily_stat import DailyStat


# 活跃时段模板
ACTIVE_HOURS_WEEKDAY = [
    {"start": "08:00", "end": "09:30", "intensity": 0.3},
    {"start": "12:00", "end": "14:00", "intensity": 0.8},
    {"start": "18:00", "end": "19:30", "intensity": 0.6},
    {"start": "21:00", "end": "23:30", "intensity": 1.0},
]

ACTIVE_HOURS_WEEKEND = [
    {"start": "09:00", "end": "12:00", "intensity": 0.7},
    {"start": "14:00", "end": "17:00", "intensity": 0.8},
    {"start": "20:00", "end": "23:30", "intensity": 1.0},
]


class StrategyEngine:
    """运营策略引擎"""

    async def generate_daily_plan(
        self, account_id: str, date: Optional[datetime] = None
    ) -> Dict[str, Any]:
        """生成每日计划"""
        if date is None:
            date = datetime.utcnow()
        date_str = date.strftime("%Y-%m-%d")

        async with async_session_maker() as session:
            account = await session.get(Account, account_id)
            if not account:
                raise ValueError(f"Account {account_id} not found")

            # 检查已有任务数
            result = await session.execute(
                select(func.count(Task.id)).where(
                    Task.account_id == account_id,
                    Task.created_at >= datetime.strptime(date_str, "%Y-%m-%d"),
                )
            )
            existing_count = result.scalar()
            if existing_count > 10:
                logger.info(f"Account {account_id} already has {existing_count} tasks today, skipping")
                return {"skipped": True, "reason": "enough tasks already"}

            # 检查策略覆盖
            result = await session.execute(
                select(StrategyOverride).where(
                    StrategyOverride.account_id == account_id,
                    StrategyOverride.date == date_str,
                )
            )
            override = result.scalar_one_or_none()

            # 检查昨日未完成任务
            yesterday = (date - timedelta(days=1)).strftime("%Y-%m-%d")
            result = await session.execute(
                select(Task).where(
                    Task.account_id == account_id,
                    Task.status.in_([TaskStatus.PENDING, TaskStatus.RUNNING]),
                    Task.created_at >= datetime.strptime(yesterday, "%Y-%m-%d"),
                    Task.created_at < datetime.strptime(date_str, "%Y-%m-%d"),
                )
            )
            incomplete_tasks = result.scalars().all()

        # 获取活跃时段
        active_hours = self._get_active_hours(date)

        # 根据阶段调整
        if account.operation_started_at:
            days_running = (date - account.operation_started_at).days
            if days_running < 7:
                stage = "nurture"
            elif days_running < 30:
                stage = "growth"
            else:
                stage = "mature"
        else:
            stage = "preparation"

        # 生成任务
        tasks = []
        async with async_session_maker() as session:
            # 添加未完成的昨日任务
            for old_task in incomplete_tasks:
                old_task.status = TaskStatus.PENDING
                old_task.updated_at = datetime.utcnow()
                tasks.append(old_task)

            # 根据阶段生成不同类型的任务
            if stage == "nurture":
                # 养号阶段以浏览为主
                for hour_slot in active_hours[:3]:
                    task = Task(
                        id=str(uuid.uuid4()),
                        account_id=account_id,
                        task_type=TaskType.BROWSE,
                        task_name=f"浏览推荐 ({hour_slot['start']})",
                        status=TaskStatus.PENDING,
                        priority=5,
                        task_data={"slot": hour_slot},
                        created_at=datetime.utcnow(),
                        updated_at=datetime.utcnow(),
                    )
                    session.add(task)
                    tasks.append(task)

            elif stage in ("growth", "mature"):
                # 生成内容
                content_count = 1 if stage == "growth" else 2
                for i in range(content_count):
                    task = Task(
                        id=str(uuid.uuid4()),
                        account_id=account_id,
                        task_type=TaskType.GENERATE,
                        task_name=f"生成内容 #{i + 1}",
                        status=TaskStatus.PENDING,
                        priority=8,
                        created_at=datetime.utcnow(),
                        updated_at=datetime.utcnow(),
                    )
                    session.add(task)
                    tasks.append(task)

                # 浏览互动
                for hour_slot in active_hours[:2]:
                    task = Task(
                        id=str(uuid.uuid4()),
                        account_id=account_id,
                        task_type=TaskType.BROWSE,
                        task_name=f"浏览互动 ({hour_slot['start']})",
                        status=TaskStatus.PENDING,
                        priority=4,
                        task_data={"slot": hour_slot},
                        created_at=datetime.utcnow(),
                        updated_at=datetime.utcnow(),
                    )
                    session.add(task)
                    tasks.append(task)

            # 应用策略覆盖
            if override:
                override_data = override.data or {}
                if override_data.get("skip_tasks"):
                    for task in tasks:
                        task.status = TaskStatus.CANCELLED
                if override_data.get("extra_tasks"):
                    for extra in override_data["extra_tasks"]:
                        task = Task(
                            id=str(uuid.uuid4()),
                            account_id=account_id,
                            task_type=extra.get("type", TaskType.BROWSE),
                            task_name=extra.get("name", "Extra task"),
                            status=TaskStatus.PENDING,
                            priority=extra.get("priority", 3),
                            task_data=extra.get("data", {}),
                            created_at=datetime.utcnow(),
                            updated_at=datetime.utcnow(),
                        )
                        session.add(task)
                        tasks.append(task)

            await session.commit()

        return {
            "account_id": account_id,
            "date": date_str,
            "stage": stage,
            "tasks_count": len(tasks),
            "tasks": [
                {
                    "id": str(t.id) if hasattr(t, "id") else str(uuid.uuid4()),
                    "type": t.task_type if hasattr(t, "task_type") else "unknown",
                    "name": t.task_name if hasattr(t, "task_name") else "",
                }
                for t in tasks
            ],
        }

    async def generate_all_daily_plans(self):
        """为所有活跃账号生成计划"""
        async with async_session_maker() as session:
            result = await session.execute(
                select(Account).where(
                    Account.status.in_([
                        AccountStatus.running,
                        AccountStatus.online,
                    ])
                )
            )
            accounts = result.scalars().all()

        for account in accounts:
            try:
                await self.generate_daily_plan(str(account.id))
            except Exception as e:
                logger.error(f"Failed to generate plan for account {account.id}: {e}")

    def _adjust_intensity(
        self, account_id: str, yesterday_data: Optional[Dict[str, Any]] = None
    ) -> float:
        """调整操作强度"""
        base_intensity = 1.0

        if not yesterday_data:
            return base_intensity

        # 根据昨日表现调整
        engagement_rate = yesterday_data.get("engagement_rate", 0)
        if engagement_rate > 0.1:
            base_intensity *= 1.2  # 表现好，加大力度
        elif engagement_rate < 0.03:
            base_intensity *= 0.7  # 表现差，降低力度

        # 根据粉丝增长调整
        follower_change = yesterday_data.get("follower_change", 0)
        if follower_change < 0:
            base_intensity *= 0.8  # 掉粉，减少操作

        return min(max(base_intensity, 0.3), 2.0)

    def _get_active_hours(self, date: datetime) -> List[Dict[str, Any]]:
        """获取当日活跃时段"""
        is_weekend = date.weekday() >= 5
        hours = ACTIVE_HOURS_WEEKEND if is_weekend else ACTIVE_HOURS_WEEKDAY

        # 随机微调
        import random
        adjusted = []
        for slot in hours:
            start_parts = slot["start"].split(":")
            start_hour = int(start_parts[0]) + random.choice([-1, 0, 0, 0, 1])
            start_hour = max(6, min(23, start_hour))
            adjusted.append({
                "start": f"{start_hour:02d}:{start_parts[1]}",
                "end": slot["end"],
                "intensity": slot["intensity"],
            })
        return adjusted
