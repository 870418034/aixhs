"""
一键生成本周运营计划
"""
from __future__ import annotations
import json
from datetime import datetime, date, timedelta
from typing import List, Dict, Optional
from sqlalchemy import select, and_
from sqlalchemy.ext.asyncio import AsyncSession
from loguru import logger

from app.models import Account, Content, DailyStat, Task
from app.database import get_db_session
from app.services.strategy_engine import strategy_engine


class WeeklyPlanner:
    """一周计划生成器"""

    def __init__(self, content_generator=None):
        self.content_generator = content_generator

    async def generate_weekly_plan(self, account_id: str) -> Dict:
        """生成本周运营计划"""
        async for db in get_db_session():
            account = await db.get(Account, account_id)
            if not account:
                return {"error": "账号不存在"}

            today = date.today()
            week_start = today - timedelta(days=today.weekday())
            week_end = week_start + timedelta(days=6)

            recent_data = await self._get_recent_data(db, account_id, 7)
            plan = await self._generate_plan(db, account, recent_data, week_start, week_end)
            await db.commit()
            logger.info(f"周计划已生成: {account.nickname}")
            return plan

    async def _get_recent_data(self, db: AsyncSession, account_id: str, days: int) -> Dict:
        """获取近期数据"""
        start_date = date.today() - timedelta(days=days)
        stmt = select(DailyStat).where(
            DailyStat.account_id == account_id,
            DailyStat.date >= start_date
        ).order_by(DailyStat.date.desc())
        result = await db.execute(stmt)
        stats = result.scalars().all()
        return {
            "avg_followers_gain": sum(s.followers_gain for s in stats) / max(len(stats), 1),
            "avg_views": sum(s.total_views for s in stats) / max(len(stats), 1),
            "total_publish": sum(s.publish_count for s in stats),
            "best_publish_times": ["18:00", "21:00"],
        }

    async def _generate_plan(
        self, db: AsyncSession, account: Account,
        recent_data: Dict, start: date, end: date
    ) -> Dict:
        """生成计划详情"""
        plan = {
            "account_id": account.id,
            "week_start": str(start),
            "week_end": str(end),
            "daily_plans": [],
            "summary": "",
        }
        best_times = recent_data.get("best_publish_times", ["18:00", "21:00"])
        current = start
        while current <= end:
            is_weekend = current.weekday() >= 5
            daily = {
                "date": str(current),
                "weekday": ["周一", "周二", "周三", "周四", "周五", "周六", "周日"][current.weekday()],
                "tasks": [],
                "publish_count": 2 if not is_weekend else 1,
                "publish_times": best_times[:2] if not is_weekend else [best_times[0]],
            }
            daily["tasks"].append({"time": "09:30", "action": "browse", "duration": 15})
            daily["tasks"].append({"time": "11:00", "action": "interact", "likes": "5-8", "comments": "1-2"})
            for pub_time in daily["publish_times"]:
                daily["tasks"].append({"time": pub_time, "action": "publish", "note": "定时发布"})
            daily["tasks"].append({"time": "20:00", "action": "interact", "note": "回复评论"})
            plan["daily_plans"].append(daily)
            current += timedelta(days=1)

        plan["summary"] = f"本周计划发布 {sum(d['publish_count'] for d in plan['daily_plans'])} 篇内容"
        return plan


weekly_planner = WeeklyPlanner()
