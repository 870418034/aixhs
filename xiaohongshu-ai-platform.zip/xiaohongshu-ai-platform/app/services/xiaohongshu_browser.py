"""
Playwright操作小红书 - 核心浏览器操作封装
包含: QR码登录、Cookie管理、账号数据抓取、浏览/点赞/收藏/评论/发布等操作
"""
from __future__ import annotations

import os
import json
import base64
import asyncio
import random
import uuid
from datetime import datetime
from pathlib import Path
from typing import Optional, Dict, Any, List

from loguru import logger
from playwright.async_api import async_playwright, Browser, BrowserContext, Page

from app.config import get_config
from app.database import async_session_maker
from app.models import Account

DATA_DIR = Path("data")
ACCOUNTS_DIR = DATA_DIR / "accounts"


class XiaohongshuBrowser:
    """小红书浏览器操作封装"""

    BASE_URL = "https://www.xiaohongshu.com"
    LOGIN_URL = "https://www.xiaohongshu.com/login"

    def __init__(self):
        self._playwright = None
        self._browser: Optional[Browser] = None
        self._contexts: Dict[str, BrowserContext] = {}
        self._lock = asyncio.Lock()
        # QR code login: token -> {context, page, created_at, status}
        self._qr_sessions: Dict[str, Dict[str, Any]] = {}

    # ═══════════════════════════════════════════
    # 浏览器管理
    # ═══════════════════════════════════════════

    async def _ensure_browser(self):
        """确保浏览器已启动"""
        if self._browser and self._browser.is_connected():
            return
        config = get_config()
        self._playwright = await async_playwright().start()
        self._browser = await self._playwright.chromium.launch(
            headless=config.browser.headless,
            args=[
                "--disable-blink-features=AutomationControlled",
                "--no-sandbox",
                "--disable-setuid-sandbox",
                "--disable-dev-shm-usage",
                "--disable-gpu",
                "--window-size=1280,800",
                "--lang=zh-CN",
                "--no-first-run",
                "--no-default-browser-check",
            ],
        )
        logger.info("浏览器已启动")

    async def _get_context(self, account_id: str) -> BrowserContext:
        """获取账号对应的浏览器上下文（带Cookie+指纹伪装）"""
        await self._ensure_browser()

        if account_id in self._contexts:
            ctx = self._contexts[account_id]
            if not ctx._closed:
                return ctx

        # 从数据库获取账号
        async with async_session_maker() as session:
            account = await session.get(Account, account_id)
            if not account:
                raise ValueError(f"账号不存在: {account_id}")

        # 加载Cookie（从加密文件）
        cookies = []
        cookie_path = account.cookie_path or str(ACCOUNTS_DIR / account_id / "cookies.enc")
        if os.path.exists(cookie_path):
            try:
                from app.core.encryption import decrypt
                with open(cookie_path, "r", encoding="utf-8") as f:
                    encrypted = f.read()
                decrypted = decrypt(encrypted)
                cookies = json.loads(decrypted)
                logger.debug(f"已加载Cookie: {account_id}, {len(cookies)}条")
            except Exception as e:
                logger.warning(f"Cookie解密失败 {account_id}: {e}")

        # 获取指纹参数（账号绑定的固定指纹）
        fingerprint = json.loads(account.fingerprint or "{}")
        if not fingerprint:
            from app.core.fingerprint_spoof import FingerprintSpoof
            fp = FingerprintSpoof()
            fingerprint = fp.generate_fingerprint()
            # 保存指纹到数据库
            async with async_session_maker() as session:
                acc = await session.get(Account, account_id)
                if acc:
                    acc.fingerprint = json.dumps(fingerprint, ensure_ascii=False)
                    await session.commit()

        user_agent = fingerprint.get("user_agent", "")
        config = get_config()
        context = await self._browser.new_context(
            viewport=config.browser.viewport or {"width": 1280, "height": 800},
            user_agent=user_agent,
        )

        # 注入指纹伪装脚本
        try:
            from app.core.fingerprint_spoof import FingerprintSpoof
            fp = FingerprintSpoof()
            fp._fingerprint = fingerprint
            injection_script = fp.get_injection_script()
            await context.add_init_script(injection_script)
        except Exception as e:
            logger.warning(f"指纹注入失败: {e}")

        if cookies:
            await context.add_cookies(cookies)

        self._contexts[account_id] = context
        return context

    async def save_cookies(self, account_id: str):
        """保存账号Cookie到加密文件"""
        if account_id not in self._contexts:
            return
        ctx = self._contexts[account_id]
        try:
            cookies = await ctx.cookies()
            cookie_json = json.dumps(cookies, ensure_ascii=False)

            from app.core.encryption import encrypt
            encrypted = encrypt(cookie_json)

            # 确保目录存在
            account_dir = ACCOUNTS_DIR / account_id
            account_dir.mkdir(parents=True, exist_ok=True)
            cookie_path = account_dir / "cookies.enc"

            with open(cookie_path, "w", encoding="utf-8") as f:
                f.write(encrypted)

            # 更新数据库
            async with async_session_maker() as session:
                account = await session.get(Account, account_id)
                if account:
                    account.cookie_path = str(cookie_path)
                    await session.commit()

            logger.info(f"Cookie已保存: {account_id}")
        except Exception as e:
            logger.error(f"Cookie保存失败 {account_id}: {e}")

    # ═══════════════════════════════════════════
    # QR码登录
    # ═══════════════════════════════════════════

    async def get_qr_code(self) -> Dict[str, Any]:
        """
        获取登录二维码
        返回: {qr_code: base64字符串, token: 会话token, expires_in: 过期秒数}
        """
        await self._ensure_browser()
        context = await self._browser.new_context(
            viewport={"width": 1280, "height": 800},
            user_agent="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
        )
        page = await context.new_page()

        try:
            await page.goto(self.LOGIN_URL, wait_until="networkidle", timeout=30000)
            await page.wait_for_timeout(3000)

            # 尝试点击"二维码登录"切换
            try:
                qr_btn = page.locator('text=二维码登录, [class*="qr-tab"], [class*="qrcode-tab"]').first
                if await qr_btn.is_visible(timeout=2000):
                    await qr_btn.click()
                    await page.wait_for_timeout(2000)
            except Exception:
                pass

            # 获取二维码图片
            qr_base64 = ""
            try:
                qr_el = page.locator(
                    '[class*="qr-code"] img, [class*="qrcode"] img, '
                    '[class*="login-code"] img, [class*="login-qrcode"] img'
                ).first
                qr_src = await qr_el.get_attribute("src") or ""
                if qr_src.startswith("data:image"):
                    qr_base64 = qr_src.split(",", 1)[1] if "," in qr_src else qr_src
                else:
                    screenshot = await qr_el.screenshot(type="png")
                    qr_base64 = base64.b64encode(screenshot).decode()
            except Exception:
                # Fallback: 截取整个页面
                try:
                    screenshot = await page.screenshot(type="png")
                    qr_base64 = base64.b64encode(screenshot).decode()
                except Exception as e:
                    logger.error(f"二维码截图失败: {e}")

            # 生成唯一token
            token = str(uuid.uuid4())

            # 存储QR会话
            self._qr_sessions[token] = {
                "context": context,
                "page": page,
                "created_at": datetime.utcnow(),
                "status": "pending",
            }

            logger.info(f"二维码已生成, token={token[:8]}...")
            return {
                "qr_code": qr_base64,
                "token": token,
                "expires_in": 300,
            }

        except Exception as e:
            logger.error(f"获取二维码失败: {e}")
            try:
                await page.close()
                await context.close()
            except Exception:
                pass
            return {"qr_code": "", "token": "", "error": str(e), "expires_in": 0}

    async def check_qr_status(self, token: str) -> Dict[str, Any]:
        """
        检查扫码状态
        返回: {status: pending/scanned/success/expired, cookies: [...], user_info: {...}}
        """
        if token not in self._qr_sessions:
            return {"status": "expired", "message": "二维码不存在或已过期"}

        session = self._qr_sessions[token]
        elapsed = (datetime.utcnow() - session["created_at"]).total_seconds()

        # 5分钟超时
        if elapsed > 300:
            await self._cleanup_qr_session(token)
            return {"status": "expired", "message": "二维码已过期，请重新获取"}

        page = session["page"]
        context = session["context"]

        try:
            current_url = page.url

            # 检测是否已登录成功（页面跳转离开login页）
            if "/login" not in current_url:
                # 扫码成功！
                cookies = await context.cookies()

                # 获取用户信息
                user_info = {}
                try:
                    await page.wait_for_timeout(2000)
                    # 尝试从页面获取用户信息
                    name_el = page.locator('[class*="name"], [class*="nickname"]').first
                    if await name_el.is_visible(timeout=3000):
                        user_info["name"] = await name_el.text_content() or ""
                except Exception:
                    pass

                logger.info(f"扫码登录成功: {user_info.get('name', 'unknown')}")
                # 不关闭context，返回cookies让调用方保存
                self._cleanup_qr_session_no_close(token)

                return {
                    "status": "success",
                    "cookies": cookies,
                    "user_info": user_info,
                    "message": "登录成功",
                }

            # 检查二维码是否过期（页面提示）
            try:
                expired_el = page.locator(
                    'text=二维码已过期, text=已过期, [class*="expired"], [class*="timeout"]'
                ).first
                if await expired_el.is_visible(timeout=1000):
                    return {"status": "expired", "message": "二维码已过期，请重新获取"}
            except Exception:
                pass

            # 检查"已扫码，等待确认"状态
            try:
                scanned_el = page.locator(
                    'text=已扫码, text=请在手机上确认, text=确认登录, [class*="scanned"]'
                ).first
                if await scanned_el.is_visible(timeout=1000):
                    session["status"] = "scanned"
                    return {"status": "scanned", "message": "已扫码，请在手机上确认"}
            except Exception:
                pass

            return {"status": "pending", "message": "等待扫码中", "elapsed": int(elapsed)}

        except Exception as e:
            logger.error(f"检查扫码状态异常: {e}")
            return {"status": "pending", "message": "检查中...", "elapsed": int(elapsed)}

    def _cleanup_qr_session_no_close(self, token: str):
        """清理QR会话（不关闭context，用于登录成功后的Cookie保存）"""
        self._qr_sessions.pop(token, None)

    async def _cleanup_qr_session(self, token: str):
        """清理QR会话并关闭资源"""
        session = self._qr_sessions.pop(token, None)
        if not session:
            return
        try:
            await session["page"].close()
        except Exception:
            pass
        try:
            await session["context"].close()
        except Exception:
            pass

    # ═══════════════════════════════════════════
    # 账号数据抓取
    # ═══════════════════════════════════════════

    async def open_profile(self, account_id: str) -> Dict[str, Any]:
        """抓取账号主页数据"""
        context = await self._get_context(account_id)
        page = await context.new_page()

        try:
            await page.goto(f"{self.BASE_URL}/user/profile", wait_until="networkidle", timeout=30000)
            await page.wait_for_timeout(2000)

            data = {
                "followers": 0, "following": 0, "notes": 0, "likes": 0,
                "bio": "", "avatar_url": "", "nickname": "", "xhs_id": "",
                "gender": 0, "ip_location": "",
            }

            selectors = {
                "followers": ['[class*="followers"] .count', '[class*="fans"] .count', '[class*="fans-count"]'],
                "following": ['[class*="following"] .count', '[class*="follows"] .count'],
                "notes": ['[class*="notes"] .count', '.tab-item.active .count'],
                "likes": ['[class*="liked"] .count', '[class*="like-count"]'],
            }
            for field, sels in selectors.items():
                for sel in sels:
                    try:
                        el = page.locator(sel).first
                        if await el.is_visible(timeout=1000):
                            text = await el.text_content()
                            data[field] = self._parse_count(text)
                            break
                    except Exception:
                        continue

            text_selectors = {
                "bio": ['[class*="desc"]', '[class*="bio"]'],
                "nickname": ['[class*="name"]', '[class*="nickname"]'],
            }
            for field, sels in text_selectors.items():
                for sel in sels:
                    try:
                        el = page.locator(sel).first
                        if await el.is_visible(timeout=1000):
                            data[field] = await el.text_content() or ""
                            break
                    except Exception:
                        continue

            try:
                avatar_el = page.locator('[class*="avatar"] img').first
                data["avatar_url"] = await avatar_el.get_attribute("src") or ""
            except Exception:
                pass

            return data
        finally:
            await page.close()

    # ═══════════════════════════════════════════
    # 浏览与互动
    # ═══════════════════════════════════════════

    async def browse_recommend(self, account_id: str, duration: float = 300):
        """浏览推荐页 - 模拟自然滚动"""
        context = await self._get_context(account_id)
        page = await context.new_page()
        try:
            await page.goto(self.BASE_URL, wait_until="networkidle", timeout=30000)
            await page.wait_for_timeout(2000)

            elapsed = 0
            while elapsed < duration:
                scroll_distance = random.randint(200, 600)
                scroll_speed = random.uniform(0.3, 1.5)
                await page.evaluate(f"window.scrollBy(0, {scroll_distance})")
                await page.wait_for_timeout(int(scroll_speed * 1000))

                # 12%概率回滚
                if random.random() < 0.12:
                    rollback = random.randint(100, 300)
                    await page.evaluate(f"window.scrollBy(0, -{rollback})")
                    await page.wait_for_timeout(random.randint(500, 1500))

                # 20%概率停留阅读
                if random.random() < 0.2:
                    await page.wait_for_timeout(random.randint(3000, 10000))

                elapsed += scroll_speed + 1

                # 15%概率点击笔记
                if random.random() < 0.15:
                    try:
                        notes = await page.locator('[class*="note-item"], section.note-item').all()
                        if notes:
                            note = random.choice(notes[:5])
                            await note.click()
                            await page.wait_for_timeout(random.randint(5000, 15000))
                            await page.go_back()
                            await page.wait_for_timeout(2000)
                    except Exception:
                        pass
        finally:
            await page.close()

    async def like_note(self, page: Page) -> bool:
        """点赞当前笔记"""
        try:
            # 先等待几秒（模拟阅读）
            await page.wait_for_timeout(random.randint(3000, 8000))
            like_btn = page.locator('[class*="like"], [class*="like-wrapper"]').first
            await like_btn.click()
            await page.wait_for_timeout(random.randint(500, 1500))
            return True
        except Exception as e:
            logger.error(f"点赞失败: {e}")
            return False

    async def collect_note(self, page: Page) -> bool:
        """收藏当前笔记"""
        try:
            await page.wait_for_timeout(random.randint(5000, 10000))
            collect_btn = page.locator('[class*="collect"], [class*="star"]').first
            await collect_btn.click()
            await page.wait_for_timeout(random.randint(500, 1500))
            return True
        except Exception as e:
            logger.error(f"收藏失败: {e}")
            return False

    async def comment_note(self, page: Page, text: str) -> bool:
        """评论当前笔记"""
        try:
            comment_input = page.locator(
                'textarea[class*="comment"], [contenteditable="true"]'
            ).first
            await comment_input.click()
            await page.wait_for_timeout(500)
            # 模拟打字速度
            for char in text:
                await comment_input.type(char, delay=random.randint(50, 200))
            await page.wait_for_timeout(1000)
            submit_btn = page.locator('button:has-text("发送"), button:has-text("发布")').first
            await submit_btn.click()
            await page.wait_for_timeout(random.randint(1000, 3000))
            return True
        except Exception as e:
            logger.error(f"评论失败: {e}")
            return False

    async def follow_user(self, page: Page) -> bool:
        """关注用户"""
        try:
            follow_btn = page.locator('[class*="follow-btn"], button:has-text("关注")').first
            await follow_btn.click()
            await page.wait_for_timeout(random.randint(1000, 3000))
            return True
        except Exception as e:
            logger.error(f"关注失败: {e}")
            return False

    # ═══════════════════════════════════════════
    # 发布笔记
    # ═══════════════════════════════════════════

    async def publish_note(
        self, account_id: str, title: str, body: str,
        images: List[str], tags: List[str], topic: str = "",
    ) -> Dict[str, Any]:
        """发布笔记"""
        context = await self._get_context(account_id)
        page = await context.new_page()

        try:
            await page.goto(f"{self.BASE_URL}/creator/publish", wait_until="networkidle", timeout=30000)
            await page.wait_for_timeout(2000)

            # 上传图片
            if images:
                try:
                    upload_input = page.locator('input[type="file"]').first
                    valid_paths = [img for img in images if os.path.exists(img)]
                    if valid_paths:
                        await upload_input.set_input_files(valid_paths)
                        await page.wait_for_timeout(3000)
                except Exception as e:
                    logger.warning(f"图片上传失败: {e}")

            # 填标题
            try:
                title_input = page.locator('input[class*="title"], textarea[class*="title"]').first
                await title_input.fill(title)
                await page.wait_for_timeout(500)
            except Exception:
                pass

            # 填正文
            try:
                body_input = page.locator('[contenteditable="true"], textarea[class*="content"]').first
                await body_input.click()
                await page.wait_for_timeout(300)
                await body_input.fill(body)
                await page.wait_for_timeout(1000)
            except Exception:
                pass

            # 添加标签
            for tag in tags[:10]:
                try:
                    tag_input = page.locator('input[placeholder*="标签"], input[placeholder*="话题"]').first
                    await tag_input.fill(f"#{tag}")
                    await page.wait_for_timeout(500)
                    await page.keyboard.press("Enter")
                    await page.wait_for_timeout(300)
                except Exception:
                    break

            # 添加话题
            if topic:
                try:
                    topic_input = page.locator('input[placeholder*="话题"]').first
                    await topic_input.fill(f"#{topic}")
                    await page.wait_for_timeout(500)
                    await page.keyboard.press("Enter")
                except Exception:
                    pass

            # 截图预览
            screenshot_dir = DATA_DIR / "logs" / "screenshots"
            screenshot_dir.mkdir(parents=True, exist_ok=True)
            screenshot_path = screenshot_dir / f"preview_{account_id}_{datetime.now().strftime('%H%M%S')}.png"
            await page.screenshot(path=str(screenshot_path))

            # 点击发布
            publish_btn = page.locator('button:has-text("发布"), button:has-text("发表")').first
            await publish_btn.click()
            await page.wait_for_timeout(5000)

            # 检测错误
            try:
                error_el = page.locator('[class*="error"], [class*="toast"]').first
                if await error_el.is_visible(timeout=2000):
                    error_text = await error_el.text_content()
                    if error_text and "成功" not in error_text:
                        raise RuntimeError(f"发布失败: {error_text}")
            except RuntimeError:
                raise
            except Exception:
                pass

            # 保存Cookie
            await self.save_cookies(account_id)

            # 获取URL
            url = page.url
            note_id = url.split("/")[-1] if "/" in url else ""

            return {
                "note_id": note_id,
                "url": url,
                "screenshot": str(screenshot_path),
            }
        except Exception as e:
            logger.error(f"发布笔记失败: {e}")
            raise
        finally:
            await page.close()

    # ═══════════════════════════════════════════
    # 笔记数据
    # ═══════════════════════════════════════════

    async def open_note(self, note_id: str) -> Dict[str, Any]:
        """打开笔记详情并抓取数据"""
        if not self._contexts:
            return {}

        context = list(self._contexts.values())[0]
        page = await context.new_page()

        try:
            url = f"{self.BASE_URL}/explore/{note_id}"
            await page.goto(url, wait_until="networkidle", timeout=30000)
            await page.wait_for_timeout(2000)

            data = {
                "note_id": note_id, "title": "", "content": "",
                "likes": 0, "collects": 0, "comments": 0, "shares": 0,
            }

            field_selectors = {
                "title": ['[class*="title"]'],
                "content": ['[class*="content"]', '[class*="desc"]'],
            }
            for field, sels in field_selectors.items():
                for sel in sels:
                    try:
                        el = page.locator(sel).first
                        if await el.is_visible(timeout=1000):
                            data[field] = await el.text_content() or ""
                            break
                    except Exception:
                        continue

            count_selectors = {
                "likes": ['[class*="like"] .count', '[class*="like-count"]'],
                "collects": ['[class*="collect"] .count', '[class*="star"] .count'],
                "comments": ['[class*="comment"] .count'],
            }
            for field, sels in count_selectors.items():
                for sel in sels:
                    try:
                        el = page.locator(sel).first
                        if await el.is_visible(timeout=1000):
                            text = await el.text_content()
                            data[field] = self._parse_count(text)
                            break
                    except Exception:
                        continue

            return data
        finally:
            await page.close()

    async def get_note_stats(self, note_id: str) -> Dict[str, Any]:
        """获取笔记统计数据"""
        note_data = await self.open_note(note_id)
        return {
            "views": note_data.get("views", 0),
            "likes": note_data.get("likes", 0),
            "collects": note_data.get("collects", 0),
            "comments": note_data.get("comments", 0),
            "shares": note_data.get("shares", 0),
        }

    async def search_notes(self, keyword: str) -> List[Dict[str, Any]]:
        """搜索笔记"""
        if not self._contexts:
            return []
        context = list(self._contexts.values())[0]
        page = await context.new_page()

        try:
            url = f"{self.BASE_URL}/search_result?keyword={keyword}&source=web_search_result_notes"
            await page.goto(url, wait_until="networkidle", timeout=30000)
            await page.wait_for_timeout(3000)

            results = []
            notes = await page.locator('[class*="note-item"], section.note-item').all()
            for note in notes[:20]:
                try:
                    title = await note.locator('[class*="title"]').text_content()
                    likes = await note.locator('[class*="like-count"], [class*="count"]').text_content()
                    results.append({"title": title or "", "likes": self._parse_count(likes)})
                except Exception:
                    continue
            return results
        except Exception as e:
            logger.error(f"搜索失败: {e}")
            return []
        finally:
            await page.close()

    # ═══════════════════════════════════════════
    # 资料修改
    # ═══════════════════════════════════════════

    async def update_profile(
        self, account_id: str,
        nickname: Optional[str] = None,
        bio: Optional[str] = None,
    ) -> bool:
        """更新个人资料"""
        context = await self._get_context(account_id)
        page = await context.new_page()

        try:
            await page.goto(f"{self.BASE_URL}/user/profile/setting", wait_until="networkidle", timeout=30000)
            await page.wait_for_timeout(2000)

            if nickname:
                try:
                    name_input = page.locator('input[class*="name"], input[placeholder*="昵称"]').first
                    await name_input.fill(nickname)
                    await page.wait_for_timeout(500)
                except Exception:
                    pass

            if bio:
                try:
                    bio_input = page.locator('textarea[class*="bio"], textarea[placeholder*="简介"]').first
                    await bio_input.fill(bio)
                    await page.wait_for_timeout(500)
                except Exception:
                    pass

            save_btn = page.locator('button:has-text("保存"), button:has-text("确认")').first
            await save_btn.click()
            await page.wait_for_timeout(2000)

            await self.save_cookies(account_id)
            return True
        except Exception as e:
            logger.error(f"更新资料失败: {e}")
            return False
        finally:
            await page.close()

    # ═══════════════════════════════════════════
    # 工具方法
    # ═══════════════════════════════════════════

    @staticmethod
    def _parse_count(text: Optional[str]) -> int:
        """解析数量文本（处理万、k等）"""
        if not text:
            return 0
        text = text.strip().replace(",", "").replace(" ", "")
        try:
            if "万" in text:
                return int(float(text.replace("万", "")) * 10000)
            if "k" in text.lower():
                return int(float(text.lower().replace("k", "")) * 1000)
            if "w" in text.lower():
                return int(float(text.lower().replace("w", "")) * 10000)
            return int(float(text))
        except (ValueError, TypeError):
            return 0

    async def close(self):
        """关闭浏览器"""
        qr_tokens = list(self._qr_sessions.keys())
        for token in qr_tokens:
            await self._cleanup_qr_session(token)

        for account_id in list(self._contexts.keys()):
            await self.save_cookies(account_id)
        for ctx in self._contexts.values():
            try:
                await ctx.close()
            except Exception:
                pass
        self._contexts.clear()

        if self._browser:
            await self._browser.close()
        if self._playwright:
            await self._playwright.stop()
        logger.info("浏览器已关闭")


# 全局实例
xiaohongshu_browser = XiaohongshuBrowser()
