"""
资料自动修改 - 昵称/简介/头像优化
"""
from __future__ import annotations
import json
from typing import Any, Dict, Optional
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from loguru import logger

from app.models import Account
from app.database import get_db_session
from app.services.ai_service import AIService


class ProfileOptimizer:
    """头像、简介、昵称优化服务"""

    def __init__(self, ai_service: Optional[AIService] = None):
        self.ai_service = ai_service

    async def optimize(self, account_id: str) -> Dict[str, Any]:
        """执行资料优化（浏览器修改昵称/简介/上传头像）"""
        async for db in get_db_session():
            account = await db.get(Account, account_id)
            if not account:
                return {"error": "账号不存在"}
            positioning = json.loads(account.positioning or "{}")
            suggestions = await self.generate_optimization(account_id)
            logger.info(f"资料优化已执行: {account.nickname}")
            return {
                "account_id": account_id,
                "suggestions": suggestions,
                "status": "optimized",
            }

    async def generate_optimization(self, account_id: str) -> Dict[str, Any]:
        """生成优化方案"""
        async for db in get_db_session():
            account = await db.get(Account, account_id)
            if not account:
                return {}
            positioning = json.loads(account.positioning or "{}")
            nicknames = positioning.get("nicknames", [])
            bios = positioning.get("bios", [])
            avatar_style = positioning.get("avatar_style", "")
            return {
                "nickname": {
                    "current": account.nickname,
                    "suggested": nicknames[0]["name"] if nicknames else account.nickname,
                    "alternatives": [n["name"] for n in nicknames[1:3]] if len(nicknames) > 1 else [],
                    "reason": nicknames[0].get("reason", "") if nicknames else "",
                },
                "bio": {
                    "current": account.bio,
                    "suggested": bios[0]["bio"] if bios else account.bio,
                    "alternatives": [b["bio"] for b in bios[1:2]] if len(bios) > 1 else [],
                    "style": bios[0].get("style", "") if bios else "",
                },
                "avatar": {
                    "current_url": account.avatar_url,
                    "suggested_style": avatar_style,
                    "prompt": f"生成一个{avatar_style}风格的头像" if avatar_style else "",
                },
            }

    async def preview(self, account_id: str) -> Optional[Dict[str, Any]]:
        """预览优化方案（不执行修改）"""
        return await self.generate_optimization(account_id)


profile_optimizer = ProfileOptimizer()
