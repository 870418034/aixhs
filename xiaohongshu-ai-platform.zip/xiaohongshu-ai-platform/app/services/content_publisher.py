"""浏览器自动发布"""

import uuid
from datetime import datetime
from typing import Optional, Dict, Any

from loguru import logger
from sqlalchemy import select

from app.database import async_session_maker
from app.models.content import Content, ContentStatus
from app.models.task import Task, TaskType, TaskStatus
from app.services.xiaohongshu_browser import XiaohongshuBrowser


class ContentPublisher:
    """内容发布"""

    def __init__(self):
        self.browser = XiaohongshuBrowser()

    async def publish(self, content_id: str) -> Dict[str, Any]:
        """发布内容

        流程: 获取浏览器Context→打开发布页→上传图片→填标题→填正文→加标签/话题→截图预览→点击发布→检测错误→获取URL/ID
        """
        async with async_session_maker() as session:
            content = await session.get(Content, content_id)
            if not content:
                raise ValueError(f"Content {content_id} not found")
            if content.status == ContentStatus.PUBLISHED:
                raise ValueError("Content already published")

            account_id = content.account_id
            title = content.title
            body = content.body
            tags = []
            if content.tags:
                import json
                tags = json.loads(content.tags)
            images = []
            if content.images:
                images = json.loads(content.images)

        logger.info(f"Publishing content {content_id} for account {account_id}")

        try:
            # 使用浏览器发布
            result = await self.browser.publish_note(
                account_id=account_id,
                title=title,
                body=body,
                images=images,
                tags=tags,
                topic=content.topic or "",
            )

            # 更新内容状态
            async with async_session_maker() as session:
                content = await session.get(Content, content_id)
                content.status = ContentStatus.PUBLISHED
                content.published_at = datetime.utcnow()
                content.note_id = result.get("note_id", "")
                content.note_url = result.get("url", "")
                content.updated_at = datetime.utcnow()
                await session.commit()

            logger.info(f"Content {content_id} published successfully: {result.get('url', '')}")
            return {
                "success": True,
                "content_id": content_id,
                "note_id": result.get("note_id"),
                "url": result.get("url"),
            }

        except Exception as e:
            logger.error(f"Failed to publish content {content_id}: {e}")
            async with async_session_maker() as session:
                content = await session.get(Content, content_id)
                content.status = ContentStatus.FAILED
                content.publish_error = str(e)
                content.updated_at = datetime.utcnow()
                await session.commit()
            raise

    async def schedule_publish(
        self, content_id: str, publish_time: datetime
    ) -> Task:
        """定时发布"""
        async with async_session_maker() as session:
            content = await session.get(Content, content_id)
            if not content:
                raise ValueError(f"Content {content_id} not found")

            task = Task(
                id=str(uuid.uuid4()),
                account_id=content.account_id,
                task_type=TaskType.PUBLISH,
                task_name=f"定时发布: {content.title}",
                content_id=content_id,
                status=TaskStatus.SCHEDULED,
                scheduled_at=publish_time,
                created_at=datetime.utcnow(),
                updated_at=datetime.utcnow(),
            )
            session.add(task)

            content.status = ContentStatus.SCHEDULED
            content.scheduled_at = publish_time
            content.updated_at = datetime.utcnow()

            await session.commit()
            await session.refresh(task)

            logger.info(f"Content {content_id} scheduled for {publish_time}")
            return task

    async def cancel_schedule(self, content_id: str) -> bool:
        """取消定时发布"""
        async with async_session_maker() as session:
            content = await session.get(Content, content_id)
            if not content:
                raise ValueError(f"Content {content_id} not found")

            content.status = ContentStatus.DRAFT
            content.scheduled_at = None
            content.updated_at = datetime.utcnow()

            # 取消相关任务
            result = await session.execute(
                select(Task).where(
                    Task.content_id == content_id,
                    Task.task_type == TaskType.PUBLISH,
                    Task.status == TaskStatus.SCHEDULED,
                )
            )
            tasks = result.scalars().all()
            for task in tasks:
                task.status = TaskStatus.CANCELLED
                task.updated_at = datetime.utcnow()

            await session.commit()
            logger.info(f"Schedule cancelled for content {content_id}")
            return True

    async def publish_scheduled(self):
        """检查并发布到期的定时内容"""
        now = datetime.utcnow()
        async with async_session_maker() as session:
            result = await session.execute(
                select(Content).where(
                    Content.status == ContentStatus.SCHEDULED,
                    Content.scheduled_at <= now,
                )
            )
            contents = result.scalars().all()

        for content in contents:
            try:
                await self.publish(str(content.id))
            except Exception as e:
                logger.error(f"Failed to publish scheduled content {content.id}: {e}")
