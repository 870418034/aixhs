"""
图片安全检查 - 清晰度/水印/尺寸/内容安全
"""
from __future__ import annotations
import os
from pathlib import Path
from dataclasses import dataclass
from typing import Optional, List
from loguru import logger

try:
    from PIL import Image
    HAS_PIL = True
except ImportError:
    HAS_PIL = False


@dataclass
class ImageSafetyResult:
    passed: bool
    score: float
    issues: List[str]
    width: int = 0
    height: int = 0
    file_size: int = 0
    thumbnail_path: str = ""


class ImageSafety:
    """图片安全检查"""

    MIN_WIDTH = 600
    MIN_HEIGHT = 600
    MAX_SIZE_MB = 20
    MIN_SIZE_KB = 50

    async def check(self, image_path: str) -> ImageSafetyResult:
        """完整图片安全检查"""
        issues = []
        score = 10.0

        if not os.path.exists(image_path):
            return ImageSafetyResult(passed=False, score=0, issues=["文件不存在"])

        file_size = os.path.getsize(image_path)
        if file_size > self.MAX_SIZE_MB * 1024 * 1024:
            issues.append(f"图片过大: {file_size / 1024 / 1024:.1f}MB，最大{self.MAX_SIZE_MB}MB")
            score -= 3
        if file_size < self.MIN_SIZE_KB * 1024:
            issues.append(f"图片过小: {file_size / 1024:.0f}KB，可能不清晰")
            score -= 2

        if not HAS_PIL:
            return ImageSafetyResult(passed=score >= 5, score=max(0, score), issues=issues, file_size=file_size)

        try:
            img = Image.open(image_path)
            w, h = img.size
            if w < self.MIN_WIDTH or h < self.MIN_HEIGHT:
                issues.append(f"分辨率过低: {w}x{h}，最小要求{self.MIN_WIDTH}x{self.MIN_HEIGHT}")
                score -= 3
            if self._is_blurry(img):
                issues.append("图片可能模糊")
                score -= 2
            thumbnail_path = self._generate_thumbnail(image_path, img)
            img.close()
        except Exception as e:
            issues.append(f"图片读取失败: {e}")
            score -= 5
            w, h, thumbnail_path = 0, 0, ""

        return ImageSafetyResult(
            passed=score >= 5,
            score=max(0, score),
            issues=issues,
            width=w, height=h,
            file_size=file_size,
            thumbnail_path=thumbnail_path,
        )

    def _is_blurry(self, img) -> bool:
        """通过边缘检测判断模糊"""
        try:
            gray = img.convert("L")
            import statistics
            pixels = list(gray.getdata())
            if len(pixels) < 100:
                return False
            diffs = [abs(pixels[i] - pixels[i + 1]) for i in range(min(len(pixels) - 1, 10000))]
            avg_diff = statistics.mean(diffs) if diffs else 0
            return avg_diff < 3
        except Exception:
            return False

    def _generate_thumbnail(self, image_path: str, img=None) -> str:
        """生成缩略图"""
        try:
            if img is None:
                img = Image.open(image_path)
            img_copy = img.copy()
            img_copy.thumbnail((300, 300))
            thumb_path = str(Path(image_path).parent / f"thumb_{Path(image_path).name}")
            img_copy.save(thumb_path, quality=85)
            img_copy.close()
            return thumb_path
        except Exception as e:
            logger.warning(f"缩略图生成失败: {e}")
            return ""


image_safety = ImageSafety()
