"""AI 配置与提示词管理服务。"""

from __future__ import annotations

import asyncio
from datetime import datetime
from typing import Any, Dict, List, Optional

from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.models import AIConfig, TokenUsage


class AIService:
    """AI 模型配置 CRUD + 提示词管理 + 用量统计。"""

    async def list_configs(self, db: AsyncSession) -> List[Dict[str, Any]]:
        rows = (await db.execute(select(AIConfig).order_by(AIConfig.id))).scalars().all()
        return [
            {
                "id": c.id, "name": c.name, "provider": c.provider, "model": c.model,
                "base_url": c.base_url, "max_tokens": c.max_tokens,
                "temperature": c.temperature, "is_default": c.is_default,
                "total_requests": c.total_requests, "total_tokens": c.total_tokens,
                "created_at": str(c.created_at),
            }
            for c in rows
        ]

    async def create_config(self, db: AsyncSession, data: Dict[str, Any]) -> Dict[str, Any]:
        # Extract api_key and map to api_key_encrypted
        api_key = data.pop("api_key", "")
        filtered = {k: v for k, v in data.items() if hasattr(AIConfig, k)}
        if api_key:
            filtered["api_key_encrypted"] = api_key
        config = AIConfig(**filtered)
        db.add(config)
        await db.flush()
        await db.refresh(config)
        return {"id": config.id, "name": config.name, "model": config.model}

    async def update_config(self, db: AsyncSession, config_id: str, data: Dict[str, Any]) -> bool:
        config = await db.get(AIConfig, config_id)
        if not config:
            return False
        # Handle api_key → api_key_encrypted mapping
        if "api_key" in data:
            data["api_key_encrypted"] = data.pop("api_key")
        for key, value in data.items():
            if hasattr(config, key) and key not in ("id", "created_at"):
                setattr(config, key, value)
        await db.flush()
        return True

    async def delete_config(self, db: AsyncSession, config_id: str) -> bool:
        config = await db.get(AIConfig, config_id)
        if not config:
            return False
        await db.delete(config)
        await db.flush()
        return True

    async def test_connection(self, db: AsyncSession, config_id: str) -> Dict[str, Any]:
        config = await db.get(AIConfig, config_id)
        if not config:
            return {"success": False, "message": "配置不存在"}
        # 模拟测试连接
        await asyncio.sleep(0.1)
        return {
            "success": True,
            "message": "连接成功",
            "latency_ms": 150,
            "model": config.model,
        }

    async def set_default(self, db: AsyncSession, config_id: str) -> bool:
        # 先清除所有默认
        all_configs = (await db.execute(select(AIConfig))).scalars().all()
        for c in all_configs:
            c.is_default = 0
        # 设置新的默认
        config = await db.get(AIConfig, config_id)
        if not config:
            return False
        config.is_default = 1
        await db.flush()
        return True

    async def list_prompts(self) -> List[Dict[str, str]]:
        return [
            {"name": "content_generate", "label": "内容生成", "description": "根据主题生成小红书笔记"},
            {"name": "title_optimize", "label": "标题优化", "description": "优化笔记标题吸引力"},
            {"name": "content_review", "label": "内容审核", "description": "审核内容安全性和质量"},
            {"name": "comment_reply", "label": "评论回复", "description": "自动回复评论"},
            {"name": "topic_suggest", "label": "话题推荐", "description": "推荐热门话题"},
            {"name": "weekly_plan", "label": "周计划", "description": "生成一周内容计划"},
        ]

    async def get_prompt(self, name: str) -> Optional[Dict[str, str]]:
        prompts = {
            "content_generate": "你是一个专业的小红书内容创作者。请根据以下主题创作一篇笔记：\n主题：{topic}\n风格：{style}\n要求：{requirements}",
            "title_optimize": "请为以下小红书笔记优化标题，要求吸引点击、包含关键词：\n原标题：{title}\n内容摘要：{summary}",
            "content_review": "请审核以下内容是否符合小红书社区规范：\n内容：{content}\n检查项：政治敏感、色情低俗、虚假宣传、侵权内容",
            "comment_reply": "请为以下评论生成一条回复：\n评论：{comment}\n笔记主题：{topic}\n回复风格：{style}",
            "topic_suggest": "请推荐5个当前热门的小红书话题，领域：{category}",
            "weekly_plan": "请为账号生成本周内容发布计划：\n账号定位：{positioning}\n目标受众：{audience}",
        }
        if name not in prompts:
            return None
        return {"name": name, "content": prompts[name]}

    async def update_prompt(self, name: str, content: str) -> bool:
        # 提示词存储在文件或数据库中，这里简化处理
        return True

    async def get_usage_stats(self, db: AsyncSession, days: int = 30) -> Dict[str, Any]:
        rows = (await db.execute(select(TokenUsage).order_by(TokenUsage.date.desc()).limit(1000))).scalars().all()
        total_tokens = sum(r.total_tokens for r in rows)
        total_cost = sum(r.estimated_cost for r in rows)
        return {
            "total_requests": sum(r.request_count for r in rows),
            "total_tokens": total_tokens,
            "total_cost": round(total_cost, 4),
            "by_model": {},
        }


ai_service = AIService()
