"""任务执行引擎"""

import asyncio
import uuid
from datetime import datetime, timedelta
from typing import Dict, Any, Optional, List

from loguru import logger
from sqlalchemy import select, func, update, and_

from app.database import async_session_maker
from app.models.task import Task, TaskType, TaskStatus


class TaskExecutor:
    """任务执行引擎"""

    _running_tasks: Dict[str, asyncio.Task] = {}
    _locks: Dict[str, asyncio.Lock] = {}

    async def dispatch_pending_tasks(self):
        """检查pending任务→按优先级排队→执行"""
        async with async_session_maker() as session:
            result = await session.execute(
                select(Task)
                .where(Task.status == TaskStatus.PENDING)
                .order_by(Task.priority.desc(), Task.created_at.asc())
                .limit(10)
            )
            tasks = result.scalars().all()

        for task in tasks:
            task_id = str(task.id)
            if task_id in self._running_tasks:
                continue

            # 检查依赖
            deps_ok = await self.check_dependencies(task_id)
            if not deps_ok:
                continue

            # 检查并发限制
            account_id = str(task.account_id)
            if account_id not in self._locks:
                self._locks[account_id] = asyncio.Lock()

            # 异步执行
            running_task = asyncio.create_task(self.execute_task(task_id))
            self._running_tasks[task_id] = running_task
            running_task.add_done_callback(lambda t, tid=task_id: self._running_tasks.pop(tid, None))

    async def execute_task(self, task_id: str) -> bool:
        """执行任务（依赖检查+并发锁+超时+重试）"""
        lock_key = None
        try:
            async with async_session_maker() as session:
                task = await session.get(Task, task_id)
                if not task:
                    return False
                lock_key = str(task.account_id)

            # 获取账号级锁
            if lock_key and lock_key in self._locks:
                lock = self._locks[lock_key]
            else:
                lock = asyncio.Lock()
                if lock_key:
                    self._locks[lock_key] = lock

            async with lock:
                async with async_session_maker() as session:
                    task = await session.get(Task, task_id)
                    if not task or task.status != TaskStatus.PENDING:
                        return False
                    task.status = TaskStatus.RUNNING
                    task.started_at = datetime.utcnow()
                    task.updated_at = datetime.utcnow()
                    await session.commit()

                # 执行具体任务（带超时300秒）
                try:
                    result = await asyncio.wait_for(
                        self._execute_by_type(task),
                        timeout=300,
                    )
                    async with async_session_maker() as session:
                        task = await session.get(Task, task_id)
                        task.status = TaskStatus.COMPLETED
                        task.completed_at = datetime.utcnow()
                        task.result = str(result) if result else ""
                        task.updated_at = datetime.utcnow()
                        await session.commit()
                    return True

                except asyncio.TimeoutError:
                    async with async_session_maker() as session:
                        task = await session.get(Task, task_id)
                        task.status = TaskStatus.FAILED
                        task.error = "Task timeout (300s)"
                        task.updated_at = datetime.utcnow()
                        await session.commit()
                    return False

        except Exception as e:
            logger.error(f"Task {task_id} execution failed: {e}")
            try:
                async with async_session_maker() as session:
                    task = await session.get(Task, task_id)
                    if task:
                        task.status = TaskStatus.FAILED
                        task.error = str(e)
                        task.retry_count = (task.retry_count or 0) + 1
                        task.updated_at = datetime.utcnow()
                        await session.commit()
            except Exception:
                pass
            return False

    async def _execute_by_type(self, task: Task) -> Any:
        """根据任务类型分发执行"""
        account_id = str(task.account_id)

        if task.task_type == TaskType.BROWSE:
            from app.services.account_nurturer import AccountNurturer
            nurturer = AccountNurturer()
            config = task.task_data or {}
            return await nurturer._browse_recommend(account_id, config)

        elif task.task_type == TaskType.LIKE:
            from app.services.account_nurturer import AccountNurturer
            nurturer = AccountNurturer()
            note = await nurturer._get_random_note(account_id)
            if note:
                return await nurturer._like_note(account_id, note)

        elif task.task_type == TaskType.COLLECT:
            from app.services.account_nurturer import AccountNurturer
            nurturer = AccountNurturer()
            note = await nurturer._get_random_note(account_id)
            if note:
                return await nurturer._collect_note(account_id, note)

        elif task.task_type == TaskType.COMMENT:
            from app.services.account_nurturer import AccountNurturer
            nurturer = AccountNurturer()
            note = await nurturer._get_random_note(account_id)
            if note:
                return await nurturer._comment_note(account_id, note)

        elif task.task_type == TaskType.FOLLOW:
            from app.services.account_nurturer import AccountNurturer
            nurturer = AccountNurturer()
            user = await nurturer._get_random_user(account_id)
            if user:
                return await nurturer._follow_user(account_id, user)

        elif task.task_type == TaskType.GENERATE:
            from app.services.content_generator import ContentGenerator
            generator = ContentGenerator()
            result = await generator.generate(account_id)
            return str(result.content.id)

        elif task.task_type == TaskType.PUBLISH:
            content_id = task.content_id
            if content_id:
                from app.services.content_publisher import ContentPublisher
                publisher = ContentPublisher()
                return await publisher.publish(content_id)

        elif task.task_type == TaskType.ANALYZE:
            from app.services.account_analyzer import AccountAnalyzer
            analyzer = AccountAnalyzer()
            return await analyzer.analyze(account_id)

        return None

    async def check_dependencies(self, task_id: str) -> bool:
        """检查前置任务是否完成"""
        async with async_session_maker() as session:
            task = await session.get(Task, task_id)
            if not task or not task.depends_on:
                return True

            dep_ids = task.depends_on if isinstance(task.depends_on, list) else []
            if not dep_ids:
                return True

            result = await session.execute(
                select(func.count(Task.id)).where(
                    Task.id.in_(dep_ids),
                    Task.status != TaskStatus.COMPLETED,
                )
            )
            incomplete = result.scalar()
            return incomplete == 0

    async def cancel_task(self, task_id: str) -> bool:
        """取消任务"""
        async with async_session_maker() as session:
            task = await session.get(Task, task_id)
            if not task:
                return False
            task.status = TaskStatus.CANCELLED
            task.updated_at = datetime.utcnow()
            await session.commit()

        # 取消正在运行的
        if task_id in self._running_tasks:
            self._running_tasks[task_id].cancel()
            del self._running_tasks[task_id]

        return True

    async def retry_task(self, task_id: str) -> bool:
        """重试失败任务"""
        async with async_session_maker() as session:
            task = await session.get(Task, task_id)
            if not task:
                return False
            if task.status not in (TaskStatus.FAILED, TaskStatus.CANCELLED):
                return False

            task.status = TaskStatus.PENDING
            task.error = None
            task.started_at = None
            task.completed_at = None
            task.updated_at = datetime.utcnow()
            await session.commit()
        return True

    async def pause_task(self, task_id: str) -> bool:
        """暂停任务"""
        async with async_session_maker() as session:
            task = await session.get(Task, task_id)
            if not task:
                return False
            task.status = TaskStatus.PAUSED
            task.updated_at = datetime.utcnow()
            await session.commit()
        return True

    async def resume_task(self, task_id: str) -> bool:
        """恢复任务"""
        async with async_session_maker() as session:
            task = await session.get(Task, task_id)
            if not task:
                return False
            task.status = TaskStatus.PENDING
            task.updated_at = datetime.utcnow()
            await session.commit()
        return True

    async def get_task_stats(self) -> Dict[str, Any]:
        """任务统计"""
        async with async_session_maker() as session:
            total = await session.execute(select(func.count(Task.id)))
            pending = await session.execute(
                select(func.count(Task.id)).where(Task.status == TaskStatus.PENDING)
            )
            running = await session.execute(
                select(func.count(Task.id)).where(Task.status == TaskStatus.RUNNING)
            )
            completed = await session.execute(
                select(func.count(Task.id)).where(Task.status == TaskStatus.COMPLETED)
            )
            failed = await session.execute(
                select(func.count(Task.id)).where(Task.status == TaskStatus.FAILED)
            )

            return {
                "total": total.scalar(),
                "pending": pending.scalar(),
                "running": running.scalar(),
                "completed": completed.scalar(),
                "failed": failed.scalar(),
                "active_executions": len(self._running_tasks),
            }
