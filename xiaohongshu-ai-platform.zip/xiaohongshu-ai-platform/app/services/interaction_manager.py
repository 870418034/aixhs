"""自动回复评论"""

import re
from datetime import datetime, timedelta
from typing import Dict, Any, Optional, List

from loguru import logger
from sqlalchemy import select, and_

from app.database import async_session_maker
from app.models.account import Account, AccountStatus
from app.models.content import Content, ContentStatus
from app.models.comment import Comment
from app.services.ai_service import AIService
from app.services.xiaohongshu_browser import XiaohongshuBrowser


class InteractionManager:
    """自动回复评论"""

    def __init__(self):
        self.ai_service = AIService()
        self.browser = XiaohongshuBrowser()

    async def check_all_comments(self):
        """检查所有活跃账号最近7天笔记的新评论"""
        async with async_session_maker() as session:
            result = await session.execute(
                select(Account).where(
                    Account.status.in_([
                        AccountStatus.running,
                        AccountStatus.online,
                    ])
                )
            )
            accounts = result.scalars().all()

        for account in accounts:
            try:
                await self._check_account_comments(str(account.id))
            except Exception as e:
                logger.error(f"Failed to check comments for account {account.id}: {e}")

    async def _check_account_comments(self, account_id: str):
        """检查单个账号的评论"""
        seven_days_ago = datetime.utcnow() - timedelta(days=7)

        async with async_session_maker() as session:
            result = await session.execute(
                select(Content).where(
                    Content.account_id == account_id,
                    Content.status == ContentStatus.PUBLISHED,
                    Content.published_at >= seven_days_ago,
                    Content.note_id.isnot(None),
                )
            )
            contents = result.scalars().all()

        for content in contents:
            try:
                await self._check_note_comments(account_id, content)
            except Exception as e:
                logger.error(f"Failed to check comments for note {content.id}: {e}")

    async def _check_note_comments(self, account_id: str, content: Content):
        """检查单篇笔记的评论"""
        # 从浏览器获取最新评论
        note_data = await self.browser.open_note(content.note_id)
        comments = note_data.get("comments", [])

        async with async_session_maker() as session:
            account = await session.get(Account, account_id)

            for comment_data in comments if isinstance(comments, list) else []:
                comment_text = comment_data.get("text", "")
                comment_id = comment_data.get("id", "")

                if self._should_skip(comment_data):
                    continue

                # 检查是否已回复
                result = await session.execute(
                    select(Comment).where(
                        Comment.comment_id == comment_id,
                    )
                )
                existing = result.scalar_one_or_none()
                if existing and existing.replied:
                    continue

                # 生成回复
                context = {
                    "note_title": content.title,
                    "note_body": content.body[:500],
                    "comment": comment_text,
                    "account_name": account.name,
                    "niche": account.niche or "",
                }
                reply_text = await self.generate_reply(comment_text, context)

                # 回复
                success = await self.reply_comment(
                    account_id, str(content.id), comment_id, reply_text
                )

                # 记录
                if not existing:
                    comment = Comment(
                        comment_id=comment_id,
                        account_id=account_id,
                        content_id=str(content.id),
                        note_id=content.note_id,
                        text=comment_text,
                        author=comment_data.get("author", ""),
                        replied=success,
                        reply_text=reply_text if success else None,
                        replied_at=datetime.utcnow() if success else None,
                        created_at=datetime.utcnow(),
                    )
                    session.add(comment)
                else:
                    existing.replied = success
                    existing.reply_text = reply_text
                    existing.replied_at = datetime.utcnow() if success else None

            await session.commit()

    async def generate_reply(self, comment: str, note_context: Dict[str, Any]) -> str:
        """AI生成回复"""
        prompt = f"""请为以下小红书评论生成一条自然的回复：

笔记标题：{note_context.get('note_title', '')}
笔记领域：{note_context.get('niche', '')}
用户评论：{comment}

要求：
- 10-50字
- 自然亲切
- 可含1-2个emoji
- 不要太正式

直接返回回复文字。"""

        try:
            reply = await self.ai_service.call(prompt=prompt, temperature=0.8, max_tokens=200)
            return reply.strip().strip('"').strip("'")
        except Exception as e:
            logger.error(f"Failed to generate reply: {e}")
            return "谢谢支持～❤️"

    async def reply_comment(
        self, account_id: str, note_id: str, comment_id: str, reply_text: str
    ) -> bool:
        """浏览器回复评论"""
        try:
            # 需要在笔记详情页操作
            context = await self.browser._get_context(account_id)
            page = await context.new_page()
            try:
                # 找到评论并回复
                comment_el = page.locator(f'[data-comment-id="{comment_id}"]')
                if await comment_el.count() > 0:
                    reply_btn = comment_el.locator('[class*="reply"]').first
                    await reply_btn.click()
                    await page.wait_for_timeout(500)

                    input_el = page.locator('[class*="reply-input"] input, [class*="reply-input"] textarea').first
                    await input_el.fill(reply_text)
                    await page.wait_for_timeout(300)

                    submit = page.locator('button:has-text("回复"), button:has-text("发送")').first
                    await submit.click()
                    await page.wait_for_timeout(2000)
                    return True
            finally:
                await page.close()
            return False
        except Exception as e:
            logger.error(f"Failed to reply comment: {e}")
            return False

    def _should_skip(self, comment: Dict[str, Any]) -> bool:
        """跳过自己的+广告+恶意评论"""
        text = comment.get("text", "")

        # 跳过自己的评论
        if comment.get("is_self", False):
            return True

        # 跳过广告评论
        ad_patterns = [
            r'(?:加|➕)\s*(?:微信|vx|V)',
            r'私聊',
            r'代购',
            r'(?:免费|免费领)',
            r'(?:扫码|扫[一这]扫)',
            r'(?:代理|加盟)',
        ]
        for pattern in ad_patterns:
            if re.search(pattern, text, re.IGNORECASE):
                return True

        # 跳过恶意评论
        malicious_patterns = [
            r'(?:垃圾|废物|骗子|假的|假货)',
            r'(?:抄袭|盗[图文视频])',
        ]
        for pattern in malicious_patterns:
            if re.search(pattern, text):
                return True

        return False
