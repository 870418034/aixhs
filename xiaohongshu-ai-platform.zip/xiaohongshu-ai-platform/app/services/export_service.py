"""数据导出服务。"""

from __future__ import annotations

import csv
import io
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional

from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.models import Account, ActivityLog, Content


class ExportService:
    """数据导出：账号统计、内容统计、操作日志。"""

    EXPORT_DIR = "data/exports"

    async def export_accounts_stats(self, db: AsyncSession, fmt: str = "xlsx") -> Dict[str, Any]:
        rows = (await db.execute(select(Account))).scalars().all()
        data = [
            {
                "ID": a.id, "昵称": a.nickname, "小红书ID": a.xhs_id,
                "状态": a.status.value, "粉丝数": a.followers,
                "获赞数": a.likes, "笔记数": a.notes_count,
            }
            for a in rows
        ]
        Path(self.EXPORT_DIR).mkdir(parents=True, exist_ok=True)
        filename = f"accounts_stats_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv"
        filepath = Path(self.EXPORT_DIR) / filename
        if data:
            with open(filepath, "w", newline="", encoding="utf-8-sig") as f:
                writer = csv.DictWriter(f, fieldnames=data[0].keys())
                writer.writeheader()
                writer.writerows(data)
        return {"filepath": str(filepath), "filename": filename, "records": len(data)}

    async def export_content_stats(self, db: AsyncSession, fmt: str = "xlsx") -> Dict[str, Any]:
        rows = (await db.execute(select(Content))).scalars().all()
        data = [
            {
                "ID": c.id, "标题": c.title, "类型": c.content_type.value,
                "状态": c.status.value, "浏览": c.views, "点赞": c.likes,
                "评论": c.comments, "收藏": c.collects,
            }
            for c in rows
        ]
        Path(self.EXPORT_DIR).mkdir(parents=True, exist_ok=True)
        filename = f"content_stats_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv"
        filepath = Path(self.EXPORT_DIR) / filename
        if data:
            with open(filepath, "w", newline="", encoding="utf-8-sig") as f:
                writer = csv.DictWriter(f, fieldnames=data[0].keys())
                writer.writeheader()
                writer.writerows(data)
        return {"filepath": str(filepath), "filename": filename, "records": len(data)}

    async def export_operation_logs(self, db: AsyncSession, days: int = 30) -> Dict[str, Any]:
        from datetime import timedelta
        since = datetime.now() - timedelta(days=days)
        query = select(ActivityLog).where(ActivityLog.created_at >= since).order_by(ActivityLog.created_at.desc())
        rows = (await db.execute(query)).scalars().all()
        data = [
            {"时间": str(r.created_at), "级别": r.level, "模块": r.module, "消息": r.message}
            for r in rows
        ]
        Path(self.EXPORT_DIR).mkdir(parents=True, exist_ok=True)
        filename = f"operation_logs_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv"
        filepath = Path(self.EXPORT_DIR) / filename
        if data:
            with open(filepath, "w", newline="", encoding="utf-8-sig") as f:
                writer = csv.DictWriter(f, fieldnames=data[0].keys())
                writer.writeheader()
                writer.writerows(data)
        return {"filepath": str(filepath), "filename": filename, "records": len(data)}


export_service = ExportService()
