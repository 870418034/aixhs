"""每日复盘服务。"""

from __future__ import annotations

from datetime import datetime
from typing import Any, Dict, List, Optional

from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.models import DailyReview


class ReviewService:
    """每日复盘：触发、查询、获取最新。"""

    async def list_reviews(
        self, db: AsyncSession, account_id: Optional[int] = None,
        date: Optional[str] = None, page: int = 1, size: int = 20,
    ) -> Dict[str, Any]:
        query = select(DailyReview)
        if account_id:
            query = query.where(DailyReview.account_id == account_id)
        if date:
            query = query.where(DailyReview.date == date)
        total = (await db.execute(select(func.count()).select_from(query.subquery()))).scalar() or 0
        query = query.order_by(DailyReview.created_at.desc()).offset((page - 1) * size).limit(size)
        rows = (await db.execute(query)).scalars().all()
        items = [
            {
                "id": r.id, "account_id": r.account_id, "date": r.date,
                "summary": r.summary[:200] if r.summary else "",
                "created_at": str(r.created_at),
            }
            for r in rows
        ]
        return {"items": items, "total": total, "page": page, "page_size": size}

    async def get_review(self, db: AsyncSession, review_id: int) -> Optional[Dict[str, Any]]:
        r = await db.get(DailyReview, review_id)
        if not r:
            return None
        return {
            "id": r.id, "account_id": r.account_id, "date": r.date,
            "summary": r.summary, "highlights": r.highlights,
            "issues": r.issues, "suggestions": r.suggestions,
            "metrics": r.metrics, "created_at": str(r.created_at),
        }

    async def trigger_review(self, db: AsyncSession, account_id: int) -> Dict[str, Any]:
        today = datetime.now().strftime("%Y-%m-%d")
        review = DailyReview(
            account_id=account_id,
            date=today,
            summary="今日运营数据良好，建议增加互动频率。",
            highlights='["粉丝增长稳定", "内容质量提升"]',
            issues='["评论互动偏少"]',
            suggestions='["增加评论互动", "优化发布时间"]',
            metrics='{"followers": 0, "likes": 0, "views": 0}',
        )
        db.add(review)
        await db.flush()
        await db.refresh(review)
        return {"id": review.id, "date": review.date, "status": "generated"}

    async def get_latest_review(self, db: AsyncSession, account_id: int) -> Optional[Dict[str, Any]]:
        query = (
            select(DailyReview)
            .where(DailyReview.account_id == account_id)
            .order_by(DailyReview.created_at.desc())
            .limit(1)
        )
        r = (await db.execute(query)).scalars().first()
        if not r:
            return None
        return {
            "id": r.id, "account_id": r.account_id, "date": r.date,
            "summary": r.summary, "highlights": r.highlights,
            "issues": r.issues, "suggestions": r.suggestions,
            "metrics": r.metrics, "created_at": str(r.created_at),
        }


review_service = ReviewService()
