"""
竞品账号监控 - 自动发现/数据采集/对比分析
"""
from __future__ import annotations
import json
from datetime import datetime, timedelta
from typing import Optional, List
from sqlalchemy import select, and_
from sqlalchemy.ext.asyncio import AsyncSession
from loguru import logger

from app.models import CompetitorAccount, Account
from app.database import get_db_session


class CompetitorMonitor:
    """竞品监控"""

    async def add_competitor(self, db: AsyncSession, account_id: str, xhs_id: str) -> CompetitorAccount:
        """添加竞品"""
        competitor = CompetitorAccount(
            account_id=account_id,
            competitor_xhs_id=xhs_id,
            competitor_nickname="",
            latest_notes="[]",
            insight="{}",
        )
        db.add(competitor)
        await db.flush()
        logger.info(f"竞品已添加: {xhs_id}")
        return competitor

    async def check_all(self):
        """检查所有竞品数据（定时任务23:00调用）"""
        async for db in get_db_session():
            try:
                stmt = select(CompetitorAccount).where(
                    or_(
                        CompetitorAccount.last_check.is_(None),
                        CompetitorAccount.last_check < datetime.now() - timedelta(hours=24)
                    )
                )
                result = await db.execute(stmt)
                competitors = result.scalars().all()
                for comp in competitors:
                    await self._check_competitor(db, comp)
                await db.commit()
            except Exception as e:
                logger.error(f"竞品检查失败: {e}")
                await db.rollback()

    async def _check_competitor(self, db: AsyncSession, competitor: CompetitorAccount):
        """检查单个竞品"""
        competitor.last_check = datetime.now()
        insight = {
            "last_checked": datetime.now().isoformat(),
            "status": "monitored",
            "note": "数据需通过浏览器采集",
        }
        competitor.insight = json.dumps(insight, ensure_ascii=False)
        await db.flush()

    async def auto_discover(self, db: AsyncSession, account_id: str) -> List[CompetitorAccount]:
        """自动发现同领域竞品"""
        account = await db.get(Account, account_id)
        if not account:
            return []
        positioning = json.loads(account.positioning or "{}")
        category = positioning.get("category", "")
        if not category:
            return []
        logger.info(f"为账号 {account.nickname} 发现竞品，领域: {category}")
        return []

    async def list_competitors(self, db: AsyncSession, account_id: str) -> List[CompetitorAccount]:
        """获取竞品列表"""
        stmt = select(CompetitorAccount).where(
            CompetitorAccount.account_id == account_id
        ).order_by(CompetitorAccount.created_at.desc())
        result = await db.execute(stmt)
        return list(result.scalars().all())

    async def delete(self, db: AsyncSession, competitor_id: str) -> bool:
        """删除竞品"""
        comp = await db.get(CompetitorAccount, competitor_id)
        if comp:
            await db.delete(comp)
            await db.commit()
            return True
        return False


# Fix: need to import or_ for check_all
from sqlalchemy import or_

competitor_monitor = CompetitorMonitor()
