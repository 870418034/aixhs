"""任务调度服务。"""

from __future__ import annotations

from datetime import datetime
from typing import Any, Dict, List, Optional

from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.models import Task


class TaskService:
    """任务管理：查询、取消、重试、暂停、恢复。"""

    async def list_tasks(
        self, db: AsyncSession, page: int = 1, size: int = 20,
        account_id: Optional[str] = None, task_type: Optional[str] = None,
        status: Optional[str] = None,
    ) -> Dict[str, Any]:
        query = select(Task)
        if account_id:
            query = query.where(Task.account_id == account_id)
        if task_type:
            query = query.where(Task.task_type == task_type)
        if status:
            query = query.where(Task.status == status)
        total = (await db.execute(select(func.count()).select_from(query.subquery()))).scalar() or 0
        query = query.order_by(Task.created_at.desc()).offset((page - 1) * size).limit(size)
        rows = (await db.execute(query)).scalars().all()
        items = [
            {
                "id": t.id, "account_id": t.account_id,
                "task_type": t.task_type, "status": t.status,
                "params": t.params, "error_msg": t.error_msg,
                "started_at": str(t.started_at) if t.started_at else None,
                "completed_at": str(t.completed_at) if t.completed_at else None,
                "created_at": str(t.created_at),
            }
            for t in rows
        ]
        return {"items": items, "total": total, "page": page, "page_size": size}

    async def get_task_detail(self, db: AsyncSession, task_id: str) -> Optional[Dict[str, Any]]:
        t = await db.get(Task, task_id)
        if not t:
            return None
        return {
            "id": t.id, "account_id": t.account_id,
            "task_type": t.task_type, "status": t.status,
            "params": t.params, "result": t.result, "error_msg": t.error_msg,
            "retry_count": t.retry_count,
            "started_at": str(t.started_at) if t.started_at else None,
            "completed_at": str(t.completed_at) if t.completed_at else None,
            "created_at": str(t.created_at),
        }

    async def set_status(self, db: AsyncSession, task_id: str, status: str) -> bool:
        t = await db.get(Task, task_id)
        if not t:
            return False
        t.status = status
        if status == "running":
            t.started_at = datetime.utcnow()
        elif status in ("completed", "failed", "cancelled"):
            t.completed_at = datetime.utcnow()
        await db.flush()
        return True

    async def batch_action(self, db: AsyncSession, task_ids: List[str], action: str) -> int:
        action_map = {
            "cancel": "cancelled",
            "pause": "paused",
            "resume": "pending",
            "retry": "pending",
        }
        target_status = action_map.get(action)
        if not target_status:
            return 0
        count = 0
        for tid in task_ids:
            if await self.set_status(db, tid, target_status):
                count += 1
        return count

    async def get_stats(self, db: AsyncSession) -> Dict[str, Any]:
        total = (await db.execute(select(func.count()).select_from(Task))).scalar() or 0
        pending = (await db.execute(select(func.count()).where(Task.status == "pending"))).scalar() or 0
        running = (await db.execute(select(func.count()).where(Task.status == "running"))).scalar() or 0
        completed = (await db.execute(select(func.count()).where(Task.status == "completed"))).scalar() or 0
        failed = (await db.execute(select(func.count()).where(Task.status == "failed"))).scalar() or 0
        return {
            "total": total, "pending": pending, "running": running,
            "completed": completed, "failed": failed,
        }

    async def get_today_timeline(self, db: AsyncSession) -> List[Dict[str, Any]]:
        today = datetime.utcnow().strftime("%Y-%m-%d")
        query = (
            select(Task)
            .where(Task.created_at >= today)
            .order_by(Task.created_at.asc())
        )
        rows = (await db.execute(query)).scalars().all()
        return [
            {
                "id": t.id, "task_type": t.task_type, "status": t.status,
                "account_id": t.account_id, "time": str(t.created_at),
            }
            for t in rows
        ]


task_service = TaskService()
