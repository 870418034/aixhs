"""
素材库管理 - 上传/分类/AI标签/匹配推荐
"""
from __future__ import annotations
import json
import os
import uuid
import aiofiles
from pathlib import Path
from typing import Optional, List, Tuple
from sqlalchemy import select, func, and_
from sqlalchemy.ext.asyncio import AsyncSession
from loguru import logger

from app.models import Material, Content
from app.database import get_db_session
from app.services.image_safety import image_safety

MATERIAL_DIR = Path("data/materials/images")
MATERIAL_DIR.mkdir(parents=True, exist_ok=True)


class MaterialManager:
    """素材库管理器"""

    async def upload(self, file_content: bytes, filename: str, category: str = "未分类") -> Material:
        """上传素材"""
        file_id = str(uuid.uuid4())[:8]
        ext = Path(filename).suffix or ".jpg"
        save_name = f"{file_id}{ext}"
        save_path = MATERIAL_DIR / save_name
        async with aiofiles.open(save_path, "wb") as f:
            await f.write(file_content)

        safety = await image_safety.check(str(save_path))
        material = Material(
            file_path=str(save_path),
            file_type="image",
            thumbnail_path=safety.thumbnail_path,
            category=category,
            tags="[]",
            ai_description="",
            usage_count=0,
            width=safety.width,
            height=safety.height,
            file_size=len(file_content),
        )
        async for db in get_db_session():
            db.add(material)
            await db.commit()
            await db.refresh(material)
            logger.info(f"素材已上传: {filename} -> {save_path}")
            return material

    async def list_materials(
        self, db: AsyncSession, page: int = 1, size: int = 20, category: str = ""
    ) -> Tuple[List[Material], int]:
        """获取素材列表"""
        stmt = select(Material)
        if category:
            stmt = stmt.where(Material.category == category)
        stmt = stmt.order_by(Material.created_at.desc())
        count_stmt = select(func.count()).select_from(Material)
        if category:
            count_stmt = count_stmt.where(Material.category == category)
        total = (await db.execute(count_stmt)).scalar()
        result = await db.execute(stmt.offset((page - 1) * size).limit(size))
        return list(result.scalars().all()), total

    async def delete(self, db: AsyncSession, material_id: str) -> bool:
        """删除素材"""
        material = await db.get(Material, material_id)
        if not material:
            return False
        for path in [material.file_path, material.thumbnail_path]:
            if path and os.path.exists(path):
                try:
                    os.remove(path)
                except OSError:
                    pass
        await db.delete(material)
        await db.commit()
        return True

    async def auto_tag(self, db: AsyncSession, material_id: str) -> List[str]:
        """AI自动打标签"""
        material = await db.get(Material, material_id)
        if not material:
            return []
        tags = self._generate_default_tags(material)
        material.tags = json.dumps(tags, ensure_ascii=False)
        await db.commit()
        return tags

    async def suggest_materials(self, db: AsyncSession, content_id: str) -> List[Material]:
        """AI推荐匹配素材"""
        content = await db.get(Content, content_id)
        if not content:
            return []
        stmt = select(Material).order_by(Material.usage_count.asc(), Material.created_at.desc()).limit(10)
        result = await db.execute(stmt)
        return list(result.scalars().all())

    def _generate_default_tags(self, material: Material) -> List[str]:
        """生成默认标签"""
        tags = []
        if material.width > 1080:
            tags.append("高清")
        if material.width == material.height:
            tags.append("方形图")
        if material.category:
            tags.append(material.category)
        return tags


material_manager = MaterialManager()
