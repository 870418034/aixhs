"""内容生成与管理服务。"""

from __future__ import annotations

from datetime import datetime
from typing import Any, Dict, List, Optional

from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.models import Content, ContentVersion


class ContentService:
    """内容生成、编辑、发布、版本管理。"""

    async def generate(
        self, db: AsyncSession, account_id: str, topic: str,
        content_type: str = "note", params: Optional[Dict] = None,
    ) -> Dict[str, Any]:
        content = Content(
            account_id=account_id,
            title=f"AI生成: {topic}",
            body=f"这是关于「{topic}」的AI生成内容。详细内容由AI根据关键词自动撰写。",
            topic=topic,
            content_type=content_type,
            status="draft",
            tags='["AI生成","自动运营"]',
        )
        db.add(content)
        await db.flush()
        await db.refresh(content)
        # 创建版本
        version = ContentVersion(
            content_id=content.id, version=1,
            title=content.title, body=content.body, tags=content.tags,
        )
        db.add(version)
        await db.flush()
        return {"id": content.id, "title": content.title, "status": content.status}

    async def list_contents(
        self, db: AsyncSession, page: int = 1, size: int = 20,
        account_id: Optional[str] = None, status: Optional[str] = None,
    ) -> Dict[str, Any]:
        query = select(Content)
        if account_id:
            query = query.where(Content.account_id == account_id)
        if status:
            query = query.where(Content.status == status)
        total = (await db.execute(select(func.count()).select_from(query.subquery()))).scalar() or 0
        query = query.order_by(Content.created_at.desc()).offset((page - 1) * size).limit(size)
        rows = (await db.execute(query)).scalars().all()
        items = [
            {
                "id": c.id, "title": c.title, "content_type": c.content_type,
                "status": c.status, "topic": c.topic, "views": c.views,
                "likes": c.likes, "comments": c.comments_count, "collects": c.collects,
                "account_id": c.account_id, "created_at": str(c.created_at),
            }
            for c in rows
        ]
        return {"items": items, "total": total, "page": page, "page_size": size}

    async def get_content(self, db: AsyncSession, content_id: str) -> Optional[Dict[str, Any]]:
        c = await db.get(Content, content_id)
        if not c:
            return None
        return {
            "id": c.id, "account_id": c.account_id, "title": c.title,
            "body": c.body, "content_type": c.content_type,
            "status": c.status, "topic": c.topic, "tags": c.tags,
            "images": c.images, "cover_image": "",
            "views": c.views, "likes": c.likes, "comments": c.comments_count,
            "collects": c.collects, "shares": c.shares,
            "ai_score": c.safety_score, "safety_passed": c.safety_result,
            "scheduled_at": str(c.publish_time) if c.is_scheduled and c.publish_time else None,
            "published_at": str(c.publish_time) if c.status == "published" and c.publish_time else None,
            "created_at": str(c.created_at), "updated_at": str(c.updated_at),
        }

    async def update_content(self, db: AsyncSession, content_id: str, data: Dict[str, Any]) -> bool:
        c = await db.get(Content, content_id)
        if not c:
            return False
        for key, value in data.items():
            if hasattr(c, key) and key not in ("id", "created_at"):
                setattr(c, key, value)
        c.status = "reviewing"
        c.updated_at = datetime.utcnow()
        await db.flush()
        return True

    async def delete_content(self, db: AsyncSession, content_id: str) -> bool:
        c = await db.get(Content, content_id)
        if not c:
            return False
        await db.delete(c)
        await db.flush()
        return True

    async def publish(self, db: AsyncSession, content_id: str) -> bool:
        c = await db.get(Content, content_id)
        if not c:
            return False
        c.status = "published"
        c.publish_time = datetime.utcnow()
        c.updated_at = datetime.utcnow()
        await db.flush()
        return True

    async def schedule(self, db: AsyncSession, content_id: str, publish_time: str) -> bool:
        c = await db.get(Content, content_id)
        if not c:
            return False
        c.status = "scheduled"
        c.is_scheduled = 1
        c.publish_time = datetime.fromisoformat(publish_time)
        c.updated_at = datetime.utcnow()
        await db.flush()
        return True

    async def cancel_schedule(self, db: AsyncSession, content_id: str) -> bool:
        c = await db.get(Content, content_id)
        if not c or not c.is_scheduled:
            return False
        c.status = "approved"
        c.is_scheduled = 0
        c.publish_time = None
        c.updated_at = datetime.utcnow()
        await db.flush()
        return True

    async def regenerate(self, db: AsyncSession, content_id: str) -> Optional[Dict[str, Any]]:
        c = await db.get(Content, content_id)
        if not c:
            return None
        c.body = f"[重新生成] {c.body}"
        c.status = "reviewing"
        c.updated_at = datetime.utcnow()
        await db.flush()
        return {"id": c.id, "title": c.title, "status": c.status}

    async def get_stats(self, db: AsyncSession, content_id: str) -> Dict[str, Any]:
        c = await db.get(Content, content_id)
        if not c:
            return {}
        return {
            "id": c.id, "views": c.views, "likes": c.likes,
            "comments": c.comments_count, "collects": c.collects, "shares": c.shares,
            "engagement_rate": round((c.likes + c.comments_count + c.collects) / max(c.views, 1) * 100, 2),
        }

    async def get_versions(self, db: AsyncSession, content_id: str) -> List[Dict[str, Any]]:
        query = select(ContentVersion).where(ContentVersion.content_id == content_id).order_by(ContentVersion.version.desc())
        rows = (await db.execute(query)).scalars().all()
        return [
            {"id": v.id, "version": v.version, "title": v.title, "created_at": str(v.created_at)}
            for v in rows
        ]

    async def restore_version(self, db: AsyncSession, content_id: str, version_id: str) -> bool:
        version = await db.get(ContentVersion, version_id)
        if not version or version.content_id != content_id:
            return False
        c = await db.get(Content, content_id)
        c.title = version.title
        c.body = version.body
        c.tags = version.tags
        c.images = version.images
        c.updated_at = datetime.utcnow()
        await db.flush()
        return True

    async def batch_generate(self, db: AsyncSession, account_id: str, topics: List[str]) -> List[Dict[str, Any]]:
        results = []
        for topic in topics:
            r = await self.generate(db, account_id, topic)
            results.append(r)
        return results

    async def batch_schedule(self, db: AsyncSession, content_ids: List[str], publish_time: str) -> int:
        count = 0
        for cid in content_ids:
            if await self.schedule(db, cid, publish_time):
                count += 1
        return count

    async def generate_weekly_plan(self, db: AsyncSession, account_id: str) -> Dict[str, Any]:
        return {
            "account_id": account_id,
            "week": datetime.now().strftime("%Y-W%W"),
            "plan": [
                {"day": "周一", "topic": "行业热点分析", "type": "note"},
                {"day": "周三", "topic": "产品使用教程", "type": "video"},
                {"day": "周五", "topic": "用户故事分享", "type": "note"},
                {"day": "周日", "topic": "本周总结回顾", "type": "note"},
            ],
        }


content_service = ContentService()
