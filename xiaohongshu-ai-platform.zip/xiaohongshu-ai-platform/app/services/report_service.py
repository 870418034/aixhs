"""运营报告生成服务。"""

from __future__ import annotations

from datetime import datetime
from typing import Any, Dict, List, Optional

from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.models import Report, ReportType


class ReportService:
    """报告生成、查询、下载。"""

    async def list_reports(
        self, db: AsyncSession, page: int = 1, size: int = 20,
    ) -> Dict[str, Any]:
        query = select(Report)
        total = (await db.execute(select(func.count()).select_from(query.subquery()))).scalar() or 0
        query = query.order_by(Report.created_at.desc()).offset((page - 1) * size).limit(size)
        rows = (await db.execute(query)).scalars().all()
        items = [
            {
                "id": r.id, "title": r.title, "report_type": r.report_type.value,
                "period_start": r.period_start, "period_end": r.period_end,
                "created_at": str(r.created_at),
            }
            for r in rows
        ]
        return {"items": items, "total": total, "page": page, "page_size": size}

    async def get_report(self, db: AsyncSession, report_id: int) -> Optional[Dict[str, Any]]:
        r = await db.get(Report, report_id)
        if not r:
            return None
        return {
            "id": r.id, "title": r.title, "content": r.content,
            "report_type": r.report_type.value,
            "period_start": r.period_start, "period_end": r.period_end,
            "file_path": r.file_path, "created_at": str(r.created_at),
        }

    async def generate_report(
        self, db: AsyncSession, report_type: str = "daily",
        account_id: Optional[int] = None,
    ) -> Dict[str, Any]:
        today = datetime.now()
        report = Report(
            report_type=ReportType(report_type),
            title=f"{today.strftime('%Y-%m-%d')} {report_type}运营报告",
            content="报告内容由系统自动生成。",
            period_start=today.strftime("%Y-%m-%d"),
            period_end=today.strftime("%Y-%m-%d"),
            account_id=account_id,
        )
        db.add(report)
        await db.flush()
        await db.refresh(report)
        return {"id": report.id, "title": report.title, "status": "generated"}

    async def download_report(self, db: AsyncSession, report_id: int) -> Optional[str]:
        r = await db.get(Report, report_id)
        if not r or not r.file_path:
            return None
        return r.file_path


report_service = ReportService()
