"""账号定位"""

import os
import json
import uuid
from datetime import datetime
from typing import Dict, Any, Optional, List

from loguru import logger
from sqlalchemy import select

from app.core.config import settings
from app.database import async_session_maker
from app.models.account import Account
from app.models.positioning import PositioningResult
from app.services.ai_service import AIService


HOT_NICHES = [
    "穿搭", "美妆", "护肤", "美食", "旅行", "健身",
    "家居", "母婴", "数码", "学习", "职场", "情感",
    "摄影", "手账", "宠物", "读书", "电影", "音乐",
]


class AccountPositioner:
    """账号定位"""

    def __init__(self):
        self.ai_service = AIService()

    async def position(self, account_id: str) -> PositioningResult:
        """生成账号定位方案

        流程: 获取账号信息+热门赛道→AI生成定位方案→保存到Account.positioning+positioning.json→生成养号计划
        """
        # Step1: 获取账号信息
        async with async_session_maker() as session:
            account = await session.get(Account, account_id)
            if not account:
                raise ValueError(f"Account {account_id} not found")

        # Step2: 构建定位提示词
        prompt = self._build_positioning_prompt(account)
        system_prompt = self._load_prompt("account_positioning.txt")

        # Step3: AI生成定位方案
        try:
            ai_response = await self.ai_service.call(
                prompt=prompt,
                system_prompt=system_prompt,
                temperature=0.7,
                max_tokens=3072,
            )
            positioning_data = self.ai_service.parse_json_response(ai_response)
        except Exception as e:
            logger.error(f"AI positioning failed for account {account_id}: {e}")
            positioning_data = self._get_default_positioning(account)

        # Step4: 保存到数据库和文件
        async with async_session_maker() as session:
            account = await session.get(Account, account_id)
            account.positioning = json.dumps(positioning_data, ensure_ascii=False)
            account.niche = positioning_data.get("niche", "")
            account.target_audience = positioning_data.get("target_audience", "")
            account.content_style = positioning_data.get("content_style", "")
            account.positioned_at = datetime.utcnow()
            account.updated_at = datetime.utcnow()
            await session.commit()

        # 保存到文件
        positioning_dir = os.path.join(settings.DATA_DIR, "positioning")
        os.makedirs(positioning_dir, exist_ok=True)
        positioning_file = os.path.join(positioning_dir, f"{account_id}.json")
        with open(positioning_file, "w", encoding="utf-8") as f:
            json.dump(positioning_data, f, ensure_ascii=False, indent=2)

        # Step5: 生成养号计划
        nurture_plan = self._generate_nurture_plan(positioning_data)
        positioning_data["nurture_plan"] = nurture_plan

        # 创建定位结果记录
        async with async_session_maker() as session:
            result = PositioningResult(
                id=str(uuid.uuid4()),
                account_id=account_id,
                niche=positioning_data.get("niche", ""),
                target_audience=positioning_data.get("target_audience", ""),
                content_style=positioning_data.get("content_style", ""),
                keywords=positioning_data.get("keywords", []),
                posting_schedule=positioning_data.get("posting_schedule", {}),
                strategy=positioning_data.get("strategy", ""),
                data=positioning_data,
                created_at=datetime.utcnow(),
            )
            session.add(result)
            await session.commit()
            await session.refresh(result)

        logger.info(f"Account {account_id} positioned: {positioning_data.get('niche', '')}")
        return result

    def _build_positioning_prompt(self, account: Account) -> str:
        """构建定位提示词"""
        niches_str = ", ".join(HOT_NICHES)
        return f"""请为以下小红书新账号制定详细的定位方案：

账号信息：
- 昵称：{account.name}
- 简介：{account.bio or '未设置'}
- 当前粉丝：{account.follower_count or 0}
- 当前笔记：{account.note_count or 0}

当前热门赛道参考：{niches_str}

请以JSON格式返回定位方案：
{{
    "niche": "推荐的细分领域",
    "niche_reason": "选择该领域的理由",
    "target_audience": "目标受众画像",
    "target_age": "目标年龄段",
    "content_style": "内容风格",
    "tone": "语言调性",
    "keywords": ["关键词1", "关键词2", "关键词3"],
    "content_categories": ["内容分类1", "内容分类2"],
    "posting_schedule": {{
        "daily_posts": 1,
        "best_times": ["12:00", "18:00", "21:00"],
        "weekly_plan": {{
            "周一": "教程类",
            "周二": "分享类",
            "周三": "种草类",
            "周四": "教程类",
            "周五": "话题类",
            "周六": "生活类",
            "周日": "总结类"
        }}
    }},
    "strategy": "整体运营策略",
    "competitor_notes": "竞品分析建议",
    "growth_tactics": ["增长策略1", "增长策略2"]
}}"""

    def _get_default_positioning(self, account: Account) -> Dict[str, Any]:
        """默认定位方案"""
        return {
            "niche": "生活分享",
            "niche_reason": "通用领域适合新手起步",
            "target_audience": "18-35岁年轻女性",
            "target_age": "18-35",
            "content_style": "轻松自然",
            "tone": "亲切随和",
            "keywords": ["日常", "分享", "生活"],
            "content_categories": ["日常分享", "好物推荐"],
            "posting_schedule": {
                "daily_posts": 1,
                "best_times": ["12:00", "18:00", "21:00"],
            },
            "strategy": "先养号再发力，稳步积累",
        }

    def _generate_nurture_plan(self, positioning: Dict[str, Any]) -> List[Dict[str, Any]]:
        """生成养号计划"""
        return [
            {"day": 1, "focus": "纯浏览", "actions": "浏览推荐6次，每次约20分钟", "content_count": 0},
            {"day": 2, "focus": "开始互动", "actions": "浏览6次+点赞3-5+收藏1-2+关注2-3", "content_count": 0},
            {"day": 3, "focus": "增加评论", "actions": "浏览6+点赞+评论1-2+关注", "content_count": 0},
            {"day": 4, "focus": "全面互动", "actions": "浏览6+点赞+评论+收藏+关注(增加)", "content_count": 0},
            {"day": 5, "focus": "首次发布", "actions": "浏览减少+发布第1篇+适量互动", "content_count": 1},
            {"day": 6, "focus": "稳定发布", "actions": "正常浏览+发布1篇+适量互动", "content_count": 1},
            {"day": 7, "focus": "转入日常", "actions": "简短浏览+发布1篇", "content_count": 1},
        ]

    def _load_prompt(self, filename: str) -> str:
        """加载提示词模板"""
        prompt_path = os.path.join(settings.PROMPT_DIR, filename)
        if os.path.exists(prompt_path):
            with open(prompt_path, "r", encoding="utf-8") as f:
                return f.read()
        return "你是一个小红书账号定位专家，擅长为新账号制定精准的定位方案。"
