"""
运营报告自动生成 - 周报/月报/自定义报告
"""
from __future__ import annotations
import json
from datetime import datetime, date, timedelta
from typing import Optional, List, Dict, Any
from sqlalchemy import select, and_, func
from sqlalchemy.ext.asyncio import AsyncSession
from loguru import logger

from app.models import Account, Content, DailyStat, Report, Task
from app.database import get_db_session
from app.services.ai_service import AIService


class ReportGenerator:
    """运营报告生成器"""

    def __init__(self, ai_service: Optional[AIService] = None):
        self.ai_service = ai_service

    async def generate_weekly(self):
        """生成周报（定时任务周日22:15调用）"""
        today = date.today()
        start = today - timedelta(days=6)
        async for db in get_db_session():
            stmt = select(Account).where(Account.operation_stage == "active")
            result = await db.execute(stmt)
            accounts = result.scalars().all()
            for account in accounts:
                await self._generate_report(db, "weekly", account.id, start, today)
            await self._generate_report(db, "weekly", "", start, today)
            await db.commit()

    async def generate_monthly(self):
        """生成月报（定时任务28日22:15调用）"""
        today = date.today()
        start = today.replace(day=1)
        async for db in get_db_session():
            stmt = select(Account).where(Account.operation_stage == "active")
            result = await db.execute(stmt)
            accounts = result.scalars().all()
            for account in accounts:
                await self._generate_report(db, "monthly", account.id, start, today)
            await self._generate_report(db, "monthly", "", start, today)
            await db.commit()

    async def generate_custom(self, account_id: str, start: date, end: date) -> Report:
        """自定义时间段报告"""
        async for db in get_db_session():
            report = await self._generate_report(db, "custom", account_id, start, end)
            await db.commit()
            return report

    async def list_reports(self, db: AsyncSession, page: int = 1, size: int = 20) -> tuple[List[Report], int]:
        """获取报告列表"""
        stmt = select(Report).order_by(Report.created_at.desc())
        count_stmt = select(func.count()).select_from(Report)
        total = (await db.execute(count_stmt)).scalar()
        result = await db.execute(stmt.offset((page - 1) * size).limit(size))
        return list(result.scalars().all()), total

    async def get_report(self, db: AsyncSession, report_id: str) -> Optional[Report]:
        """获取报告详情"""
        return await db.get(Report, report_id)

    async def _generate_report(
        self, db: AsyncSession, report_type: str,
        account_id: str, start: date, end: date
    ) -> Report:
        """生成报告核心逻辑"""
        data = await self._collect_data(db, account_id, start, end)
        ai_analysis = await self._ai_analyze(data, report_type)
        highlights = self._extract_highlights(data)
        suggestions = self._generate_suggestions(data, ai_analysis)

        report = Report(
            report_type=report_type,
            account_id=account_id,
            period_start=start,
            period_end=end,
            summary=json.dumps(data, ensure_ascii=False, default=str),
            ai_analysis=ai_analysis,
            suggestions=json.dumps(suggestions, ensure_ascii=False),
            highlights=json.dumps(highlights, ensure_ascii=False),
        )
        db.add(report)
        await db.flush()
        logger.info(f"报告已生成: {report_type} {account_id} {start}~{end}")
        return report

    async def _collect_data(self, db: AsyncSession, account_id: str, start: date, end: date) -> dict:
        """汇总报告数据"""
        filters = [
            DailyStat.date >= start,
            DailyStat.date <= end,
        ]
        if account_id:
            filters.append(DailyStat.account_id == account_id)
        stmt = select(
            func.sum(DailyStat.followers_gain).label("total_followers_gain"),
            func.sum(DailyStat.likes_gain).label("total_likes_gain"),
            func.sum(DailyStat.browse_count).label("total_browse"),
            func.sum(DailyStat.like_count).label("total_likes"),
            func.sum(DailyStat.comment_count).label("total_comments"),
            func.sum(DailyStat.publish_count).label("total_publish"),
            func.sum(DailyStat.total_views).label("total_views"),
        ).where(and_(*filters))
        result = await db.execute(stmt)
        row = result.first()

        content_filters = [
            Content.status == "published",
            Content.created_at >= datetime.combine(start, datetime.min.time()),
            Content.created_at <= datetime.combine(end, datetime.max.time()),
        ]
        if account_id:
            content_filters.append(Content.account_id == account_id)
        content_stmt = select(Content).where(and_(*content_filters)).order_by(Content.views.desc())
        content_result = await db.execute(content_stmt)
        top_contents = content_result.scalars().all()

        return {
            "period": f"{start} ~ {end}",
            "followers_gain": row.total_followers_gain or 0,
            "likes_gain": row.total_likes_gain or 0,
            "total_browse": row.total_browse or 0,
            "total_publish": row.total_publish or 0,
            "total_views": row.total_views or 0,
            "top_contents": [
                {"title": c.title, "views": c.views, "likes": c.likes,
                 "collects": c.collects, "comments": c.comments_count}
                for c in top_contents[:10]
            ],
        }

    async def _ai_analyze(self, data: dict, report_type: str) -> str:
        """AI分析点评"""
        if not self.ai_service:
            return f"本{report_type}期间共获得 {data['followers_gain']} 个新粉丝，发布 {data['total_publish']} 篇内容，总阅读量 {data['total_views']}。"
        prompt = f"请分析以下{report_type}运营数据并给出专业点评：\n{json.dumps(data, ensure_ascii=False, default=str)}"
        try:
            return await self.ai_service.call(prompt)
        except Exception as e:
            logger.warning(f"AI分析失败: {e}")
            return "AI分析暂时不可用，请查看详细数据。"

    def _extract_highlights(self, data: dict) -> dict:
        """提取亮点"""
        top = data.get("top_contents", [{}])[0] if data.get("top_contents") else {}
        return {
            "best_content": top.get("title", "暂无"),
            "best_content_views": top.get("views", 0),
            "followers_growth": data.get("followers_gain", 0),
            "total_views": data.get("total_views", 0),
        }

    def _generate_suggestions(self, data: dict, ai_analysis: str) -> list:
        """生成建议"""
        suggestions = []
        if data.get("total_publish", 0) < 7:
            suggestions.append("建议增加发布频率，每天至少1篇内容")
        if data.get("total_views", 0) < 1000:
            suggestions.append("优化标题和封面，提高内容点击率")
        if data.get("followers_gain", 0) < 0:
            suggestions.append("检查内容质量，避免掉粉")
        return suggestions


report_generator = ReportGenerator()
