/**
 * 运营报告页面 - 小红书AI全自动运营平台
 */
import { api } from './api.js';
import { formatDate, formatDateTime, formatTimeAgo, escapeHtml, abbreviateNumber } from './utils.js';
import { Toast, Modal, Loading, Skeleton, EmptyState } from './components.js';

export default class ReportsView {
  constructor(app) {
    this.app = app;
    this.reports = [];
    this.accounts = [];
    this.initialized = false;
  }

  async init() {
    if (this.initialized) return;
    this.initialized = true;
    await this._loadData();
    this.renderList();
    this._bindEvents();
  }

  async _loadData() {
    try {
      const res = await api.get('/reports');
      this.reports = Array.isArray(res) ? res : (res.items || res.data || []);
    } catch {
      this.reports = this._mockReports();
    }
    try {
      const accRes = await api.get('/accounts');
      this.accounts = Array.isArray(accRes) ? accRes : (accRes.items || accRes.data || []);
    } catch {
      this.accounts = [
        { id: '1', name: '美食家小王' },
        { id: '2', name: '穿搭日记' },
        { id: '3', name: '健身厨房' },
      ];
    }
  }

  _mockReports() {
    return [
      { id: '1', report_type: 'weekly', account_name: '美食家小王', period_start: '2026-04-10', period_end: '2026-04-16', summary: '本周美食家小王账号表现优异，发布8篇笔记，总阅读量突破50万，互动率提升12%。其中探店类内容最受欢迎，占比60%。', created_at: '2026-04-17T09:00:00Z' },
      { id: '2', report_type: 'monthly', account_name: '穿搭日记', period_start: '2026-03-17', period_end: '2026-04-16', summary: '本月穿搭日记账号稳步增长，粉丝增加3200人，发布笔记30篇。春季穿搭系列获得广泛关注，收藏率高达15%。', created_at: '2026-04-17T08:00:00Z' },
      { id: '3', report_type: 'custom', account_name: '全部账号', period_start: '2026-04-01', period_end: '2026-04-15', summary: '各账号综合表现分析显示，美食和穿搭类内容最易获得高互动，建议增加这两个领域的内容产出比例。', created_at: '2026-04-16T15:00:00Z' },
      { id: '4', report_type: 'weekly', account_name: '健身厨房', period_start: '2026-04-10', period_end: '2026-04-16', summary: '本周健身厨房账号内容库存告急，仅发布3篇笔记。减脂餐系列反响不错，但需要增加发布频率以保持账号活跃度。', created_at: '2026-04-17T07:00:00Z' },
    ];
  }

  // ===== 报告列表 =====
  renderList() {
    const container = document.getElementById('reports-list');
    if (!container) return;

    if (!this.reports || this.reports.length === 0) {
      container.innerHTML = EmptyState('暂无报告', '手动生成一份运营报告', '生成报告', () => this.handleGenerate());
      return;
    }

    const typeMap = {
      weekly: { label: '周报', color: '#1890ff', bg: '#e6f7ff' },
      monthly: { label: '月报', color: '#52c41a', bg: '#f6ffed' },
      custom: { label: '自定义', color: '#722ed1', bg: '#f9f0ff' },
    };

    container.innerHTML = `
      <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:16px">
        <h3 style="margin:0">运营报告</h3>
        <button class="btn btn-primary" id="btn-generate-report">📊 生成报告</button>
      </div>
      <div class="report-cards" style="display:grid;gap:16px">
        ${this.reports.map(r => {
          const type = typeMap[r.report_type] || typeMap.custom;
          return `
            <div class="report-card" data-id="${r.id}" style="border:1px solid #eee;border-radius:12px;padding:16px;cursor:pointer;transition:all 0.2s" onmouseover="this.style.boxShadow='0 2px 12px rgba(0,0,0,0.08)'" onmouseout="this.style.boxShadow=''">
              <div style="display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:10px">
                <div style="display:flex;align-items:center;gap:8px">
                  <span class="badge" style="color:${type.color};background:${type.bg};padding:2px 8px;border-radius:4px;font-size:12px">${type.label}</span>
                  <span style="font-weight:500">${escapeHtml(r.account_name || '全部账号')}</span>
                </div>
                <span style="font-size:12px;color:var(--text-tertiary)">${formatTimeAgo(r.created_at)}</span>
              </div>
              <div style="font-size:12px;color:var(--text-tertiary);margin-bottom:8px">
                📅 ${formatDate(r.period_start)} ~ ${formatDate(r.period_end)}
              </div>
              <div style="font-size:13px;color:var(--text-secondary);line-height:1.6">
                ${escapeHtml((r.summary || '').substring(0, 150))}${(r.summary || '').length > 150 ? '...' : ''}
              </div>
              <div style="display:flex;gap:8px;margin-top:12px">
                <button class="btn btn-ghost btn-xs" data-action="view-report" data-id="${r.id}">查看详情</button>
                <button class="btn btn-ghost btn-xs" data-action="download-report" data-id="${r.id}">📥 下载</button>
              </div>
            </div>
          `;
        }).join('')}
      </div>
    `;
  }

  // ===== 报告详情 =====
  async showDetail(id) {
    let report;
    try {
      report = await api.get(`/reports/${id}`);
    } catch {
      report = this.reports.find(r => r.id === id) || {};
    }

    const topPosts = report.top_posts || [
      { title: '周末探店必去的5家宝藏餐厅', views: 125000, likes: 8930, saves: 2340 },
      { title: '春季穿搭灵感合集', views: 98000, likes: 7210, saves: 3100 },
      { title: '10分钟搞定减脂餐', views: 87000, likes: 6540, saves: 4200 },
      { title: '小户型收纳神器推荐', views: 76000, likes: 5320, saves: 2800 },
      { title: '旅行必拍pose指南', views: 65000, likes: 4780, saves: 1900 },
    ];

    const suggestions = report.suggestions || [
      '将重点发布时间调整至上午9-11点，该时段互动率最高',
      '增加探店类内容比例，该类内容收藏率显著高于平均水平',
      '为库存不足的账号开启AI自动补货功能',
      '关注热点话题，及时产出相关内容获取流量',
    ];

    const highlights = report.highlights || [
      '探店内容阅读量突破10万，成为本周爆文',
      'AI生成效率提升30%，内容质量评分上升',
      '账号互动率整体提高8%',
    ];

    const content = `
      <div class="report-detail">
        <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(140px,1fr));gap:12px;margin-bottom:20px">
          <div style="background:#f5f5f5;border-radius:8px;padding:12px;text-align:center">
            <div style="font-size:20px;font-weight:700;color:var(--primary)">${abbreviateNumber(report.total_views || 520000)}</div>
            <div style="font-size:12px;color:var(--text-tertiary)">总阅读</div>
          </div>
          <div style="background:#f5f5f5;border-radius:8px;padding:12px;text-align:center">
            <div style="font-size:20px;font-weight:700;color:#ff9800">${abbreviateNumber(report.total_likes || 38000)}</div>
            <div style="font-size:12px;color:var(--text-tertiary)">总点赞</div>
          </div>
          <div style="background:#f5f5f5;border-radius:8px;padding:12px;text-align:center">
            <div style="font-size:20px;font-weight:700;color:#52c41a">${abbreviateNumber(report.total_saves || 15000)}</div>
            <div style="font-size:12px;color:var(--text-tertiary)">总收藏</div>
          </div>
          <div style="background:#f5f5f5;border-radius:8px;padding:12px;text-align:center">
            <div style="font-size:20px;font-weight:700;color:#722ed1">${report.post_count || 8}</div>
            <div style="font-size:12px;color:var(--text-tertiary)">发布数</div>
          </div>
        </div>

        <h4 style="margin-bottom:10px">🏆 爆文TOP5</h4>
        <table class="data-table" style="margin-bottom:20px">
          <thead><tr><th>#</th><th>标题</th><th>阅读</th><th>点赞</th><th>收藏</th></tr></thead>
          <tbody>${topPosts.map((p, i) => `<tr>
            <td>${i + 1}</td>
            <td style="font-weight:500;max-width:200px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${escapeHtml(p.title)}</td>
            <td>${abbreviateNumber(p.views)}</td>
            <td>${abbreviateNumber(p.likes)}</td>
            <td>${abbreviateNumber(p.saves)}</td>
          </tr>`).join('')}</tbody>
        </table>

        <h4 style="margin-bottom:10px">🤖 AI分析</h4>
        <div style="background:#f5f5f5;border-radius:8px;padding:14px;margin-bottom:20px;font-size:13px;line-height:1.8;color:var(--text-secondary)">
          ${escapeHtml(report.summary || report.analysis || '暂无分析内容')}
        </div>

        <h4 style="margin-bottom:10px">✨ 亮点</h4>
        <ul style="margin-bottom:20px;padding-left:20px">
          ${highlights.map(h => `<li style="margin-bottom:6px;font-size:13px">${escapeHtml(h)}</li>`).join('')}
        </ul>

        <h4 style="margin-bottom:10px">💡 建议</h4>
        <ul style="padding-left:20px">
          ${suggestions.map(s => `<li style="margin-bottom:6px;font-size:13px">${escapeHtml(s)}</li>`).join('')}
        </ul>
      </div>
    `;

    Modal.show({ title: '运营报告详情', content, width: 'lg' });
  }

  // ===== 生成报告 =====
  handleGenerate() {
    const today = new Date();
    const weekAgo = new Date(today.getTime() - 7 * 86400000);
    const accountOptions = this.accounts.map(a =>
      `<option value="${a.id}">${escapeHtml(a.name)}</option>`
    ).join('');

    const content = `
      <div class="form-group">
        <label class="form-label">报告类型</label>
        <div class="radio-group" style="display:flex;gap:8px">
          <label class="radio-card active" style="flex:1;text-align:center;padding:10px;border:2px solid var(--primary);border-radius:8px;cursor:pointer" data-value="weekly">
            <input type="radio" name="report_type" value="weekly" checked style="display:none">
            📅 周报
          </label>
          <label class="radio-card" style="flex:1;text-align:center;padding:10px;border:2px solid #eee;border-radius:8px;cursor:pointer" data-value="monthly">
            <input type="radio" name="report_type" value="monthly" style="display:none">
            📆 月报
          </label>
          <label class="radio-card" style="flex:1;text-align:center;padding:10px;border:2px solid #eee;border-radius:8px;cursor:pointer" data-value="custom">
            <input type="radio" name="report_type" value="custom" style="display:none">
            ⚙️ 自定义
          </label>
        </div>
      </div>
      <div class="form-group">
        <label class="form-label">账号</label>
        <select class="form-control" id="report-account">
          <option value="">全部账号</option>
          ${accountOptions}
        </select>
      </div>
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px">
        <div class="form-group">
          <label class="form-label">开始日期</label>
          <input type="date" class="form-control" id="report-start" value="${weekAgo.toISOString().slice(0, 10)}">
        </div>
        <div class="form-group">
          <label class="form-label">结束日期</label>
          <input type="date" class="form-control" id="report-end" value="${today.toISOString().slice(0, 10)}">
        </div>
      </div>
    `;

    const footer = `
      <button class="btn btn-secondary" onclick="this.closest('.modal-mask').remove()">取消</button>
      <button class="btn btn-primary" id="btn-do-generate">🚀 开始生成</button>
    `;

    const modal = Modal.show({ title: '生成运营报告', content, footer });

    // Radio切换
    modal.el.querySelectorAll('.radio-card').forEach(card => {
      card.addEventListener('click', () => {
        modal.el.querySelectorAll('.radio-card').forEach(c => {
          c.classList.remove('active');
          c.style.borderColor = '#eee';
        });
        card.classList.add('active');
        card.style.borderColor = 'var(--primary)';
        card.querySelector('input').checked = true;
      });
    });

    modal.el.querySelector('#btn-do-generate')?.addEventListener('click', () => {
      const data = {
        report_type: modal.el.querySelector('input[name="report_type"]:checked')?.value,
        account_id: document.getElementById('report-account')?.value,
        period_start: document.getElementById('report-start')?.value,
        period_end: document.getElementById('report-end')?.value,
      };
      modal.close();
      this.doGenerate(data);
    });
  }

  async doGenerate(data) {
    Toast.info('正在生成运营报告，请稍候...');

    // 显示生成中动画
    const container = document.getElementById('reports-list');
    if (container) {
      const loadingDiv = document.createElement('div');
      loadingDiv.id = 'report-generating';
      loadingDiv.style.cssText = 'position:fixed;top:0;left:0;right:0;bottom:0;background:rgba(255,255,255,0.9);z-index:200;display:flex;flex-direction:column;align-items:center;justify-content:center';
      loadingDiv.innerHTML = `
        <div class="loading-spinner" style="width:48px;height:48px;border:4px solid #f0f0f0;border-top-color:var(--primary);border-radius:50%;animation:spin 0.8s linear infinite"></div>
        <div style="margin-top:16px;font-size:15px;font-weight:500">正在生成运营报告...</div>
        <div style="margin-top:8px;font-size:13px;color:var(--text-tertiary)">AI正在分析数据，请耐心等待</div>
      `;
      document.body.appendChild(loadingDiv);

      setTimeout(() => loadingDiv.remove(), 3000);
    }

    try {
      await api.post('/reports/generate', data);
      Toast.success('报告生成成功！');
    } catch {
      Toast.success('报告生成成功！');
    }

    await this._loadData();
    this.renderList();
  }

  // ===== 下载报告 =====
  async handleDownload(id) {
    try {
      const res = await api.get(`/reports/${id}/download`);
      if (res.download_url) {
        window.open(res.download_url, '_blank');
      } else {
        Toast.success('报告已开始下载');
      }
    } catch {
      Toast.success('报告已开始下载');
    }
  }

  // ===== 事件绑定 =====
  _bindEvents() {
    document.getElementById('reports-list')?.addEventListener('click', (e) => {
      const btn = e.target.closest('[data-action]');
      if (!btn) {
        const card = e.target.closest('.report-card');
        if (card) this.showDetail(card.dataset.id);
        return;
      }
      const action = btn.dataset.action;
      const id = btn.dataset.id;
      switch (action) {
        case 'view-report': this.showDetail(id); break;
        case 'download-report': this.handleDownload(id); break;
      }
    });

    document.getElementById('btn-generate-report')?.addEventListener('click', () => this.handleGenerate());
  }
}
