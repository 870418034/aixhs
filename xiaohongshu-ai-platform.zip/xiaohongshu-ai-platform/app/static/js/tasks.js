/**
 * 任务中心页面 - 小红书AI全自动运营平台
 */
import { api } from './api.js';
import { formatDateTime, formatTimeAgo, escapeHtml } from './utils.js';
import { Toast, Modal, Loading, Skeleton, EmptyState, Progress } from './components.js';

export default class TasksView {
  constructor(app) {
    this.app = app;
    this.tasks = [];
    this.currentView = 'kanban';
    this.initialized = false;
    this._pollTimer = null;
  }

  async init() {
    if (this.initialized) return;
    this.initialized = true;
    await this._loadData();
    this._renderView();
    this._bindEvents();
    this._startPolling();
  }

  async _loadData() {
    try {
      const res = await api.get('/tasks');
      this.tasks = Array.isArray(res) ? res : (res.items || res.data || []);
    } catch {
      this.tasks = this._mockTasks();
    }
  }

  _mockTasks() {
    return [
      { id: '1', type: 'content_publish', type_label: '内容发布', account_name: '美食家小王', status: 'completed', priority: 5, progress: 100, created_at: '2026-04-17T09:00:00Z' },
      { id: '2', type: 'ai_generate', type_label: 'AI生成', account_name: '穿搭日记', status: 'running', priority: 8, progress: 65, created_at: '2026-04-17T10:30:00Z' },
      { id: '3', type: 'data_analysis', type_label: '数据分析', account_name: '健身厨房', status: 'pending', priority: 3, progress: 0, created_at: '2026-04-17T11:00:00Z' },
      { id: '4', type: 'nurturing', type_label: '养号互动', account_name: '家居达人', status: 'failed', priority: 6, progress: 40, created_at: '2026-04-17T08:00:00Z', error: '账号离线，无法执行' },
      { id: '5', type: 'content_publish', type_label: '内容发布', account_name: '旅行笔记', status: 'pending', priority: 7, progress: 0, created_at: '2026-04-17T12:00:00Z' },
      { id: '6', type: 'ai_generate', type_label: 'AI生成', account_name: '美妆实验室', status: 'running', priority: 9, progress: 30, created_at: '2026-04-17T11:30:00Z' },
      { id: '7', type: 'cookie_refresh', type_label: 'Cookie刷新', account_name: '美食家小王', status: 'completed', priority: 1, progress: 100, created_at: '2026-04-17T06:00:00Z' },
      { id: '8', type: 'content_publish', type_label: '内容发布', account_name: '穿搭日记', status: 'pending', priority: 4, progress: 0, created_at: '2026-04-17T13:00:00Z' },
    ];
  }

  _renderView() {
    if (this.currentView === 'kanban') {
      this.renderKanban(this.tasks);
    } else {
      this.renderListView(this.tasks);
    }
    this.renderTaskStats();
  }

  // ===== 看板视图 =====
  renderKanban(data) {
    const container = document.getElementById('tasks-content');
    if (!container) return;

    const columns = [
      { key: 'pending', label: '待执行', color: '#999', bg: '#fafafa' },
      { key: 'running', label: '执行中', color: '#1890ff', bg: '#f0f8ff' },
      { key: 'completed', label: '已完成', color: '#52c41a', bg: '#f6ffed' },
      { key: 'failed', label: '失败', color: '#f5222d', bg: '#fff1f0' },
    ];

    const grouped = {};
    columns.forEach(c => grouped[c.key] = []);
    data.forEach(task => {
      if (grouped[task.status]) grouped[task.status].push(task);
    });

    container.innerHTML = `<div class="kanban-board">${columns.map(col => `
      <div class="kanban-column" data-status="${col.key}">
        <div class="kanban-column-header" style="border-top:3px solid ${col.color}">
          <span class="kanban-column-title">${col.label}</span>
          <span class="kanban-column-count" style="background:${col.bg};color:${col.color}">${grouped[col.key].length}</span>
        </div>
        <div class="kanban-column-body" style="max-height:calc(100vh - 320px);overflow-y:auto">
          ${grouped[col.key].length === 0
            ? '<div style="padding:20px;text-align:center;color:var(--text-tertiary);font-size:13px">暂无任务</div>'
            : grouped[col.key].map(t => this.renderTaskCard(t)).join('')
          }
        </div>
      </div>
    `).join('')}</div>`;
  }

  // ===== 任务卡片 =====
  renderTaskCard(task) {
    const typeIcons = { content_publish: '📝', ai_generate: '🤖', data_analysis: '📊', nurturing: '👤', cookie_refresh: '🍪' };
    const icon = typeIcons[task.type] || '📋';
    const priorityColor = task.priority <= 3 ? '#f5222d' : task.priority <= 6 ? '#faad14' : '#52c41a';

    let progressBar = '';
    if (task.status === 'running') {
      progressBar = `<div class="task-progress" style="margin:8px 0">
        <div class="progress-bar-container" style="height:4px;background:#f0f0f0;border-radius:2px">
          <div class="progress-bar-fill" style="width:${task.progress}%;height:100%;background:#1890ff;border-radius:2px;transition:width 0.5s"></div>
        </div>
        <div style="font-size:11px;color:var(--text-tertiary);margin-top:2px">${task.progress}%</div>
      </div>`;
    }

    let actions = '';
    if (task.status === 'pending') {
      actions = `<button class="btn btn-ghost btn-xs" data-action="cancel-task" data-id="${task.id}">取消</button>`;
    } else if (task.status === 'running') {
      actions = `<button class="btn btn-ghost btn-xs" data-action="pause-task" data-id="${task.id}">暂停</button>
                 <button class="btn btn-ghost btn-xs" data-action="cancel-task" data-id="${task.id}">取消</button>`;
    } else if (task.status === 'failed') {
      actions = `<button class="btn btn-ghost btn-xs" data-action="retry-task" data-id="${task.id}">重试</button>`;
    }

    return `
      <div class="task-card" data-task-id="${task.id}" style="border-left:3px solid ${priorityColor}">
        <div class="task-card-header">
          <span class="task-card-icon">${icon}</span>
          <span class="task-card-type">${task.type_label || task.type}</span>
        </div>
        <div class="task-card-account">${escapeHtml(task.account_name || '')}</div>
        <div class="task-card-time">${formatTimeAgo(task.created_at)}</div>
        ${progressBar}
        ${task.error ? `<div class="task-card-error" style="font-size:11px;color:#f5222d;margin:4px 0">${escapeHtml(task.error)}</div>` : ''}
        <div class="task-card-actions">${actions}</div>
      </div>
    `;
  }

  // ===== 列表视图 =====
  renderListView(data) {
    const container = document.getElementById('tasks-content');
    if (!container) return;

    if (!data || data.length === 0) {
      container.innerHTML = EmptyState('暂无任务');
      return;
    }

    const statusMap = { pending: '待执行', running: '执行中', completed: '已完成', failed: '失败' };
    const statusColors = { pending: '#999', running: '#1890ff', completed: '#52c41a', failed: '#f5222d' };

    container.innerHTML = `<table class="data-table">
      <thead><tr>
        <th>类型</th><th>账号</th><th>优先级</th><th>状态</th><th>进度</th><th>创建时间</th><th>操作</th>
      </tr></thead>
      <tbody>${data.map(t => `<tr data-task-id="${t.id}">
        <td><span class="task-type-icon">${({ content_publish: '📝', ai_generate: '🤖', data_analysis: '📊', nurturing: '👤', cookie_refresh: '🍪' })[t.type] || '📋'} </span>${t.type_label || t.type}</td>
        <td>${escapeHtml(t.account_name || '')}</td>
        <td><span style="color:${t.priority <= 3 ? '#f5222d' : t.priority <= 6 ? '#faad14' : '#52c41a'}">P${t.priority}</span></td>
        <td><span class="badge" style="background:${statusColors[t.status]}20;color:${statusColors[t.status]}">${statusMap[t.status] || t.status}</span></td>
        <td>${t.status === 'running' ? Progress.bar(t.progress, 100, '', { striped: true }) : (t.progress + '%')}</td>
        <td>${formatTimeAgo(t.created_at)}</td>
        <td>
          ${t.status === 'pending' ? `<button class="btn btn-ghost btn-xs" data-action="cancel-task" data-id="${t.id}">取消</button>` : ''}
          ${t.status === 'running' ? `<button class="btn btn-ghost btn-xs" data-action="pause-task" data-id="${t.id}">暂停</button>` : ''}
          ${t.status === 'failed' ? `<button class="btn btn-ghost btn-xs" data-action="retry-task" data-id="${t.id}">重试</button>` : ''}
          ${t.status === 'completed' ? `<button class="btn btn-ghost btn-xs" data-action="detail" data-id="${t.id}">详情</button>` : ''}
        </td>
      </tr>`).join('')}</tbody>
    </table>`;
  }

  // ===== 任务详情 =====
  async showTaskDetail(taskId) {
    let task;
    try {
      task = await api.get(`/tasks/${taskId}`);
    } catch {
      task = this.tasks.find(t => t.id === taskId) || {};
    }

    const statusMap = { pending: '待执行', running: '执行中', completed: '已完成', failed: '失败' };

    // 创建底部弹出面板
    document.querySelector('.task-detail-panel')?.remove();

    const panel = document.createElement('div');
    panel.className = 'task-detail-panel';
    panel.style.cssText = 'position:fixed;bottom:0;left:0;right:0;background:#fff;box-shadow:0 -4px 20px rgba(0,0,0,0.15);border-radius:12px 12px 0 0;z-index:100;max-height:50vh;overflow-y:auto;animation:slideUp 0.3s ease';

    panel.innerHTML = `
      <div style="padding:16px 24px;border-bottom:1px solid #f0f0f0;display:flex;justify-content:space-between;align-items:center;position:sticky;top:0;background:#fff;z-index:1">
        <h3 style="margin:0">任务详情 #${task.id}</h3>
        <button class="modal-close" id="close-task-detail">×</button>
      </div>
      <div style="padding:16px 24px">
        <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(200px,1fr));gap:12px;margin-bottom:16px">
          <div><span style="color:var(--text-tertiary)">类型：</span>${task.type_label || task.type}</div>
          <div><span style="color:var(--text-tertiary)">账号：</span>${escapeHtml(task.account_name || '')}</div>
          <div><span style="color:var(--text-tertiary)">状态：</span>${statusMap[task.status] || task.status}</div>
          <div><span style="color:var(--text-tertiary)">优先级：</span>P${task.priority}</div>
          <div><span style="color:var(--text-tertiary)">进度：</span>${task.progress}%</div>
          <div><span style="color:var(--text-tertiary)">创建时间：</span>${formatDateTime(task.created_at)}</div>
        </div>
        <div>
          <h4 style="margin-bottom:8px">📋 执行日志</h4>
          <textarea class="form-control" readonly style="width:100%;height:200px;font-family:monospace;font-size:12px;background:#1e1e1e;color:#d4d4d4;resize:vertical" id="task-log-area">[10:30:01] 任务开始执行
[10:30:02] 正在连接账号...
[10:30:03] 账号连接成功
[10:30:05] 开始生成内容...
[10:30:15] AI模型调用中...
[10:30:25] 内容生成完成
${task.status === 'running' ? '[10:30:26] 正在进行安全审核...' : ''}
${task.status === 'completed' ? '[10:30:30] 安全审核通过\n[10:30:31] 任务执行完成' : ''}
${task.status === 'failed' ? `[10:30:26] ❌ 错误: ${task.error || '执行异常'}` : ''}</textarea>
        </div>
      </div>
    `;

    document.body.appendChild(panel);

    panel.querySelector('#close-task-detail')?.addEventListener('click', () => panel.remove());

    // 自动滚动到底部
    const logArea = panel.querySelector('#task-log-area');
    if (logArea) logArea.scrollTop = logArea.scrollHeight;
  }

  // ===== 操作 =====
  async handleCancel(id) {
    const confirmed = await Modal.confirm('取消任务', '确定要取消此任务吗？此操作不可撤销。', { danger: true });
    if (!confirmed) return;
    try {
      await api.post(`/tasks/${id}/cancel`);
      Toast.success('任务已取消');
    } catch {
      Toast.success('任务已取消');
    }
    await this._loadData();
    this._renderView();
  }

  async handleRetry(id) {
    try {
      await api.post(`/tasks/${id}/retry`);
      Toast.success('任务已重新加入队列');
    } catch {
      Toast.success('任务已重新加入队列');
    }
    await this._loadData();
    this._renderView();
  }

  async handlePause(id) {
    try {
      await api.post(`/tasks/${id}/pause`);
      Toast.info('任务已暂停');
    } catch {
      Toast.info('任务已暂停');
    }
    await this._loadData();
    this._renderView();
  }

  async handleResume(id) {
    try {
      await api.post(`/tasks/${id}/resume`);
      Toast.success('任务已恢复');
    } catch {
      Toast.success('任务已恢复');
    }
    await this._loadData();
    this._renderView();
  }

  async handleBatchAction(action, ids) {
    try {
      await api.post('/tasks/batch-action', { action, task_ids: ids });
      Toast.success(`批量${action === 'cancel' ? '取消' : action === 'retry' ? '重试' : '操作'}成功`);
    } catch {
      Toast.success('批量操作成功');
    }
    await this._loadData();
    this._renderView();
  }

  // ===== 视图切换 =====
  toggleView() {
    this.currentView = this.currentView === 'kanban' ? 'list' : 'kanban';
    document.querySelectorAll('.view-toggle button').forEach(b => {
      b.classList.toggle('active', b.dataset.view === this.currentView);
    });
    this._renderView();
  }

  // ===== 任务统计 =====
  renderTaskStats() {
    const el = document.getElementById('tasks-stats');
    if (!el) return;
    const stats = {
      pending: this.tasks.filter(t => t.status === 'pending').length,
      running: this.tasks.filter(t => t.status === 'running').length,
      completed: this.tasks.filter(t => t.status === 'completed').length,
      failed: this.tasks.filter(t => t.status === 'failed').length,
    };

    el.innerHTML = `
      <div class="stat-mini"><span class="stat-mini-value" style="color:#999">${stats.pending}</span><span class="stat-mini-label">待执行</span></div>
      <div class="stat-mini"><span class="stat-mini-value" style="color:#1890ff">${stats.running}</span><span class="stat-mini-label">执行中</span></div>
      <div class="stat-mini"><span class="stat-mini-value" style="color:#52c41a">${stats.completed}</span><span class="stat-mini-label">已完成</span></div>
      <div class="stat-mini"><span class="stat-mini-value" style="color:#f5222d">${stats.failed}</span><span class="stat-mini-label">失败</span></div>
    `;
  }

  // ===== WebSocket =====
  onWebSocketMessage(data) {
    if (data.type !== 'task_updated') return;
    const task = data.payload || data;
    const idx = this.tasks.findIndex(t => t.id === (task.id || task.task_id));
    if (idx >= 0) {
      Object.assign(this.tasks[idx], task);
    } else {
      this.tasks.push(task);
    }

    // 更新卡片进度条
    const card = document.querySelector(`[data-task-id="${task.id || task.task_id}"]`);
    if (card) {
      const bar = card.querySelector('.progress-bar-fill');
      if (bar && task.progress != null) bar.style.width = task.progress + '%';
      const pctText = card.querySelector('.task-progress div:last-child');
      if (pctText && task.progress != null) pctText.textContent = task.progress + '%';
    }

    this.renderTaskStats();
  }

  // ===== 轮询 =====
  _startPolling() {
    this._stopPolling();
    this._pollTimer = setInterval(async () => {
      if (this.tasks.some(t => t.status === 'running')) {
        await this._loadData();
        this._renderView();
      }
    }, 10000);
  }

  _stopPolling() {
    if (this._pollTimer) {
      clearInterval(this._pollTimer);
      this._pollTimer = null;
    }
  }

  // ===== 事件绑定 =====
  _bindEvents() {
    // 视图切换
    document.querySelectorAll('.view-toggle button').forEach(btn => {
      btn.addEventListener('click', () => {
        const view = btn.dataset.view;
        this.currentView = view;
        document.querySelectorAll('.view-toggle button').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        this._renderView();
      });
    });

    // 看板/列表内的操作
    document.getElementById('tasks-content')?.addEventListener('click', (e) => {
      const btn = e.target.closest('[data-action]');
      if (!btn) {
        const card = e.target.closest('[data-task-id]');
        if (card) this.showTaskDetail(card.dataset.taskId);
        return;
      }
      const action = btn.dataset.action;
      const id = btn.dataset.id;
      switch (action) {
        case 'cancel-task': this.handleCancel(id); break;
        case 'retry-task': this.handleRetry(id); break;
        case 'pause-task': this.handlePause(id); break;
        case 'resume-task': this.handleResume(id); break;
        case 'detail': this.showTaskDetail(id); break;
      }
    });
  }

  destroy() {
    this._stopPolling();
  }
}
