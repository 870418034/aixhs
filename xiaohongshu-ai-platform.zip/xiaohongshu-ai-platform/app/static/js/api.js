/**
 * API封装 - 小红书AI全自动运营平台
 */
import { generateId } from './utils.js';

export class XHSApi {
  constructor(baseUrl = '') {
    this.baseUrl = baseUrl || '';
    this.timeout = 30000;
  }

  async request(method, url, data = null, options = {}) {
    const requestId = generateId('req');
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), options.timeout || this.timeout);

    const headers = {
      'Content-Type': 'application/json',
      'X-Request-ID': requestId,
      ...options.headers,
    };

    const config = {
      method,
      headers,
      signal: controller.signal,
      ...options,
    };

    if (data && ['POST', 'PUT', 'PATCH'].includes(method)) {
      config.body = JSON.stringify(data);
    }

    try {
      const response = await fetch(this.baseUrl + url, config);
      clearTimeout(timeoutId);

      if (response.status === 429) {
        const retryAfter = response.headers.get('Retry-After') || 5;
        window.__toast?.warning(`请求过于频繁，请${retryAfter}秒后重试`);
        throw new Error(`Rate limited: retry after ${retryAfter}s`);
      }

      if (response.status === 401) {
        window.__toast?.error('登录已过期，请重新登录');
        setTimeout(() => {
          window.location.hash = '#/login';
        }, 1500);
        throw new Error('Unauthorized');
      }

      if (response.status >= 500) {
        const errorText = await response.text().catch(() => '服务器错误');
        window.__toast?.error(`服务器错误: ${errorText}`);
        throw new Error(`Server error: ${response.status}`);
      }

      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}));
        throw new Error(errorData.message || `请求失败: ${response.status}`);
      }

      const contentType = response.headers.get('content-type');
      if (contentType && contentType.includes('application/json')) {
        return await response.json();
      }
      return await response.text();
    } catch (error) {
      clearTimeout(timeoutId);
      if (error.name === 'AbortError') {
        window.__toast?.error('请求超时，请检查网络连接');
        throw new Error('Request timeout');
      }
      if (error.message === 'Failed to fetch') {
        window.__toast?.error('网络连接失败，正在尝试重连...');
        throw new Error('Network error');
      }
      throw error;
    }
  }

  get(url, options) {
    return this.request('GET', url, null, options);
  }

  post(url, data, options) {
    return this.request('POST', url, data, options);
  }

  put(url, data, options) {
    return this.request('PUT', url, data, options);
  }

  delete(url, options) {
    return this.request('DELETE', url, null, options);
  }
}

// 全局API实例
export const api = new XHSApi('/api');
