/**
 * SPA核心 - 小红书AI全自动运营平台
 * 路由 / Store / WebSocket / 深色模式 / 侧边栏 / 快捷键
 */
import { Toast, Modal } from './components.js';
import { parseJSON, generateId, sleep } from './utils.js';

// ==================== Store 状态管理 ====================
class Store {
  constructor() {
    this._state = {
      accounts: [],
      currentAccount: null,
      contentList: [],
      taskList: [],
      settings: {},
      preferences: { darkMode: false, sidebarCollapsed: false },
      alerts: [],
    };
    this._listeners = new Map();
    this._loadFromStorage();
  }

  get(key) { return this._state[key]; }

  set(key, value) {
    this._state[key] = value;
    this._notify(key);
    this._persistToStorage(key);
  }

  update(key, fn) {
    this._state[key] = fn(this._state[key]);
    this._notify(key);
    this._persistToStorage(key);
  }

  subscribe(key, fn) {
    if (!this._listeners.has(key)) this._listeners.set(key, new Set());
    this._listeners.get(key).add(fn);
    return () => this._listeners.get(key)?.delete(fn);
  }

  _notify(key) {
    this._listeners.get(key)?.forEach(fn => fn(this._state[key]));
  }

  _loadFromStorage() {
    try {
      const prefs = localStorage.getItem('xhs_prefs');
      if (prefs) Object.assign(this._state.preferences, JSON.parse(prefs));
      const settings = localStorage.getItem('xhs_settings');
      if (settings) this._state.settings = JSON.parse(settings);
    } catch {}
  }

  _persistToStorage(key) {
    try {
      if (key === 'preferences') localStorage.setItem('xhs_prefs', JSON.stringify(this._state.preferences));
      if (key === 'settings') localStorage.setItem('xhs_settings', JSON.stringify(this._state.settings));
    } catch {}
  }
}

// ==================== Router ====================
class Router {
  constructor(app) {
    this.app = app;
    this.routes = {
      dashboard: { title: '仪表盘', icon: '📊' },
      accounts: { title: '账号管理', icon: '👤' },
      content: { title: '内容管理', icon: '📝' },
      calendar: { title: '发布日历', icon: '📅' },
      tasks: { title: '任务中心', icon: '⚡' },
      ai: { title: 'AI配置', icon: '🤖' },
      materials: { title: '素材库', icon: '🖼️' },
      reports: { title: '运营报告', icon: '📈' },
      settings: { title: '系统设置', icon: '⚙️' },
      logs: { title: '运行日志', icon: '📋' },
      alerts: { title: '通知中心', icon: '🔔' },
    };
    this.currentPage = null;
    this.views = {};
  }

  init() {
    window.addEventListener('hashchange', () => this._onHashChange());
    this._onHashChange();
  }

  _onHashChange() {
    const hash = window.location.hash.replace('#/', '') || 'dashboard';
    const page = hash.split('/')[0];
    if (this.routes[page]) {
      this.switchPage(page);
    } else {
      this.switchPage('dashboard');
    }
  }

  async switchPage(page) {
    if (this.currentPage === page) return;
    // 隐藏所有模板
    document.querySelectorAll('.page-template').forEach(el => el.classList.remove('active'));
    // 显示目标模板
    const template = document.getElementById(`page-${page}`);
    if (template) template.classList.add('active');

    // 更新侧边栏active
    document.querySelectorAll('.nav-item').forEach(el => {
      el.classList.toggle('active', el.dataset.page === page);
    });

    this.currentPage = page;
    window.location.hash = `#/${page}`;

    // 动态加载页面视图
    try {
      if (!this.views[page]) {
        const view = await this._loadView(page);
        this.views[page] = view;
      }
      await this.views[page].init();
    } catch (err) {
      console.error(`Failed to load page ${page}:`, err);
      if (template) template.innerHTML = `<div class="empty-state"><div class="empty-state-icon">❌</div><div class="empty-state-title">页面加载失败</div><div class="empty-state-desc">${err.message}</div></div>`;
    }
  }

  async _loadView(page) {
    const modules = {
      dashboard: () => import('./dashboard.js'),
      accounts: () => import('./accounts.js'),
      content: () => import('./content.js'),
      tasks: () => import('./tasks.js'),
      ai: () => import('./ai-settings.js'),
      materials: () => import('./materials.js'),
      reports: () => import('./reports.js'),
      settings: () => import('./settings.js'),
      logs: () => import('./logs.js'),
    };
    const loader = modules[page];
    if (!loader) return { init: () => {} };
    const mod = await loader();
    const ViewClass = mod.default || Object.values(mod)[0];
    return new ViewClass(this.app);
  }
}

// ==================== WebSocket ====================
class WSManager {
  constructor(app) {
    this.app = app;
    this.ws = null;
    this.reconnectAttempts = 0;
    this.maxReconnectDelay = 30000;
    this.baseDelay = 1000;
    this.heartbeatInterval = null;
    this.offlineQueue = [];
    this.messageIds = new Set();
    this.connected = false;
  }

  connect() {
    const protocol = location.protocol === 'https:' ? 'wss:' : 'ws:';
    const url = `${protocol}//${location.host}/ws`;
    try {
      this.ws = new WebSocket(url);
      this.ws.onopen = () => this._onOpen();
      this.ws.onmessage = (e) => this._onMessage(e);
      this.ws.onclose = () => this._onClose();
      this.ws.onerror = () => {};
    } catch {
      this._onClose();
    }
  }

  _onOpen() {
    this.connected = true;
    this.reconnectAttempts = 0;
    document.getElementById('ws-banner')?.classList.add('hidden');
    this._startHeartbeat();
    // 补发离线消息
    while (this.offlineQueue.length) {
      this.send(this.offlineQueue.shift());
    }
  }

  _onMessage(event) {
    try {
      const data = JSON.parse(event.data);
      // 消息去重
      if (data.id) {
        if (this.messageIds.has(data.id)) return;
        this.messageIds.add(data.id);
        if (this.messageIds.size > 1000) {
          const arr = [...this.messageIds];
          this.messageIds = new Set(arr.slice(-500));
        }
      }
      // 心跳响应
      if (data.type === 'pong') return;
      // 事件分发
      this.app.onWSMessage(data);
    } catch {}
  }

  _onClose() {
    this.connected = false;
    this._stopHeartbeat();
    document.getElementById('ws-banner')?.classList.remove('hidden');
    this._reconnect();
  }

  _reconnect() {
    const delay = Math.min(this.baseDelay * Math.pow(2, this.reconnectAttempts), this.maxReconnectDelay);
    this.reconnectAttempts++;
    setTimeout(() => this.connect(), delay);
  }

  _startHeartbeat() {
    this._stopHeartbeat();
    this.heartbeatInterval = setInterval(() => {
      if (this.ws?.readyState === WebSocket.OPEN) {
        this.ws.send(JSON.stringify({ type: 'ping' }));
      }
    }, 30000);
  }

  _stopHeartbeat() {
    if (this.heartbeatInterval) {
      clearInterval(this.heartbeatInterval);
      this.heartbeatInterval = null;
    }
  }

  send(data) {
    const msg = typeof data === 'string' ? data : JSON.stringify(data);
    if (this.ws?.readyState === WebSocket.OPEN) {
      this.ws.send(msg);
    } else {
      if (this.offlineQueue.length < 20) this.offlineQueue.push(msg);
    }
  }

  disconnect() {
    this._stopHeartbeat();
    this.ws?.close();
  }
}

// ==================== App ====================
export class App {
  constructor() {
    this.store = new Store();
    this.router = new Router(this);
    this.ws = new WSManager(this);
  }

  async init() {
    this._initDarkMode();
    this._initSidebar();
    this._initShortcuts();
    this._initErrorHandling();
    this._initTopbar();
    this.router.init();
    this.ws.connect();
    // 初始化通知
    this._initAlerts();
  }

  // ===== 深色模式 =====
  _initDarkMode() {
    const pref = this.store.get('preferences');
    if (pref.darkMode === 'system') {
      this._applyTheme(window.matchMedia('(prefers-color-scheme: dark)').matches);
      window.matchMedia('(prefers-color-scheme: dark)').addEventListener('change', e => this._applyTheme(e.matches));
    } else {
      this._applyTheme(pref.darkMode === true);
    }
  }

  _applyTheme(isDark) {
    document.documentElement.classList.toggle('dark', isDark);
    document.documentElement.setAttribute('data-theme', isDark ? 'dark' : 'light');
  }

  toggleDarkMode() {
    const isDark = document.documentElement.classList.contains('dark');
    this._applyTheme(!isDark);
    this.store.update('preferences', p => ({ ...p, darkMode: !isDark }));
    Toast.info(isDark ? '已切换为浅色模式' : '已切换为深色模式');
  }

  // ===== 侧边栏 =====
  _initSidebar() {
    const collapsed = this.store.get('preferences').sidebarCollapsed;
    if (collapsed) document.getElementById('sidebar')?.classList.add('collapsed');

    document.getElementById('sidebar-toggle')?.addEventListener('click', () => this.toggleSidebar());
    // 导航点击
    document.querySelectorAll('.nav-item[data-page]').forEach(item => {
      item.addEventListener('click', () => {
        const page = item.dataset.page;
        if (page) window.location.hash = `#/${page}`;
      });
    });
  }

  toggleSidebar() {
    const sidebar = document.getElementById('sidebar');
    sidebar?.classList.toggle('collapsed');
    this.store.update('preferences', p => ({ ...p, sidebarCollapsed: sidebar?.classList.contains('collapsed') }));
  }

  // ===== 顶栏 =====
  _initTopbar() {
    // 通知按钮
    document.getElementById('notification-btn')?.addEventListener('click', () => {
      const panel = document.getElementById('notification-panel');
      panel?.classList.toggle('hidden');
    });
    // 全部已读
    document.getElementById('mark-all-read')?.addEventListener('click', () => {
      this.store.update('alerts', alerts => alerts.map(a => ({ ...a, read: true })));
      Toast.success('已全部标记为已读');
      this._updateAlertBadge();
    });
    // 设置按钮
    document.getElementById('settings-btn')?.addEventListener('click', () => {
      window.location.hash = '#/settings';
    });
    // 运行状态
    document.getElementById('run-status-btn')?.addEventListener('click', () => {
      const btn = document.getElementById('run-status-btn');
      const isRunning = btn?.textContent.includes('运行中');
      if (isRunning) {
        btn.innerHTML = '⏸ 已暂停';
        btn.classList.remove('btn-primary');
        btn.classList.add('btn-secondary');
        Toast.warning('已暂停所有任务');
      } else {
        btn.innerHTML = '▶ 运行中';
        btn.classList.remove('btn-secondary');
        btn.classList.add('btn-primary');
        Toast.success('已恢复运行');
      }
    });
  }

  // ===== 快捷键 =====
  _initShortcuts() {
    document.addEventListener('keydown', (e) => {
      // Ctrl+B 侧边栏
      if (e.ctrlKey && e.key === 'b') {
        e.preventDefault();
        this.toggleSidebar();
      }
      // Ctrl+K 搜索
      if (e.ctrlKey && e.key === 'k') {
        e.preventDefault();
        document.querySelector('.search-bar input')?.focus();
      }
      // Ctrl+N 新建
      if (e.ctrlKey && e.key === 'n') {
        e.preventDefault();
        const page = this.router.currentPage;
        if (page === 'content') document.getElementById('btn-ai-generate')?.click();
        else if (page === 'accounts') document.getElementById('btn-add-account')?.click();
      }
      // Escape 关闭模态框
      if (e.key === 'Escape') {
        document.querySelector('.modal-mask')?.remove();
        document.getElementById('notification-panel')?.classList.add('hidden');
        document.querySelector('.detail-drawer-mask')?.remove();
        document.querySelector('.detail-drawer')?.remove();
      }
    });
  }

  // ===== 错误处理 =====
  _initErrorHandling() {
    window.onerror = (msg, src, line) => {
      console.error(`Error: ${msg} at ${src}:${line}`);
    };
    window.addEventListener('unhandledrejection', (e) => {
      console.error('Unhandled rejection:', e.reason);
    });
  }

  // ===== 通知 =====
  _initAlerts() {
    // 模拟一些通知
    const sampleAlerts = [
      { id: '1', title: '账号异常提醒', message: '账号"美食探店"已连续3天未发布内容', type: 'warning', time: new Date(Date.now() - 3600000).toISOString(), read: false },
      { id: '2', title: '任务完成', message: 'AI内容生成任务已完成，共生成5篇内容', type: 'success', time: new Date(Date.now() - 7200000).toISOString(), read: false },
      { id: '3', title: '系统更新', message: '平台已更新至v2.1.0，新增批量操作功能', type: 'info', time: new Date(Date.now() - 86400000).toISOString(), read: false },
    ];
    this.store.set('alerts', sampleAlerts);
    this._updateAlertBadge();
    this._renderAlertPanel();
  }

  _updateAlertBadge() {
    const unread = (this.store.get('alerts') || []).filter(a => !a.read).length;
    const badge = document.querySelector('#notification-btn .badge');
    if (badge) {
      badge.textContent = unread;
      badge.style.display = unread > 0 ? '' : 'none';
    }
  }

  _renderAlertPanel() {
    const list = document.getElementById('notification-list');
    if (!list) return;
    const alerts = this.store.get('alerts') || [];
    if (alerts.length === 0) {
      list.innerHTML = '<div class="empty-state" style="padding:24px"><div class="empty-state-desc">暂无通知</div></div>';
      return;
    }
    list.innerHTML = alerts.map(a => {
      const icons = { warning: '⚠️', success: '✅', info: 'ℹ️', error: '❌' };
      return `<div class="activity-item ${a.read ? '' : 'unread'}" data-alert-id="${a.id}" style="padding:12px 16px;cursor:pointer;${a.read ? '' : 'background:var(--primary-light);'}">
        <div class="activity-icon">${icons[a.type] || '🔔'}</div>
        <div class="activity-content">
          <div class="activity-text" style="font-weight:${a.read ? 400 : 600}">${a.title}</div>
          <div style="font-size:12px;color:var(--text-tertiary);margin-top:2px">${a.message}</div>
          <div class="activity-time">${new Date(a.time).toLocaleString('zh-CN')}</div>
        </div>
      </div>`;
    }).join('');
  }

  // ===== WebSocket事件处理 =====
  onWSMessage(data) {
    const { type, payload } = data;
    switch (type) {
      case 'task_updated':
        this.router.views.tasks?.onWebSocketMessage?.(data);
        break;
      case 'alert':
        this.store.update('alerts', alerts => [{ ...payload, id: generateId('a'), time: new Date().toISOString(), read: false }, ...alerts]);
        this._updateAlertBadge();
        this._renderAlertPanel();
        Toast.info(payload.title || '新通知');
        break;
      case 'dashboard_update':
        this.router.views.dashboard?.onWebSocketMessage?.(data);
        break;
      default:
        break;
    }
  }
}

// ===== 启动 =====
document.addEventListener('DOMContentLoaded', () => {
  const app = new App();
  window.__app = app;
  app.init().catch(err => console.error('App init failed:', err));
});
