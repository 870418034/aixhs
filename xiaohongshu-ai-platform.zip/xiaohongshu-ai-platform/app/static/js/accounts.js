/**
 * 账号管理页面
 */
import { api } from './api.js';
import { formatNumber, abbreviateNumber, formatTimeAgo } from './utils.js';
import { Toast, Modal, Loading, Skeleton, EmptyState } from './components.js';

export default class AccountsView {
  constructor(app) {
    this.app = app;
    this.accounts = [];
    this.initialized = false;
  }

  async init() {
    if (this.initialized && this._lastRender) return;
    this.initialized = true;
    await this._loadAccounts();
    this.renderAccountCards();
    this._bindEvents();
  }

  async _loadAccounts() {
    // 模拟账号数据
    this.accounts = [
      { id: '1', name: '美食家小王', avatar: '', status: 'online', followers: 85200, likes: 423000, notes: 156, tags: ['美食', '探店'], stage: 'active', todayPosts: 2 },
      { id: '2', name: '穿搭日记', avatar: '', status: 'online', followers: 62800, likes: 318000, notes: 203, tags: ['穿搭', '时尚'], stage: 'growing', todayPosts: 1 },
      { id: '3', name: '健身厨房', avatar: '', status: 'offline', followers: 41500, likes: 195000, notes: 89, tags: ['健身', '减脂'], stage: 'active', todayPosts: 0 },
      { id: '4', name: '家居达人', avatar: '', status: 'online', followers: 53700, likes: 267000, notes: 134, tags: ['家居', '收纳'], stage: 'active', todayPosts: 3 },
      { id: '5', name: '旅行笔记', avatar: '', status: 'verifying', followers: 28900, likes: 142000, notes: 67, tags: ['旅行', '攻略'], stage: 'growing', todayPosts: 1 },
      { id: '6', name: '美妆实验室', avatar: '', status: 'online', followers: 12400, likes: 78000, notes: 45, tags: ['美妆', '护肤'], stage: 'active', todayPosts: 1 },
    ];
    this._lastRender = Date.now();
  }

  renderAccountCards() {
    const grid = document.getElementById('accounts-grid');
    const countEl = document.getElementById('accounts-count');
    if (!grid) return;
    if (countEl) countEl.textContent = `共 ${this.accounts.length} 个账号`;

    grid.innerHTML = this.accounts.map(acc => {
      const statusLabels = { online: '在线', offline: '离线', verifying: '验证中', banned: '已封禁' };
      const stageLabels = { active: '运营中', growing: '养号中', paused: '暂停' };
      return `
        <div class="account-card" data-account-id="${acc.id}">
          <div class="account-card-header">
            <div class="account-avatar-placeholder">${acc.name[0]}</div>
            <div class="account-info">
              <div class="account-name">
                ${acc.name}
                <span class="status-dot ${acc.status}" title="${statusLabels[acc.status]}"></span>
              </div>
              <div class="account-id">ID: ${acc.id} · 今日发布: ${acc.todayPosts}</div>
            </div>
          </div>
          <div class="account-stats">
            <div class="account-stat-item">
              <div class="account-stat-value">${abbreviateNumber(acc.followers)}</div>
              <div class="account-stat-label">粉丝</div>
            </div>
            <div class="account-stat-item">
              <div class="account-stat-value">${abbreviateNumber(acc.likes)}</div>
              <div class="account-stat-label">获赞</div>
            </div>
            <div class="account-stat-item">
              <div class="account-stat-value">${acc.notes}</div>
              <div class="account-stat-label">笔记</div>
            </div>
          </div>
          <div class="account-meta">
            <span class="account-stage ${acc.stage}">${stageLabels[acc.stage] || acc.stage}</span>
            <div class="account-tags">${acc.tags.map(t => `<span class="tag">${t}</span>`).join('')}</div>
          </div>
          <div class="account-actions">
            ${acc.status === 'online'
              ? `<button class="btn btn-secondary btn-sm" data-action="pause" data-id="${acc.id}">暂停</button>
                 <button class="btn btn-secondary btn-sm" data-action="refresh" data-id="${acc.id}">刷新</button>`
              : acc.status === 'offline'
              ? `<button class="btn btn-primary btn-sm" data-action="start" data-id="${acc.id}">启动</button>`
              : `<button class="btn btn-secondary btn-sm" data-action="verify" data-id="${acc.id}">重新验证</button>`
            }
            <button class="btn btn-ghost btn-sm" data-action="detail" data-id="${acc.id}">详情</button>
          </div>
        </div>
      `;
    }).join('');
  }

  _bindEvents() {
    const grid = document.getElementById('accounts-grid');
    if (!grid) return;

    grid.addEventListener('click', (e) => {
      const btn = e.target.closest('[data-action]');
      if (!btn) {
        const card = e.target.closest('.account-card');
        if (card) this.showDetailDrawer(card.dataset.accountId);
        return;
      }
      const action = btn.dataset.action;
      const id = btn.dataset.id;
      switch (action) {
        case 'start': this.handleStart(id); break;
        case 'pause': this.handlePause(id); break;
        case 'refresh': this.handleRefresh(id); break;
        case 'detail': this.showDetailDrawer(id); break;
        case 'verify': Toast.info('正在重新验证...'); break;
      }
    });

    document.getElementById('btn-add-account')?.addEventListener('click', () => this.handleAddAccount());

    document.getElementById('accounts-filter-status')?.addEventListener('change', (e) => {
      const status = e.target.value;
      const filtered = status ? this.accounts.filter(a => a.status === status) : this.accounts;
      this.accounts = filtered;
      this.renderAccountCards();
      // 重新加载所有
      if (!status) this._loadAccounts().then(() => this.renderAccountCards());
    });
  }

  handleAddAccount() {
    const content = `
      <div class="login-modal-body">
        <div class="login-tabs">
          <div class="login-tab active" data-method="qr">📱 扫码登录</div>
          <div class="login-tab" data-method="cookie">🍪 Cookie登录</div>
        </div>
        <div id="login-qr-area">
          <div class="qr-container">
            <div style="width:200px;height:200px;background:#f0f0f0;display:flex;align-items:center;justify-content:center;border-radius:8px">
              <div style="text-align:center">
                <div style="font-size:48px;margin-bottom:8px">📱</div>
                <div style="font-size:13px;color:#999">扫码登录小红书</div>
              </div>
            </div>
          </div>
          <div class="qr-hint">请使用小红书App扫描二维码登录</div>
        </div>
        <div id="login-cookie-area" style="display:none">
          <div class="cookie-input-area">
            <textarea placeholder="请粘贴小红书Cookie...\n\n获取方式：\n1. 登录小红书网页版\n2. F12打开开发者工具\n3. 复制Request Headers中的Cookie"></textarea>
          </div>
        </div>
      </div>
      <div class="modal-footer">
        <button class="btn btn-secondary" onclick="this.closest('.modal-mask').remove()">取消</button>
        <button class="btn btn-primary" id="btn-do-login">验证登录</button>
      </div>
    `;
    Modal.show({ title: '添加账号', content, width: 'sm' });

    // Tab切换
    document.querySelectorAll('.login-tab').forEach(tab => {
      tab.addEventListener('click', () => {
        document.querySelectorAll('.login-tab').forEach(t => t.classList.remove('active'));
        tab.classList.add('active');
        const method = tab.dataset.method;
        document.getElementById('login-qr-area').style.display = method === 'qr' ? '' : 'none';
        document.getElementById('login-cookie-area').style.display = method === 'cookie' ? '' : 'none';
      });
    });

    document.getElementById('btn-do-login')?.addEventListener('click', () => {
      Toast.success('账号验证成功！');
      document.querySelector('.modal-mask')?.remove();
    });
  }

  showDetailDrawer(accountId) {
    const acc = this.accounts.find(a => a.id === accountId);
    if (!acc) return;

    // 移除已有抽屉
    document.querySelector('.detail-drawer-mask')?.remove();
    document.querySelector('.detail-drawer')?.remove();

    const mask = document.createElement('div');
    mask.className = 'detail-drawer-mask';
    document.body.appendChild(mask);

    const drawer = document.createElement('div');
    drawer.className = 'detail-drawer';
    drawer.innerHTML = `
      <div class="detail-drawer-header">
        <h3>${acc.name}</h3>
        <button class="modal-close" id="drawer-close">×</button>
      </div>
      <div class="detail-drawer-tabs">
        <div class="detail-drawer-tab active" data-tab="basic">基本信息</div>
        <div class="detail-drawer-tab" data-tab="analysis">分析报告</div>
        <div class="detail-drawer-tab" data-tab="stats">运营数据</div>
        <div class="detail-drawer-tab" data-tab="content">内容列表</div>
        <div class="detail-drawer-tab" data-tab="history">任务历史</div>
      </div>
      <div class="detail-drawer-body" id="drawer-tab-content">
        <div class="detail-info-row"><span class="detail-info-label">昵称</span><span class="detail-info-value">${acc.name}</span></div>
        <div class="detail-info-row"><span class="detail-info-label">状态</span><span class="detail-info-value"><span class="status-dot ${acc.status}"></span> ${acc.status === 'online' ? '在线' : '离线'}</span></div>
        <div class="detail-info-row"><span class="detail-info-label">粉丝</span><span class="detail-info-value">${formatNumber(acc.followers)}</span></div>
        <div class="detail-info-row"><span class="detail-info-label">获赞</span><span class="detail-info-value">${formatNumber(acc.likes)}</span></div>
        <div class="detail-info-row"><span class="detail-info-label">笔记</span><span class="detail-info-value">${acc.notes}</span></div>
        <div class="detail-info-row"><span class="detail-info-label">阶段</span><span class="detail-info-value"><span class="account-stage ${acc.stage}">${acc.stage === 'active' ? '运营中' : '养号中'}</span></span></div>
        <div class="detail-info-row"><span class="detail-info-label">标签</span><span class="detail-info-value">${acc.tags.map(t => `<span class="tag" style="margin-right:4px">${t}</span>`).join('')}</span></div>
      </div>
      <div class="detail-drawer-footer">
        <button class="btn btn-secondary" onclick="this.closest('.detail-drawer').remove();document.querySelector('.detail-drawer-mask')?.remove()">关闭</button>
      </div>
    `;
    document.body.appendChild(drawer);

    const closeDrawer = () => { mask.remove(); drawer.remove(); };
    mask.addEventListener('click', closeDrawer);
    drawer.querySelector('#drawer-close')?.addEventListener('click', closeDrawer);

    // Tab切换
    drawer.querySelectorAll('.detail-drawer-tab').forEach(tab => {
      tab.addEventListener('click', () => {
        drawer.querySelectorAll('.detail-drawer-tab').forEach(t => t.classList.remove('active'));
        tab.classList.add('active');
        const tabName = tab.dataset.tab;
        const content = document.getElementById('drawer-tab-content');
        if (tabName === 'analysis') this.renderAnalysisTab(content, acc);
        else if (tabName === 'stats') this.renderStatsTab(content, acc);
        else if (tabName === 'content') this.renderContentTab(content, acc);
        else if (tabName === 'history') this.renderHistoryTab(content, acc);
        else {
          content.innerHTML = `
            <div class="detail-info-row"><span class="detail-info-label">昵称</span><span class="detail-info-value">${acc.name}</span></div>
            <div class="detail-info-row"><span class="detail-info-label">状态</span><span class="detail-info-value"><span class="status-dot ${acc.status}"></span> ${acc.status === 'online' ? '在线' : '离线'}</span></div>
            <div class="detail-info-row"><span class="detail-info-label">粉丝</span><span class="detail-info-value">${formatNumber(acc.followers)}</span></div>
            <div class="detail-info-row"><span class="detail-info-label">获赞</span><span class="detail-info-value">${formatNumber(acc.likes)}</span></div>
            <div class="detail-info-row"><span class="detail-info-label">笔记</span><span class="detail-info-value">${acc.notes}</span></div>
          `;
        }
      });
    });
  }

  renderAnalysisTab(el, acc) {
    el.innerHTML = `
      <h4 style="margin-bottom:16px">📊 账号分析报告</h4>
      <div class="detail-info-row"><span class="detail-info-label">账号权重</span><span class="detail-info-value" style="color:var(--success)">优秀 (85/100)</span></div>
      <div class="detail-info-row"><span class="detail-info-label">内容质量</span><span class="detail-info-value">良好 (72/100)</span></div>
      <div class="detail-info-row"><span class="detail-info-label">互动率</span><span class="detail-info-value">5.8%</span></div>
      <div class="detail-info-row"><span class="detail-info-label">涨粉趋势</span><span class="detail-info-value" style="color:var(--success)">↑ 日均+128</span></div>
      <div style="margin-top:16px;padding:12px;background:var(--bg-hover);border-radius:8px">
        <p style="font-size:13px;color:var(--text-secondary)">💡 <strong>建议：</strong>该账号互动率较高，建议增加发布频率至每日2篇，重点在上午9-11点发布。</p>
      </div>
    `;
  }

  renderStatsTab(el, acc) {
    el.innerHTML = `
      <h4 style="margin-bottom:16px">📈 近7天数据</h4>
      <div class="detail-mini-chart" id="detail-mini-chart-${acc.id}"></div>
    `;
    setTimeout(() => {
      const chartEl = document.getElementById(`detail-mini-chart-${acc.id}`);
      if (chartEl && window.echarts) {
        const chart = echarts.init(chartEl);
        chart.setOption({
          grid: { left: 40, right: 10, top: 10, bottom: 30 },
          xAxis: { type: 'category', data: ['周一', '周二', '周三', '周四', '周五', '周六', '周日'], axisLabel: { fontSize: 11 } },
          yAxis: { type: 'value', axisLabel: { fontSize: 11 } },
          series: [
            { type: 'line', data: [120, 132, 101, 134, 190, 230, 210], smooth: true, itemStyle: { color: '#e54d42' }, name: '阅读' },
            { type: 'line', data: [45, 52, 38, 56, 78, 95, 88], smooth: true, itemStyle: { color: '#ff9800' }, name: '点赞' },
          ],
          tooltip: { trigger: 'axis' },
          legend: { bottom: 0, textStyle: { fontSize: 11 } },
        });
      }
    }, 100);
  }

  renderContentTab(el, acc) {
    const contents = ['探店美食分享', '穿搭灵感合集', '周末vlog'].map((t, i) => ({
      title: t, status: ['已发布', '草稿', '已发布'][i], views: [12500, 0, 8900][i], likes: [890, 0, 650][i],
    }));
    el.innerHTML = `<table class="data-table">
      <thead><tr><th>标题</th><th>状态</th><th>阅读</th><th>点赞</th></tr></thead>
      <tbody>${contents.map(c => `<tr>
        <td style="font-weight:500">${c.title}</td>
        <td><span class="tag ${c.status === '已发布' ? 'success' : 'warning'}">${c.status}</span></td>
        <td>${formatNumber(c.views)}</td>
        <td>${formatNumber(c.likes)}</td>
      </tr>`).join('')}</tbody>
    </table>`;
  }

  renderHistoryTab(el, acc) {
    const tasks = [
      { type: '内容发布', time: '今天 09:00', status: 'success' },
      { type: 'AI文案生成', time: '今天 10:30', status: 'success' },
      { type: '数据分析', time: '昨天 14:00', status: 'success' },
      { type: '养号互动', time: '昨天 16:00', status: 'failed' },
    ];
    el.innerHTML = `<div class="timeline">${tasks.map(t => `
      <div class="timeline-item">
        <div class="timeline-dot ${t.status}"></div>
        <div class="timeline-content">
          <div class="timeline-time">${t.time}</div>
          <div class="timeline-title">${t.type}</div>
        </div>
      </div>
    `).join('')}</div>`;
  }

  handleStart(id) { Toast.success('账号已启动'); }
  handlePause(id) { Toast.warning('账号已暂停'); }
  handleRefresh(id) { Toast.info('正在刷新账号数据...'); }
}
