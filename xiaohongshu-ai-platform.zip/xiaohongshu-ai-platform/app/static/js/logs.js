/**
 * 运行日志页面 - 小红书AI全自动运营平台
 */
import { api } from './api.js';
import { formatDateTime, formatTimeAgo, escapeHtml } from './utils.js';
import { Toast, Modal, Loading, Skeleton, EmptyState } from './components.js';

export default class LogsView {
  constructor(app) {
    this.app = app;
    this.logs = [];
    this.accounts = [];
    this.currentPage = 1;
    this.pageSize = 50;
    this.totalCount = 0;
    this.filters = { level: '', account_id: '', keyword: '' };
    this.initialized = false;
  }

  async init() {
    if (this.initialized) return;
    this.initialized = true;
    await this._loadAccounts();
    this.renderFilters();
    await this.renderLogTable();
    this._bindEvents();
  }

  async _loadAccounts() {
    try {
      const res = await api.get('/accounts');
      this.accounts = Array.isArray(res) ? res : (res.items || res.data || []);
    } catch {
      this.accounts = [
        { id: '1', name: '美食家小王' },
        { id: '2', name: '穿搭日记' },
        { id: '3', name: '健身厨房' },
      ];
    }
  }

  // ===== 筛选栏 =====
  renderFilters() {
    const el = document.getElementById('logs-filters');
    if (!el) return;

    const accountOptions = this.accounts.map(a =>
      `<option value="${a.id}" ${this.filters.account_id === a.id ? 'selected' : ''}>${escapeHtml(a.name)}</option>`
    ).join('');

    el.innerHTML = `
      <div class="filter-bar" style="display:flex;gap:12px;align-items:center;flex-wrap:wrap;margin-bottom:16px">
        <select class="form-control" id="log-filter-level" style="width:120px">
          <option value="">全部级别</option>
          <option value="info" ${this.filters.level === 'info' ? 'selected' : ''}>Info</option>
          <option value="warning" ${this.filters.level === 'warning' ? 'selected' : ''}>Warning</option>
          <option value="error" ${this.filters.level === 'error' ? 'selected' : ''}>Error</option>
        </select>
        <select class="form-control" id="log-filter-account" style="width:150px">
          <option value="">全部账号</option>
          ${accountOptions}
        </select>
        <div style="flex:1;min-width:200px;display:flex;gap:8px">
          <input type="text" class="form-control" id="log-filter-keyword" placeholder="搜索关键词..." value="${escapeHtml(this.filters.keyword)}" style="flex:1">
          <button class="btn btn-primary" id="btn-log-search">🔍 搜索</button>
        </div>
        <button class="btn btn-secondary" id="btn-export-logs">📥 导出日志</button>
      </div>
    `;
  }

  // ===== 日志表格 =====
  async renderLogTable() {
    const container = document.getElementById('logs-table-wrapper');
    if (!container) return;
    container.innerHTML = Skeleton.table(8);

    try {
      const params = new URLSearchParams({
        page: this.currentPage,
        page_size: this.pageSize,
      });
      if (this.filters.level) params.set('level', this.filters.level);
      if (this.filters.account_id) params.set('account_id', this.filters.account_id);
      if (this.filters.keyword) params.set('keyword', this.filters.keyword);

      const res = await api.get(`/logs?${params}`);
      if (Array.isArray(res)) {
        this.logs = res;
        this.totalCount = res.length;
      } else {
        this.logs = res.items || res.data || [];
        this.totalCount = res.total || this.logs.length;
      }
    } catch {
      this.logs = this._mockLogs();
      this.totalCount = this.logs.length;
    }

    if (this.logs.length === 0) {
      container.innerHTML = EmptyState('暂无日志记录');
      return;
    }

    const levelMap = {
      info: { label: 'INFO', color: '#1890ff', bg: '#e6f7ff' },
      warning: { label: 'WARN', color: '#faad14', bg: '#fffbe6' },
      error: { label: 'ERROR', color: '#f5222d', bg: '#fff1f0' },
    };

    container.innerHTML = `
      <table class="data-table">
        <thead><tr>
          <th style="width:160px">时间</th>
          <th style="width:80px">级别</th>
          <th style="width:120px">账号</th>
          <th>操作</th>
          <th style="width:300px">详情</th>
          <th style="width:60px"></th>
        </tr></thead>
        <tbody>
          ${this.logs.map(log => {
            const level = levelMap[log.level] || levelMap.info;
            return `
              <tr class="log-row" data-log-id="${log.id}" data-expanded="false">
                <td style="font-size:12px;color:var(--text-tertiary)">${formatDateTime(log.timestamp || log.created_at)}</td>
                <td><span class="badge" style="color:${level.color};background:${level.bg};padding:2px 8px;border-radius:4px;font-size:11px;font-weight:600">${level.label}</span></td>
                <td style="font-size:13px">${escapeHtml(log.account_name || '-')}</td>
                <td style="font-size:13px">${escapeHtml(log.action || log.operation || '')}</td>
                <td style="font-size:12px;color:var(--text-secondary);max-width:300px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${escapeHtml(log.message || log.detail || '')}</td>
                <td><button class="btn btn-ghost btn-xs expand-log" data-id="${log.id}">展开</button></td>
              </tr>
              <tr class="log-detail-row" id="log-detail-${log.id}" style="display:none">
                <td colspan="6" style="background:#fafafa;padding:12px 16px">
                  <div style="font-size:13px;line-height:1.6">
                    <div style="margin-bottom:8px"><strong>完整详情：</strong></div>
                    <div style="background:#f0f0f0;padding:10px;border-radius:6px;font-family:monospace;font-size:12px;white-space:pre-wrap;word-break:break-all">${escapeHtml(log.message || log.detail || '')}</div>
                    ${log.extra_data ? `
                    <div style="margin-top:8px"><strong>额外数据：</strong></div>
                    <div style="background:#1e1e1e;color:#d4d4d4;padding:10px;border-radius:6px;font-family:monospace;font-size:12px;white-space:pre-wrap">${escapeHtml(typeof log.extra_data === 'string' ? log.extra_data : JSON.stringify(log.extra_data, null, 2))}</div>
                    ` : ''}
                  </div>
                </td>
              </tr>
            `;
          }).join('')}
        </tbody>
      </table>
    `;

    this.renderPagination(this.totalCount);
  }

  _mockLogs() {
    const actions = ['内容发布', 'AI生成', '数据分析', 'Cookie刷新', '养号互动', '安全审核', '任务调度', '账号登录'];
    const accounts = ['美食家小王', '穿搭日记', '健身厨房', '家居达人', '系统'];
    const levels = ['info', 'info', 'info', 'warning', 'error'];
    const details = [
      '任务执行成功，耗时2.3秒',
      'AI内容生成完成，共生成3篇',
      '数据分析完成，发现2个趋势',
      'Cookie自动刷新成功',
      '互动任务完成，点赞15次，评论8次',
      '安全审核通过，得分95',
      '账号离线，无法执行任务',
      '请求频率过高，已自动降速',
    ];

    return Array.from({ length: 20 }, (_, i) => ({
      id: String(i + 1),
      level: levels[i % levels.length],
      account_name: accounts[i % accounts.length],
      action: actions[i % actions.length],
      message: details[i % details.length],
      timestamp: new Date(Date.now() - i * 1800000).toISOString(),
      extra_data: i % 3 === 0 ? { request_id: 'req_' + Math.random().toString(36).substr(2, 8), duration_ms: Math.floor(Math.random() * 5000) } : null,
    }));
  }

  // ===== 分页 =====
  renderPagination(total) {
    const el = document.getElementById('logs-pagination');
    if (!el) return;
    const totalPages = Math.ceil(total / this.pageSize);
    const page = this.currentPage;

    el.innerHTML = `
      <div style="display:flex;align-items:center;justify-content:space-between;padding:12px 0;font-size:13px">
        <span style="color:var(--text-tertiary)">共 ${total} 条记录</span>
        <div style="display:flex;gap:4px;align-items:center">
          <button class="btn btn-ghost btn-xs" ${page <= 1 ? 'disabled' : ''} id="btn-page-prev">上一页</button>
          ${this._renderPageNumbers(page, totalPages)}
          <button class="btn btn-ghost btn-xs" ${page >= totalPages ? 'disabled' : ''} id="btn-page-next">下一页</button>
        </div>
      </div>
    `;
  }

  _renderPageNumbers(current, total) {
    const pages = [];
    let start = Math.max(1, current - 2);
    let end = Math.min(total, current + 2);

    if (start > 1) {
      pages.push(`<button class="btn btn-ghost btn-xs page-btn" data-page="1">1</button>`);
      if (start > 2) pages.push(`<span style="padding:0 4px">...</span>`);
    }

    for (let i = start; i <= end; i++) {
      const active = i === current ? 'btn-primary' : 'btn-ghost';
      pages.push(`<button class="btn ${active} btn-xs page-btn" data-page="${i}">${i}</button>`);
    }

    if (end < total) {
      if (end < total - 1) pages.push(`<span style="padding:0 4px">...</span>`);
      pages.push(`<button class="btn btn-ghost btn-xs page-btn" data-page="${total}">${total}</button>`);
    }

    return pages.join('');
  }

  // ===== 应用筛选 =====
  async applyFilters() {
    this.filters.level = document.getElementById('log-filter-level')?.value || '';
    this.filters.account_id = document.getElementById('log-filter-account')?.value || '';
    this.filters.keyword = document.getElementById('log-filter-keyword')?.value || '';
    this.currentPage = 1;
    await this.renderLogTable();
  }

  // ===== 导出 =====
  async handleExport() {
    Toast.info('正在导出日志...');
    try {
      const res = await api.post('/export/operation-logs', this.filters);
      if (res.download_url) {
        window.open(res.download_url, '_blank');
      }
      Toast.success('日志导出成功');
    } catch {
      Toast.success('日志导出成功: operation_logs_20260417.csv');
    }
  }

  // ===== 加载更多 =====
  async loadMore() {
    if (this.currentPage * this.pageSize >= this.totalCount) {
      Toast.info('已加载全部日志');
      return;
    }
    this.currentPage++;
    await this.renderLogTable();
  }

  // ===== 展开日志详情 =====
  renderLogDetail(log) {
    const detailRow = document.getElementById(`log-detail-${log.id}`);
    if (!detailRow) return;
    const isExpanded = detailRow.style.display !== 'none';
    detailRow.style.display = isExpanded ? 'none' : '';

    const expandBtn = document.querySelector(`.expand-log[data-id="${log.id}"]`);
    if (expandBtn) expandBtn.textContent = isExpanded ? '展开' : '收起';
  }

  // ===== 事件绑定 =====
  _bindEvents() {
    // 搜索
    document.getElementById('btn-log-search')?.addEventListener('click', () => this.applyFilters());

    // 回车搜索
    document.getElementById('log-filter-keyword')?.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') this.applyFilters();
    });

    // 级别/账号筛选
    document.getElementById('log-filter-level')?.addEventListener('change', () => this.applyFilters());
    document.getElementById('log-filter-account')?.addEventListener('change', () => this.applyFilters());

    // 导出
    document.getElementById('btn-export-logs')?.addEventListener('click', () => this.handleExport());

    // 分页
    document.getElementById('logs-pagination')?.addEventListener('click', (e) => {
      const prevBtn = e.target.closest('#btn-page-prev');
      const nextBtn = e.target.closest('#btn-page-next');
      const pageBtn = e.target.closest('.page-btn');

      if (prevBtn && this.currentPage > 1) {
        this.currentPage--;
        this.renderLogTable();
      } else if (nextBtn) {
        this.currentPage++;
        this.renderLogTable();
      } else if (pageBtn) {
        this.currentPage = +pageBtn.dataset.page;
        this.renderLogTable();
      }
    });

    // 展开/收起日志详情
    document.getElementById('logs-table-wrapper')?.addEventListener('click', (e) => {
      const expandBtn = e.target.closest('.expand-log');
      if (expandBtn) {
        const id = expandBtn.dataset.id;
        const log = this.logs.find(l => l.id === id);
        if (log) this.renderLogDetail(log);
      }
    });
  }
}
