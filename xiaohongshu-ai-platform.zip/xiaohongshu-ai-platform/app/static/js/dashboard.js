/**
 * Dashboard页面 - 仪表盘
 */
import { api } from './api.js';
import { formatNumber, abbreviateNumber, formatTimeAgo, formatPercent } from './utils.js';
import { DataTable, Progress, Skeleton, Toast } from './components.js';

export default class DashboardView {
  constructor(app) {
    this.app = app;
    this.charts = {};
    this.initialized = false;
  }

  async init() {
    if (this.initialized) return;
    this.initialized = true;
    await this._loadData();
    this.renderOverview();
    this.renderTrendsChart();
    this.renderStatusChart();
    this.renderTopContent();
    this.renderHeatmap();
    this.renderTimeline();
    this.renderActivityLog();
    this.renderAccountComparison();
    this.renderStockStatus();
    this.renderAIUsage();
    this.renderAlertBanner();
    this.renderReviewCard();
    this._bindEvents();
  }

  async _loadData() {
    // 模拟数据
    this.stats = { accounts: 12, todayPosts: 8, totalFollowers: 284500, totalLikes: 1523000 };
    this.trendsData = this._genTrendsData(7);
    this.statusData = [
      { name: '运营中', value: 7, color: '#52c41a' },
      { name: '养号中', value: 3, color: '#1890ff' },
      { name: '暂停', value: 1, color: '#faad14' },
      { name: '离线', value: 1, color: '#999' },
    ];
    this.topContent = [
      { title: '周末探店必去的5家宝藏餐厅', account: '美食家小王', views: 125000, likes: 8930, saves: 2340 },
      { title: '春季穿搭灵感合集', account: '穿搭日记', views: 98000, likes: 7210, saves: 3100 },
      { title: '10分钟搞定减脂餐', account: '健身厨房', views: 87000, likes: 6540, saves: 4200 },
      { title: '小户型收纳神器推荐', account: '家居达人', views: 76000, likes: 5320, saves: 2800 },
      { title: '旅行必拍pose指南', account: '旅行笔记', views: 65000, likes: 4780, saves: 1900 },
    ];
    this.heatmapData = this._genHeatmapData();
    this.timelineData = [
      { time: '09:00', title: '发布美食探店内容', status: 'success', account: '美食家小王' },
      { time: '10:30', title: 'AI生成穿搭文案×3', status: 'success', account: '穿搭日记' },
      { time: '12:00', title: '发布午餐内容', status: 'running', account: '美食家小王' },
      { time: '14:00', title: '数据分析报告', status: 'pending', account: '系统' },
      { time: '16:00', title: '养号互动任务', status: 'pending', account: '全部账号' },
    ];
    this.activityData = [
      { icon: '✅', text: '完成发布任务"探店内容"', time: '5分钟前' },
      { icon: '🤖', text: 'AI生成3篇穿搭文案', time: '30分钟前' },
      { icon: '📊', text: '数据分析完成，发现3个爆文趋势', time: '1小时前' },
      { icon: '👤', text: '新增账号"旅行博主小李"', time: '2小时前' },
      { icon: '⚠️', text: '账号"美食家"触发风控预警', time: '3小时前' },
      { icon: '✅', text: '定时发布任务完成', time: '4小时前' },
      { icon: '🔄', text: 'Cookie自动刷新成功', time: '5小时前' },
      { icon: '📈', text: '今日粉丝增长+128', time: '6小时前' },
    ];
    this.stockData = [
      { name: '美食家小王', count: 8, max: 10 },
      { name: '穿搭日记', count: 5, max: 10 },
      { name: '健身厨房', count: 2, max: 10 },
      { name: '家居达人', count: 7, max: 10 },
      { name: '旅行笔记', count: 0, max: 10 },
    ];
    this.aiUsage = { today: 156000, month: 2340000, budget: 5000000, cost: 187.5 };
  }

  _genTrendsData(days) {
    const data = { dates: [], followers: [], likes: [], saves: [], views: [] };
    for (let i = days - 1; i >= 0; i--) {
      const d = new Date(Date.now() - i * 86400000);
      data.dates.push(`${d.getMonth() + 1}/${d.getDate()}`);
      data.followers.push(280000 + Math.floor(Math.random() * 5000));
      data.likes.push(1500000 + Math.floor(Math.random() * 50000));
      data.saves.push(320000 + Math.floor(Math.random() * 10000));
      data.views.push(5000000 + Math.floor(Math.random() * 500000));
    }
    return data;
  }

  _genHeatmapData() {
    const data = [];
    for (let d = 0; d < 7; d++) {
      for (let h = 6; h < 24; h++) {
        data.push([h, d, Math.floor(Math.random() * 100)]);
      }
    }
    return data;
  }

  renderOverview() {
    const el = document.getElementById('dashboard-stats');
    if (!el) return;
    const cards = [
      { icon: '👥', label: '账号数量', value: this.stats.accounts, trend: '+2', trendDir: 'up', iconClass: 'blue' },
      { icon: '📝', label: '今日发布', value: this.stats.todayPosts, trend: '+3', trendDir: 'up', iconClass: 'green' },
      { icon: '💕', label: '总粉丝数', value: abbreviateNumber(this.stats.totalFollowers), trend: '+1.2%', trendDir: 'up', iconClass: 'red' },
      { icon: '❤️', label: '总获赞数', value: abbreviateNumber(this.stats.totalLikes), trend: '+3.5%', trendDir: 'up', iconClass: 'orange' },
    ];
    el.innerHTML = cards.map(c => `
      <div class="stat-card">
        <div class="stat-icon ${c.iconClass}">${c.icon}</div>
        <div class="stat-info">
          <div class="stat-value">${c.value}</div>
          <div class="stat-label">${c.label}</div>
          <div class="stat-trend ${c.trendDir}">${c.trendDir === 'up' ? '↑' : '↓'} ${c.trend}</div>
        </div>
      </div>
    `).join('');
  }

  renderTrendsChart() {
    const el = document.getElementById('trends-chart');
    if (!el) return;
    if (this.charts.trends) this.charts.trends.dispose();
    this.charts.trends = echarts.init(el);
    const d = this.trendsData;
    const option = {
      tooltip: { trigger: 'axis', axisPointer: { type: 'cross' } },
      legend: { data: ['粉丝', '获赞', '收藏', '阅读'], bottom: 0 },
      grid: { left: 60, right: 20, top: 20, bottom: 40 },
      xAxis: { type: 'category', data: d.dates, boundaryGap: false },
      yAxis: [
        { type: 'value', name: '粉丝/获赞', axisLabel: { formatter: v => abbreviateNumber(v) } },
        { type: 'value', name: '阅读', axisLabel: { formatter: v => abbreviateNumber(v) } },
      ],
      series: [
        { name: '粉丝', type: 'line', smooth: true, data: d.followers, areaStyle: { opacity: 0.1 }, itemStyle: { color: '#e54d42' } },
        { name: '获赞', type: 'line', smooth: true, data: d.likes, areaStyle: { opacity: 0.1 }, itemStyle: { color: '#ff9800' } },
        { name: '收藏', type: 'line', smooth: true, data: d.saves, areaStyle: { opacity: 0.1 }, itemStyle: { color: '#1890ff' } },
        { name: '阅读', type: 'line', smooth: true, yAxisIndex: 1, data: d.views, areaStyle: { opacity: 0.05 }, itemStyle: { color: '#52c41a' } },
      ],
    };
    this.charts.trends.setOption(option);
    window.addEventListener('resize', () => this.charts.trends?.resize());
  }

  renderStatusChart() {
    const el = document.getElementById('status-chart');
    if (!el) return;
    if (this.charts.status) this.charts.status.dispose();
    this.charts.status = echarts.init(el);
    const total = this.statusData.reduce((s, d) => s + d.value, 0);
    const option = {
      tooltip: { trigger: 'item' },
      series: [{
        type: 'pie',
        radius: ['50%', '75%'],
        center: ['50%', '50%'],
        avoidLabelOverlap: true,
        label: { show: false },
        emphasis: { scale: true, scaleSize: 6 },
        data: this.statusData.map(d => ({
          name: d.name, value: d.value,
          itemStyle: { color: d.color },
        })),
      }],
      graphic: [{
        type: 'text',
        left: 'center',
        top: 'center',
        style: { text: String(total), fontSize: 24, fontWeight: 700, fill: 'var(--text-primary)', textAlign: 'center' },
      }],
    };
    this.charts.status.setOption(option);
    window.addEventListener('resize', () => this.charts.status?.resize());
  }

  renderTopContent() {
    const el = document.getElementById('top-content-table');
    if (!el) return;
    el.innerHTML = DataTable({
      columns: [
        { key: 'title', title: '标题', render: v => `<span style="font-weight:500">${v}</span>` },
        { key: 'account', title: '账号' },
        { key: 'views', title: '阅读', render: v => abbreviateNumber(v) },
        { key: 'likes', title: '点赞', render: v => abbreviateNumber(v) },
        { key: 'saves', title: '收藏', render: v => abbreviateNumber(v) },
      ],
      data: this.topContent,
    });
  }

  renderHeatmap() {
    const el = document.getElementById('heatmap-chart');
    if (!el) return;
    if (this.charts.heatmap) this.charts.heatmap.dispose();
    this.charts.heatmap = echarts.init(el);
    const days = ['周日', '周一', '周二', '周三', '周四', '周五', '周六'];
    const hours = Array.from({ length: 18 }, (_, i) => `${i + 6}:00`);
    const option = {
      tooltip: { formatter: p => `${days[p.value[1]]} ${hours[p.value[0] - 6]}<br>互动率: ${p.value[2]}%` },
      grid: { left: 50, right: 10, top: 10, bottom: 30 },
      xAxis: { type: 'category', data: hours, splitLine: { show: false }, axisLabel: { fontSize: 10 } },
      yAxis: { type: 'category', data: days, splitLine: { show: false } },
      visualMap: { min: 0, max: 100, show: false, inRange: { color: ['#f5f5f5', '#ff6b61', '#e54d42', '#c43030'] } },
      series: [{ type: 'heatmap', data: this.heatmapData, itemStyle: { borderRadius: 3 } }],
    };
    this.charts.heatmap.setOption(option);
    window.addEventListener('resize', () => this.charts.heatmap?.resize());
  }

  renderTimeline() {
    const el = document.getElementById('dashboard-timeline-list');
    if (!el) return;
    const icons = { success: '✅', running: '🔄', pending: '⏳', failed: '❌' };
    el.innerHTML = `<div class="timeline">${this.timelineData.map(t => `
      <div class="timeline-item">
        <div class="timeline-dot ${t.status}"></div>
        <div class="timeline-content">
          <div class="timeline-time">${t.time} · ${t.account}</div>
          <div class="timeline-title">${icons[t.status] || ''} ${t.title}</div>
        </div>
      </div>
    `).join('')}</div>`;
  }

  renderActivityLog() {
    const el = document.getElementById('dashboard-activity-list');
    if (!el) return;
    el.innerHTML = this.activityData.map(a => `
      <div class="activity-item">
        <div class="activity-icon">${a.icon}</div>
        <div class="activity-content">
          <div class="activity-text">${a.text}</div>
          <div class="activity-time">${a.time}</div>
        </div>
      </div>
    `).join('');
  }

  renderAccountComparison() {
    const el = document.getElementById('comparison-chart');
    if (!el) return;
    if (this.charts.comparison) this.charts.comparison.dispose();
    this.charts.comparison = echarts.init(el);
    const accounts = ['美食家', '穿搭日记', '健身厨房', '家居达人', '旅行笔记'];
    const option = {
      tooltip: { trigger: 'axis' },
      legend: { data: ['阅读量', '点赞数', '收藏数'], bottom: 0 },
      grid: { left: 60, right: 20, top: 20, bottom: 40 },
      xAxis: { type: 'category', data: accounts },
      yAxis: { type: 'value', axisLabel: { formatter: v => abbreviateNumber(v) } },
      series: [
        { name: '阅读量', type: 'bar', data: accounts.map(() => 50000 + Math.floor(Math.random() * 100000)), itemStyle: { color: '#e54d42' } },
        { name: '点赞数', type: 'bar', data: accounts.map(() => 3000 + Math.floor(Math.random() * 8000)), itemStyle: { color: '#ff9800' } },
        { name: '收藏数', type: 'bar', data: accounts.map(() => 1000 + Math.floor(Math.random() * 4000)), itemStyle: { color: '#1890ff' } },
      ],
    };
    this.charts.comparison.setOption(option);
    window.addEventListener('resize', () => this.charts.comparison?.resize());
  }

  renderStockStatus() {
    const el = document.getElementById('stock-list');
    if (!el) return;
    el.innerHTML = this.stockData.map(s => {
      const pct = (s.count / s.max) * 100;
      const cls = pct > 60 ? 'sufficient' : pct > 20 ? 'low' : 'critical';
      return `<div class="stock-item">
        <span class="stock-name">${s.name}</span>
        <div class="stock-bar"><div class="stock-bar-fill ${cls}" style="width:${pct}%"></div></div>
        <span class="stock-count">${s.count}/${s.max}</span>
        <span class="stock-action"><button onclick="window.__app?.router?.switchPage?.('content')">生成</button></span>
      </div>`;
    }).join('');
  }

  renderAIUsage() {
    const summaryEl = document.getElementById('ai-usage-summary');
    const budgetEl = document.getElementById('ai-usage-budget');
    const catEl = document.getElementById('ai-usage-categories');
    if (!summaryEl) return;

    summaryEl.innerHTML = `
      <div class="ai-usage-item"><div class="ai-usage-value">${abbreviateNumber(this.aiUsage.today)}</div><div class="ai-usage-label">今日Token</div></div>
      <div class="ai-usage-item"><div class="ai-usage-value">${abbreviateNumber(this.aiUsage.month)}</div><div class="ai-usage-label">本月Token</div></div>
      <div class="ai-usage-item"><div class="ai-usage-value">¥${this.aiUsage.cost}</div><div class="ai-usage-label">本月费用</div></div>
    `;

    const used = (this.aiUsage.month / this.aiUsage.budget) * 100;
    budgetEl.innerHTML = Progress.bar(this.aiUsage.month, this.aiUsage.budget, `月度预算: ¥${this.aiUsage.cost} / ¥${(this.aiUsage.budget * 0.00015).toFixed(0)}`);

    const categories = [
      { name: '文案生成', value: '1,200,000', color: '#e54d42' },
      { name: '标题优化', value: '560,000', color: '#ff9800' },
      { name: '内容分析', value: '380,000', color: '#1890ff' },
      { name: '标签推荐', value: '200,000', color: '#52c41a' },
    ];
    catEl.innerHTML = categories.map(c => `
      <div class="ai-category-item">
        <span class="ai-category-dot" style="background:${c.color}"></span>
        <span class="ai-category-name">${c.name}</span>
        <span class="ai-category-value">${c.value}</span>
      </div>
    `).join('');
  }

  renderAlertBanner() {
    const el = document.getElementById('dashboard-alerts');
    if (!el) return;
    el.innerHTML = `
      <div class="alert-banner warning">
        <span class="alert-banner-icon">⚠️</span>
        <span class="alert-banner-text">账号"健身厨房"内容库存不足，当前仅剩2篇。建议尽快补充内容。</span>
        <span class="alert-banner-close" onclick="this.parentElement.remove()">✕</span>
      </div>
    `;
  }

  renderReviewCard() {
    const el = document.getElementById('review-card');
    if (!el) return;
    el.innerHTML = `
      <div class="review-card">
        <div class="review-score">
          <div class="review-score-circle excellent">87</div>
          <div class="review-score-info">
            <h4>今日运营表现：优秀</h4>
            <p>相比昨日提升 12%，多项指标超出预期</p>
          </div>
        </div>
        <div class="review-section">
          <h5>✨ 亮点</h5>
          <ul>
            <li>"探店内容"阅读量突破10万，成为今日爆文</li>
            <li>AI生成效率提升30%，内容质量评分上升</li>
            <li>账号互动率整体提高8%</li>
          </ul>
        </div>
        <div class="review-section">
          <h5>⚠️ 问题</h5>
          <ul>
            <li>"健身厨房"内容库存告急，需补充</li>
            <li>下午时段发布效果普遍偏低</li>
          </ul>
        </div>
        <div class="review-section">
          <h5>💡 建议</h5>
          <ul>
            <li>将重点发布时间调整至上午9-11点</li>
            <li>为"健身厨房"开启AI自动补货</li>
          </ul>
        </div>
      </div>
    `;
  }

  _bindEvents() {
    document.querySelectorAll('#trends-range-btns button').forEach(btn => {
      btn.addEventListener('click', () => {
        document.querySelectorAll('#trends-range-btns button').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        const range = btn.dataset.range;
        const days = range === '7d' ? 7 : range === '30d' ? 30 : 90;
        this.trendsData = this._genTrendsData(days);
        this.renderTrendsChart();
      });
    });
  }

  onWebSocketMessage(data) {
    if (data.type === 'dashboard_update') {
      // 根据payload更新对应区域
      if (data.payload?.stats) {
        Object.assign(this.stats, data.payload.stats);
        this.renderOverview();
      }
    }
  }
}
