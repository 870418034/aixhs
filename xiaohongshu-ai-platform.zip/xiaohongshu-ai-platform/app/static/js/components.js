/**
 * UI组件工厂 - 小红书AI全自动运营平台
 */
import { escapeHtml, generateId } from './utils.js';

// ===== Toast =====
export const Toast = {
  _container: null,

  _getContainer() {
    if (!this._container) {
      this._container = document.getElementById('toast-container');
    }
    return this._container;
  },

  _show(type, message, duration = 3000) {
    const container = this._getContainer();
    const icons = { success: '✓', error: '✕', warning: '⚠', info: 'ℹ' };
    const toast = document.createElement('div');
    toast.className = `toast ${type}`;
    toast.innerHTML = `
      <span class="toast-icon">${icons[type] || 'ℹ'}</span>
      <div class="toast-content"><div class="toast-message">${escapeHtml(message)}</div></div>
      <button class="toast-close" onclick="this.parentElement.remove()">×</button>
    `;
    container.appendChild(toast);

    if (duration > 0) {
      setTimeout(() => {
        toast.classList.add('removing');
        setTimeout(() => toast.remove(), 300);
      }, duration);
    }
    return toast;
  },

  success(msg, dur) { return this._show('success', msg, dur); },
  error(msg, dur) { return this._show('error', msg, dur || 5000); },
  warning(msg, dur) { return this._show('warning', msg, dur); },
  info(msg, dur) { return this._show('info', msg, dur); },
};

// 挂到全局供api.js使用
window.__toast = Toast;

// ===== Modal =====
export const Modal = {
  _container: null,

  _getContainer() {
    if (!this._container) {
      this._container = document.getElementById('modal-container');
    }
    return this._container;
  },

  show(options = {}) {
    const { title = '', content = '', width = 'md', footer = '', closable = true, onClose } = options;
    const container = this._getContainer();
    const widthClass = width === 'sm' ? 'modal-sm' : width === 'lg' ? 'modal-lg' : '';

    const mask = document.createElement('div');
    mask.className = 'modal-mask';
    mask.innerHTML = `
      <div class="modal ${widthClass}">
        ${title ? `<div class="modal-header">
          <h3>${escapeHtml(title)}</h3>
          ${closable ? '<button class="modal-close">×</button>' : ''}
        </div>` : ''}
        <div class="modal-body">${content}</div>
        ${footer ? `<div class="modal-footer">${footer}</div>` : ''}
      </div>
    `;

    const close = () => {
      mask.style.animation = 'fadeOut 0.2s ease';
      const modal = mask.querySelector('.modal');
      if (modal) modal.style.transform = 'scale(0.95)';
      setTimeout(() => {
        mask.remove();
        onClose?.();
      }, 200);
    };

    mask.querySelector('.modal-close')?.addEventListener('click', close);
    mask.addEventListener('click', e => { if (e.target === mask) close(); });

    container.appendChild(mask);
    return { close, el: mask };
  },

  confirm(title, content, { okText = '确定', cancelText = '取消', danger = false } = {}) {
    return new Promise(resolve => {
      const btnClass = danger ? 'btn-danger' : 'btn-primary';
      const footer = `
        <button class="btn btn-secondary modal-cancel">${cancelText}</button>
        <button class="btn ${btnClass} modal-ok">${okText}</button>
      `;
      const { close, el } = this.show({ title, content, footer, onClose: () => resolve(false) });
      el.querySelector('.modal-ok').addEventListener('click', () => { close(); resolve(true); });
      el.querySelector('.modal-cancel').addEventListener('click', () => { close(); resolve(false); });
    });
  },
};

// ===== Loading =====
export const Loading = {
  show(target) {
    const el = typeof target === 'string' ? document.querySelector(target) : target;
    if (!el) return;
    el.style.position = 'relative';
    const overlay = document.createElement('div');
    overlay.className = 'loading-overlay';
    overlay.innerHTML = '<div class="loading-spinner"></div>';
    overlay.dataset.loadingId = generateId('ld');
    el.appendChild(overlay);
    return overlay.dataset.loadingId;
  },

  hide(target) {
    const el = typeof target === 'string' ? document.querySelector(target) : target;
    if (!el) return;
    el.querySelectorAll('.loading-overlay').forEach(o => o.remove());
  },
};

// ===== Skeleton =====
export const Skeleton = {
  cards(count = 4) {
    return `<div class="skeleton-cards">${Array(count).fill('<div class="skeleton skeleton-card"></div>').join('')}</div>`;
  },

  table(rows = 5) {
    return `<div class="skeleton-table">
      <div class="skeleton skeleton-table-row" style="height:40px;background:#e8e8e8"></div>
      ${Array(rows).fill('<div class="skeleton skeleton-table-row"></div>').join('')}
    </div>`;
  },

  text(lines = 3) {
    return Array(lines).fill('<div class="skeleton skeleton-text"></div>').join('');
  },
};

// ===== EmptyState =====
export function EmptyState(title, desc = '', actionText = '', actionFn = null) {
  return `<div class="empty-state">
    <div class="empty-state-icon">📭</div>
    <div class="empty-state-title">${escapeHtml(title)}</div>
    ${desc ? `<div class="empty-state-desc">${escapeHtml(desc)}</div>` : ''}
    ${actionText ? `<button class="btn btn-primary">${escapeHtml(actionText)}</button>` : ''}
  </div>`;
}

// ===== Progress =====
export const Progress = {
  bar(value, max = 100, label = '', options = {}) {
    const percent = Math.min(100, Math.round((value / max) * 100));
    const cls = options.striped ? 'striped' : '';
    const colorClass = options.color || '';
    return `
      ${label ? `<div class="progress-info"><span>${escapeHtml(label)}</span><span>${percent}%</span></div>` : ''}
      <div class="progress">
        <div class="progress-bar ${cls} ${colorClass}" style="width:${percent}%"></div>
      </div>
    `;
  },
};

// ===== Dropdown =====
export function Dropdown(items, onSelect) {
  const menu = document.createElement('div');
  menu.className = 'dropdown-menu';

  items.forEach(item => {
    if (item === 'divider') {
      menu.innerHTML += '<div class="dropdown-divider"></div>';
      return;
    }
    const div = document.createElement('div');
    div.className = `dropdown-item ${item.danger ? 'danger' : ''}`;
    div.textContent = item.label;
    div.addEventListener('click', () => {
      onSelect?.(item);
      menu.remove();
    });
    menu.appendChild(div);
  });

  return menu;
}

// ===== DataTable 简化版 =====
export function DataTable(config) {
  const { columns, data, empty = '暂无数据', onSort } = config;
  if (!data || data.length === 0) {
    return EmptyState(empty);
  }

  let html = '<table class="data-table"><thead><tr>';
  columns.forEach(col => {
    const sortClass = col.sortable ? 'sortable' : '';
    const sortedClass = col.sorted ? 'sorted' : '';
    html += `<th class="${sortClass} ${sortedClass}" data-key="${col.key || ''}">${escapeHtml(col.title)}`;
    if (col.sortable) {
      const arrow = col.sorted === 'asc' ? '↑' : col.sorted === 'desc' ? '↓' : '↕';
      html += `<span class="sort-icon">${arrow}</span>`;
    }
    html += '</th>';
  });
  html += '</tr></thead><tbody>';
  data.forEach(row => {
    html += '<tr>';
    columns.forEach(col => {
      const val = col.render ? col.render(row[col.key], row) : escapeHtml(String(row[col.key] ?? ''));
      html += `<td>${val}</td>`;
    });
    html += '</tr>';
  });
  html += '</tbody></table>';
  return html;
}
