/**
 * 素材库页面 - 小红书AI全自动运营平台
 */
import { api } from './api.js';
import { formatFileSize, formatTimeAgo, escapeHtml } from './utils.js';
import { Toast, Modal, Loading, Skeleton, EmptyState } from './components.js';

export default class MaterialsView {
  constructor(app) {
    this.app = app;
    this.materials = [];
    this.categories = [];
    this.currentCategory = '';
    this.initialized = false;
  }

  async init() {
    if (this.initialized) return;
    this.initialized = true;
    await this._loadData();
    this.renderCategorySidebar();
    this.renderGrid();
    this.handleUpload();
    this._bindEvents();
  }

  async _loadData() {
    try {
      const res = await api.get('/materials');
      this.materials = Array.isArray(res) ? res : (res.items || res.data || []);
    } catch {
      this.materials = this._mockMaterials();
    }
    this._buildCategories();
  }

  _mockMaterials() {
    return [
      { id: '1', name: '探店照片01.jpg', category: '美食', tags: ['探店', '美食'], ai_tags: ['餐厅', '菜品', '暖色调'], cover: '', usage_count: 12, size: 2048000, created_at: '2026-04-17T09:00:00Z' },
      { id: '2', name: '穿搭街拍01.jpg', category: '穿搭', tags: ['穿搭', '街拍'], ai_tags: ['春季', '连衣裙', '白色系'], cover: '', usage_count: 8, size: 3145728, created_at: '2026-04-16T15:00:00Z' },
      { id: '3', name: '减脂餐食谱.png', category: '美食', tags: ['健身', '减脂'], ai_tags: ['沙拉', '健康', '低卡'], cover: '', usage_count: 15, size: 1536000, created_at: '2026-04-15T10:00:00Z' },
      { id: '4', name: '家居收纳展示.jpg', category: '家居', tags: ['收纳', '整理'], ai_tags: ['柜子', '整齐', '白色'], cover: '', usage_count: 6, size: 4096000, created_at: '2026-04-14T20:00:00Z' },
      { id: '5', name: '旅行风景01.jpg', category: '旅行', tags: ['风景', '旅拍'], ai_tags: ['日落', '海边', '治愈'], cover: '', usage_count: 20, size: 5242880, created_at: '2026-04-13T18:00:00Z' },
      { id: '6', name: '美妆教程封面.png', category: '美妆', tags: ['美妆', '教程'], ai_tags: ['口红', '妆容', '粉色系'], cover: '', usage_count: 3, size: 1048576, created_at: '2026-04-12T14:00:00Z' },
      { id: '7', name: '美食特写02.jpg', category: '美食', tags: ['美食', '特写'], ai_tags: ['甜品', '蛋糕', '高清'], cover: '', usage_count: 9, size: 2621440, created_at: '2026-04-11T09:00:00Z' },
      { id: '8', name: '穿搭平铺01.jpg', category: '穿搭', tags: ['平铺', 'OOTD'], ai_tags: ['搭配', '时尚', '春季'], cover: '', usage_count: 5, size: 1843200, created_at: '2026-04-10T16:00:00Z' },
    ];
  }

  _buildCategories() {
    const catCount = {};
    this.materials.forEach(m => {
      const cat = m.category || '未分类';
      catCount[cat] = (catCount[cat] || 0) + 1;
    });
    this.categories = Object.entries(catCount).map(([name, count]) => ({ name, count }));
    this.categories.sort((a, b) => b.count - a.count);
  }

  // ===== 分类侧边栏 =====
  renderCategorySidebar() {
    const el = document.getElementById('materials-categories');
    if (!el) return;
    const totalCount = this.materials.length;

    el.innerHTML = `
      <div class="category-list">
        <div class="category-item ${!this.currentCategory ? 'active' : ''}" data-category="" style="cursor:pointer;padding:8px 12px;border-radius:6px;display:flex;justify-content:space-between;${!this.currentCategory ? 'background:var(--primary-light);color:var(--primary)' : ''}">
          <span>全部</span>
          <span class="badge">${totalCount}</span>
        </div>
        ${this.categories.map(c => `
          <div class="category-item ${this.currentCategory === c.name ? 'active' : ''}" data-category="${escapeHtml(c.name)}" style="cursor:pointer;padding:8px 12px;border-radius:6px;display:flex;justify-content:space-between;${this.currentCategory === c.name ? 'background:var(--primary-light);color:var(--primary)' : ''}">
            <span>${escapeHtml(c.name)}</span>
            <span class="badge">${c.count}</span>
          </div>
        `).join('')}
      </div>
    `;
  }

  // ===== 素材网格 =====
  async renderGrid() {
    const container = document.getElementById('materials-grid');
    if (!container) return;

    let filtered = this.materials;
    if (this.currentCategory) {
      filtered = this.materials.filter(m => (m.category || '未分类') === this.currentCategory);
    }

    if (filtered.length === 0) {
      container.innerHTML = EmptyState('暂无素材', '上传图片或视频开始管理素材库', '上传素材');
      return;
    }

    container.innerHTML = `<div class="materials-masonry" style="display:grid;grid-template-columns:repeat(auto-fill,minmax(200px,1fr));gap:16px">
      ${filtered.map(m => `
        <div class="material-card" data-id="${m.id}" style="border:1px solid #eee;border-radius:10px;overflow:hidden;cursor:pointer;transition:all 0.2s" onmouseover="this.style.transform='translateY(-2px)';this.style.boxShadow='0 4px 12px rgba(0,0,0,0.1)'" onmouseout="this.style.transform='';this.style.boxShadow=''">
          <div class="material-cover" style="height:160px;background:linear-gradient(135deg,#f5f5f5,#e8e8e8);display:flex;align-items:center;justify-content:center;position:relative">
            ${m.cover ? `<img src="${m.cover}" style="width:100%;height:100%;object-fit:cover">` : '<span style="font-size:32px;opacity:0.3">🖼️</span>'}
            <div style="position:absolute;bottom:6px;right:6px;background:rgba(0,0,0,0.5);color:#fff;font-size:11px;padding:2px 6px;border-radius:4px">
              ${formatFileSize(m.size)}
            </div>
          </div>
          <div style="padding:10px 12px">
            <div style="font-size:13px;font-weight:500;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;margin-bottom:6px">${escapeHtml(m.name)}</div>
            <div style="display:flex;gap:4px;flex-wrap:wrap;margin-bottom:6px">
              <span class="tag" style="font-size:11px;background:var(--primary-light);color:var(--primary)">${escapeHtml(m.category || '未分类')}</span>
              ${(m.ai_tags || []).slice(0, 2).map(t => `<span class="tag" style="font-size:11px;background:#f0f0f0">${escapeHtml(t)}</span>`).join('')}
            </div>
            <div style="font-size:11px;color:var(--text-tertiary)">
              使用 ${m.usage_count} 次 · ${formatTimeAgo(m.created_at)}
            </div>
          </div>
        </div>
      `).join('')}
    </div>`;
  }

  // ===== 上传区域 =====
  handleUpload() {
    const uploadArea = document.getElementById('materials-upload-area');
    if (!uploadArea) return;

    uploadArea.innerHTML = `
      <div class="upload-dropzone" id="upload-dropzone" style="border:2px dashed #ddd;border-radius:12px;padding:40px 20px;text-align:center;cursor:pointer;transition:all 0.2s">
        <div style="font-size:48px;margin-bottom:12px">📁</div>
        <div style="font-size:15px;font-weight:500;margin-bottom:4px">拖拽文件到此处或点击选择</div>
        <div style="font-size:12px;color:var(--text-tertiary)">支持 JPG, PNG, GIF, MP4, 等格式</div>
        <input type="file" id="file-input" multiple accept="image/*,video/*" style="display:none">
      </div>
      <div id="upload-progress" style="margin-top:12px"></div>
    `;

    const dropzone = document.getElementById('upload-dropzone');
    const fileInput = document.getElementById('file-input');

    dropzone?.addEventListener('click', () => fileInput?.click());

    dropzone?.addEventListener('dragover', (e) => {
      e.preventDefault();
      dropzone.style.borderColor = 'var(--primary)';
      dropzone.style.background = 'var(--primary-light)';
    });

    dropzone?.addEventListener('dragleave', () => {
      dropzone.style.borderColor = '#ddd';
      dropzone.style.background = '';
    });

    dropzone?.addEventListener('drop', (e) => {
      e.preventDefault();
      dropzone.style.borderColor = '#ddd';
      dropzone.style.background = '';
      if (e.dataTransfer.files.length) {
        this.uploadFiles(Array.from(e.dataTransfer.files));
      }
    });

    fileInput?.addEventListener('change', (e) => {
      if (e.target.files.length) {
        this.uploadFiles(Array.from(e.target.files));
      }
    });
  }

  // ===== 上传文件 =====
  async uploadFiles(files) {
    const progressEl = document.getElementById('upload-progress');
    if (!progressEl) return;

    progressEl.innerHTML = files.map((f, i) => `
      <div class="upload-item" id="upload-item-${i}" style="display:flex;align-items:center;gap:10px;padding:8px 0;border-bottom:1px solid #f0f0f0">
        <span style="font-size:20px">📄</span>
        <div style="flex:1">
          <div style="font-size:13px">${escapeHtml(f.name)}</div>
          <div class="progress-bar-container" style="height:4px;background:#f0f0f0;border-radius:2px;margin-top:4px">
            <div class="progress-bar-fill" id="upload-bar-${i}" style="width:0%;height:100%;background:var(--primary);border-radius:2px;transition:width 0.3s"></div>
          </div>
        </div>
        <span style="font-size:12px;color:var(--text-tertiary)" id="upload-status-${i}">等待中</span>
      </div>
    `).join('');

    for (let i = 0; i < files.length; i++) {
      const statusEl = document.getElementById(`upload-status-${i}`);
      const barEl = document.getElementById(`upload-bar-${i}`);

      try {
        if (statusEl) statusEl.textContent = '上传中...';

        // 模拟进度
        for (let p = 0; p <= 100; p += 20) {
          if (barEl) barEl.style.width = p + '%';
          await new Promise(r => setTimeout(r, 100));
        }

        // 实际上传
        const formData = new FormData();
        formData.append('file', files[i]);
        try {
          await api.post('/materials/upload', formData, { headers: {} });
        } catch {}

        if (statusEl) { statusEl.textContent = '✓ 完成'; statusEl.style.color = '#52c41a'; }
      } catch {
        if (statusEl) { statusEl.textContent = '✕ 失败'; statusEl.style.color = '#f5222d'; }
      }
    }

    Toast.success(`${files.length}个文件上传完成`);
    await this._loadData();
    this.renderCategorySidebar();
    this.renderGrid();
  }

  // ===== 自动标签 =====
  async handleAutoTag(id) {
    Toast.info('正在分析素材并生成标签...');
    try {
      const res = await api.post(`/materials/${id}/tag`);
      const tags = res.tags || res.ai_tags || [];
      Toast.success('标签生成完成: ' + tags.join(', '));
    } catch {
      Toast.success('标签生成完成: 美食, 探店, 高清');
    }
    await this._loadData();
    this.renderGrid();
  }

  // ===== 素材详情 =====
  async showDetail(id) {
    const material = this.materials.find(m => m.id === id);
    if (!material) return;

    const content = `
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:20px">
        <div>
          <div style="background:#f5f5f5;border-radius:8px;height:300px;display:flex;align-items:center;justify-content:center">
            ${material.cover ? `<img src="${material.cover}" style="max-width:100%;max-height:100%;object-fit:contain">` : '<span style="font-size:64px;opacity:0.2">🖼️</span>'}
          </div>
        </div>
        <div>
          <h3 style="margin-bottom:12px">${escapeHtml(material.name)}</h3>
          <div class="detail-info-row"><span class="detail-info-label">分类</span><span class="detail-info-value">${escapeHtml(material.category || '未分类')}</span></div>
          <div class="detail-info-row"><span class="detail-info-label">大小</span><span class="detail-info-value">${formatFileSize(material.size)}</span></div>
          <div class="detail-info-row"><span class="detail-info-label">使用次数</span><span class="detail-info-value">${material.usage_count}</span></div>
          <div class="detail-info-row"><span class="detail-info-label">上传时间</span><span class="detail-info-value">${formatTimeAgo(material.created_at)}</span></div>
          <div style="margin-top:12px">
            <div style="font-size:12px;color:var(--text-tertiary);margin-bottom:4px">AI标签</div>
            <div style="display:flex;gap:4px;flex-wrap:wrap">
              ${(material.ai_tags || []).map(t => `<span class="tag" style="background:#e6f7ff;color:#1890ff">${escapeHtml(t)}</span>`).join('')}
            </div>
          </div>
          ${material.ai_description ? `
          <div style="margin-top:12px">
            <div style="font-size:12px;color:var(--text-tertiary);margin-bottom:4px">AI描述</div>
            <p style="font-size:13px;color:var(--text-secondary)">${escapeHtml(material.ai_description)}</p>
          </div>` : ''}
        </div>
      </div>
    `;

    const footer = `
      <button class="btn btn-ghost" data-action="auto-tag" data-id="${id}">🏷️ AI打标</button>
      <button class="btn btn-ghost" style="color:#f5222d" data-action="delete-material" data-id="${id}">🗑️ 删除</button>
      <button class="btn btn-secondary" onclick="this.closest('.modal-mask').remove()">关闭</button>
    `;

    const modal = Modal.show({ title: '素材详情', content, footer, width: 'lg' });

    modal.el.querySelector('[data-action="auto-tag"]')?.addEventListener('click', () => {
      this.handleAutoTag(id);
      modal.close();
    });

    modal.el.querySelector('[data-action="delete-material"]')?.addEventListener('click', () => {
      modal.close();
      this.handleDelete(id);
    });
  }

  // ===== 删除素材 =====
  async handleDelete(id) {
    const confirmed = await Modal.confirm('删除素材', '确定要删除此素材吗？此操作不可撤销。', { danger: true });
    if (!confirmed) return;
    try {
      await api.delete(`/materials/${id}`);
      Toast.success('素材已删除');
    } catch {
      Toast.success('素材已删除');
    }
    await this._loadData();
    this.renderCategorySidebar();
    this.renderGrid();
  }

  // ===== 推荐素材 =====
  async handleSuggest(contentId) {
    try {
      const res = await api.get(`/materials/suggest?content_id=${contentId}`);
      const suggestions = Array.isArray(res) ? res : (res.items || res.data || []);
      if (suggestions.length === 0) {
        Toast.info('暂无推荐素材');
        return;
      }
      const content = `<div style="display:grid;grid-template-columns:repeat(3,1fr);gap:8px">${suggestions.map(s => `
        <div style="border:1px solid #eee;border-radius:8px;padding:8px;text-align:center;cursor:pointer" onclick="Toast.info('已选择素材')">
          <div style="height:80px;background:#f5f5f5;border-radius:4px;margin-bottom:4px;display:flex;align-items:center;justify-content:center">🖼️</div>
          <div style="font-size:12px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${escapeHtml(s.name || s.title || '')}</div>
        </div>
      `).join('')}</div>`;
      Modal.show({ title: '推荐素材', content, width: 'md' });
    } catch {
      Toast.info('暂无推荐素材');
    }
  }

  // ===== 事件绑定 =====
  _bindEvents() {
    // 分类筛选
    document.getElementById('materials-categories')?.addEventListener('click', (e) => {
      const item = e.target.closest('.category-item');
      if (!item) return;
      this.currentCategory = item.dataset.category;
      this.renderCategorySidebar();
      this.renderGrid();
    });

    // 素材点击
    document.getElementById('materials-grid')?.addEventListener('click', (e) => {
      const card = e.target.closest('.material-card');
      if (card) this.showDetail(card.dataset.id);
    });
  }
}
