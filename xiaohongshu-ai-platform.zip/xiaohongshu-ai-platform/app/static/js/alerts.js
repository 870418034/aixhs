/**
 * 通知/预警面板 - 小红书AI全自动运营平台
 */
import { api } from './api.js';
import { formatTimeAgo, escapeHtml } from './utils.js';
import { Toast, Modal } from './components.js';

export default class AlertsView {
  constructor(app) {
    this.app = app;
    this.alerts = [];
    this.initialized = false;
    this.panelVisible = false;
    this.unreadCount = 0;
  }

  async init() {
    if (this.initialized) return;
    this.initialized = true;
    await this.loadAlerts();
    this._initBellButton();
    this._renderFullPage();
    this._bindEvents();
  }

  // ===== 渲染全页面通知列表 =====
  _renderFullPage() {
    const container = document.getElementById('alerts-list-full');
    if (!container) return;
    const alerts = this.alerts;
    if (!alerts || alerts.length === 0) {
      container.innerHTML = '<div style="padding:40px;text-align:center;color:var(--text-tertiary)"><div style="font-size:32px;margin-bottom:8px">🔔</div>暂无通知</div>';
      return;
    }
    const icons = { info: '💬', warning: '⚠️', critical: '🚨' };
    container.innerHTML = alerts.map(a => `
      <div class="activity-item ${a.read ? '' : 'unread'}" data-alert-id="${a.id}" style="padding:16px;border-bottom:1px solid var(--border-light);${a.read ? '' : 'background:var(--info-light);'}">
        <div class="activity-icon">${icons[a.type] || '💬'}</div>
        <div class="activity-content" style="flex:1">
          <div class="activity-text" style="font-weight:${a.read ? 400 : 600}">${escapeHtml(a.title)}</div>
          <div style="font-size:13px;color:var(--text-secondary);margin-top:4px">${escapeHtml(a.message || '')}</div>
          <div class="activity-time">${formatTimeAgo(a.created_at)}</div>
        </div>
        <div style="display:flex;gap:8px">
          ${!a.read ? `<button class="btn btn-ghost btn-xs fp-mark-read" data-id="${a.id}">标记已读</button>` : ''}
          <button class="btn btn-ghost btn-xs fp-delete" data-id="${a.id}" style="color:var(--error)">删除</button>
        </div>
      </div>
    `).join('');

    container.querySelectorAll('.fp-mark-read').forEach(btn => {
      btn.addEventListener('click', (e) => {
        e.stopPropagation();
        this.handleMarkRead(btn.dataset.id);
        this._renderFullPage();
      });
    });

    container.querySelectorAll('.fp-delete').forEach(btn => {
      btn.addEventListener('click', (e) => {
        e.stopPropagation();
        this.handleDelete(btn.dataset.id);
        this._renderFullPage();
      });
    });
  }

  // ===== 初始化通知铃铛 =====
  _initBellButton() {
    let bellBtn = document.getElementById('alerts-bell-btn');
    if (!bellBtn) {
      // 如果没有现成的铃铛按钮，注入到顶栏
      const topbar = document.querySelector('.topbar-actions') || document.querySelector('.topbar');
      if (topbar) {
        bellBtn = document.createElement('div');
        bellBtn.id = 'alerts-bell-btn';
        bellBtn.style.cssText = 'position:relative;cursor:pointer;padding:8px;font-size:20px;display:inline-flex;align-items:center';
        bellBtn.innerHTML = `
          🔔
          <span class="alerts-badge" id="alerts-badge" style="display:none;position:absolute;top:2px;right:2px;min-width:18px;height:18px;background:#f5222d;color:#fff;border-radius:9px;font-size:11px;font-weight:700;display:flex;align-items:center;justify-content:center;padding:0 4px"></span>
        `;
        topbar.appendChild(bellBtn);
      }
    }

    // 创建通知面板
    this._createPanel();
    this.getUnreadCount();
  }

  _createPanel() {
    let panel = document.getElementById('alerts-panel');
    if (panel) return;

    panel = document.createElement('div');
    panel.id = 'alerts-panel';
    panel.style.cssText = `
      display:none;position:fixed;top:56px;right:16px;width:360px;max-height:480px;
      background:#fff;border-radius:12px;box-shadow:0 8px 32px rgba(0,0,0,0.15);
      z-index:1000;overflow:hidden;
    `;
    panel.innerHTML = `
      <div style="padding:14px 16px;border-bottom:1px solid #f0f0f0;display:flex;justify-content:space-between;align-items:center;position:sticky;top:0;background:#fff;z-index:1">
        <h3 style="margin:0;font-size:15px">通知中心</h3>
        <div style="display:flex;gap:8px">
          <button class="btn btn-ghost btn-xs" id="btn-mark-all-read">全部已读</button>
          <button class="btn btn-ghost btn-xs" id="btn-close-alerts-panel">×</button>
        </div>
      </div>
      <div id="alerts-list" style="max-height:400px;overflow-y:auto"></div>
    `;
    document.body.appendChild(panel);
  }

  // ===== 加载通知 =====
  async loadAlerts() {
    try {
      const res = await api.get('/notifications');
      this.alerts = Array.isArray(res) ? res : (res.items || res.data || []);
    } catch {
      this.alerts = this._mockAlerts();
    }
    this.renderAlertList(this.alerts);
  }

  _mockAlerts() {
    return [
      { id: '1', title: '账号异常提醒', message: '账号"美食家小王"已连续3天未发布内容', type: 'warning', created_at: new Date(Date.now() - 1800000).toISOString(), read: false },
      { id: '2', title: '任务完成', message: 'AI内容生成任务已完成，共生成5篇内容', type: 'info', created_at: new Date(Date.now() - 3600000).toISOString(), read: false },
      { id: '3', title: '安全预警', message: '检测到高频操作，已自动降速处理', type: 'critical', created_at: new Date(Date.now() - 7200000).toISOString(), read: false },
      { id: '4', title: '系统更新', message: '平台已更新至v2.1.0，新增批量操作功能', type: 'info', created_at: new Date(Date.now() - 86400000).toISOString(), read: true },
      { id: '5', title: '内容爆文提醒', message: '"探店内容"阅读量突破10万，成为今日爆文', type: 'info', created_at: new Date(Date.now() - 172800000).toISOString(), read: true },
    ];
  }

  // ===== 渲染通知列表 =====
  renderAlertList(alerts) {
    const listEl = document.getElementById('alerts-list');
    if (!listEl) return;

    if (!alerts || alerts.length === 0) {
      listEl.innerHTML = '<div style="padding:40px 20px;text-align:center;color:var(--text-tertiary)"><div style="font-size:32px;margin-bottom:8px">🔔</div>暂无通知</div>';
      return;
    }

    const icons = { info: '💬', warning: '⚠️', critical: '🚨' };

    listEl.innerHTML = alerts.map(a => `
      <div class="alert-item ${a.read ? '' : 'unread'}" data-alert-id="${a.id}" style="
        padding:12px 16px;border-bottom:1px solid #f5f5f5;display:flex;gap:10px;
        cursor:pointer;transition:background 0.2s;
        ${a.read ? '' : 'background:#f0f8ff;'}
      " onmouseover="this.style.background='${a.read ? '#fafafa' : '#e6f3ff'}'" onmouseout="this.style.background='${a.read ? '' : '#f0f8ff'}'">
        <div style="font-size:18px;flex-shrink:0;margin-top:2px">${icons[a.type] || '💬'}</div>
        <div style="flex:1;min-width:0">
          <div style="display:flex;justify-content:space-between;align-items:flex-start">
            <span style="font-weight:${a.read ? 400 : 600};font-size:13px">${escapeHtml(a.title)}</span>
            ${!a.read ? '<span style="width:8px;height:8px;background:#1890ff;border-radius:50%;flex-shrink:0;margin-top:6px;margin-left:8px"></span>' : ''}
          </div>
          <div style="font-size:12px;color:var(--text-secondary);margin-top:3px;line-height:1.4">${escapeHtml(a.message || '')}</div>
          <div style="font-size:11px;color:var(--text-tertiary);margin-top:4px">${formatTimeAgo(a.created_at)}</div>
        </div>
        <div class="alert-actions" style="display:none;flex-shrink:0">
          ${!a.read ? `<button class="btn btn-ghost btn-xs mark-read-btn" data-id="${a.id}" title="标记已读" style="font-size:14px">✓</button>` : ''}
          <button class="btn btn-ghost btn-xs delete-alert-btn" data-id="${a.id}" title="删除" style="font-size:14px;color:#f5222d">×</button>
        </div>
      </div>
    `).join('');

    // 悬停显示操作按钮
    listEl.querySelectorAll('.alert-item').forEach(item => {
      item.addEventListener('mouseenter', () => {
        const actions = item.querySelector('.alert-actions');
        if (actions) actions.style.display = 'flex';
      });
      item.addEventListener('mouseleave', () => {
        const actions = item.querySelector('.alert-actions');
        if (actions) actions.style.display = 'none';
      });
    });

    // 标记已读
    listEl.querySelectorAll('.mark-read-btn').forEach(btn => {
      btn.addEventListener('click', (e) => {
        e.stopPropagation();
        this.handleMarkRead(btn.dataset.id);
      });
    });

    // 删除
    listEl.querySelectorAll('.delete-alert-btn').forEach(btn => {
      btn.addEventListener('click', (e) => {
        e.stopPropagation();
        this.handleDelete(btn.dataset.id);
      });
    });
  }

  // ===== 标记已读 =====
  async handleMarkRead(id) {
    try {
      await api.put(`/notifications/${id}/read`);
    } catch {}

    const alert = this.alerts.find(a => a.id === id);
    if (alert) alert.read = true;

    // 移除未读样式
    const item = document.querySelector(`.alert-item[data-alert-id="${id}"]`);
    if (item) {
      item.classList.remove('unread');
      item.style.background = '';
      const dot = item.querySelector('span[style*="border-radius: 50%"]');
      if (dot) dot.remove();
      const readBtn = item.querySelector('.mark-read-btn');
      if (readBtn) readBtn.remove();
    }

    this.unreadCount = Math.max(0, this.unreadCount - 1);
    this.updateBadge(this.unreadCount);
  }

  // ===== 全部已读 =====
  async handleMarkAllRead() {
    try {
      await api.post('/notifications/read-all');
    } catch {}

    this.alerts.forEach(a => a.read = true);
    this.unreadCount = 0;
    this.updateBadge(0);
    this.renderAlertList(this.alerts);
    Toast.success('已全部标记为已读');
  }

  // ===== 删除通知 =====
  async handleDelete(id) {
    try {
      await api.delete(`/notifications/${id}`);
    } catch {}

    const item = document.querySelector(`.alert-item[data-alert-id="${id}"]`);
    if (item) {
      item.style.transition = 'all 0.3s ease';
      item.style.opacity = '0';
      item.style.transform = 'translateX(100%)';
      item.style.maxHeight = item.scrollHeight + 'px';
      setTimeout(() => {
        item.style.maxHeight = '0';
        item.style.padding = '0';
        item.style.margin = '0';
        item.style.border = 'none';
      }, 200);
      setTimeout(() => item.remove(), 400);
    }

    const alert = this.alerts.find(a => a.id === id);
    if (alert && !alert.read) {
      this.unreadCount = Math.max(0, this.unreadCount - 1);
      this.updateBadge(this.unreadCount);
    }
    this.alerts = this.alerts.filter(a => a.id !== id);
  }

  // ===== 获取未读数 =====
  async getUnreadCount() {
    try {
      const res = await api.get('/notifications/unread-count');
      this.unreadCount = typeof res === 'number' ? res : (res.count || 0);
    } catch {
      this.unreadCount = this.alerts.filter(a => !a.read).length;
    }
    this.updateBadge(this.unreadCount);
  }

  // ===== 更新Badge =====
  updateBadge(count) {
    const badge = document.getElementById('alerts-badge');
    if (!badge) return;

    if (count > 0) {
      badge.style.display = 'flex';
      badge.textContent = count > 99 ? '99+' : count;
    } else {
      badge.style.display = 'none';
    }

    // 同步更新app内的通知badge
    const appBadge = document.querySelector('#notification-btn .badge');
    if (appBadge) {
      appBadge.textContent = count;
      appBadge.style.display = count > 0 ? '' : 'none';
    }
  }

  // ===== WebSocket新通知 =====
  onNewAlert(data) {
    const newAlert = {
      id: 'ws_' + Date.now(),
      title: data.title || data.payload?.title || '新通知',
      message: data.message || data.payload?.message || '',
      type: data.alert_type || data.payload?.type || 'info',
      created_at: new Date().toISOString(),
      read: false,
    };

    this.alerts.unshift(newAlert);
    this.unreadCount++;
    this.updateBadge(this.unreadCount);

    // 插入到列表顶部
    const listEl = document.getElementById('alerts-list');
    if (listEl) {
      const icons = { info: '💬', warning: '⚠️', critical: '🚨' };
      const div = document.createElement('div');
      div.className = 'alert-item unread';
      div.dataset.alertId = newAlert.id;
      div.style.cssText = 'padding:12px 16px;border-bottom:1px solid #f5f5f5;display:flex;gap:10px;cursor:pointer;background:#f0f8ff;animation:slideIn 0.3s ease';
      div.innerHTML = `
        <div style="font-size:18px;flex-shrink:0;margin-top:2px">${icons[newAlert.type] || '💬'}</div>
        <div style="flex:1;min-width:0">
          <div style="display:flex;justify-content:space-between;align-items:flex-start">
            <span style="font-weight:600;font-size:13px">${escapeHtml(newAlert.title)}</span>
            <span style="width:8px;height:8px;background:#1890ff;border-radius:50%;flex-shrink:0;margin-top:6px;margin-left:8px"></span>
          </div>
          <div style="font-size:12px;color:var(--text-secondary);margin-top:3px">${escapeHtml(newAlert.message)}</div>
          <div style="font-size:11px;color:var(--text-tertiary);margin-top:4px">刚刚</div>
        </div>
      `;
      if (listEl.firstChild) {
        listEl.insertBefore(div, listEl.firstChild);
      } else {
        listEl.appendChild(div);
      }
    }

    Toast.info(newAlert.title);
  }

  // ===== 切换面板 =====
  togglePanel() {
    const panel = document.getElementById('alerts-panel');
    if (!panel) return;
    this.panelVisible = !this.panelVisible;
    panel.style.display = this.panelVisible ? 'block' : 'none';

    if (this.panelVisible) {
      this.loadAlerts();
    }
  }

  // ===== 事件绑定 =====
  _bindEvents() {
    // 铃铛按钮
    document.getElementById('alerts-bell-btn')?.addEventListener('click', () => this.togglePanel());

    // 关闭面板
    document.getElementById('btn-close-alerts-panel')?.addEventListener('click', () => {
      document.getElementById('alerts-panel').style.display = 'none';
      this.panelVisible = false;
    });

    // 全部已读
    document.getElementById('btn-mark-all-read')?.addEventListener('click', () => this.handleMarkAllRead());

    // 点击外部关闭
    document.addEventListener('click', (e) => {
      if (!this.panelVisible) return;
      const panel = document.getElementById('alerts-panel');
      const bell = document.getElementById('alerts-bell-btn');
      if (panel && !panel.contains(e.target) && bell && !bell.contains(e.target)) {
        panel.style.display = 'none';
        this.panelVisible = false;
      }
    });

    // 顶栏通知按钮（如果有）
    document.getElementById('notification-btn')?.addEventListener('click', () => this.togglePanel());
    document.getElementById('mark-all-read')?.addEventListener('click', () => this.handleMarkAllRead());

    // 全页面通知中心按钮
    document.getElementById('btn-mark-all-read-2')?.addEventListener('click', () => {
      this.handleMarkAllRead();
      this._renderFullPage();
    });
    document.getElementById('btn-clear-alerts')?.addEventListener('click', async () => {
      const confirmed = await Modal.confirm('清除全部', '确定要清除所有通知吗？', { danger: true });
      if (!confirmed) return;
      this.alerts = [];
      this.unreadCount = 0;
      this.updateBadge(0);
      this._renderFullPage();
      Toast.success('已清除全部通知');
    });
  }
}
