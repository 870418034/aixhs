/**
 * 内容管理页面 - 小红书AI全自动运营平台
 */
import { api } from './api.js';
import { escapeHtml, formatNumber } from './utils.js';
import { Toast, Modal, Loading, Skeleton, EmptyState } from './components.js';

export default class ContentView {
  constructor(app) {
    this.app = app;
    this.currentPage = 1;
    this.accountFilter = '';
    this.statusFilter = '';
    this.generatorVisible = false;
    this.generatedResult = null;
    this.selectedTitleIndex = 0;
    this.initialized = false;
  }

  async init() {
    if (this.initialized) return;
    this.initialized = true;
    this._render();
    await this.loadAccounts();
    await this.loadContent();
    this._bindEvents();
  }

  _render() {
    const container = document.getElementById('page-content');
    container.innerHTML = `
      <div class="ai-generator-panel" id="ai-generator">
        <div class="ai-generator-header" id="ai-generator-toggle">
          <h3>✨ AI内容生成器</h3>
          <span class="ai-generator-toggle">▼</span>
        </div>
        <div class="ai-generator-body" id="ai-generator-body">
          <div class="generator-form">
            <div class="form-row" style="display:grid;grid-template-columns:1fr 1fr;gap:16px">
              <div class="form-group"><label>目标账号</label><select id="gen-account" class="form-select"></select></div>
              <div class="form-group"><label>内容类型</label>
                <div class="radio-group" style="display:flex;gap:12px;margin-top:4px">
                  <label style="display:flex;align-items:center;gap:4px;cursor:pointer"><input type="radio" name="gen-type" value="image_text" checked> 📝 图文</label>
                  <label style="display:flex;align-items:center;gap:4px;cursor:pointer"><input type="radio" name="gen-type" value="video"> 🎬 视频</label>
                </div>
              </div>
            </div>
            <div class="form-group">
              <label>生成方式</label>
              <div style="display:flex;flex-direction:column;gap:8px;margin-top:4px">
                <label style="display:flex;align-items:center;gap:4px;cursor:pointer"><input type="radio" name="gen-mode" value="topic" checked> 📌 输入主题关键词：<input type="text" id="gen-topic" class="form-input" style="display:inline;width:200px" placeholder="如：秋冬护肤"></label>
                <label style="display:flex;align-items:center;gap:4px;cursor:pointer"><input type="radio" name="gen-mode" value="recommend"> 🎯 AI推荐主题（根据定位自动选择）</label>
                <label style="display:flex;align-items:center;gap:4px;cursor:pointer"><input type="radio" name="gen-mode" value="trending"> 🔥 热点追踪（实时热点+领域匹配）</label>
              </div>
            </div>
            <div class="form-group advanced-settings">
              <details><summary>⚙️ 高级设置</summary>
                <div style="display:grid;grid-template-columns:1fr 1fr;gap:16px;margin-top:12px">
                  <div class="form-group"><label>字数</label><div style="display:flex;align-items:center;gap:8px"><input type="range" id="gen-words" min="300" max="2000" value="800" style="flex:1"><span id="gen-words-val">800字</span></div></div>
                  <div class="form-group"><label>语气</label><select id="gen-tone" class="form-select"><option>活泼亲切</option><option>专业严谨</option><option>幽默风趣</option><option>温柔治愈</option></select></div>
                </div>
              </details>
            </div>
            <div class="form-actions" style="margin-top:16px"><button class="btn btn-primary btn-lg" id="btn-do-generate">🤖 开始生成</button></div>
          </div>
          <div id="gen-progress" class="hidden" style="padding:24px 0">
            <div class="progress-steps" style="display:flex;gap:8px;margin-bottom:16px">
              <div class="step active" data-step="1" style="flex:1;text-align:center;padding:8px;border-radius:6px;background:var(--primary-light);font-size:13px">📖 确定主题</div>
              <div class="step" data-step="2" style="flex:1;text-align:center;padding:8px;border-radius:6px;background:var(--bg-hover);font-size:13px">✍️ 生成标题</div>
              <div class="step" data-step="3" style="flex:1;text-align:center;padding:8px;border-radius:6px;background:var(--bg-hover);font-size:13px">📝 生成正文</div>
              <div class="step" data-step="4" style="flex:1;text-align:center;padding:8px;border-radius:6px;background:var(--bg-hover);font-size:13px">🏷️ 生成标签</div>
              <div class="step" data-step="5" style="flex:1;text-align:center;padding:8px;border-radius:6px;background:var(--bg-hover);font-size:13px">🔍 安全审核</div>
            </div>
            <div class="progress" style="height:6px"><div class="progress-bar" id="gen-progress-fill" style="width:0%"></div></div>
          </div>
          <div id="gen-result" class="hidden"></div>
        </div>
      </div>
      <div class="content-toolbar">
        <div class="content-toolbar-left">
          <select class="form-select" id="cf-status" style="width:120px">
            <option value="">全部状态</option><option value="draft">草稿</option><option value="generated">已生成</option>
            <option value="safety_passed">安全通过</option><option value="published">已发布</option>
          </select>
          <select class="form-select" id="cf-account" style="width:140px"><option value="">全部账号</option></select>
        </div>
        <div class="content-toolbar-right">
          <button class="btn btn-secondary" id="btn-ai-generate">✨ AI生成</button>
        </div>
      </div>
      <div class="content-table-wrapper">
        <table class="data-table" id="content-table">
          <thead><tr><th>封面</th><th>标题</th><th>账号</th><th>状态</th><th>阅读</th><th>点赞</th><th>收藏</th><th>操作</th></tr></thead>
          <tbody id="content-tbody"></tbody>
        </table>
      </div>
      <div id="content-pagination" class="pagination"></div>
    `;
  }

  _bindEvents() {
    // AI生成器折叠
    document.getElementById('ai-generator-toggle')?.addEventListener('click', () => {
      this.generatorVisible = !this.generatorVisible;
      const panel = document.getElementById('ai-generator');
      const body = document.getElementById('ai-generator-body');
      if (body) body.style.display = this.generatorVisible ? 'block' : 'none';
      panel?.classList.toggle('expanded', this.generatorVisible);
    });

    // AI生成按钮
    document.getElementById('btn-ai-generate')?.addEventListener('click', () => {
      this.generatorVisible = true;
      const body = document.getElementById('ai-generator-body');
      if (body) body.style.display = 'block';
      document.getElementById('ai-generator')?.classList.add('expanded');
    });

    // 开始生成
    document.getElementById('btn-do-generate')?.addEventListener('click', () => this.handleGenerate());

    // 字数滑块
    document.getElementById('gen-words')?.addEventListener('input', e => {
      document.getElementById('gen-words-val').textContent = e.target.value + '字';
    });

    // 筛选
    document.getElementById('cf-account')?.addEventListener('change', (e) => {
      this.accountFilter = e.target.value;
      this.currentPage = 1;
      this.loadContent();
    });

    document.getElementById('cf-status')?.addEventListener('change', (e) => {
      this.statusFilter = e.target.value;
      this.currentPage = 1;
      this.loadContent();
    });

    // 事件委托 - 表格和分页中的操作
    document.getElementById('page-content')?.addEventListener('click', (e) => {
      const btn = e.target.closest('[data-action]');
      if (!btn) return;
      const action = btn.dataset.action;
      const id = btn.dataset.id;
      switch (action) {
        case 'publish': this.handlePublish(id); break;
        case 'schedule': this.handleSchedule(id); break;
        case 'detail': this.showDetail(id); break;
      }
    });
  }

  async loadAccounts() {
    try {
      const res = await api.get('/accounts?page=1&size=100');
      const items = res.data?.items || [];
      ['cf-account', 'gen-account'].forEach(id => {
        const sel = document.getElementById(id);
        if (sel) {
          sel.innerHTML = '<option value="">全部账号</option>' + items.map(a => `<option value="${a.id}">${escapeHtml(a.nickname || a.xhs_id || a.id)}</option>`).join('');
        }
      });
    } catch (e) { console.error(e); }
  }

  async loadContent() {
    try {
      let url = `/contents?page=${this.currentPage}&size=20`;
      if (this.accountFilter) url += `&account_id=${this.accountFilter}`;
      if (this.statusFilter) url += `&status=${this.statusFilter}`;
      const res = await api.get(url);
      this.renderTable(res.data?.items || []);
      this.renderPagination(res.data?.total || 0);
    } catch (e) {
      Toast.error('加载内容列表失败');
    }
  }

  renderTable(items) {
    const tbody = document.getElementById('content-tbody');
    if (!items.length) {
      tbody.innerHTML = '<tr><td colspan="8" class="empty-cell" style="text-align:center;padding:40px;color:var(--text-tertiary)">暂无内容</td></tr>';
      return;
    }
    const statusColors = { draft: '#999', generated: '#1890ff', safety_passed: '#52c41a', safety_blocked: '#ff4d4f', scheduled: '#722ed1', published: '#1890ff', removed: '#999' };
    tbody.innerHTML = items.map(c => `
      <tr>
        <td><div class="content-thumb-placeholder">📝</div></td>
        <td class="content-title-cell" style="max-width:300px;font-weight:500;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${escapeHtml(c.title || '未命名')}</td>
        <td>${escapeHtml(c.account_id?.substring(0, 8) || '-')}</td>
        <td><span class="badge" style="background:${statusColors[c.status] || '#999'}">${escapeHtml(c.status)}</span></td>
        <td>${c.views || 0}</td>
        <td>${c.likes || 0}</td>
        <td>${c.collects || 0}</td>
        <td class="actions-cell">
          ${c.status === 'draft' || c.status === 'safety_passed' ? `<button class="btn btn-sm btn-primary" data-action="publish" data-id="${c.id}">发布</button>` : ''}
          ${c.status === 'draft' ? `<button class="btn btn-sm" data-action="schedule" data-id="${c.id}">定时</button>` : ''}
          <button class="btn btn-sm btn-ghost" data-action="detail" data-id="${c.id}">详情</button>
        </td>
      </tr>`).join('');
  }

  renderPagination(total) {
    const pages = Math.ceil(total / 20);
    const el = document.getElementById('content-pagination');
    if (pages <= 1) { el.innerHTML = ''; return; }
    let html = `<button ${this.currentPage <= 1 ? 'disabled' : ''} data-page="${this.currentPage - 1}">上一页</button>`;
    for (let i = 1; i <= pages; i++) html += `<button class="${i === this.currentPage ? 'active' : ''}" data-page="${i}">${i}</button>`;
    html += `<button ${this.currentPage >= pages ? 'disabled' : ''} data-page="${this.currentPage + 1}">下一页</button>`;
    el.innerHTML = html;

    el.querySelectorAll('button[data-page]').forEach(btn => {
      btn.addEventListener('click', () => {
        this.currentPage = +btn.dataset.page;
        this.loadContent();
      });
    });
  }

  toggleGenerator() {
    this.generatorVisible = !this.generatorVisible;
    const body = document.getElementById('ai-generator-body');
    if (body) body.style.display = this.generatorVisible ? 'block' : 'none';
    document.getElementById('ai-generator')?.classList.toggle('expanded', this.generatorVisible);
    document.getElementById('gen-progress')?.classList.add('hidden');
    document.getElementById('gen-result')?.classList.add('hidden');
  }

  async handleGenerate() {
    const accountId = document.getElementById('gen-account')?.value;
    if (!accountId) { Toast.warning('请选择目标账号'); return; }
    const topic = document.getElementById('gen-topic')?.value;
    const mode = document.querySelector('input[name="gen-mode"]:checked')?.value;
    const contentType = document.querySelector('input[name="gen-type"]:checked')?.value;
    const progressEl = document.getElementById('gen-progress');
    const resultEl = document.getElementById('gen-result');
    progressEl?.classList.remove('hidden');
    resultEl?.classList.add('hidden');
    const steps = progressEl?.querySelectorAll('.step');
    const fill = document.getElementById('gen-progress-fill');
    for (let i = 0; i < (steps?.length || 0); i++) {
      steps.forEach((s, idx) => {
        s.classList.toggle('active', idx <= i);
        s.style.background = idx <= i ? 'var(--primary-light)' : 'var(--bg-hover)';
      });
      if (fill) fill.style.width = ((i + 1) / steps.length * 100) + '%';
      await new Promise(r => setTimeout(r, 800));
    }
    try {
      const payload = { account_id: accountId, topic: topic || undefined, content_type: contentType };
      const res = await api.post('/contents/generate', payload);
      this.generatedResult = res.data;
      this.selectedTitleIndex = 0;
      progressEl?.classList.add('hidden');
      resultEl?.classList.remove('hidden');
      this.renderGenerationResult(res.data);
      Toast.success('内容生成完成！');
    } catch (e) {
      progressEl?.classList.add('hidden');
      Toast.error('生成失败: ' + (e.message || '未知错误'));
    }
  }

  renderGenerationResult(data) {
    const el = document.getElementById('gen-result');
    const titles = data.titles || [{ title: data.title, type: '默认' }];
    el.innerHTML = `
      <div style="margin-bottom:16px"><h3>✨ 生成结果</h3></div>
      <div id="title-options">${titles.map((t, i) => `<div class="tag ${i === this.selectedTitleIndex ? 'primary' : ''}" data-title-idx="${i}" style="cursor:pointer;padding:6px 12px;margin:4px;display:inline-block">${t.type ? `<span class="badge" style="font-size:10px;margin-right:4px">${escapeHtml(t.type)}</span> ` : ''}${escapeHtml(t.title)}</div>`).join('')}</div>
      <div class="form-group"><label>正文</label><textarea id="result-body" class="form-textarea" rows="12">${escapeHtml(data.body || '')}</textarea></div>
      <div class="form-group"><label>标签</label><div>${(data.tags || []).map(t => `<span class="tag">${escapeHtml(t)}</span>`).join(' ')}</div></div>
      <div style="border:1px solid var(--border-color);border-radius:12px;padding:16px;margin-bottom:16px;max-width:375px">
        <div style="font-size:12px;color:var(--text-tertiary);margin-bottom:8px">📱 小红书预览</div>
        <div class="preview-title" style="font-weight:600;margin-bottom:8px">${escapeHtml(titles[this.selectedTitleIndex]?.title || '')}</div>
        <div style="font-size:13px;color:var(--text-secondary)">${escapeHtml((data.body || '').substring(0, 200))}...</div>
        <div style="margin-top:8px">${(data.tags || []).slice(0, 3).map(t => `<span style="color:var(--info);font-size:12px;margin-right:8px">#${escapeHtml(t)}</span>`).join('')}</div>
      </div>
      <div style="display:flex;gap:8px;flex-wrap:wrap">
        <button class="btn btn-primary" id="btn-save-draft">💾 保存草稿</button>
        <button class="btn btn-primary" id="btn-publish-gen">▶ 立即发布</button>
        <button class="btn btn-secondary" id="btn-schedule-gen">📅 定时发布</button>
        <button class="btn btn-ghost" id="btn-regen">🔄 重新生成</button>
      </div>`;

    // 标题选择
    el.querySelectorAll('[data-title-idx]').forEach(tag => {
      tag.addEventListener('click', () => {
        this.selectedTitleIndex = +tag.dataset.titleIdx;
        el.querySelectorAll('[data-title-idx]').forEach((t, i) => {
          t.classList.toggle('primary', i === this.selectedTitleIndex);
        });
        const previewTitle = el.querySelector('.preview-title');
        if (previewTitle && this.generatedResult) {
          previewTitle.textContent = this.generatedResult.titles?.[this.selectedTitleIndex]?.title || '';
        }
      });
    });

    el.querySelector('#btn-save-draft')?.addEventListener('click', () => this.handleSaveDraft());
    el.querySelector('#btn-publish-gen')?.addEventListener('click', () => this.handlePublish(this.generatedResult?.id));
    el.querySelector('#btn-schedule-gen')?.addEventListener('click', () => this.handleSchedule(this.generatedResult?.id));
    el.querySelector('#btn-regen')?.addEventListener('click', () => this.handleGenerate());
  }

  async handlePublish(id) {
    if (!id && this.generatedResult?.id) id = this.generatedResult.id;
    if (!id) { Toast.warning('无内容ID'); return; }
    if (!await Modal.confirm('确认发布', '确定要立即发布这篇内容吗？')) return;
    try {
      await api.post(`/contents/${id}/publish`);
      Toast.success('发布成功！');
      this.loadContent();
    } catch (e) { Toast.error('发布失败: ' + e.message); }
  }

  async handleSchedule(id) {
    if (!id && this.generatedResult?.id) id = this.generatedResult.id;
    const time = prompt('请输入发布时间 (YYYY-MM-DD HH:MM):');
    if (!time) return;
    try {
      await api.post(`/contents/${id}/schedule`, { publish_time: time });
      Toast.success('定时发布已设置');
      this.loadContent();
    } catch (e) { Toast.error('设置失败: ' + e.message); }
  }

  async handleSaveDraft() {
    if (!this.generatedResult?.id) return;
    const body = document.getElementById('result-body')?.value;
    try {
      await api.put(`/contents/${this.generatedResult.id}`, { body });
      Toast.success('已保存');
    } catch (e) { Toast.error('保存失败'); }
  }

  async showDetail(id) {
    try {
      const res = await api.get(`/contents/${id}`);
      const c = res.data || res;
      Modal.show({
        title: '内容详情',
        content: `<div style="margin-bottom:12px"><strong>标题:</strong> ${escapeHtml(c.title || '')}</div>
          <div style="margin-bottom:12px"><strong>正文:</strong><pre style="white-space:pre-wrap;margin-top:4px;padding:8px;background:var(--bg-hover);border-radius:6px;font-size:13px">${escapeHtml(c.body || '')}</pre></div>
          <div style="margin-bottom:8px"><strong>状态:</strong> ${escapeHtml(c.status || '')}</div>
          <div><strong>阅读:</strong> ${c.views || 0} | <strong>点赞:</strong> ${c.likes || 0} | <strong>收藏:</strong> ${c.collects || 0}</div>`,
        width: 'lg'
      });
    } catch (e) { Toast.error('加载详情失败'); }
  }
}
