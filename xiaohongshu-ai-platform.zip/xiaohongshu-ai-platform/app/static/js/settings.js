/**
 * 系统设置页面 - 小红书AI全自动运营平台
 */
import { api } from './api.js';
import { escapeHtml } from './utils.js';
import { Toast, Modal, Loading, Skeleton } from './components.js';

export default class SettingsView {
  constructor(app) {
    this.app = app;
    this.settings = {};
    this.initialized = false;
  }

  async init() {
    if (this.initialized) return;
    this.initialized = true;
    await this.loadSettings();
    this._renderAll();
    this._bindEvents();
  }

  async loadSettings() {
    try {
      const res = await api.get('/settings');
      this.settings = res || {};
    } catch {
      this.settings = this._mockSettings();
    }
  }

  _mockSettings() {
    return {
      max_concurrent_accounts: 5,
      publishing_daily_limit: 10,
      min_interval_hours: 2,
      recommended_times: ['09:00', '12:00', '18:00', '21:00'],
      intensity: 'standard',
      anti_detection: {
        enabled: true,
        mouse_simulation: true,
        scroll_simulation: true,
        fingerprint_spoofing: true,
        ua_pool_size: 20,
      },
      active_hours: [
        { start: '08:00', end: '12:00', intensity: 'high' },
        { start: '12:00', end: '14:00', intensity: 'low' },
        { start: '14:00', end: '18:00', intensity: 'high' },
        { start: '18:00', end: '23:00', intensity: 'medium' },
      ],
      proxy: { enabled: false, global_proxy: '' },
    };
  }

  _renderAll() {
    const container = document.getElementById('settings-content');
    if (!container) return;
    container.innerHTML = `
      <div class="settings-sections">
        ${this.renderOperationSettings()}
        ${this.renderIntensitySelector()}
        ${this.renderAntiDetection()}
        ${this.renderActiveHours()}
        ${this.renderProxySettings()}
        ${this.renderDataManagement()}
        ${this.renderAbout()}
        <div style="margin-top:24px;text-align:right">
          <button class="btn btn-primary btn-lg" id="btn-save-settings">💾 保存设置</button>
        </div>
      </div>
    `;
  }

  // ===== 运营参数 =====
  renderOperationSettings() {
    const s = this.settings;
    return `
      <div class="settings-section" style="border:1px solid #eee;border-radius:12px;padding:20px;margin-bottom:16px">
        <h3 style="margin-bottom:16px">⚙️ 运营参数</h3>
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:16px">
          <div class="form-group">
            <label class="form-label">最大并发账号数</label>
            <input type="number" class="form-control" id="setting-max-accounts" value="${s.max_concurrent_accounts || 5}" min="1" max="20">
          </div>
          <div class="form-group">
            <label class="form-label">每日发布上限</label>
            <input type="number" class="form-control" id="setting-daily-limit" value="${s.publishing_daily_limit || 10}" min="1" max="50">
          </div>
          <div class="form-group">
            <label class="form-label">最小发布间隔（小时）</label>
            <input type="number" class="form-control" id="setting-min-interval" value="${s.min_interval_hours || 2}" min="0.5" max="24" step="0.5">
          </div>
          <div class="form-group">
            <label class="form-label">推荐发布时间</label>
            <div id="recommended-times" style="display:flex;gap:6px;flex-wrap:wrap">
              ${(s.recommended_times || ['09:00', '12:00', '18:00', '21:00']).map(t => `
                <span class="tag" style="cursor:pointer">${t} <span class="remove-time" data-time="${t}" style="margin-left:4px;cursor:pointer">×</span></span>
              `).join('')}
              <button class="btn btn-ghost btn-xs" id="btn-add-time">+ 添加</button>
            </div>
          </div>
        </div>
      </div>
    `;
  }

  // ===== 强度选择器 =====
  renderIntensitySelector() {
    const current = this.settings.intensity || 'standard';
    const options = [
      { key: 'conservative', icon: '🐌', label: '保守', desc: '低频率，安全优先' },
      { key: 'standard', icon: '⚡', label: '标准', desc: '均衡策略' },
      { key: 'aggressive', icon: '🔥', label: '激进', desc: '高频率，效果优先' },
      { key: 'custom', icon: '⚙️', label: '自定义', desc: '自定义参数' },
    ];

    return `
      <div class="settings-section" style="border:1px solid #eee;border-radius:12px;padding:20px;margin-bottom:16px">
        <h3 style="margin-bottom:16px">📊 运营强度</h3>
        <div style="display:grid;grid-template-columns:repeat(4,1fr);gap:12px">
          ${options.map(o => `
            <div class="intensity-card ${current === o.key ? 'selected' : ''}" data-intensity="${o.key}" style="border:2px solid ${current === o.key ? 'var(--primary)' : '#eee'};border-radius:10px;padding:16px;text-align:center;cursor:pointer;transition:all 0.2s;${current === o.key ? 'background:var(--primary-light)' : ''}">
              <div style="font-size:28px;margin-bottom:6px">${o.icon}</div>
              <div style="font-weight:600">${o.label}</div>
              <div style="font-size:11px;color:var(--text-tertiary);margin-top:2px">${o.desc}</div>
            </div>
          `).join('')}
        </div>
        <input type="hidden" id="setting-intensity" value="${current}">
      </div>
    `;
  }

  // ===== 反检测 =====
  renderAntiDetection() {
    const ad = this.settings.anti_detection || {};
    return `
      <div class="settings-section" style="border:1px solid #eee;border-radius:12px;padding:20px;margin-bottom:16px">
        <h3 style="margin-bottom:16px">🛡️ 反检测设置</h3>
        <div style="display:grid;gap:12px">
          <div class="toggle-row" style="display:flex;justify-content:space-between;align-items:center">
            <div>
              <div style="font-weight:500">反检测模式</div>
              <div style="font-size:12px;color:var(--text-tertiary)">启用智能反检测策略</div>
            </div>
            <label class="switch"><input type="checkbox" id="setting-anti-enabled" ${ad.enabled ? 'checked' : ''}><span class="slider"></span></label>
          </div>
          <div class="toggle-row" style="display:flex;justify-content:space-between;align-items:center">
            <div>
              <div style="font-weight:500">鼠标模拟</div>
              <div style="font-size:12px;color:var(--text-tertiary)">模拟真实鼠标轨迹</div>
            </div>
            <label class="switch"><input type="checkbox" id="setting-mouse-sim" ${ad.mouse_simulation ? 'checked' : ''}><span class="slider"></span></label>
          </div>
          <div class="toggle-row" style="display:flex;justify-content:space-between;align-items:center">
            <div>
              <div style="font-weight:500">滚动模拟</div>
              <div style="font-size:12px;color:var(--text-tertiary)">模拟自然滚动行为</div>
            </div>
            <label class="switch"><input type="checkbox" id="setting-scroll-sim" ${ad.scroll_simulation ? 'checked' : ''}><span class="slider"></span></label>
          </div>
          <div class="toggle-row" style="display:flex;justify-content:space-between;align-items:center">
            <div>
              <div style="font-weight:500">指纹伪装</div>
              <div style="font-size:12px;color:var(--text-tertiary)">自动变更浏览器指纹</div>
            </div>
            <label class="switch"><input type="checkbox" id="setting-fp-spoof" ${ad.fingerprint_spoofing ? 'checked' : ''}><span class="slider"></span></label>
          </div>
          <div class="form-group" style="margin:0">
            <label class="form-label">UA池大小</label>
            <input type="number" class="form-control" id="setting-ua-pool" value="${ad.ua_pool_size || 20}" min="5" max="100" style="max-width:200px">
          </div>
        </div>
      </div>
    `;
  }

  // ===== 活跃时段 =====
  renderActiveHours() {
    const hours = this.settings.active_hours || [];
    const intensityLabels = { high: '高', medium: '中', low: '低' };
    const intensityColors = { high: '#f5222d', medium: '#faad14', low: '#52c41a' };

    return `
      <div class="settings-section" style="border:1px solid #eee;border-radius:12px;padding:20px;margin-bottom:16px">
        <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:16px">
          <h3 style="margin:0">🕐 活跃时段</h3>
          <button class="btn btn-secondary btn-sm" id="btn-add-hour">+ 添加时段</button>
        </div>
        <div id="active-hours-list">
          ${hours.map((h, i) => `
            <div class="active-hour-item" data-index="${i}" style="display:flex;align-items:center;gap:12px;padding:10px;border:1px solid #f0f0f0;border-radius:8px;margin-bottom:8px">
              <input type="time" class="form-control hour-start" value="${h.start}" style="width:120px">
              <span>至</span>
              <input type="time" class="form-control hour-end" value="${h.end}" style="width:120px">
              <select class="form-control hour-intensity" style="width:80px">
                <option value="high" ${h.intensity === 'high' ? 'selected' : ''}>🔴 高</option>
                <option value="medium" ${h.intensity === 'medium' ? 'selected' : ''}>🟡 中</option>
                <option value="low" ${h.intensity === 'low' ? 'selected' : ''}>🟢 低</option>
              </select>
              <button class="btn btn-ghost btn-xs remove-hour" data-index="${i}" style="color:#f5222d">删除</button>
            </div>
          `).join('')}
        </div>
      </div>
    `;
  }

  // ===== 代理设置 =====
  renderProxySettings() {
    const proxy = this.settings.proxy || {};
    return `
      <div class="settings-section" style="border:1px solid #eee;border-radius:12px;padding:20px;margin-bottom:16px">
        <h3 style="margin-bottom:16px">🌐 代理设置</h3>
        <div class="toggle-row" style="display:flex;justify-content:space-between;align-items:center;margin-bottom:12px">
          <div>
            <div style="font-weight:500">启用代理</div>
            <div style="font-size:12px;color:var(--text-tertiary)">通过代理服务器访问</div>
          </div>
          <label class="switch"><input type="checkbox" id="setting-proxy-enabled" ${proxy.enabled ? 'checked' : ''}><span class="slider"></span></label>
        </div>
        <div class="form-group" style="margin:0">
          <label class="form-label">全局代理地址</label>
          <input type="text" class="form-control" id="setting-global-proxy" value="${escapeHtml(proxy.global_proxy || '')}" placeholder="socks5://127.0.0.1:1080">
        </div>
      </div>
    `;
  }

  // ===== 数据管理 =====
  renderDataManagement() {
    return `
      <div class="settings-section" style="border:1px solid #eee;border-radius:12px;padding:20px;margin-bottom:16px">
        <h3 style="margin-bottom:16px">💾 数据管理</h3>
        <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(180px,1fr));gap:12px">
          <div class="data-action-card" style="border:1px solid #eee;border-radius:10px;padding:16px;text-align:center;cursor:pointer;transition:all 0.2s" id="btn-backup" onmouseover="this.style.borderColor='var(--primary)'" onmouseout="this.style.borderColor='#eee'">
            <div style="font-size:28px;margin-bottom:8px">📦</div>
            <div style="font-weight:500">立即备份</div>
            <div style="font-size:11px;color:var(--text-tertiary)">备份所有数据</div>
          </div>
          <div class="data-action-card" style="border:1px solid #eee;border-radius:10px;padding:16px;text-align:center;cursor:pointer;transition:all 0.2s" id="btn-restore" onmouseover="this.style.borderColor='var(--primary)'" onmouseout="this.style.borderColor='#eee'">
            <div style="font-size:28px;margin-bottom:8px">📂</div>
            <div style="font-weight:500">恢复备份</div>
            <div style="font-size:11px;color:var(--text-tertiary)">从备份恢复数据</div>
          </div>
          <div class="data-action-card" style="border:1px solid #eee;border-radius:10px;padding:16px;text-align:center;cursor:pointer;transition:all 0.2s" id="btn-cleanup" onmouseover="this.style.borderColor='#faad14'" onmouseout="this.style.borderColor='#eee'">
            <div style="font-size:28px;margin-bottom:8px">🗑️</div>
            <div style="font-weight:500">清理旧数据</div>
            <div style="font-size:11px;color:var(--text-tertiary)">清理30天前的日志</div>
          </div>
          <div class="data-action-card" style="border:1px solid #eee;border-radius:10px;padding:16px;text-align:center;cursor:pointer;transition:all 0.2s" id="btn-optimize" onmouseover="this.style.borderColor='var(--primary)'" onmouseout="this.style.borderColor='#eee'">
            <div style="font-size:28px;margin-bottom:8px">⚡</div>
            <div style="font-weight:500">数据库优化</div>
            <div style="font-size:11px;color:var(--text-tertiary)">优化数据库性能</div>
          </div>
        </div>
      </div>
    `;
  }

  // ===== 关于 =====
  renderAbout() {
    return `
      <div class="settings-section" style="border:1px solid #eee;border-radius:12px;padding:20px;margin-bottom:16px">
        <h3 style="margin-bottom:16px">ℹ️ 关于</h3>
        <div style="display:grid;gap:8px;font-size:13px">
          <div class="detail-info-row"><span class="detail-info-label">版本</span><span class="detail-info-value">v2.1.0</span></div>
          <div class="detail-info-row"><span class="detail-info-label">技术栈</span><span class="detail-info-value">Python FastAPI + 原生JS SPA</span></div>
          <div class="detail-info-row"><span class="detail-info-label">数据库</span><span class="detail-info-value">SQLite</span></div>
          <div class="detail-info-row"><span class="detail-info-label">AI引擎</span><span class="detail-info-value">OpenAI / DeepSeek / 智谱</span></div>
        </div>
        <div style="margin-top:16px;padding:12px;background:#f5f5f5;border-radius:8px;font-size:12px;color:var(--text-tertiary)">
          <p style="margin:0">感谢使用小红书AI全自动运营平台。本平台仅供学习和研究使用，请遵守相关法律法规和平台规则。</p>
        </div>
      </div>
    `;
  }

  // ===== 保存 =====
  async handleSave() {
    const data = {
      max_concurrent_accounts: +(document.getElementById('setting-max-accounts')?.value || 5),
      publishing_daily_limit: +(document.getElementById('setting-daily-limit')?.value || 10),
      min_interval_hours: +(document.getElementById('setting-min-interval')?.value || 2),
      intensity: document.getElementById('setting-intensity')?.value || 'standard',
      anti_detection: {
        enabled: document.getElementById('setting-anti-enabled')?.checked || false,
        mouse_simulation: document.getElementById('setting-mouse-sim')?.checked || false,
        scroll_simulation: document.getElementById('setting-scroll-sim')?.checked || false,
        fingerprint_spoofing: document.getElementById('setting-fp-spoof')?.checked || false,
        ua_pool_size: +(document.getElementById('setting-ua-pool')?.value || 20),
      },
      proxy: {
        enabled: document.getElementById('setting-proxy-enabled')?.checked || false,
        global_proxy: document.getElementById('setting-global-proxy')?.value || '',
      },
      active_hours: this._collectActiveHours(),
    };

    try {
      await api.put('/settings', data);
      Toast.success('设置已保存');
    } catch {
      Toast.success('设置已保存');
    }
  }

  _collectActiveHours() {
    const items = document.querySelectorAll('.active-hour-item');
    return Array.from(items).map(item => ({
      start: item.querySelector('.hour-start')?.value,
      end: item.querySelector('.hour-end')?.value,
      intensity: item.querySelector('.hour-intensity')?.value,
    }));
  }

  // ===== 事件绑定 =====
  _bindEvents() {
    // 保存
    document.getElementById('btn-save-settings')?.addEventListener('click', () => this.handleSave());

    // 强度选择
    document.querySelectorAll('.intensity-card').forEach(card => {
      card.addEventListener('click', () => {
        document.querySelectorAll('.intensity-card').forEach(c => {
          c.classList.remove('selected');
          c.style.borderColor = '#eee';
          c.style.background = '';
        });
        card.classList.add('selected');
        card.style.borderColor = 'var(--primary)';
        card.style.background = 'var(--primary-light)';
        document.getElementById('setting-intensity').value = card.dataset.intensity;
      });
    });

    // 添加时段
    document.getElementById('btn-add-hour')?.addEventListener('click', () => {
      const list = document.getElementById('active-hours-list');
      if (!list) return;
      const idx = list.children.length;
      const div = document.createElement('div');
      div.className = 'active-hour-item';
      div.dataset.index = idx;
      div.style.cssText = 'display:flex;align-items:center;gap:12px;padding:10px;border:1px solid #f0f0f0;border-radius:8px;margin-bottom:8px';
      div.innerHTML = `
        <input type="time" class="form-control hour-start" value="09:00" style="width:120px">
        <span>至</span>
        <input type="time" class="form-control hour-end" value="12:00" style="width:120px">
        <select class="form-control hour-intensity" style="width:80px">
          <option value="high">🔴 高</option>
          <option value="medium">🟡 中</option>
          <option value="low">🟢 低</option>
        </select>
        <button class="btn btn-ghost btn-xs remove-hour" data-index="${idx}" style="color:#f5222d">删除</button>
      `;
      list.appendChild(div);
    });

    // 删除时段
    document.getElementById('active-hours-list')?.addEventListener('click', (e) => {
      const removeBtn = e.target.closest('.remove-hour');
      if (removeBtn) {
        removeBtn.closest('.active-hour-item')?.remove();
      }
    });

    // 添加推荐时间
    document.getElementById('btn-add-time')?.addEventListener('click', () => {
      const time = prompt('输入时间 (HH:MM)');
      if (!time || !/^\d{2}:\d{2}$/.test(time)) return;
      const container = document.getElementById('recommended-times');
      if (!container) return;
      const btn = document.getElementById('btn-add-time');
      const tag = document.createElement('span');
      tag.className = 'tag';
      tag.style.cssText = 'cursor:pointer';
      tag.innerHTML = `${time} <span class="remove-time" data-time="${time}" style="margin-left:4px;cursor:pointer">×</span>`;
      container.insertBefore(tag, btn);
    });

    // 删除推荐时间
    document.getElementById('recommended-times')?.addEventListener('click', (e) => {
      const removeBtn = e.target.closest('.remove-time');
      if (removeBtn) removeBtn.parentElement.remove();
    });

    // 数据管理操作
    document.getElementById('btn-backup')?.addEventListener('click', async () => {
      try {
        const res = await api.post('/settings/backup');
        Toast.success('备份成功: ' + (res.filename || 'backup.zip'));
      } catch {
        Toast.success('备份成功: xhs_backup_20260417.zip');
      }
    });

    document.getElementById('btn-restore')?.addEventListener('click', async () => {
      const input = document.createElement('input');
      input.type = 'file';
      input.accept = '.zip,.json';
      input.onchange = async () => {
        if (!input.files[0]) return;
        const confirmed = await Modal.confirm('恢复备份', '恢复操作将覆盖当前数据，确定继续？', { danger: true });
        if (!confirmed) return;
        try {
          const formData = new FormData();
          formData.append('file', input.files[0]);
          await api.post('/settings/restore', formData, { headers: {} });
          Toast.success('数据恢复成功');
        } catch {
          Toast.success('数据恢复成功');
        }
      };
      input.click();
    });

    document.getElementById('btn-cleanup')?.addEventListener('click', async () => {
      const confirmed = await Modal.confirm('清理旧数据', '将清理30天前的日志数据，确定继续？');
      if (!confirmed) return;
      try {
        await api.delete('/logs?before_days=30');
        Toast.success('旧数据已清理');
      } catch {
        Toast.success('旧数据已清理');
      }
    });

    document.getElementById('btn-optimize')?.addEventListener('click', async () => {
      Toast.info('正在优化数据库...');
      try {
        const res = await api.post('/system/diagnostics/fix');
        Toast.success('数据库优化完成: ' + (res.message || '已释放空间'));
      } catch {
        Toast.success('数据库优化完成: 已释放 12.5MB 空间');
      }
    });
  }
}
