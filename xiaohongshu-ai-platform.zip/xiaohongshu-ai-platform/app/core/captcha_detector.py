"""验证码检测与处理。"""

from __future__ import annotations

import random
import time
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Tuple

from app.core.logger import get_logger

logger = get_logger(__name__)


@dataclass
class CaptchaResult:
    """验证码检测结果。"""
    detected: bool = False
    captcha_type: str = ""  # slider / image_select / sms / none
    position: Dict[str, int] = field(default_factory=dict)
    screenshot: Optional[bytes] = None
    details: Dict[str, Any] = field(default_factory=dict)


class CaptchaDetector:
    """验证码检测与处理。"""

    # 验证码选择器
    CAPTCHA_SELECTORS = {
        "slider": [
            "div.captcha-slider",
            "div[class*='slider']",
            "div.geetest_slider_button",
            ".slide-btn",
            ".captcha-slider-btn",
        ],
        "image_select": [
            "div.captcha-img-select",
            "div[class*='captcha-img']",
            ".geetest_widget",
        ],
        "sms": [
            "div.sms-captcha",
            "input[name='smsCode']",
        ],
    }

    async def detect(self, page: Any) -> CaptchaResult:
        """检测页面上的验证码。
        page: Playwright Page 对象
        """
        if page is None:
            return CaptchaResult()

        result = CaptchaResult()

        try:
            # 检测滑块验证码
            for sel in self.CAPTCHA_SELECTORS["slider"]:
                try:
                    elem = page.locator(sel)
                    if await elem.count() > 0 and await elem.is_visible():
                        bbox = await elem.bounding_box()
                        result.detected = True
                        result.captcha_type = "slider"
                        if bbox:
                            result.position = {
                                "x": int(bbox["x"]),
                                "y": int(bbox["y"]),
                                "width": int(bbox["width"]),
                                "height": int(bbox["height"]),
                            }
                        # 截图
                        try:
                            result.screenshot = await page.screenshot(type="png")
                        except Exception:
                            pass
                        logger.info(f"检测到滑块验证码: {sel}")
                        return result
                except Exception:
                    continue

            # 检测图片选择验证码
            for sel in self.CAPTCHA_SELECTORS["image_select"]:
                try:
                    elem = page.locator(sel)
                    if await elem.count() > 0 and await elem.is_visible():
                        result.detected = True
                        result.captcha_type = "image_select"
                        try:
                            result.screenshot = await page.screenshot(type="png")
                        except Exception:
                            pass
                        logger.info(f"检测到图片选择验证码: {sel}")
                        return result
                except Exception:
                    continue

            # 检测短信验证码
            for sel in self.CAPTCHA_SELECTORS["sms"]:
                try:
                    elem = page.locator(sel)
                    if await elem.count() > 0 and await elem.is_visible():
                        result.detected = True
                        result.captcha_type = "sms"
                        logger.info(f"检测到短信验证码: {sel}")
                        return result
                except Exception:
                    continue

            # 通用检测：检查页面文字
            try:
                body_text = await page.inner_text("body")
                if "请拖动滑块" in body_text or "验证通过" in body_text or "安全验证" in body_text:
                    result.detected = True
                    result.captcha_type = "slider"
                    try:
                        result.screenshot = await page.screenshot(type="png")
                    except Exception:
                        pass
            except Exception:
                pass

        except Exception as e:
            logger.error(f"验证码检测异常: {e}")

        return result

    def generate_slider_track(self, width: int) -> List[Tuple[int, int, float]]:
        """生成滑块拖拽轨迹。
        模式：起步快 → 匀速 → 减速 → 回弹
        返回 [(x, y, timestamp)] 列表。
        """
        track: List[Tuple[int, int, float]] = []
        base_time = time.time()

        # 随机化总距离（不是完全到位）
        actual_width = int(width * random.uniform(0.92, 1.0))
        total_time = random.uniform(0.8, 2.0)  # 800ms - 2000ms

        # 阶段划分
        phase1_end = int(actual_width * 0.3)  # 起步快
        phase2_end = int(actual_width * 0.7)  # 匀速
        phase3_end = int(actual_width * 0.95)  # 减速
        # 最后 5% 回弹

        x = 0
        t = 0.0

        # Phase 1: 起步快 (0-30%)
        steps1 = max(5, int(phase1_end / 8))
        for i in range(steps1):
            progress = i / steps1
            x = int(phase1_end * progress)
            t = total_time * 0.15 * progress
            track.append((x, random.randint(-1, 1), base_time + t))
            x += random.randint(5, 10)

        # Phase 2: 匀速 (30-70%)
        steps2 = max(10, int((phase2_end - phase1_end) / 5))
        for i in range(steps2):
            progress = i / steps2
            x = phase1_end + int((phase2_end - phase1_end) * progress)
            t = total_time * 0.15 + total_time * 0.45 * progress
            track.append((x, random.randint(-1, 1), base_time + t))
            x += random.randint(3, 7)

        # Phase 3: 减速 (70-95%)
        steps3 = max(8, int((phase3_end - phase2_end) / 4))
        for i in range(steps3):
            progress = i / steps3
            eased = 1 - (1 - progress) ** 2  # ease-out
            x = phase2_end + int((phase3_end - phase2_end) * eased)
            t = total_time * 0.6 + total_time * 0.3 * progress
            track.append((x, random.randint(-1, 1), base_time + t))

        # Phase 4: 回弹到目标
        steps4 = random.randint(3, 8)
        for i in range(steps4):
            progress = i / steps4
            x = phase3_end + int((actual_width - phase3_end) * progress)
            t = total_time * 0.9 + total_time * 0.1 * progress
            track.append((x, random.randint(-1, 1), base_time + t))

        # 最终位置
        track.append((actual_width, 0, base_time + total_time))

        return track

    async def handle_slider(self, page: Any, track: List[Tuple[int, int, float]]) -> bool:
        """执行滑块拖拽操作。
        page: Playwright Page 对象
        track: generate_slider_track 生成的轨迹
        """
        if page is None or not track:
            return False

        try:
            # 找到滑块按钮
            slider_selectors = [
                "div.captcha-slider",
                "div[class*='slider']",
                "div.geetest_slider_button",
                ".slide-btn",
                ".captcha-slider-btn",
            ]

            slider_elem = None
            for sel in slider_selectors:
                try:
                    elem = page.locator(sel)
                    if await elem.count() > 0:
                        slider_elem = elem
                        break
                except Exception:
                    continue

            if slider_elem is None:
                logger.warning("未找到滑块元素")
                return False

            bbox = await slider_elem.bounding_box()
            if bbox is None:
                return False

            start_x = bbox["x"] + bbox["width"] / 2
            start_y = bbox["y"] + bbox["height"] / 2

            # 执行拖拽
            await page.mouse.move(start_x, start_y)
            await page.mouse.down()

            for x_offset, y_offset, _ in track:
                target_x = start_x + x_offset
                target_y = start_y + y_offset
                await page.mouse.move(target_x, target_y)
                await page.wait_for_timeout(random.randint(10, 30))

            await page.mouse.up()

            # 等待验证结果
            await page.wait_for_timeout(1000)

            # 检查是否成功
            try:
                body_text = await page.inner_text("body")
                if "验证通过" in body_text or "验证成功" in body_text:
                    logger.info("滑块验证成功")
                    return True
            except Exception:
                pass

            # 再检查验证码是否消失
            for sel in slider_selectors:
                try:
                    elem = page.locator(sel)
                    if await elem.count() == 0 or not await elem.is_visible():
                        logger.info("滑块验证码已消失，可能验证成功")
                        return True
                except Exception:
                    continue

            logger.warning("滑块验证可能失败")
            return False

        except Exception as e:
            logger.error(f"滑块处理异常: {e}")
            return False

    async def notify_user(
        self,
        account_id: str,
        captcha_type: str,
        screenshot: Optional[bytes] = None,
    ) -> None:
        """通知用户需要处理验证码。"""
        logger.warning(
            f"账号 {account_id} 触发 {captcha_type} 验证码，需要人工处理"
        )
        # 实际实现中可发送 WebSocket 通知或写入通知表
        try:
            from app.database import get_db_session
            from app.models import Notification
            async with get_db_session() as session:
                notification = Notification(
                    level="warning",
                    title="验证码需要处理",
                    message=f"账号 {account_id} 触发了 {captcha_type} 验证码，请手动处理",
                    account_id=account_id,
                    related_type="captcha",
                )
                session.add(notification)
                await session.commit()
        except Exception as e:
            logger.error(f"创建验证码通知失败: {e}")


# 全局实例
captcha_detector = CaptchaDetector()
