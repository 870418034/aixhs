"""实时风控监控。"""

from __future__ import annotations

import time
from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Dict, List, Optional

from app.core.logger import get_logger

logger = get_logger(__name__)


@dataclass
class RiskSignal:
    """风控信号。"""
    signal_type: str  # captcha / warning / expired / rate_limit / page_error / content_deleted
    severity: str = "medium"  # low / medium / high / critical
    message: str = ""
    details: Dict[str, Any] = field(default_factory=dict)
    timestamp: float = field(default_factory=time.time)


class RiskMonitor:
    """实时风控监控器。"""

    def __init__(self) -> None:
        self._risk_events: Dict[str, List[RiskSignal]] = {}
        self._account_baseline: Dict[str, Dict[str, int]] = {}

    async def scan_page(self, page: Any) -> List[RiskSignal]:
        """扫描页面中的风控信号。
        page: Playwright Page 对象
        """
        signals: List[RiskSignal] = []
        if page is None:
            return signals

        try:
            # 检查验证码弹窗
            captcha_selectors = [
                "div.captcha-container",
                "div[class*='captcha']",
                "div[class*='verify']",
                "div[class*='slider']",
                "#captcha",
                ".geetest_holder",
            ]
            for sel in captcha_selectors:
                try:
                    elem = page.locator(sel)
                    if await elem.count() > 0 and await elem.is_visible():
                        signals.append(RiskSignal(
                            signal_type="captcha",
                            severity="high",
                            message=f"检测到验证码弹窗: {sel}",
                        ))
                        break
                except Exception:
                    continue

            # 检查风险警告
            warning_texts = ["账号异常", "操作频繁", "存在风险", "暂时限制", "账号被封"]
            try:
                body_text = await page.inner_text("body")
                for wt in warning_texts:
                    if wt in body_text:
                        signals.append(RiskSignal(
                            signal_type="warning",
                            severity="high",
                            message=f"检测到风险警告: {wt}",
                        ))
            except Exception:
                pass

            # 检查登录过期
            login_indicators = ["请先登录", "登录已过期", "重新登录", "login"]
            try:
                body_text = await page.inner_text("body")
                for li in login_indicators:
                    if li in body_text:
                        signals.append(RiskSignal(
                            signal_type="expired",
                            severity="critical",
                            message="登录已过期",
                        ))
                        break
            except Exception:
                pass

            # 检查限流
            rate_limit_texts = ["请求过于频繁", "请稍后再试", "操作太频繁"]
            try:
                body_text = await page.inner_text("body")
                for rl in rate_limit_texts:
                    if rl in body_text:
                        signals.append(RiskSignal(
                            signal_type="rate_limit",
                            severity="medium",
                            message=f"检测到限流提示: {rl}",
                        ))
            except Exception:
                pass

            # 检查页面错误
            try:
                error_elem = page.locator(".error-page, .not-found, [class*='error']")
                if await error_elem.count() > 0:
                    signals.append(RiskSignal(
                        signal_type="page_error",
                        severity="medium",
                        message="页面错误",
                    ))
            except Exception:
                pass

            # 检查内容被删
            deleted_texts = ["笔记不存在", "内容已被删除", "该笔记已下架"]
            try:
                body_text = await page.inner_text("body")
                for dt in deleted_texts:
                    if dt in body_text:
                        signals.append(RiskSignal(
                            signal_type="content_deleted",
                            severity="low",
                            message="内容已被删除",
                        ))
            except Exception:
                pass

        except Exception as e:
            logger.error(f"页面扫描异常: {e}")

        return signals

    def check_account_signals(self, account_id: str) -> List[RiskSignal]:
        """检查账号级风控信号（粉丝突降、笔记减少等）。"""
        signals: List[RiskSignal] = []

        # 检查历史风控事件
        events = self._risk_events.get(account_id, [])
        recent_cutoff = time.time() - 3600  # 最近 1 小时
        recent_events = [e for e in events if e.timestamp > recent_cutoff]

        if len(recent_events) > 5:
            signals.append(RiskSignal(
                signal_type="warning",
                severity="high",
                message=f"最近 1 小时内触发 {len(recent_events)} 次风控",
            ))

        # 检查连续验证码
        captcha_events = [e for e in recent_events if e.signal_type == "captcha"]
        if len(captcha_events) >= 3:
            signals.append(RiskSignal(
                signal_type="captcha",
                severity="critical",
                message="连续触发验证码，建议暂停操作",
            ))

        return signals

    def determine_response(self, signals: List[RiskSignal]) -> str:
        """根据信号确定响应策略。
        返回: pause / stop / retry / reduce
        """
        if not signals:
            return "continue"

        # 按严重程度排序
        severity_order = {"critical": 4, "high": 3, "medium": 2, "low": 1}
        max_severity = max(severity_order.get(s.severity, 0) for s in signals)
        signal_types = {s.signal_type for s in signals}

        if "expired" in signal_types:
            return "stop"
        if "captcha" in signal_types and max_severity >= 4:
            return "pause"
        if "captcha" in signal_types:
            return "pause"
        if max_severity >= 3:
            return "reduce"
        if "rate_limit" in signal_types:
            return "retry"
        if "content_deleted" in signal_types:
            return "continue"
        return "continue"

    def record_risk_event(self, account_id: str, event: RiskSignal) -> None:
        """记录风控事件。"""
        if account_id not in self._risk_events:
            self._risk_events[account_id] = []
        self._risk_events[account_id].append(event)

        # 保留最近 7 天的事件
        cutoff = time.time() - 7 * 86400
        self._risk_events[account_id] = [
            e for e in self._risk_events[account_id] if e.timestamp > cutoff
        ]

        logger.info(
            f"风控事件记录: 账号={account_id}, "
            f"类型={event.signal_type}, 严重度={event.severity}, "
            f"信息={event.message}"
        )

    def get_account_risk_summary(self, account_id: str) -> Dict[str, Any]:
        """获取账号风控摘要。"""
        events = self._risk_events.get(account_id, [])
        recent_24h = [e for e in events if e.timestamp > time.time() - 86400]
        return {
            "total_events": len(events),
            "events_24h": len(recent_24h),
            "captcha_count": sum(1 for e in recent_24h if e.signal_type == "captcha"),
            "warning_count": sum(1 for e in recent_24h if e.signal_type == "warning"),
            "last_event": events[-1].signal_type if events else None,
            "last_event_time": datetime.fromtimestamp(events[-1].timestamp).isoformat() if events else None,
        }


# 全局实例
risk_monitor = RiskMonitor()
