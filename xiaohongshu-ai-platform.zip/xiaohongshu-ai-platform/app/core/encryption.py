"""Fernet 对称加密，用于 Cookie / API Key 加密存储。"""

from __future__ import annotations

import os
from pathlib import Path
from typing import Optional

from cryptography.fernet import Fernet

from app.core.logger import get_logger

logger = get_logger(__name__)

KEY_PATH = Path("data/encryption.key")


def generate_key() -> bytes:
    """生成 Fernet 密钥并保存到文件。"""
    KEY_PATH.parent.mkdir(parents=True, exist_ok=True)
    key = Fernet.generate_key()
    KEY_PATH.write_bytes(key)
    os.chmod(KEY_PATH, 0o600)
    logger.info(f"加密密钥已生成: {KEY_PATH}")
    return key


def load_key() -> bytes:
    """加载密钥，不存在则自动生成。"""
    if not KEY_PATH.exists():
        return generate_key()
    return KEY_PATH.read_bytes()


class Encryptor:
    """Fernet 加密器单例。"""

    _instance: Optional["Encryptor"] = None
    _fernet: Fernet

    def __new__(cls) -> "Encryptor":
        if cls._instance is None:
            cls._instance = super().__new__(cls)
            cls._instance._fernet = Fernet(load_key())
        return cls._instance

    @property
    def fernet(self) -> Fernet:
        return self._fernet

    def encrypt(self, data: str) -> str:
        """加密字符串，返回 base64 编码的密文。"""
        if not data:
            return ""
        return self._fernet.encrypt(data.encode("utf-8")).decode("utf-8")

    def decrypt(self, data: str) -> str:
        """解密字符串。"""
        if not data:
            return ""
        return self._fernet.decrypt(data.encode("utf-8")).decode("utf-8")


# 全局 encryptor 单例
encryptor = Encryptor()


def encrypt(data: str) -> str:
    return encryptor.encrypt(data)


def decrypt(data: str) -> str:
    return encryptor.decrypt(data)
