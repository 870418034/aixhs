"""浏览器指纹伪装。"""

from __future__ import annotations

import json
import random
import string
from typing import Any, Dict, List, Optional

from app.core.logger import get_logger

logger = get_logger(__name__)


# 8 种常见屏幕分辨率
SCREEN_RESOLUTIONS = [
    (1920, 1080),
    (1366, 768),
    (1536, 864),
    (1440, 900),
    (1280, 720),
    (2560, 1440),
    (1600, 900),
    (1280, 1024),
]

# WebGL renderer / vendor 组合 (7 renderers + 3 vendors)
WEBGL_RENDERERS = [
    "ANGLE (Intel(R) UHD Graphics 630 Direct3D11 vs_5_0 ps_5_0)",
    "ANGLE (NVIDIA GeForce GTX 1660 Direct3D11 vs_5_0 ps_5_0)",
    "ANGLE (Intel(R) Iris(R) Plus Graphics 640 Direct3D11 vs_5_0 ps_5_0)",
    "ANGLE (AMD Radeon RX 580 Direct3D11 vs_5_0 ps_5_0)",
    "ANGLE (Intel(R) HD Graphics 620 Direct3D11 vs_5_0 ps_5_0)",
    "ANGLE (NVIDIA GeForce RTX 3060 Direct3D11 vs_5_0 ps_5_0)",
    "ANGLE (Intel(R) UHD Graphics 620 Direct3D11 vs_5_0 ps_5_0)",
]

WEBGL_VENDORS = [
    "Google Inc. (Intel)",
    "Google Inc. (NVIDIA)",
    "Google Inc. (AMD)",
]

# User-Agent 模板
UA_TEMPLATES = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/{chrome_ver} Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/{chrome_ver} Safari/537.36 Edg/{edge_ver}",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/{chrome_ver} Safari/537.36",
]

CHROME_VERSIONS = ["120.0.6099.109", "121.0.6167.85", "122.0.6261.94", "123.0.6312.58"]
EDGE_VERSIONS = ["120.0.2210.91", "121.0.2277.83", "122.0.2365.52"]

# 浏览器插件列表
COMMON_PLUGINS = [
    {"name": "PDF Viewer", "filename": "internal-pdf-viewer", "description": "Portable Document Format"},
    {"name": "Chrome PDF Viewer", "filename": "mhjfbmdgcfjbbpaeojofohoefgiehjai", "description": "Portable Document Format"},
    {"name": "Chromium PDF Viewer", "filename": "internal-pdf-viewer", "description": "Portable Document Format"},
]


class FingerprintSpoof:
    """浏览器指纹伪装器。"""

    def __init__(self) -> None:
        self._current: Optional[Dict[str, Any]] = None

    def generate_fingerprint(self) -> Dict[str, Any]:
        """生成一套随机但一致的浏览器指纹。"""
        # 屏幕
        screen_w, screen_h = random.choice(SCREEN_RESOLUTIONS)

        # WebGL
        renderer = random.choice(WEBGL_RENDERERS)
        vendor = random.choice(WEBGL_VENDORS)

        # UA
        ua_template = random.choice(UA_TEMPLATES)
        chrome_ver = random.choice(CHROME_VERSIONS)
        edge_ver = random.choice(EDGE_VERSIONS)
        ua = ua_template.format(chrome_ver=chrome_ver, edge_ver=edge_ver)

        # 硬件
        hardware_concurrency = random.choice([4, 8, 12, 16])
        device_memory = random.choice([4, 8, 16, 32])

        # Canvas 种子
        canvas_seed = "".join(random.choices(string.ascii_letters + string.digits, k=16))

        # 插件（随机选 2-4 个）
        plugins = random.sample(COMMON_PLUGINS, min(len(COMMON_PLUGINS), random.randint(2, 4)))

        fingerprint = {
            "user_agent": ua,
            "platform": "Win32" if "Windows" in ua else "MacIntel",
            "hardware_concurrency": hardware_concurrency,
            "device_memory": device_memory,
            "plugins": plugins,
            "screen": {
                "width": screen_w,
                "height": screen_h,
                "avail_width": screen_w,
                "avail_height": screen_h - random.randint(30, 80),
                "color_depth": random.choice([24, 32]),
                "pixel_ratio": random.choice([1.0, 1.25, 1.5, 2.0]),
            },
            "webgl": {
                "renderer": renderer,
                "vendor": vendor,
            },
            "canvas_seed": canvas_seed,
            "audio_context": {
                "sample_rate": random.choice([44100, 48000]),
                "channel_count": 2,
            },
            "webrtc": {
                "mode": random.choice(["disabled", "fake"]),
                "fake_ip": f"{random.randint(10,254)}.{random.randint(0,255)}.{random.randint(0,255)}.{random.randint(1,254)}",
            },
        }

        self._current = fingerprint
        return fingerprint

    def get_injection_script(self) -> str:
        """生成用于 Playwright add_init_script 的 JavaScript 代码。"""
        if self._current is None:
            self.generate_fingerprint()

        fp = self._current
        screen_info = fp["screen"]
        webgl_info = fp["webgl"]
        canvas_seed = fp["canvas_seed"]
        audio_info = fp["audio_context"]
        webrtc_info = fp["webrtc"]

        plugins_json = json.dumps(fp["plugins"])
        ua = fp["user_agent"]
        platform = fp["platform"]
        hw_concurrency = fp["hardware_concurrency"]
        device_memory = fp["device_memory"]

        script = f"""
        // === 浏览器指纹伪装 ===

        // User-Agent
        Object.defineProperty(navigator, 'userAgent', {{
            get: () => '{ua}'
        }});
        Object.defineProperty(navigator, 'platform', {{
            get: () => '{platform}'
        }});

        // 硬件
        Object.defineProperty(navigator, 'hardwareConcurrency', {{
            get: () => {hw_concurrency}
        }});
        Object.defineProperty(navigator, 'deviceMemory', {{
            get: () => {device_memory}
        }});

        // 屏幕
        Object.defineProperty(screen, 'width', {{ get: () => {screen_info['width']} }});
        Object.defineProperty(screen, 'height', {{ get: () => {screen_info['height']} }});
        Object.defineProperty(screen, 'availWidth', {{ get: () => {screen_info['avail_width']} }});
        Object.defineProperty(screen, 'availHeight', {{ get: () => {screen_info['avail_height']} }});
        Object.defineProperty(screen, 'colorDepth', {{ get: () => {screen_info['color_depth']} }});
        Object.defineProperty(window, 'devicePixelRatio', {{ get: () => {screen_info['pixel_ratio']} }});

        // 插件
        const makePluginArray = () => {{
            const arr = [];
            const plugins = {plugins_json};
            plugins.forEach(p => {{
                const plugin = {{ name: p.name, filename: p.filename, description: p.description }};
                plugin.length = 0;
                arr.push(plugin);
            }});
            arr.item = (i) => arr[i] || null;
            arr.namedItem = (n) => arr.find(p => p.name === n) || null;
            arr.refresh = () => {{}};
            return arr;
        }};
        Object.defineProperty(navigator, 'plugins', {{
            get: () => makePluginArray()
        }});

        // WebGL
        const origGetExtension = WebGLRenderingContext.prototype.getExtension;
        WebGLRenderingContext.prototype.getExtension = function(name) {{
            if (name === 'WEBGL_debug_renderer_info') {{
                return {{
                    UNMASKED_VENDOR_WEBGL: 0x9245,
                    UNMASKED_RENDERER_WEBGL: 0x9246
                }};
            }}
            return origGetExtension.call(this, name);
        }};
        const origGetParameter = WebGLRenderingContext.prototype.getParameter;
        WebGLRenderingContext.prototype.getParameter = function(param) {{
            if (param === 0x9245) return '{webgl_info['vendor']}';
            if (param === 0x9246) return '{webgl_info['renderer']}';
            return origGetParameter.call(this, param);
        }};

        // Canvas 指纹干扰
        const origToDataURL = HTMLCanvasElement.prototype.toDataURL;
        HTMLCanvasElement.prototype.toDataURL = function() {{
            const ctx = this.getContext('2d');
            if (ctx) {{
                ctx.fillStyle = 'rgba(255,255,255,0.01)';
                ctx.fillRect(0, 0, 1, 1);
            }}
            return origToDataURL.apply(this, arguments);
        }};

        // AudioContext 指纹干扰
        const origCreateOscillator = AudioContext.prototype.createOscillator;
        AudioContext.prototype.createOscillator = function() {{
            const osc = origCreateOscillator.call(this);
            const origConnect = osc.connect.bind(osc);
            osc.connect = function(dest) {{
                if (dest instanceof AnalyserNode) {{
                    // 添加微小噪声
                    const gain = osc.context.createGain();
                    gain.gain.value = 0.0001;
                    origConnect(gain);
                    gain.connect(dest);
                    return dest;
                }}
                return origConnect(dest);
            }};
            return osc;
        }};

        // WebRTC 泄露防护
        if (typeof RTCPeerConnection !== 'undefined') {{
            const origRTC = RTCPeerConnection;
            window.RTCPeerConnection = function(config, constraints) {{
                if (config && config.iceServers) {{
                    config.iceServers = [];
                }}
                return new origRTC(config, constraints);
            }};
            window.RTCPeerConnection.prototype = origRTC.prototype;
        }}

        // 语言
        Object.defineProperty(navigator, 'languages', {{
            get: () => ['zh-CN', 'zh', 'en']
        }});
        Object.defineProperty(navigator, 'language', {{
            get: () => 'zh-CN'
        }});

        // Permissions 干扰
        const origQuery = Permissions.prototype.query;
        Permissions.prototype.query = function(desc) {{
            if (desc.name === 'notifications') {{
                return Promise.resolve({{ state: 'prompt' }});
            }}
            return origQuery.call(this, desc);
        }};
        """
        return script

    @property
    def current(self) -> Optional[Dict[str, Any]]:
        return self._current


# 全局实例
fingerprint_spoof = FingerprintSpoof()
