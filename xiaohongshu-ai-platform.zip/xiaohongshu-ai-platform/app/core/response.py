"""统一响应格式工具函数。"""

from __future__ import annotations

from typing import Any, Dict, List, Optional

from app.core.exceptions import BusinessError


def success(data: Any = None, message: str = "success") -> Dict[str, Any]:
    """成功响应。"""
    return {"code": 200, "message": message, "data": data}


def error(code: int, message: str, status_code: int = 400) -> None:
    """错误响应，抛出 BusinessError（由 GlobalExceptionMiddleware 捕获）。"""
    raise BusinessError(code=code, message=message, status_code=status_code)


def paginated(
    items: List[Any],
    total: int,
    page: int,
    page_size: int,
) -> Dict[str, Any]:
    """分页响应。"""
    return {
        "code": 200,
        "message": "success",
        "data": {
            "items": items,
            "total": total,
            "page": page,
            "page_size": page_size,
        },
    }
