"""敏感词库管理，基于 Aho-Corasick 自动机。"""

from __future__ import annotations

from pathlib import Path
from typing import Dict, List, Optional, Set, Tuple

try:
    import ahocorasick
except ImportError:
    ahocorasick = None  # type: ignore[assignment,misc]

from app.core.logger import get_logger

logger = get_logger(__name__)


# 词库分类
WORD_CATEGORIES = [
    "political",
    "sexual",
    "violent",
    "medical",
    "financial",
    "drainage",
]


class SensitiveWordManager:
    """敏感词管理器，使用 Aho-Corasick 自动机。"""

    _instance: Optional["SensitiveWordManager"] = None

    def __new__(cls) -> "SensitiveWordManager":
        if cls._instance is None:
            cls._instance = super().__new__(cls)
            cls._instance._automaton = None
            cls._instance._words: Dict[str, str] = {}  # word -> category
            cls._instance._loaded = False
        return cls._instance

    def _build_automaton(self) -> None:
        """构建 Aho-Corasick 自动机。"""
        if ahocorasick is None:
            logger.warning("pyahocorasick 未安装，敏感词检测将使用简单匹配")
            return
        automaton = ahocorasick.Automaton()
        for word, category in self._words.items():
            automaton.add_word(word, (category, word))
        automaton.make_automaton()
        self._automaton = automaton

    def load_words(self, file_path: str | Path) -> int:
        """从文件加载词库。文件格式：每行一个词，可用 | 分隔词和分类。
        例：敏感词|political
        """
        path = Path(file_path)
        if not path.exists():
            logger.warning(f"敏感词文件不存在: {file_path}")
            return 0

        count = 0
        with open(path, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line or line.startswith("#"):
                    continue
                parts = line.split("|", 1)
                word = parts[0].strip()
                category = parts[1].strip() if len(parts) > 1 else "political"
                if word and category in WORD_CATEGORIES:
                    self._words[word] = category
                    count += 1

        self._build_automaton()
        self._loaded = True
        logger.info(f"加载敏感词 {count} 个，来自 {file_path}")
        return count

    def add_custom_words(self, words: Dict[str, str] | List[Tuple[str, str]]) -> int:
        """添加自定义词。格式：{word: category} 或 [(word, category)]。"""
        count = 0
        if isinstance(words, dict):
            items = words.items()
        else:
            items = words

        for word, category in items:
            if category in WORD_CATEGORIES:
                self._words[word] = category
                count += 1

        self._build_automaton()
        logger.info(f"添加自定义敏感词 {count} 个")
        return count

    def check(self, text: str) -> List[Dict[str, str]]:
        """检查文本中的敏感词，返回命中的词列表。
        返回格式：[{"word": "...", "category": "...", "position": int}]
        """
        if not text:
            return []

        results: List[Dict[str, str]] = []
        seen: Set[str] = set()

        if self._automaton is not None and ahocorasick is not None:
            for end_index, (category, word) in self._automaton.iter(text):
                if word not in seen:
                    seen.add(word)
                    start_index = end_index - len(word) + 1
                    results.append({
                        "word": word,
                        "category": category,
                        "position": start_index,
                    })
        else:
            # 回退到简单匹配
            for word, category in self._words.items():
                pos = text.find(word)
                if pos != -1 and word not in seen:
                    seen.add(word)
                    results.append({
                        "word": word,
                        "category": category,
                        "position": pos,
                    })

        return results

    def get_stats(self) -> Dict[str, int]:
        """获取词库统计。"""
        stats: Dict[str, int] = {cat: 0 for cat in WORD_CATEGORIES}
        for category in self._words.values():
            stats[category] = stats.get(category, 0) + 1
        stats["total"] = len(self._words)
        return stats


# 全局实例
sensitive_word_manager = SensitiveWordManager()
