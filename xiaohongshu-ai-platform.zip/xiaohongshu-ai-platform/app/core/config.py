"""核心配置常量 — 兼容层，为旧版 service 提供 settings.PROMPT_DIR 等常量。"""

from __future__ import annotations

import os
from pathlib import Path

from app.config import get_config

_config = get_config()


class _Settings:
    """兼容旧代码的 settings 对象。"""

    # 目录常量
    DATA_DIR = "data"
    PROMPT_DIR = "prompts"
    IMAGE_DIR = "data/materials"
    SCREENSHOT_DIR = "data/screenshots"
    EXPORT_DIR = "data/exports"
    LOG_DIR = "data/logs"
    BROWSER_DATA_DIR = "data/browser"

    # 浏览器
    PLAYWRIGHT_HEADLESS = True
    PLAYWRIGHT_SLOW_MO = 50
    PLAYWRIGHT_TIMEOUT = 30000
    VIEWPORT_WIDTH = 1280
    VIEWPORT_HEIGHT = 800

    # AI
    DEFAULT_AI_MODEL = "gpt-4o"
    AI_MAX_TOKENS = 4096
    AI_TEMPERATURE = 0.7
    AI_TIMEOUT = 60

    # 运营
    MIN_PUBLISH_INTERVAL_HOURS = 4
    MAX_PUBLISHES_PER_DAY = 3
    PREFERRED_TIMES = ["09:00", "12:00", "19:00"]

    # 安全
    CONTENT_SAFETY_ENABLED = True
    SAFETY_OVERALL_THRESHOLD = 0.7

    @classmethod
    def from_config(cls):
        """从 AppConfig 覆盖默认值。"""
        c = get_config()
        cls.PLAYWRIGHT_HEADLESS = c.browser.headless
        cls.PLAYWRIGHT_SLOW_MO = c.browser.slow_mo_ms
        cls.PLAYWRIGHT_TIMEOUT = c.browser.default_timeout_ms
        cls.VIEWPORT_WIDTH = c.browser.viewport_width
        cls.VIEWPORT_HEIGHT = c.browser.viewport_height
        cls.BROWSER_DATA_DIR = c.browser.user_data_dir
        cls.DEFAULT_AI_MODEL = c.ai.default_model
        cls.AI_MAX_TOKENS = c.ai.max_content_tokens
        cls.AI_TEMPERATURE = 0.7
        cls.MIN_PUBLISH_INTERVAL_HOURS = c.operation.publishing.min_interval_hours
        cls.MAX_PUBLISHES_PER_DAY = c.operation.publishing.max_per_day
        cls.PREFERRED_TIMES = c.operation.publishing.preferred_times
        cls.CONTENT_SAFETY_ENABLED = c.content_safety.enabled
        cls.SAFETY_OVERALL_THRESHOLD = c.content_safety.thresholds.overall
        cls.LOG_DIR = str(Path(c.logging.file).parent)
        return cls


# 确保目录存在
for _d in [_Settings.DATA_DIR, _Settings.PROMPT_DIR, _Settings.IMAGE_DIR,
           _Settings.SCREENSHOT_DIR, _Settings.EXPORT_DIR, _Settings.LOG_DIR,
           _Settings.BROWSER_DATA_DIR]:
    Path(_d).mkdir(parents=True, exist_ok=True)

settings = _Settings.from_config()
