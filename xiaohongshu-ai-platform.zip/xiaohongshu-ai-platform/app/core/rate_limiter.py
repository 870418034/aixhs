"""滑动窗口频率限制，三层：全局 > 账号 > 操作类型。"""

from __future__ import annotations

import math
import random
import time
from collections import defaultdict
from datetime import datetime
from typing import Dict, List, Optional, Tuple

from app.core.logger import get_logger

logger = get_logger(__name__)


# 操作间延迟矩阵 (from_action, to_action) -> (min_delay, max_delay, distribution)
DELAY_MATRIX: Dict[Tuple[str, str], Tuple[float, float, str]] = {
    ("browse", "like"): (2.0, 6.0, "normal"),
    ("browse", "collect"): (1.5, 5.0, "normal"),
    ("browse", "comment"): (8.0, 25.0, "normal"),
    ("browse", "follow"): (3.0, 10.0, "uniform"),
    ("like", "like"): (3.0, 10.0, "uniform"),
    ("like", "collect"): (2.0, 5.0, "uniform"),
    ("like", "comment"): (8.0, 20.0, "normal"),
    ("collect", "like"): (2.0, 6.0, "uniform"),
    ("collect", "collect"): (3.0, 8.0, "uniform"),
    ("comment", "browse"): (5.0, 15.0, "normal"),
    ("comment", "like"): (3.0, 8.0, "uniform"),
    ("follow", "browse"): (3.0, 10.0, "uniform"),
    ("publish", "publish"): (3600.0, 7200.0, "uniform"),
}

# 时段权重 (hour -> weight)
TIME_WEIGHTS: Dict[int, float] = {}
for h in range(0, 8):
    TIME_WEIGHTS[h] = 0.0  # 禁止
for h in range(8, 9):
    TIME_WEIGHTS[h] = 0.3  # 低频
for h in range(9, 12):
    TIME_WEIGHTS[h] = 1.0  # 高频
for h in range(12, 14):
    TIME_WEIGHTS[h] = 0.5  # 低频
for h in range(14, 17):
    TIME_WEIGHTS[h] = 1.0  # 高频
for h in range(17, 19):
    TIME_WEIGHTS[h] = 0.5  # 低频
for h in range(19, 23):
    TIME_WEIGHTS[h] = 1.0  # 高频
for h in range(23, 24):
    TIME_WEIGHTS[h] = 0.3  # 低频


class RateLimiter:
    """滑动窗口频率限制器。"""

    def __init__(
        self,
        global_window_size: int = 60,
        account_window_size: int = 3600,
        action_window_size: int = 600,
    ) -> None:
        self._global_window = global_window_size
        self._account_window = account_window_size
        self._action_window = action_window_size

        # 滑动窗口：key -> list[timestamp]
        self._global_actions: List[float] = []
        self._account_actions: Dict[str, List[float]] = defaultdict(list)
        self._action_counts: Dict[str, Dict[str, List[float]]] = defaultdict(lambda: defaultdict(list))

        # 每日上限
        self._daily_limits: Dict[str, int] = {
            "browse": 60,
            "like": 50,
            "collect": 30,
            "comment": 15,
            "follow": 10,
            "publish": 3,
        }

        # 每日计数
        self._daily_counts: Dict[str, Dict[str, int]] = defaultdict(lambda: defaultdict(int))
        self._daily_reset_date: Optional[str] = None

    def _clean_window(self, timestamps: List[float], window: int) -> List[float]:
        """清理过期的时间戳。"""
        now = time.time()
        cutoff = now - window
        return [t for t in timestamps if t > cutoff]

    def _check_daily_reset(self) -> None:
        today = datetime.now().strftime("%Y-%m-%d")
        if self._daily_reset_date != today:
            self._daily_counts.clear()
            self._daily_reset_date = today

    def is_allowed(self, account_id: str, action: str) -> Tuple[bool, float]:
        """检查是否允许操作。返回 (allowed, wait_seconds)。"""
        now = time.time()

        # 检查时段
        hour = datetime.now().hour
        weight = TIME_WEIGHTS.get(hour, 0.0)
        if weight == 0.0:
            return False, 3600.0  # 禁止时段

        # 周末权重
        weekday = datetime.now().weekday()
        weekend_factor = 1.3 if weekday >= 5 else 1.0

        # 全局限制
        self._global_actions = self._clean_window(self._global_actions, self._global_window)
        if len(self._global_actions) >= 30:  # 全局每分钟不超过30个操作
            oldest = self._global_actions[0]
            wait = (oldest + self._global_window) - now
            return False, max(wait, 1.0)

        # 账号限制
        acc_actions = self._clean_window(self._account_actions[account_id], self._account_window)
        if len(acc_actions) >= 200:  # 每小时每账号不超过200操作
            oldest = acc_actions[0]
            wait = (oldest + self._account_window) - now
            return False, max(wait, 1.0)

        # 操作类型限制
        act_actions = self._clean_window(
            self._action_counts[account_id][action], self._action_window
        )
        action_limits = {
            "browse": 60,
            "like": 30,
            "collect": 20,
            "comment": 10,
            "follow": 5,
            "publish": 2,
        }
        limit = int(action_limits.get(action, 10) * weight / weekend_factor)
        if len(act_actions) >= limit and limit > 0:
            oldest = act_actions[0]
            wait = (oldest + self._action_window) - now
            return False, max(wait, 1.0)

        # 每日上限
        self._check_daily_reset()
        daily_limit = self._daily_limits.get(action, 999)
        if self._daily_counts[account_id][action] >= daily_limit:
            return False, 3600.0

        return True, 0.0

    def record_action(self, account_id: str, action: str) -> None:
        """记录一次操作。"""
        now = time.time()
        self._global_actions.append(now)
        self._account_actions[account_id].append(now)
        self._action_counts[account_id][action].append(now)
        self._check_daily_reset()
        self._daily_counts[account_id][action] += 1

    def get_delay(self, action_from: str, action_to: str) -> float:
        """获取操作间延迟（秒）。"""
        key = (action_from, action_to)
        if key in DELAY_MATRIX:
            min_d, max_d, dist = DELAY_MATRIX[key]
            if dist == "normal":
                # 正态分布，均值=(min+max)/2，标准差=(max-min)/4
                mean = (min_d + max_d) / 2
                std = (max_d - min_d) / 4
                delay = random.gauss(mean, std)
                return max(min_d, min(max_d, delay))
            else:
                return random.uniform(min_d, max_d)
        # 默认延迟
        return random.uniform(2.0, 8.0)

    def get_daily_stats(self, account_id: str) -> Dict[str, int]:
        """获取账号今日操作统计。"""
        self._check_daily_reset()
        return dict(self._daily_counts.get(account_id, {}))

    def set_daily_limit(self, action: str, limit: int) -> None:
        """设置每日上限。"""
        self._daily_limits[action] = limit


# 全局实例
rate_limiter = RateLimiter()
