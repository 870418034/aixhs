"""自定义异常体系。"""

from __future__ import annotations


class BusinessError(Exception):
    """业务异常基类。"""

    def __init__(self, code: int, message: str, status_code: int = 400) -> None:
        self.code = code
        self.message = message
        self.status_code = status_code
        super().__init__(message)


# ---------------------------------------------------------------------------
# Account 异常 (2000+)
# ---------------------------------------------------------------------------


class AccountNotFoundError(BusinessError):
    def __init__(self, message: str = "账号不存在"):
        super().__init__(code=2001, message=message, status_code=404)


class AccountOfflineError(BusinessError):
    def __init__(self, message: str = "账号不在线"):
        super().__init__(code=2002, message=message, status_code=400)


class AccountBannedError(BusinessError):
    def __init__(self, message: str = "账号已被封禁"):
        super().__init__(code=2003, message=message, status_code=403)


class AccountHealthLowError(BusinessError):
    def __init__(self, message: str = "账号健康度过低"):
        super().__init__(code=2004, message=message, status_code=400)


class AccountExistsError(BusinessError):
    def __init__(self, message: str = "账号已存在"):
        super().__init__(code=2005, message=message, status_code=409)


# ---------------------------------------------------------------------------
# Content 异常 (3000+)
# ---------------------------------------------------------------------------


class ContentNotFoundError(BusinessError):
    def __init__(self, message: str = "内容不存在"):
        super().__init__(code=3001, message=message, status_code=404)


class ContentGenerateError(BusinessError):
    def __init__(self, message: str = "内容生成失败"):
        super().__init__(code=3002, message=message, status_code=500)


class ContentSafetyBlockedError(BusinessError):
    def __init__(self, message: str = "内容未通过安全审核"):
        super().__init__(code=3003, message=message, status_code=400)


class ContentPublishError(BusinessError):
    def __init__(self, message: str = "内容发布失败"):
        super().__init__(code=3004, message=message, status_code=500)


# ---------------------------------------------------------------------------
# Task 异常 (4000+)
# ---------------------------------------------------------------------------


class TaskNotFoundError(BusinessError):
    def __init__(self, message: str = "任务不存在"):
        super().__init__(code=4001, message=message, status_code=404)


class TaskRunningError(BusinessError):
    def __init__(self, message: str = "任务正在运行"):
        super().__init__(code=4002, message=message, status_code=400)


class TaskMaxRetriesError(BusinessError):
    def __init__(self, message: str = "任务已达最大重试次数"):
        super().__init__(code=4003, message=message, status_code=400)


class TaskDependencyError(BusinessError):
    def __init__(self, message: str = "任务依赖未满足"):
        super().__init__(code=4004, message=message, status_code=400)


# ---------------------------------------------------------------------------
# AI 异常 (5000+)
# ---------------------------------------------------------------------------


class AIConfigNotFoundError(BusinessError):
    def __init__(self, message: str = "AI配置不存在"):
        super().__init__(code=5001, message=message, status_code=404)


class AIServiceError(BusinessError):
    def __init__(self, message: str = "AI服务调用失败"):
        super().__init__(code=5002, message=message, status_code=502)


class AITimeoutError(BusinessError):
    def __init__(self, message: str = "AI服务超时"):
        super().__init__(code=5003, message=message, status_code=504)


class AIRateLimitError(BusinessError):
    def __init__(self, message: str = "AI服务频率限制"):
        super().__init__(code=5004, message=message, status_code=429)


class AITokenBudgetError(BusinessError):
    def __init__(self, message: str = "AI Token 预算不足"):
        super().__init__(code=5005, message=message, status_code=400)


# ---------------------------------------------------------------------------
# Browser 异常 (6000+)
# ---------------------------------------------------------------------------


class BrowserError(BusinessError):
    def __init__(self, message: str = "浏览器操作失败"):
        super().__init__(code=6001, message=message, status_code=500)


class BrowserPoolExhaustedError(BusinessError):
    def __init__(self, message: str = "浏览器实例池已耗尽"):
        super().__init__(code=6002, message=message, status_code=503)


class CaptchaDetectedError(BusinessError):
    def __init__(self, message: str = "检测到验证码"):
        super().__init__(code=6003, message=message, status_code=400)


class CookieExpiredError(BusinessError):
    def __init__(self, message: str = "Cookie已过期"):
        super().__init__(code=6004, message=message, status_code=401)


# ---------------------------------------------------------------------------
# 限流 & 反检测 异常 (7000+)
# ---------------------------------------------------------------------------


class RateLimitError(BusinessError):
    def __init__(self, message: str = "请求频率超限"):
        super().__init__(code=7001, message=message, status_code=429)


class AntiDetectionError(BusinessError):
    def __init__(self, message: str = "触发反检测机制"):
        super().__init__(code=7002, message=message, status_code=403)


# ---------------------------------------------------------------------------
# 系统异常 (9000+)
# ---------------------------------------------------------------------------


class SystemError(BusinessError):
    def __init__(self, message: str = "系统错误"):
        super().__init__(code=9001, message=message, status_code=500)


class ConfigError(BusinessError):
    def __init__(self, message: str = "配置错误"):
        super().__init__(code=9002, message=message, status_code=500)
