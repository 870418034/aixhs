"""多账号浏览器实例池。"""

from __future__ import annotations

import json
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional

from app.core.logger import get_logger

logger = get_logger(__name__)


@dataclass
class BrowserContext:
    """浏览器上下文封装。"""
    context: Any = None  # Playwright BrowserContext
    page: Any = None  # Playwright Page
    fingerprint: Dict[str, Any] = field(default_factory=dict)
    last_used: float = field(default_factory=time.time)
    account_id: str = ""


class BrowserPool:
    """多账号浏览器实例池，LRU 淘汰。"""

    def __init__(self, max_contexts: int = 5) -> None:
        self._max_contexts = max_contexts
        self._contexts: Dict[str, BrowserContext] = {}
        self._browser: Any = None  # Playwright Browser
        self._playwright: Any = None  # Playwright instance
        self._initialized: bool = False

    async def _ensure_browser(self) -> None:
        """确保浏览器已启动。"""
        if self._initialized:
            return
        try:
            from playwright.async_api import async_playwright
            self._playwright = await async_playwright().start()
            self._browser = await self._playwright.chromium.launch(
                headless=True,
                args=[
                    "--disable-blink-features=AutomationControlled",
                    "--no-sandbox",
                    "--disable-setuid-sandbox",
                    "--disable-dev-shm-usage",
                ],
            )
            self._initialized = True
            logger.info("浏览器已启动")
        except Exception as e:
            logger.error(f"浏览器启动失败: {e}")
            raise

    async def acquire(self, account_id: str) -> BrowserContext:
        """获取或创建浏览器上下文。LRU 淘汰最久未使用的。"""
        await self._ensure_browser()

        if account_id in self._contexts:
            ctx = self._contexts[account_id]
            ctx.last_used = time.time()
            return ctx

        # 超过最大数量时淘汰
        if len(self._contexts) >= self._max_contexts:
            await self._evict_lru()

        return await self.get_or_create(account_id)

    async def _evict_lru(self) -> None:
        """淘汰最久未使用的上下文。"""
        if not self._contexts:
            return

        lru_account = min(self._contexts, key=lambda k: self._contexts[k].last_used)
        logger.info(f"淘汰浏览器上下文: {lru_account}")
        await self.release(lru_account)

    async def get_or_create(self, account_id: str) -> BrowserContext:
        """获取或创建上下文。"""
        await self._ensure_browser()

        if account_id in self._contexts:
            ctx = self._contexts[account_id]
            ctx.last_used = time.time()
            return ctx

        # 生成指纹
        from app.core.fingerprint_spoof import fingerprint_spoof
        fingerprint = fingerprint_spoof.generate_fingerprint()

        # 创建上下文
        screen = fingerprint.get("screen", {})
        viewport_width = screen.get("width", 1280)
        viewport_height = screen.get("height", 800)

        context = await self._browser.new_context(
            viewport={"width": viewport_width, "height": viewport_height},
            user_agent=fingerprint.get("user_agent", ""),
            locale="zh-CN",
            timezone_id="Asia/Shanghai",
        )

        # 注入指纹伪装脚本
        injection_script = fingerprint_spoof.get_injection_script()
        await context.add_init_script(injection_script)

        # 创建页面
        page = await context.new_page()
        page.set_default_timeout(30000)

        browser_ctx = BrowserContext(
            context=context,
            page=page,
            fingerprint=fingerprint,
            last_used=time.time(),
            account_id=account_id,
        )

        self._contexts[account_id] = browser_ctx
        logger.info(f"创建浏览器上下文: 账号={account_id}, UA={fingerprint.get('user_agent', '')[:50]}...")

        # 加载已有 Cookie
        await self._load_cookies(account_id, context)

        return browser_ctx

    async def release(self, account_id: str) -> None:
        """保存 Cookie 并释放上下文。"""
        if account_id not in self._contexts:
            return

        ctx = self._contexts.pop(account_id)

        # 保存 Cookie
        try:
            if ctx.context:
                await self.save_cookies(account_id)
                await ctx.context.close()
        except Exception as e:
            logger.warning(f"关闭浏览器上下文异常: {e}")

        logger.info(f"释放浏览器上下文: {account_id}")

    async def save_cookies(self, account_id: str) -> None:
        """保存 Cookie 到加密文件。"""
        if account_id not in self._contexts:
            return

        ctx = self._contexts[account_id]
        try:
            cookies = await ctx.context.cookies()

            # 加密保存
            from app.core.encryption import encrypt
            cookie_dir = Path("data/cookies")
            cookie_dir.mkdir(parents=True, exist_ok=True)
            cookie_file = cookie_dir / f"{account_id}.json"

            encrypted = encrypt(json.dumps(cookies))
            cookie_file.write_text(encrypted, encoding="utf-8")

            logger.info(f"Cookie 已保存: {account_id} ({len(cookies)} 条)")
        except Exception as e:
            logger.error(f"保存 Cookie 失败: {e}")

    async def _load_cookies(self, account_id: str, context: Any) -> None:
        """从加密文件加载 Cookie。"""
        cookie_file = Path(f"data/cookies/{account_id}.json")
        if not cookie_file.exists():
            return

        try:
            from app.core.encryption import decrypt
            encrypted = cookie_file.read_text(encoding="utf-8")
            cookies_json = decrypt(encrypted)
            cookies = json.loads(cookies_json)
            await context.add_cookies(cookies)
            logger.info(f"Cookie 已加载: {account_id} ({len(cookies)} 条)")
        except Exception as e:
            logger.warning(f"加载 Cookie 失败: {e}")

    async def cleanup_idle(self, timeout_minutes: int = 30) -> int:
        """清理空闲超时的上下文。"""
        now = time.time()
        timeout_seconds = timeout_minutes * 60
        idle_accounts = [
            aid for aid, ctx in self._contexts.items()
            if now - ctx.last_used > timeout_seconds
        ]
        for aid in idle_accounts:
            await self.release(aid)
        if idle_accounts:
            logger.info(f"清理空闲浏览器上下文: {len(idle_accounts)} 个")
        return len(idle_accounts)

    async def shutdown(self) -> None:
        """关闭所有上下文和浏览器。"""
        accounts = list(self._contexts.keys())
        for aid in accounts:
            await self.release(aid)

        if self._browser:
            try:
                await self._browser.close()
            except Exception:
                pass

        if self._playwright:
            try:
                await self._playwright.stop()
            except Exception:
                pass

        self._initialized = False
        logger.info("浏览器池已关闭")

    @property
    def size(self) -> int:
        return len(self._contexts)

    @property
    def max_contexts(self) -> int:
        return self._max_contexts

    def get_active_accounts(self) -> List[str]:
        return list(self._contexts.keys())

    def is_account_active(self, account_id: str) -> bool:
        return account_id in self._contexts


# 全局实例
browser_pool = BrowserPool()
