"""防封总控制器，协调指纹、频率、行为延迟。"""

from __future__ import annotations

import json
import time
from datetime import datetime
from typing import Dict, Optional

from app.core.logger import get_logger

logger = get_logger(__name__)


class AntiBanController:
    """防封总控制器。"""

    def __init__(self) -> None:
        self._action_log: Dict[str, list] = {}  # account_id -> [timestamps]
        self._health_scores: Dict[str, int] = {}  # account_id -> score

    def check_before_action(self, account_id: str, action: str) -> bool:
        """操作前检查，协调指纹+频率+行为延迟。
        返回是否允许执行。
        """
        from app.core.rate_limiter import rate_limiter

        # 检查是否在活跃时段
        if not self.is_active_hours():
            logger.info(f"账号 {account_id}: 当前不在活跃时段")
            return False

        # 检查健康度
        score = self._health_scores.get(account_id, 100)
        if score < 30:
            logger.warning(f"账号 {account_id}: 健康度 {score} 过低，暂停操作")
            return False

        # 检查频率限制
        allowed, wait = rate_limiter.is_allowed(account_id, action)
        if not allowed:
            logger.info(f"账号 {account_id}: 操作 {action} 被限流，等待 {wait:.1f}s")
            return False

        return True

    def check_after_action(self, account_id: str, action: str) -> Dict[str, any]:
        """操作后扫描风控信号。"""
        from app.core.rate_limiter import rate_limiter

        # 记录操作
        rate_limiter.record_action(account_id, action)
        self.log_action(account_id, action)

        signals: Dict[str, any] = {
            "action": action,
            "timestamp": time.time(),
            "warnings": [],
            "risk_level": "low",
        }

        # 检查今日操作数
        stats = rate_limiter.get_daily_stats(account_id)
        total_today = sum(stats.values())
        if total_today > 100:
            signals["warnings"].append("今日操作数超过 100")
            signals["risk_level"] = "medium"
        if total_today > 200:
            signals["warnings"].append("今日操作数超过 200，高风险")
            signals["risk_level"] = "high"

        # 检查验证码计数
        score = self._health_scores.get(account_id, 100)
        if score < 50:
            signals["warnings"].append(f"账号健康度较低: {score}")
            signals["risk_level"] = "medium"

        return signals

    def update_health_score(self, account_id: str, delta: int) -> int:
        """更新账号健康度。"""
        current = self._health_scores.get(account_id, 100)
        new_score = max(0, min(100, current + delta))
        self._health_scores[account_id] = new_score
        logger.info(f"账号 {account_id}: 健康度 {current} -> {new_score}")
        return new_score

    def should_pause(self, account_id: str) -> bool:
        """判断是否应暂停该账号操作。"""
        score = self._health_scores.get(account_id, 100)
        if score < 30:
            return True  # 完全暂停
        return False

    def get_throttle_factor(self, account_id: str) -> float:
        """获取降频因子。健康度 < 50 时降频 50%。"""
        score = self._health_scores.get(account_id, 100)
        if score < 50:
            return 0.5
        return 1.0

    def is_active_hours(self) -> bool:
        """判断当前是否在活跃时段（0-7 点禁止）。"""
        hour = datetime.now().hour
        return hour >= 8 and hour < 24

    def log_action(self, account_id: str, action: str) -> None:
        """记录操作。"""
        if account_id not in self._action_log:
            self._action_log[account_id] = []
        self._action_log[account_id].append(time.time())

        # 保留最近 24 小时的记录
        cutoff = time.time() - 86400
        self._action_log[account_id] = [
            t for t in self._action_log[account_id] if t > cutoff
        ]

    def get_action_stats(self, account_id: str) -> Dict[str, int]:
        """获取账号操作统计。"""
        logs = self._action_log.get(account_id, [])
        hour_ago = time.time() - 3600
        recent = [t for t in logs if t > hour_ago]
        return {
            "total_today": len(logs),
            "last_hour": len(recent),
            "health_score": self._health_scores.get(account_id, 100),
        }

    def set_health_score(self, account_id: str, score: int) -> None:
        """直接设置健康度。"""
        self._health_scores[account_id] = max(0, min(100, score))


# 全局实例
anti_ban_controller = AntiBanController()
