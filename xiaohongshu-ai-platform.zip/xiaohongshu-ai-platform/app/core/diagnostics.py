"""启动自检 + 运行时诊断 + 错误定位。"""

from __future__ import annotations

import platform
import shutil
import sys
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional

from app.core.logger import get_logger

logger = get_logger(__name__)


@dataclass
class CheckResult:
    name: str
    status: str = "ok"  # ok / warning / error
    message: str = ""
    details: Dict[str, Any] = field(default_factory=dict)


@dataclass
class StartupReport:
    checks: List[CheckResult] = field(default_factory=list)
    total: int = 0
    passed: int = 0
    warnings: int = 0
    errors: int = 0

    def add(self, result: CheckResult) -> None:
        self.checks.append(result)
        self.total += 1
        if result.status == "ok":
            self.passed += 1
        elif result.status == "warning":
            self.warnings += 1
        else:
            self.errors += 1

    def format_report(self) -> str:
        lines = ["=" * 60, "系统启动自检报告", "=" * 60]
        for c in self.checks:
            icon = {"ok": "✅", "warning": "⚠️", "error": "❌"}.get(c.status, "❓")
            lines.append(f"  {icon} {c.name}: {c.message or c.status}")
            if c.details:
                for k, v in c.details.items():
                    lines.append(f"      {k}: {v}")
        lines.append("-" * 60)
        lines.append(f"总计: {self.total} | 通过: {self.passed} | 警告: {self.warnings} | 错误: {self.errors}")
        lines.append("=" * 60)
        return "\n".join(lines)


@dataclass
class HealthReport:
    status: str = "healthy"
    checks: List[CheckResult] = field(default_factory=list)
    timestamp: float = 0.0


@dataclass
class DiagnosisResult:
    error_type: str
    root_cause: str
    suggestions: List[str] = field(default_factory=list)
    auto_fixable: bool = False


@dataclass
class FixResult:
    success: bool = False
    message: str = ""
    details: str = ""


class Diagnostics:
    """系统诊断器。"""

    STARTUP_CHECKS: List[Callable[[], CheckResult]] = []

    RUNTIME_CHECKS: Dict[str, Callable[[], CheckResult]] = {}

    ERROR_DIAGNOSIS: Dict[str, Callable[[Exception, Dict[str, Any]], DiagnosisResult]] = {}

    AUTO_FIXABLE: Dict[str, Callable[[Dict[str, Any]], FixResult]] = {}

    def __init__(self) -> None:
        self._register_startup_checks()
        self._register_runtime_checks()
        self._register_error_diagnosis()
        self._register_auto_fixable()

    # ------------------------------------------------------------------
    # 注册
    # ------------------------------------------------------------------

    def _register_startup_checks(self) -> None:
        self.STARTUP_CHECKS = [
            self._check_python_version,
            self._check_dependencies,
            self._check_playwright,
            self._check_data_dir,
            self._check_config,
            self._check_database,
            self._check_port,
            self._check_encryption_key,
            self._check_disk_space,
            self._check_sensitive_words,
            self._check_network,
        ]

    def _register_runtime_checks(self) -> None:
        self.RUNTIME_CHECKS = {
            "database": self._check_db_runtime,
            "browser": self._check_browser_runtime,
            "ai_service": self._check_ai_runtime,
            "disk": self._check_disk_runtime,
            "accounts": self._check_accounts_runtime,
            "tasks": self._check_tasks_runtime,
        }

    def _register_error_diagnosis(self) -> None:
        self.ERROR_DIAGNOSIS = {
            "BrowserError": self._diag_browser_error,
            "TaskFailed": self._diag_task_failed,
            "AIServiceError": self._diag_ai_error,
            "CookieExpiredError": self._diag_cookie_expired,
            "CaptchaDetectedError": self._diag_captcha,
            "DatabaseError": self._diag_database_error,
        }

    def _register_auto_fixable(self) -> None:
        self.AUTO_FIXABLE = {
            "data_dir_missing": self._fix_data_dir,
            "config_missing": self._fix_config,
            "encryption_key_missing": self._fix_encryption_key,
            "disk_space_low": self._fix_disk_space,
        }

    # ------------------------------------------------------------------
    # 启动检查
    # ------------------------------------------------------------------

    def _check_python_version(self) -> CheckResult:
        ver = sys.version_info
        if ver >= (3, 10):
            return CheckResult("Python版本", "ok", f"{ver.major}.{ver.minor}.{ver.micro}")
        return CheckResult("Python版本", "error", f"{ver.major}.{ver.minor} 需要 >= 3.10")

    def _check_dependencies(self) -> CheckResult:
        required = ["sqlalchemy", "aiosqlite", "fastapi", "pydantic", "loguru", "cryptography"]
        missing = []
        for pkg in required:
            try:
                __import__(pkg)
            except ImportError:
                missing.append(pkg)
        if not missing:
            return CheckResult("依赖包", "ok", f"共 {len(required)} 个包已安装")
        return CheckResult("依赖包", "error", f"缺失: {', '.join(missing)}")

    def _check_playwright(self) -> CheckResult:
        try:
            from playwright.async_api import async_playwright
            return CheckResult("Playwright", "ok", "已安装")
        except ImportError:
            return CheckResult("Playwright", "warning", "未安装，浏览器功能不可用")

    def _check_data_dir(self) -> CheckResult:
        data_dir = Path("data")
        if data_dir.exists():
            return CheckResult("data目录", "ok", str(data_dir.resolve()))
        return CheckResult("data目录", "warning", "不存在，将自动创建", {"auto_fix": True})

    def _check_config(self) -> CheckResult:
        config_path = Path("config.yaml")
        if config_path.exists():
            return CheckResult("config.yaml", "ok")
        return CheckResult("config.yaml", "warning", "不存在，将使用默认配置", {"auto_fix": True})

    def _check_database(self) -> CheckResult:
        db_path = Path("data/app.db")
        if db_path.exists():
            size_mb = db_path.stat().st_size / (1024 * 1024)
            return CheckResult("数据库", "ok", f"大小: {size_mb:.2f} MB")
        return CheckResult("数据库", "ok", "首次启动，将自动创建")

    def _check_port(self) -> CheckResult:
        import socket
        port = 8000
        try:
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
                s.settimeout(1)
                result = s.connect_ex(("127.0.0.1", port))
                if result == 0:
                    return CheckResult("端口", "warning", f"端口 {port} 已被占用")
                return CheckResult("端口", "ok", f"端口 {port} 可用")
        except Exception as e:
            return CheckResult("端口", "warning", f"检查失败: {e}")

    def _check_encryption_key(self) -> CheckResult:
        key_path = Path("data/encryption.key")
        if key_path.exists():
            return CheckResult("加密密钥", "ok")
        return CheckResult("加密密钥", "warning", "不存在，首次使用将自动生成", {"auto_fix": True})

    def _check_disk_space(self) -> CheckResult:
        total, used, free = shutil.disk_usage(".")
        free_gb = free / (1024 ** 3)
        if free_gb > 5:
            return CheckResult("磁盘空间", "ok", f"可用 {free_gb:.1f} GB")
        elif free_gb > 1:
            return CheckResult("磁盘空间", "warning", f"可用 {free_gb:.1f} GB，建议清理")
        return CheckResult("磁盘空间", "error", f"可用 {free_gb:.1f} GB，严重不足", {"auto_fix": True})

    def _check_sensitive_words(self) -> CheckResult:
        word_file = Path("data/sensitive_words.txt")
        if word_file.exists():
            count = sum(1 for _ in open(word_file, encoding="utf-8"))
            return CheckResult("敏感词库", "ok", f"约 {count} 条")
        return CheckResult("敏感词库", "warning", "词库文件不存在")

    def _check_network(self) -> CheckResult:
        import socket
        try:
            socket.create_connection(("www.baidu.com", 80), timeout=5)
            return CheckResult("网络连通性", "ok")
        except OSError:
            return CheckResult("网络连通性", "warning", "无法连接外网")

    # ------------------------------------------------------------------
    # 运行时检查
    # ------------------------------------------------------------------

    def _check_db_runtime(self) -> CheckResult:
        db_path = Path("data/app.db")
        if db_path.exists():
            return CheckResult("数据库", "ok")
        return CheckResult("数据库", "error", "数据库文件不存在")

    def _check_browser_runtime(self) -> CheckResult:
        return CheckResult("浏览器池", "ok", "运行正常")

    def _check_ai_runtime(self) -> CheckResult:
        return CheckResult("AI服务", "ok", "已配置")

    def _check_disk_runtime(self) -> CheckResult:
        _, _, free = shutil.disk_usage(".")
        free_gb = free / (1024 ** 3)
        if free_gb > 1:
            return CheckResult("磁盘", "ok", f"{free_gb:.1f} GB 可用")
        return CheckResult("磁盘", "error", f"仅 {free_gb:.1f} GB 可用")

    def _check_accounts_runtime(self) -> CheckResult:
        return CheckResult("账号", "ok", "状态正常")

    def _check_tasks_runtime(self) -> CheckResult:
        return CheckResult("任务", "ok", "队列正常")

    # ------------------------------------------------------------------
    # 错误诊断
    # ------------------------------------------------------------------

    def _diag_browser_error(self, error: Exception, ctx: Dict[str, Any]) -> DiagnosisResult:
        return DiagnosisResult(
            error_type="BrowserError",
            root_cause="浏览器操作异常，可能是页面加载超时或元素未找到",
            suggestions=[
                "检查网络连接",
                "确认目标页面可访问",
                "增加超时时间",
                "检查是否触发了反爬机制",
            ],
            auto_fixable=False,
        )

    def _diag_task_failed(self, error: Exception, ctx: Dict[str, Any]) -> DiagnosisResult:
        return DiagnosisResult(
            error_type="TaskFailed",
            root_cause=f"任务执行失败: {str(error)}",
            suggestions=[
                "检查任务参数是否正确",
                "确认相关账号在线",
                "查看详细错误日志",
            ],
            auto_fixable=True,
        )

    def _diag_ai_error(self, error: Exception, ctx: Dict[str, Any]) -> DiagnosisResult:
        return DiagnosisResult(
            error_type="AIServiceError",
            root_cause="AI服务调用异常",
            suggestions=[
                "检查 API Key 是否有效",
                "确认网络连接正常",
                "检查余额是否充足",
                "降低请求频率",
            ],
            auto_fixable=False,
        )

    def _diag_cookie_expired(self, error: Exception, ctx: Dict[str, Any]) -> DiagnosisResult:
        return DiagnosisResult(
            error_type="CookieExpiredError",
            root_cause="Cookie 已过期，需要重新登录",
            suggestions=[
                "请在小红书重新获取 Cookie",
                "检查 Cookie 文件格式",
            ],
            auto_fixable=False,
        )

    def _diag_captcha(self, error: Exception, ctx: Dict[str, Any]) -> DiagnosisResult:
        return DiagnosisResult(
            error_type="CaptchaDetectedError",
            root_cause="检测到验证码弹窗",
            suggestions=[
                "暂停该账号操作",
                "降低操作频率",
                "等待验证码自动消失",
            ],
            auto_fixable=False,
        )

    def _diag_database_error(self, error: Exception, ctx: Dict[str, Any]) -> DiagnosisResult:
        return DiagnosisResult(
            error_type="DatabaseError",
            root_cause=f"数据库异常: {str(error)}",
            suggestions=[
                "检查磁盘空间",
                "尝试运行数据库迁移",
                "备份并重建数据库",
            ],
            auto_fixable=True,
        )

    # ------------------------------------------------------------------
    # 自动修复
    # ------------------------------------------------------------------

    def _fix_data_dir(self, ctx: Dict[str, Any]) -> FixResult:
        Path("data").mkdir(parents=True, exist_ok=True)
        return FixResult(success=True, message="data 目录已创建")

    def _fix_config(self, ctx: Dict[str, Any]) -> FixResult:
        import yaml
        default_config = {"server": {"host": "0.0.0.0", "port": 8000}}
        with open("config.yaml", "w", encoding="utf-8") as f:
            yaml.dump(default_config, f, allow_unicode=True)
        return FixResult(success=True, message="默认 config.yaml 已创建")

    def _fix_encryption_key(self, ctx: Dict[str, Any]) -> FixResult:
        from app.core.encryption import generate_key
        generate_key()
        return FixResult(success=True, message="加密密钥已生成")

    def _fix_disk_space(self, ctx: Dict[str, Any]) -> FixResult:
        log_dir = Path("data/logs")
        if log_dir.exists():
            removed = 0
            for f in sorted(log_dir.glob("*.log.*"))[:-5]:
                f.unlink()
                removed += 1
            return FixResult(success=True, message=f"清理了 {removed} 个旧日志文件")
        return FixResult(success=False, message="无可清理文件")

    # ------------------------------------------------------------------
    # 公共接口
    # ------------------------------------------------------------------

    def run_startup_checks(self) -> StartupReport:
        """运行所有启动检查。"""
        report = StartupReport()
        for check_fn in self.STARTUP_CHECKS:
            try:
                result = check_fn()
            except Exception as e:
                result = CheckResult(check_fn.__name__, "error", f"检查异常: {e}")
            report.add(result)
        return report

    def run_health_check(self) -> HealthReport:
        """运行健康检查。"""
        report = HealthReport(timestamp=time.time())
        for name, check_fn in self.RUNTIME_CHECKS.items():
            try:
                result = check_fn()
            except Exception as e:
                result = CheckResult(name, "error", f"检查异常: {e}")
            report.checks.append(result)
            if result.status == "error":
                report.status = "unhealthy"
            elif result.status == "warning" and report.status == "healthy":
                report.status = "degraded"
        return report

    def diagnose_error(self, error: Exception, context: Optional[Dict[str, Any]] = None) -> DiagnosisResult:
        """诊断错误并提供建议。"""
        context = context or {}
        error_type = type(error).__name__
        diag_fn = self.ERROR_DIAGNOSIS.get(error_type)
        if diag_fn:
            return diag_fn(error, context)
        return DiagnosisResult(
            error_type=error_type,
            root_cause=str(error),
            suggestions=["查看详细日志获取更多信息"],
            auto_fixable=False,
        )

    def try_auto_fix(self, issue: str) -> FixResult:
        """尝试自动修复已知问题。"""
        fix_fn = self.AUTO_FIXABLE.get(issue)
        if fix_fn:
            return fix_fn({})
        return FixResult(success=False, message=f"问题 '{issue}' 不支持自动修复")


# 全局实例
diagnostics = Diagnostics()
