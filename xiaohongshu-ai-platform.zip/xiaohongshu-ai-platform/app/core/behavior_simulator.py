"""人类行为模拟：鼠标轨迹、滚动、打字、阅读时间。"""

from __future__ import annotations

import math
import random
import time
from typing import List, Tuple

from app.core.logger import get_logger

logger = get_logger(__name__)


class BehaviorSimulator:
    """人类行为模拟器。"""

    def __init__(self) -> None:
        self._typing_speed_base: float = 5.0  # 基础打字速度 (字符/秒)
        self._reading_speed: float = 8.0  # 阅读速度 (字/秒)

    # ------------------------------------------------------------------
    # 鼠标移动
    # ------------------------------------------------------------------

    @staticmethod
    def _bezier_point(
        t: float,
        p0: Tuple[float, float],
        p1: Tuple[float, float],
        p2: Tuple[float, float],
        p3: Tuple[float, float],
    ) -> Tuple[float, float]:
        """计算三次贝塞尔曲线上的点。"""
        u = 1 - t
        x = (u ** 3) * p0[0] + 3 * (u ** 2) * t * p1[0] + 3 * u * (t ** 2) * p2[0] + (t ** 3) * p3[0]
        y = (u ** 3) * p0[1] + 3 * (u ** 2) * t * p1[1] + 3 * u * (t ** 2) * p2[1] + (t ** 3) * p3[1]
        return (x, y)

    def simulate_mouse_move(
        self,
        start: Tuple[float, float],
        end: Tuple[float, float],
        steps: int = 0,
    ) -> List[Tuple[float, float, float]]:
        """模拟鼠标从 start 到 end 的贝塞尔曲线轨迹。
        返回 [(x, y, timestamp)] 列表。
        """
        if steps == 0:
            dist = math.hypot(end[0] - start[0], end[1] - start[1])
            steps = max(10, min(50, int(dist / 20)))

        # 生成随机控制点
        dx = end[0] - start[0]
        dy = end[1] - start[1]
        p1 = (
            start[0] + dx * 0.3 + random.uniform(-50, 50),
            start[1] + dy * 0.3 + random.uniform(-50, 50),
        )
        p2 = (
            start[0] + dx * 0.7 + random.uniform(-50, 50),
            start[1] + dy * 0.7 + random.uniform(-50, 50),
        )

        points: List[Tuple[float, float, float]] = []
        base_time = time.time()
        total_duration = random.uniform(0.2, 0.8)  # 总时长 200-800ms

        for i in range(steps + 1):
            t = i / steps
            # 缓动函数：ease-in-out
            eased = t * t * (3 - 2 * t)
            x, y = self._bezier_point(eased, start, p1, p2, end)
            # 添加微小抖动
            x += random.gauss(0, 1)
            y += random.gauss(0, 1)
            timestamp = base_time + t * total_duration
            points.append((round(x, 2), round(y, 2), timestamp))

        return points

    # ------------------------------------------------------------------
    # 滚动
    # ------------------------------------------------------------------

    def simulate_scroll(self, distance: int) -> List[dict]:
        """模拟人类滚动行为，含 12% 回滚。
        返回滚动事件列表。
        """
        events: List[dict] = []
        base_time = time.time()

        # 主滚动：减速曲线
        total_steps = max(5, min(30, abs(distance) // 50))
        scroll_per_step = distance / total_steps

        current_y = 0
        for i in range(total_steps):
            # 减速
            factor = 1.0 - (i / total_steps) * 0.6
            delta = scroll_per_step * factor
            current_y += delta
            t = base_time + i * random.uniform(0.02, 0.08)
            events.append({"y": round(current_y), "delta": round(delta), "time": t})

        # 12% 概率回滚
        if random.random() < 0.12:
            rollback = int(abs(distance) * random.uniform(0.1, 0.3))
            rollback_steps = random.randint(3, 8)
            for j in range(rollback_steps):
                delta = -rollback / rollback_steps
                current_y += delta
                t = base_time + (total_steps + j) * random.uniform(0.03, 0.1)
                events.append({"y": round(current_y), "delta": round(delta), "time": t})

        return events

    # ------------------------------------------------------------------
    # 打字
    # ------------------------------------------------------------------

    def typing_delay(self) -> float:
        """返回字符间延迟（秒），速度 3-8 字符/秒。"""
        speed = random.uniform(3.0, 8.0)
        return 1.0 / speed

    def simulate_typing(self, text: str) -> List[Tuple[str, float]]:
        """模拟打字过程。返回 [(char, delay)] 列表。"""
        result: List[Tuple[str, float]] = []
        for char in text:
            delay = self.typing_delay()
            # 标点符号后额外停顿
            if char in "。！？，；":
                delay += random.uniform(0.1, 0.4)
            elif char == "\n":
                delay += random.uniform(0.3, 0.8)
            # 偶尔打错再修正 (5% 概率)
            if random.random() < 0.03 and char.isalpha():
                wrong_char = random.choice("qwertyuiop")
                result.append((wrong_char, delay))
                result.append(("\b", random.uniform(0.05, 0.15)))  # 退格
            result.append((char, delay))
        return result

    # ------------------------------------------------------------------
    # 阅读
    # ------------------------------------------------------------------

    def reading_time(self, content_length: int) -> float:
        """根据内容长度计算阅读时间（秒）。"""
        base_time = content_length / self._reading_speed
        # 添加随机波动 ±30%
        variation = random.uniform(0.7, 1.3)
        return max(1.0, base_time * variation)

    # ------------------------------------------------------------------
    # 操作间延迟
    # ------------------------------------------------------------------

    def action_delay(self, action_type: str) -> float:
        """返回特定操作前的延迟（秒）。"""
        delays = {
            "browse": (1.0, 4.0),
            "like": (3.0, 10.0),
            "collect": (2.0, 6.0),
            "comment": (10.0, 30.0),
            "follow": (3.0, 8.0),
            "publish": (5.0, 15.0),
        }
        min_d, max_d = delays.get(action_type, (2.0, 8.0))
        return random.uniform(min_d, max_d)

    def before_like(self) -> float:
        """点赞前的阅读时间。"""
        return random.uniform(3.0, 10.0)

    def before_comment(self) -> float:
        """评论前的阅读时间。"""
        return random.uniform(10.0, 30.0)


# 全局实例
behavior_simulator = BehaviorSimulator()
