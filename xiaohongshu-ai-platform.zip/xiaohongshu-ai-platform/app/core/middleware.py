"""中间件集合：RequestID、日志、限流、异常处理、安全头。"""

from __future__ import annotations

import time
import uuid
from collections import defaultdict
from typing import Callable, Dict

from fastapi import Request, Response
from fastapi.middleware.cors import CORSMiddleware as _CORSMiddleware
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.responses import JSONResponse

from app.core.exceptions import BusinessError
from app.core.logger import get_logger

logger = get_logger(__name__)


# ---------------------------------------------------------------------------
# 1. RequestIDMiddleware
# ---------------------------------------------------------------------------

class RequestIDMiddleware(BaseHTTPMiddleware):
    """为每个请求生成 UUID，注入 request.state + 响应头 X-Request-ID。"""

    async def dispatch(self, request: Request, call_next: Callable) -> Response:
        request_id = str(uuid.uuid4())
        request.state.request_id = request_id
        response: Response = await call_next(request)
        response.headers["X-Request-ID"] = request_id
        return response


# ---------------------------------------------------------------------------
# 2. RequestLoggingMiddleware
# ---------------------------------------------------------------------------

class RequestLoggingMiddleware(BaseHTTPMiddleware):
    """记录方法/路径/状态码/耗时，慢请求(>2s)标记warning，静态文件不记录。"""

    STATIC_PREFIXES = ("/static/", "/favicon.ico", "/assets/")

    async def dispatch(self, request: Request, call_next: Callable) -> Response:
        path = request.url.path
        if any(path.startswith(p) for p in self.STATIC_PREFIXES):
            return await call_next(request)

        method = request.method
        start = time.monotonic()
        response: Response = await call_next(request)
        elapsed = time.monotonic() - start
        elapsed_ms = round(elapsed * 1000, 1)
        status_code = response.status_code

        request_id = getattr(request.state, "request_id", "-")
        msg = f"{method} {path} {status_code} {elapsed_ms}ms [{request_id}]"

        if elapsed > 2.0:
            logger.warning(f"[SLOW] {msg}")
        else:
            logger.info(msg)

        return response


# ---------------------------------------------------------------------------
# 3. APIRateLimitMiddleware
# ---------------------------------------------------------------------------

class APIRateLimitMiddleware(BaseHTTPMiddleware):
    """每 IP 每分钟最多 60 次请求，超限返回 429。"""

    MAX_REQUESTS = 60
    WINDOW_SECONDS = 60

    def __init__(self, app):
        super().__init__(app)
        self._ip_requests: Dict[str, list] = defaultdict(list)

    def _get_client_ip(self, request: Request) -> str:
        forwarded = request.headers.get("X-Forwarded-For")
        if forwarded:
            return forwarded.split(",")[0].strip()
        return request.client.host if request.client else "unknown"

    async def dispatch(self, request: Request, call_next: Callable) -> Response:
        path = request.url.path
        if not path.startswith("/api/"):
            return await call_next(request)

        ip = self._get_client_ip(request)
        now = time.time()
        window_start = now - self.WINDOW_SECONDS

        timestamps = self._ip_requests[ip]
        timestamps[:] = [t for t in timestamps if t > window_start]

        if len(timestamps) >= self.MAX_REQUESTS:
            retry_after = int(timestamps[0] + self.WINDOW_SECONDS - now) + 1
            return JSONResponse(
                status_code=429,
                content={"code": 429, "message": "请求过于频繁，请稍后再试", "data": None},
                headers={"Retry-After": str(retry_after)},
            )

        timestamps.append(now)
        return await call_next(request)


# ---------------------------------------------------------------------------
# 4. GlobalExceptionMiddleware
# ---------------------------------------------------------------------------

class GlobalExceptionMiddleware(BaseHTTPMiddleware):
    """捕获 BusinessError → 统一 JSON 响应；未知异常 → 记录日志 + 通用错误。"""

    async def dispatch(self, request: Request, call_next: Callable) -> Response:
        try:
            return await call_next(request)
        except BusinessError as exc:
            return JSONResponse(
                status_code=exc.status_code,
                content={
                    "code": exc.code,
                    "message": exc.message,
                    "data": None,
                },
            )
        except Exception as exc:
            request_id = getattr(request.state, "request_id", "unknown")
            logger.exception(f"未处理异常 [{request_id}]: {exc}")
            return JSONResponse(
                status_code=500,
                content={
                    "code": 500,
                    "message": "服务器内部错误",
                    "data": None,
                },
            )


# ---------------------------------------------------------------------------
# 5. SecurityHeadersMiddleware
# ---------------------------------------------------------------------------

class SecurityHeadersMiddleware(BaseHTTPMiddleware):
    """注入安全响应头。"""

    SECURITY_HEADERS = {
        "X-Content-Type-Options": "nosniff",
        "X-Frame-Options": "DENY",
        "X-XSS-Protection": "1; mode=block",
        "Referrer-Policy": "strict-origin-when-cross-origin",
        "Permissions-Policy": "camera=(), microphone=(), geolocation=()",
    }

    async def dispatch(self, request: Request, call_next: Callable) -> Response:
        response: Response = await call_next(request)
        for header, value in self.SECURITY_HEADERS.items():
            response.headers[header] = value
        return response
