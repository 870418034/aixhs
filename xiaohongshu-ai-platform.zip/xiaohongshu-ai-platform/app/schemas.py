"""Pydantic 请求/响应模型。"""

from __future__ import annotations

from datetime import date, datetime
from typing import Any, Dict, List, Optional

from pydantic import BaseModel, Field


# ---------------------------------------------------------------------------
# 统一响应
# ---------------------------------------------------------------------------


class ApiResponse(BaseModel):
    code: int = 200
    message: str = "success"
    data: Any = None


class PaginatedResponse(BaseModel):
    items: List[Any] = Field(default_factory=list)
    total: int = 0
    page: int = 1
    page_size: int = 20


# ---------------------------------------------------------------------------
# Account
# ---------------------------------------------------------------------------


class AccountCreate(BaseModel):
    nickname: str = ""
    xhs_id: str = ""
    avatar_url: str = ""
    bio: str = ""
    gender: int = 0
    account_type: str = "personal"
    positioning: str = ""
    login_method: str = "cookie"
    cookie_path: str = ""
    proxy: str = ""
    user_agent: str = ""
    note: str = ""


class AccountUpdate(BaseModel):
    nickname: Optional[str] = None
    xhs_id: Optional[str] = None
    avatar_url: Optional[str] = None
    bio: Optional[str] = None
    gender: Optional[int] = None
    account_type: Optional[str] = None
    positioning: Optional[str] = None
    operation_stage: Optional[str] = None
    nurturing_day: Optional[int] = None
    nurturing_total_days: Optional[int] = None
    status: Optional[str] = None
    proxy: Optional[str] = None
    user_agent: Optional[str] = None
    health_score: Optional[int] = None
    note: Optional[str] = None


class AccountResponse(BaseModel):
    id: str
    nickname: Optional[str] = None
    xhs_id: Optional[str] = None
    avatar_url: Optional[str] = None
    bio: Optional[str] = None
    gender: int = 0
    ip_location: Optional[str] = None
    followers: int = 0
    following: int = 0
    likes: int = 0
    notes_count: int = 0
    account_type: str = "personal"
    positioning: Optional[str] = None
    operation_stage: str = "nurturing"
    nurturing_day: int = 0
    nurturing_total_days: int = 7
    status: str = "offline"
    login_method: str = "cookie"
    cookie_path: Optional[str] = None
    proxy: Optional[str] = None
    user_agent: Optional[str] = None
    total_published: int = 0
    today_actions: int = 0
    health_score: int = 100
    fingerprint: Optional[str] = None
    captcha_count_today: int = 0
    last_captcha_at: Optional[datetime] = None
    banned_reason: Optional[str] = None
    note: Optional[str] = None
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None
    last_active_at: Optional[datetime] = None
    last_data_refresh: Optional[datetime] = None

    model_config = {"from_attributes": True}


class AccountList(PaginatedResponse):
    items: List[AccountResponse] = Field(default_factory=list)


class AccountLogin(BaseModel):
    account_id: str
    cookies: str = ""


# ---------------------------------------------------------------------------
# Content
# ---------------------------------------------------------------------------


class ContentGenerate(BaseModel):
    account_id: str
    topic: str = ""
    content_type: str = "note"
    category: str = ""
    prompt_extra: str = ""
    ai_config_id: Optional[str] = None


class ContentUpdate(BaseModel):
    title: Optional[str] = None
    body: Optional[str] = None
    tags: Optional[str] = None
    topic: Optional[str] = None
    images: Optional[str] = None
    content_type: Optional[str] = None
    category: Optional[str] = None
    status: Optional[str] = None
    is_scheduled: Optional[bool] = None
    publish_time: Optional[datetime] = None


class ContentResponse(BaseModel):
    id: str
    account_id: str
    title: Optional[str] = None
    body: Optional[str] = None
    tags: Optional[str] = None
    topic: Optional[str] = None
    images: Optional[str] = None
    content_type: str = "note"
    category: Optional[str] = None
    status: str = "draft"
    xhs_note_id: Optional[str] = None
    xhs_note_url: Optional[str] = None
    publish_time: Optional[datetime] = None
    is_scheduled: bool = False
    views: int = 0
    likes: int = 0
    comments_count: int = 0
    collects: int = 0
    shares: int = 0
    last_stats_refresh: Optional[datetime] = None
    ai_config_id: Optional[str] = None
    ai_prompt_used: Optional[str] = None
    generation_params: Optional[str] = None
    safety_score: Optional[float] = None
    safety_result: Optional[str] = None
    safety_checked_at: Optional[datetime] = None
    original_body: Optional[str] = None
    rewrite_count: int = 0
    title_variants: Optional[str] = None
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None

    model_config = {"from_attributes": True}


class ContentList(PaginatedResponse):
    items: List[ContentResponse] = Field(default_factory=list)


# ---------------------------------------------------------------------------
# Task
# ---------------------------------------------------------------------------


class TaskResponse(BaseModel):
    id: str
    account_id: Optional[str] = None
    task_type: str
    priority: int = 0
    params: Optional[str] = None
    status: str = "pending"
    progress: int = 0
    result: Optional[str] = None
    error_msg: Optional[str] = None
    retry_count: int = 0
    max_retries: int = 3
    scheduled_at: Optional[datetime] = None
    started_at: Optional[datetime] = None
    completed_at: Optional[datetime] = None
    created_at: Optional[datetime] = None

    model_config = {"from_attributes": True}


class TaskList(PaginatedResponse):
    items: List[TaskResponse] = Field(default_factory=list)


class TaskStats(BaseModel):
    total: int = 0
    pending: int = 0
    running: int = 0
    completed: int = 0
    failed: int = 0
    cancelled: int = 0


# ---------------------------------------------------------------------------
# AI Config
# ---------------------------------------------------------------------------


class AIConfigCreate(BaseModel):
    name: str
    provider: str
    api_key: str = ""
    base_url: str = ""
    model: str = ""
    max_tokens: int = 4096
    temperature: float = 0.7
    is_default: bool = False


class AIConfigUpdate(BaseModel):
    name: Optional[str] = None
    provider: Optional[str] = None
    api_key: Optional[str] = None
    base_url: Optional[str] = None
    model: Optional[str] = None
    max_tokens: Optional[int] = None
    temperature: Optional[float] = None
    is_default: Optional[bool] = None


class AIConfigResponse(BaseModel):
    id: str
    name: str
    provider: str
    base_url: Optional[str] = None
    model: str
    max_tokens: int = 4096
    temperature: float = 0.7
    is_default: bool = False
    total_requests: int = 0
    total_tokens: int = 0
    last_used: Optional[datetime] = None
    created_at: Optional[datetime] = None

    model_config = {"from_attributes": True}


class AIConfigList(PaginatedResponse):
    items: List[AIConfigResponse] = Field(default_factory=list)


# ---------------------------------------------------------------------------
# Dashboard
# ---------------------------------------------------------------------------


class DashboardOverview(BaseModel):
    total_accounts: int = 0
    online_accounts: int = 0
    total_contents: int = 0
    published_today: int = 0
    total_followers: int = 0
    followers_gain_today: int = 0
    total_views: int = 0
    pending_tasks: int = 0
    running_tasks: int = 0
    health_warnings: int = 0
    notifications_unread: int = 0


class DashboardTrendPoint(BaseModel):
    date: str
    followers: int = 0
    views: int = 0
    likes: int = 0
    publishes: int = 0


class DashboardTrends(BaseModel):
    points: List[DashboardTrendPoint] = Field(default_factory=list)


class AccountComparison(BaseModel):
    account_id: str
    nickname: Optional[str] = None
    followers: int = 0
    followers_gain: int = 0
    total_views: int = 0
    total_likes: int = 0
    engagement_rate: float = 0.0
    health_score: int = 100


# ---------------------------------------------------------------------------
# Notification
# ---------------------------------------------------------------------------


class NotificationResponse(BaseModel):
    id: str
    level: str = "info"
    title: str
    message: Optional[str] = None
    account_id: Optional[str] = None
    related_type: Optional[str] = None
    related_id: Optional[str] = None
    action_url: Optional[str] = None
    is_read: bool = False
    created_at: Optional[datetime] = None

    model_config = {"from_attributes": True}


class NotificationList(PaginatedResponse):
    items: List[NotificationResponse] = Field(default_factory=list)


# ---------------------------------------------------------------------------
# Material
# ---------------------------------------------------------------------------


class MaterialUpload(BaseModel):
    category: str = ""
    tags: str = ""


class MaterialResponse(BaseModel):
    id: str
    file_path: str
    file_type: str
    thumbnail_path: Optional[str] = None
    category: Optional[str] = None
    tags: Optional[str] = None
    ai_description: Optional[str] = None
    usage_count: int = 0
    width: Optional[int] = None
    height: Optional[int] = None
    file_size: Optional[int] = None
    created_at: Optional[datetime] = None

    model_config = {"from_attributes": True}


class MaterialList(PaginatedResponse):
    items: List[MaterialResponse] = Field(default_factory=list)


# ---------------------------------------------------------------------------
# Report
# ---------------------------------------------------------------------------


class ReportResponse(BaseModel):
    id: str
    report_type: str
    account_id: Optional[str] = None
    period_start: Optional[date] = None
    period_end: Optional[date] = None
    summary: Optional[str] = None
    ai_analysis: Optional[str] = None
    suggestions: Optional[str] = None
    highlights: Optional[str] = None
    file_path: Optional[str] = None
    created_at: Optional[datetime] = None

    model_config = {"from_attributes": True}


class ReportList(PaginatedResponse):
    items: List[ReportResponse] = Field(default_factory=list)


# ---------------------------------------------------------------------------
# Review
# ---------------------------------------------------------------------------


class ReviewResponse(BaseModel):
    id: str
    account_id: str
    review_date: date
    today_score: int = 0
    today_summary: Optional[str] = None
    highlights: Optional[str] = None
    issues: Optional[str] = None
    followers_start: int = 0
    followers_end: int = 0
    followers_gain: int = 0
    content_published: int = 0
    total_views: int = 0
    total_engagement: int = 0
    tasks_completed: int = 0
    tasks_failed: int = 0
    health_score: int = 100
    strategy_updates: Optional[str] = None
    tomorrow_tasks: Optional[str] = None
    trend_analysis: Optional[str] = None
    applied_to_plan: bool = False
    created_at: Optional[datetime] = None

    model_config = {"from_attributes": True}


class ReviewList(PaginatedResponse):
    items: List[ReviewResponse] = Field(default_factory=list)


# ---------------------------------------------------------------------------
# System
# ---------------------------------------------------------------------------


class LogEntry(BaseModel):
    id: str
    account_id: Optional[str] = None
    level: str = "INFO"
    action: str
    detail: Optional[str] = None
    extra_data: Optional[str] = None
    created_at: Optional[datetime] = None

    model_config = {"from_attributes": True}


class LogList(PaginatedResponse):
    items: List[LogEntry] = Field(default_factory=list)


class SystemStatus(BaseModel):
    status: str = "ok"
    uptime_seconds: float = 0.0
    version: str = "1.0.0"
    db_connected: bool = True
    browser_pool_size: int = 0
    active_accounts: int = 0
    pending_tasks: int = 0
    memory_usage_mb: float = 0.0
    cpu_percent: float = 0.0
    disk_usage_percent: float = 0.0


class DiagnosticsCheck(BaseModel):
    name: str
    status: str = "ok"
    message: str = ""
    details: Dict[str, Any] = Field(default_factory=dict)


class SystemDiagnostics(BaseModel):
    checks: List[DiagnosticsCheck] = Field(default_factory=list)
    total: int = 0
    passed: int = 0
    warnings: int = 0
    errors: int = 0


class SettingsUpdate(BaseModel):
    settings: Dict[str, str] = Field(default_factory=dict)


class BackupRequest(BaseModel):
    include_data: bool = True
    include_config: bool = True
    include_cookies: bool = False
    destination: str = ""
