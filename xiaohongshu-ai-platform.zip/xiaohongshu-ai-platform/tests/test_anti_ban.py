"""防封测试：指纹生成、健康度管理、行为延迟。"""

from __future__ import annotations

import hashlib
import random
import time
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from typing import Dict, List, Optional
from unittest.mock import patch

import pytest


# ---------------------------------------------------------------------------
# AntiBan 实现（纯逻辑，方便测试）
# ---------------------------------------------------------------------------

@dataclass
class DeviceFingerprint:
    """设备指纹。"""
    user_agent: str
    viewport_width: int
    viewport_height: int
    screen_width: int
    screen_height: int
    timezone: str
    language: str
    platform: str
    webgl_vendor: str
    webgl_renderer: str
    canvas_hash: str
    audio_hash: str
    fonts_hash: str
    webrtc_ip: str

    @property
    def fingerprint_id(self) -> str:
        raw = (
            f"{self.user_agent}|{self.viewport_width}x{self.viewport_height}|"
            f"{self.screen_width}x{self.screen_height}|{self.timezone}|"
            f"{self.language}|{self.platform}|{self.webgl_vendor}|"
            f"{self.webgl_renderer}|{self.canvas_hash}|{self.audio_hash}"
        )
        return hashlib.sha256(raw.encode()).hexdigest()[:32]

    def to_dict(self) -> dict:
        return {
            "user_agent": self.user_agent,
            "viewport": f"{self.viewport_width}x{self.viewport_height}",
            "screen": f"{self.screen_width}x{self.screen_height}",
            "timezone": self.timezone,
            "language": self.language,
            "platform": self.platform,
            "fingerprint_id": self.fingerprint_id,
        }


class FingerprintGenerator:
    """指纹生成器。"""

    VIEWPORTS = [
        (1920, 1080), (1366, 768), (1536, 864),
        (1440, 900), (1280, 720), (1600, 900),
    ]
    USER_AGENTS = [
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/120.0.0.0 Safari/537.36",
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 Safari/605.1.15",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/119.0.0.0 Safari/537.36",
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 Chrome/120.0.0.0 Safari/537.36",
    ]
    TIMEZONES = ["Asia/Shanghai", "Asia/Chongqing", "Asia/Harbin"]
    PLATFORMS = ["Win32", "MacIntel"]

    @classmethod
    def generate(cls) -> DeviceFingerprint:
        ua = random.choice(cls.USER_AGENTS)
        vp = random.choice(cls.VIEWPORTS)
        tz = random.choice(cls.TIMEZONES)
        plat = random.choice(cls.PLATFORMS)
        is_win = "Windows" in ua

        return DeviceFingerprint(
            user_agent=ua,
            viewport_width=vp[0],
            viewport_height=vp[1],
            screen_width=vp[0],
            screen_height=vp[1],
            timezone=tz,
            language="zh-CN",
            platform=plat,
            webgl_vendor="Google Inc. (NVIDIA)" if is_win else "Apple",
            webgl_renderer="ANGLE (NVIDIA" if is_win else "Apple GPU",
            canvas_hash=hashlib.md5(f"canvas_{random.randint(1,1000)}".encode()).hexdigest(),
            audio_hash=hashlib.md5(f"audio_{random.randint(1,1000)}".encode()).hexdigest(),
            fonts_hash=hashlib.md5(f"fonts_{random.randint(1,1000)}".encode()).hexdigest(),
            webrtc_ip=f"192.168.1.{random.randint(1, 254)}",
        )


class HealthScoreManager:
    """健康度管理器。"""

    MAX_SCORE = 100
    MIN_SCORE = 0

    # 各操作扣分
    PENALTIES = {
        "captcha": 10,
        "rate_limit_hit": 15,
        "suspicious_behavior": 5,
        "cookie_expired": 20,
        "account_warning": 25,
        "too_fast_action": 3,
    }

    # 恢复操作
    RECOVERY = {
        "normal_browse": 1,
        "successful_action": 0.5,
        "rest_day": 5,
    }

    PAUSE_THRESHOLD = 30
    WARNING_THRESHOLD = 50

    def __init__(self, initial_score: int = 100):
        self.score = initial_score
        self.history: list[dict] = []
        self.paused = False

    def decrease(self, reason: str, amount: Optional[int] = None) -> int:
        """扣减健康度。"""
        delta = amount or self.PENALTIES.get(reason, 5)
        old_score = self.score
        self.score = max(self.MIN_SCORE, self.score - delta)
        self.history.append({
            "type": "decrease",
            "reason": reason,
            "amount": delta,
            "score_before": old_score,
            "score_after": self.score,
            "time": datetime.now(),
        })
        if self.score <= self.PAUSE_THRESHOLD:
            self.paused = True
        return self.score

    def recover(self, reason: str, amount: Optional[int] = None) -> int:
        """恢复健康度。"""
        delta = amount or self.RECOVERY.get(reason, 1)
        old_score = self.score
        self.score = min(self.MAX_SCORE, self.score + delta)
        self.history.append({
            "type": "recover",
            "reason": reason,
            "amount": delta,
            "score_before": old_score,
            "score_after": self.score,
            "time": datetime.now(),
        })
        if self.score > self.PAUSE_THRESHOLD:
            self.paused = False
        return self.score

    def get_status(self) -> str:
        if self.score <= self.PAUSE_THRESHOLD:
            return "paused"
        if self.score <= self.WARNING_THRESHOLD:
            return "warning"
        return "healthy"


def calculate_behavior_delay(action: str, health_score: int) -> float:
    """根据健康度计算行为延迟（健康度越低，延迟越长）。"""
    base_delays = {
        "like": 3.0,
        "collect": 2.0,
        "comment": 10.0,
        "follow": 5.0,
        "browse": 1.0,
    }
    base = base_delays.get(action, 3.0)
    # 健康度 < 80 时增加延迟
    if health_score < 80:
        multiplier = 1 + (80 - health_score) / 20  # 1.0 ~ 5.0
    else:
        multiplier = 1.0
    jitter = random.uniform(0.8, 1.3)
    return round(base * multiplier * jitter, 2)


# ---------------------------------------------------------------------------
# Test cases
# ---------------------------------------------------------------------------

class TestFingerprintGeneration:
    """指纹生成。"""

    def test_generates_valid_fingerprint(self):
        fp = FingerprintGenerator.generate()
        assert fp.user_agent
        assert fp.viewport_width > 0
        assert fp.viewport_height > 0
        assert fp.timezone
        assert fp.language
        assert fp.fingerprint_id
        assert len(fp.fingerprint_id) == 32

    def test_to_dict(self):
        fp = FingerprintGenerator.generate()
        d = fp.to_dict()
        assert "user_agent" in d
        assert "viewport" in d
        assert "fingerprint_id" in d


class TestFingerprintConsistency:
    """指纹一致性。"""

    def test_same_input_same_id(self):
        fp = DeviceFingerprint(
            user_agent="test_ua",
            viewport_width=1920, viewport_height=1080,
            screen_width=1920, screen_height=1080,
            timezone="Asia/Shanghai", language="zh-CN",
            platform="Win32", webgl_vendor="test",
            webgl_renderer="test", canvas_hash="abc",
            audio_hash="def", fonts_hash="ghi",
            webrtc_ip="192.168.1.1",
        )
        id1 = fp.fingerprint_id
        id2 = fp.fingerprint_id
        assert id1 == id2

    def test_different_input_different_id(self):
        fp1 = FingerprintGenerator.generate()
        fp2 = FingerprintGenerator.generate()
        # 概率上几乎必然不同
        ids = {fp1.fingerprint_id, fp2.fingerprint_id}
        # 至少有一个不同的可能（随机性）
        assert len(ids) >= 1


class TestHealthScoreDecrease:
    """健康度扣减。"""

    def test_normal_decrease(self):
        mgr = HealthScoreManager()
        score = mgr.decrease("captcha")
        assert score == 90

    def test_multiple_decreases(self):
        mgr = HealthScoreManager()
        mgr.decrease("captcha")      # 100 -> 90
        mgr.decrease("too_fast_action")  # 90 -> 87
        mgr.decrease("captcha")      # 87 -> 77
        assert mgr.score == 77

    def test_custom_amount(self):
        mgr = HealthScoreManager()
        mgr.decrease("custom", amount=25)
        assert mgr.score == 75

    def test_minimum_zero(self):
        mgr = HealthScoreManager(initial_score=5)
        mgr.decrease("captcha")  # 5 - 10 = max(0, -5) = 0
        assert mgr.score == 0

    def test_history_recorded(self):
        mgr = HealthScoreManager()
        mgr.decrease("captcha")
        assert len(mgr.history) == 1
        assert mgr.history[0]["reason"] == "captcha"
        assert mgr.history[0]["amount"] == 10


class TestHealthScoreRecovery:
    """健康度恢复。"""

    def test_normal_recovery(self):
        mgr = HealthScoreManager(initial_score=50)
        score = mgr.recover("normal_browse")
        assert score == 51

    def test_rest_day_recovery(self):
        mgr = HealthScoreManager(initial_score=50)
        score = mgr.recover("rest_day")
        assert score == 55

    def test_maximum_100(self):
        mgr = HealthScoreManager(initial_score=99)
        mgr.recover("rest_day")  # 99 + 5 = min(100, 104) = 100
        assert mgr.score == 100


class TestAutoPauseLowHealth:
    """自动暂停。"""

    def test_pause_at_threshold(self):
        mgr = HealthScoreManager(initial_score=35)
        mgr.decrease("captcha")  # 35 - 10 = 25 <= 30
        assert mgr.paused
        assert mgr.get_status() == "paused"

    def test_resume_after_recovery(self):
        mgr = HealthScoreManager(initial_score=25)
        mgr.paused = True
        mgr.recover("rest_day")  # 25 + 5 = 30
        # 30 == threshold, not > threshold
        mgr.recover("rest_day")  # 30 + 5 = 35 > 30
        assert not mgr.paused
        assert mgr.get_status() == "warning"

    def test_warning_status(self):
        mgr = HealthScoreManager(initial_score=55)
        mgr.decrease("captcha")  # 55 - 10 = 45
        assert mgr.get_status() == "warning"

    def test_healthy_status(self):
        mgr = HealthScoreManager()
        assert mgr.get_status() == "healthy"


class TestBehaviorDelay:
    """行为延迟。"""

    def test_high_health_normal_delay(self):
        delay = calculate_behavior_delay("like", 100)
        assert 2.0 <= delay <= 5.0

    def test_low_health_longer_delay(self):
        high_delay = calculate_behavior_delay("like", 30)
        low_delay = calculate_behavior_delay("like", 100)
        # 健康度低时延迟应该更长（概率上）
        assert high_delay >= low_delay * 0.5  # 容忍随机抖动

    def test_comment_always_longer_than_like(self):
        comment_delays = [calculate_behavior_delay("comment", 100) for _ in range(20)]
        like_delays = [calculate_behavior_delay("like", 100) for _ in range(20)]
        assert min(comment_delays) > min(like_delays)

    def test_jitter_variability(self):
        delays = [calculate_behavior_delay("like", 100) for _ in range(50)]
        assert max(delays) > min(delays)  # 有变化

    def test_zero_health_max_delay(self):
        delay = calculate_behavior_delay("like", 0)
        assert delay > 10  # 非常长的延迟
