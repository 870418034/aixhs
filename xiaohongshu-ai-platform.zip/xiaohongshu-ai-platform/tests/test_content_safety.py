"""内容安全测试：安全内容、违禁内容、高风险内容、AI审核、去AI化、完整流水线。"""

from __future__ import annotations

import json
import re
from dataclasses import dataclass
from enum import Enum
from typing import Any, Dict, List, Optional
from unittest.mock import AsyncMock, MagicMock

import pytest


# ---------------------------------------------------------------------------
# ContentSafety 实现（纯逻辑）
# ---------------------------------------------------------------------------

class RiskLevel(str, Enum):
    SAFE = "safe"
    MODERATE = "moderate"
    HIGH_RISK = "high_risk"
    BANNED = "banned"


@dataclass
class SafetyResult:
    risk_level: RiskLevel
    score: float  # 0-10, 10=最安全
    passed: bool
    details: Dict[str, Any]
    suggestions: List[str]


# 违禁词列表
BANNED_WORDS = [
    "代购", "兼职刷单", "赌博", "色情", "暴力", "毒品",
    "枪支", "假货", "传销", "诈骗", "高利贷",
]

# 高风险词
HIGH_RISK_WORDS = [
    "赚钱", "暴利", "躺赚", "日入过万", "月入百万",
    "减肥药", "壮阳", "丰胸",
]

# 绝对化用语
ABSOLUTE_WORDS = [
    "最好", "第一", "绝对", "100%", "全网最低", "史上最",
    "国家级", "世界级", "顶级", "最佳", "最高级",
]

# AI痕迹特征
AI_PATTERNS = [
    (r'(首先|其次|再次|最后|总之|综上所述)', "排比式连接词"),
    (r'(值得注意的是|需要指出的是|不可否认)', "书面过渡语"),
    (r'(在当今社会|在现代生活中|随着.{2,6}的发展)', "套话开头"),
    (r'(至关重要|不可或缺|举足轻重)', "过度书面化"),
    (r'(让我们|让我们一起)', "号召式表达"),
]


def check_banned_words(text: str) -> List[Dict[str, str]]:
    """违禁词检测。"""
    found = []
    for word in BANNED_WORDS:
        pos = text.find(word)
        if pos != -1:
            found.append({"word": word, "position": pos})
    return found


def check_high_risk_words(text: str) -> List[Dict[str, str]]:
    """高风险词检测。"""
    found = []
    for word in HIGH_RISK_WORDS:
        pos = text.find(word)
        if pos != -1:
            found.append({"word": word, "position": pos})
    return found


def check_absolute_words(text: str) -> List[str]:
    """绝对化用语检测。"""
    return [w for w in ABSOLUTE_WORDS if w in text]


def check_drainage(text: str) -> Dict[str, Any]:
    """引流检测。"""
    wechat = re.findall(
        r'(?:微信|wx|wechat)[：:\s]*[a-zA-Z0-9_-]{5,20}|'
        r'(?:加我|私我|联系我).{0,10}(?:微信|wx)',
        text, re.IGNORECASE,
    )
    qq = re.findall(r'(?:QQ|qq)[：:\s]*\d{5,11}', text)
    phone = re.findall(r'1[3-9]\d{9}', text)
    urls = re.findall(r'https?://[^\s]+', text)

    detected = bool(wechat or qq or phone or urls)
    return {
        "detected": detected,
        "wechat": wechat,
        "qq": qq,
        "phone": phone,
        "urls": urls,
    }


def detect_ai_trace(text: str) -> Dict[str, Any]:
    """AI痕迹检测。"""
    traces = []
    for pattern, desc in AI_PATTERNS:
        matches = re.findall(pattern, text)
        if matches:
            traces.append({"type": desc, "matches": matches[:3]})

    # 检查句式整齐度
    sentences = re.split(r'[。！？\n]', text)
    sentences = [s.strip() for s in sentences if len(s.strip()) > 5]
    if len(sentences) >= 4:
        lengths = [len(s) for s in sentences[:8]]
        avg = sum(lengths) / len(lengths)
        variance = sum((l - avg) ** 2 for l in lengths) / len(lengths)
        if variance < 5:  # 句式过于整齐
            traces.append({"type": "句式过于整齐", "variance": round(variance, 2)})

    detected = len(traces) >= 2
    return {"detected": detected, "traces": traces}


def dehumanize_suggestions(ai_result: Dict[str, Any]) -> List[str]:
    """去AI化建议。"""
    suggestions = []
    for trace in ai_result.get("traces", []):
        t = trace["type"]
        if "排比" in t:
            suggestions.append("减少排比句式，用更口语化的过渡")
        if "书面" in t:
            suggestions.append("替换书面用语为口语表达")
        if "套话" in t:
            suggestions.append("用个人经历或具体场景替代套话开头")
        if "号召" in t:
            suggestions.append("用提问式结尾替代号召式表达")
        if "整齐" in t:
            suggestions.append("长短句交替，增加口语化短句")
    return suggestions


def full_safety_pipeline(title: str, body: str) -> SafetyResult:
    """完整安全审核流水线。"""
    text = f"{title} {body}"
    suggestions = []
    score = 10.0

    # 1. 违禁词
    banned = check_banned_words(text)
    if banned:
        return SafetyResult(
            risk_level=RiskLevel.BANNED,
            score=0.0,
            passed=False,
            details={"banned_words": banned},
            suggestions=[f"删除违禁词：{', '.join(w['word'] for w in banned)}"],
        )

    # 2. 高风险词
    high_risk = check_high_risk_words(text)
    if high_risk:
        score -= len(high_risk) * 1.5
        suggestions.append(f"考虑替换高风险词：{', '.join(w['word'] for w in high_risk)}")

    # 3. 绝对化用语
    absolute = check_absolute_words(text)
    if absolute:
        score -= len(absolute) * 0.5
        suggestions.append(f"软化绝对化用语：{', '.join(absolute)}")

    # 4. 引流检测
    drainage = check_drainage(text)
    if drainage["detected"]:
        score -= 3.0
        suggestions.append("移除引流信息（微信号/QQ号/外链）")

    # 5. AI痕迹
    ai = detect_ai_trace(text)
    if ai["detected"]:
        score -= 1.5
        suggestions.extend(dehumanize_suggestions(ai))

    score = max(0.0, min(10.0, score))

    if score >= 7:
        level = RiskLevel.SAFE
    elif score >= 4:
        level = RiskLevel.MODERATE
    else:
        level = RiskLevel.HIGH_RISK

    return SafetyResult(
        risk_level=level,
        score=round(score, 1),
        passed=level in (RiskLevel.SAFE, RiskLevel.MODERATE),
        details={
            "banned_words": banned,
            "high_risk_words": high_risk,
            "absolute_words": absolute,
            "drainage": drainage,
            "ai_trace": ai,
        },
        suggestions=suggestions,
    )


# ---------------------------------------------------------------------------
# Test cases
# ---------------------------------------------------------------------------

class TestSafeContent:
    """安全内容通过。"""

    def test_normal_content_passes(self):
        title = "分享我的早餐搭配 🍳"
        body = (
            "最近迷上了做早餐！每天早起15分钟就能搞定～\n\n"
            "今天做的是牛油果吐司+水煮蛋+一杯燕麦奶 ☕\n"
            "做法超简单：吐司烤一下，牛油果切片铺上去，撒点盐和黑胡椒就OK了！\n\n"
            "姐妹们平时早餐都吃什么呀？评论区交流一下 👇"
        )
        result = full_safety_pipeline(title, body)
        assert result.passed
        assert result.risk_level == RiskLevel.SAFE
        assert result.score >= 7.0

    def test_content_with_emoji_passes(self):
        title = "5个超实用的收纳技巧 ✨"
        body = "今天整理了衣柜，用了这些方法空间翻倍！👕👖👗"
        result = full_safety_pipeline(title, body)
        assert result.passed


class TestBannedContent:
    """违禁内容拦截。"""

    def test_banned_word_detected(self):
        title = "靠谱代购推荐"
        body = "这个代购渠道价格超低"
        result = full_safety_pipeline(title, body)
        assert result.risk_level == RiskLevel.BANNED
        assert not result.passed
        assert result.score == 0.0

    def test_multiple_banned_words(self):
        title = "代购赌博一条龙"
        body = "色情内容也有哦"
        result = full_safety_pipeline(title, body)
        assert result.risk_level == RiskLevel.BANNED
        assert len(result.details["banned_words"]) >= 3

    def test_banned_in_body_only(self):
        title = "日常分享"
        body = "有人兼职刷单吗？日入过千"
        result = full_safety_pipeline(title, body)
        assert result.risk_level == RiskLevel.BANNED


class TestHighRiskContent:
    """高风险内容。"""

    def test_high_risk_words(self):
        title = "日入过万的方法"
        body = "躺赚项目分享，月入百万不是梦"
        result = full_safety_pipeline(title, body)
        assert result.score < 7.0
        assert len(result.suggestions) > 0

    def test_absolute_words_reduce_score(self):
        title = "全网最好用的产品"
        body = "这是最好的，绝对是第一，100%有效"
        result = full_safety_pipeline(title, body)
        assert result.score < 10.0


class TestAIReviewFlow:
    """AI审核流程。"""

    def test_ai_trace_detected(self):
        text = (
            "首先，我们需要了解背景。其次，分析问题所在。"
            "再次，提出解决方案。最后，总结要点。"
            "值得注意的是，在当今社会中，这至关重要。"
        )
        result = detect_ai_trace(text)
        assert result["detected"]
        assert len(result["traces"]) >= 2

    def test_human_like_text_no_trace(self):
        text = "今天去逛街啦！买了件超好看的衣服，打折只要99块～开心！"
        result = detect_ai_trace(text)
        assert not result["detected"]

    def test_dehumanize_suggestions(self):
        ai_result = {
            "traces": [
                {"type": "排比式连接词", "matches": ["首先", "其次"]},
                {"type": "书面过渡语", "matches": ["值得注意的是"]},
                {"type": "句式过于整齐", "variance": 2.5},
            ]
        }
        suggestions = dehumanize_suggestions(ai_result)
        assert len(suggestions) >= 3


class TestDehumanizeFlow:
    """去AI化流程。"""

    def test_suggestions_for_ai_content(self):
        text = "首先，我们需要思考。其次，需要行动。最后，需要总结。"
        ai = detect_ai_trace(text)
        suggestions = dehumanize_suggestions(ai)
        assert any("排比" in s for s in suggestions)

    def test_no_suggestions_for_human_content(self):
        text = "哈哈今天太搞笑了，我同事居然把咖啡倒进了键盘里！"
        ai = detect_ai_trace(text)
        suggestions = dehumanize_suggestions(ai)
        assert len(suggestions) == 0


class TestFullPipeline:
    """完整pipeline。"""

    def test_safe_content_full_pipeline(self):
        result = full_safety_pipeline(
            "周末去公园野餐了 🌳",
            "带上自制三明治和水果，铺个毯子晒太阳，太惬意了～推荐大家周末也出去走走 ☀️",
        )
        assert result.passed
        assert result.risk_level == RiskLevel.SAFE
        assert result.score >= 8.0

    def test_banned_blocks_pipeline(self):
        result = full_safety_pipeline("代购好物", "推荐一个代购渠道")
        assert not result.passed
        assert result.risk_level == RiskLevel.BANNED

    def test_pipeline_with_drainage(self):
        result = full_safety_pipeline(
            "好物分享",
            "想了解的加我微信 abc123456 哦",
        )
        assert result.score < 8.0
        assert result.details["drainage"]["detected"]

    def test_pipeline_scoring(self):
        # 完美内容
        perfect = full_safety_pipeline("好物推荐 🌸", "真的太好用了，分享给姐妹们！")
        # 有绝对化用语的内容
        with_absolute = full_safety_pipeline("最好用的产品", "这是最好的，绝对是第一")
        assert perfect.score > with_absolute.score
