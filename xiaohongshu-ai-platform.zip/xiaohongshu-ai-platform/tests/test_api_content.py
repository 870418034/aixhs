"""内容 API 测试：生成、列表、更新、发布、定时、重新生成、版本管理。"""

from __future__ import annotations

import json
from datetime import datetime, timedelta
from unittest.mock import AsyncMock, MagicMock, patch

import pytest
import pytest_asyncio
from sqlalchemy import select, func
from sqlalchemy.ext.asyncio import AsyncSession

from app.models import (
    Account,
    Content,
    ContentStatus,
    ContentType,
    ContentVersion,
)


# ---------------------------------------------------------------------------
# Content Service 实现（简化版）
# ---------------------------------------------------------------------------

class ContentService:
    """内容 CRUD 服务。"""

    async def create_content(
        self, db: AsyncSession, account_id: int,
        title: str = "", body: str = "", topic: str = "",
        content_type: str = "note",
    ) -> dict:
        ct = ContentType.note if content_type == "note" else ContentType.video
        content = Content(
            account_id=account_id,
            title=title,
            body=body,
            topic=topic,
            content_type=ct,
            status=ContentStatus.draft,
        )
        db.add(content)
        await db.flush()
        await db.refresh(content)
        return {"id": content.id, "title": content.title, "status": content.status.value}

    async def list_contents(
        self, db: AsyncSession, account_id: int,
        page: int = 1, size: int = 20,
    ) -> dict:
        query = select(Content).where(Content.account_id == account_id)
        total = (await db.execute(select(func.count()).select_from(query.subquery()))).scalar() or 0
        query = query.order_by(Content.created_at.desc()).offset((page - 1) * size).limit(size)
        rows = (await db.execute(query)).scalars().all()
        items = [
            {
                "id": c.id, "title": c.title, "status": c.status.value,
                "content_type": c.content_type.value,
                "views": c.views, "likes": c.likes,
            }
            for c in rows
        ]
        return {"items": items, "total": total, "page": page, "page_size": size}

    async def update_content(self, db: AsyncSession, content_id: int, data: dict) -> bool:
        content = await db.get(Content, content_id)
        if not content:
            return False
        for key, value in data.items():
            if hasattr(content, key) and key not in ("id", "created_at"):
                setattr(content, key, value)
        await db.flush()
        return True

    async def publish_content(self, db: AsyncSession, content_id: int) -> bool:
        content = await db.get(Content, content_id)
        if not content:
            return False
        content.status = ContentStatus.published
        content.published_at = datetime.utcnow()
        await db.flush()
        return True

    async def schedule_content(self, db: AsyncSession, content_id: int, publish_time: datetime) -> bool:
        content = await db.get(Content, content_id)
        if not content:
            return False
        content.status = ContentStatus.scheduled
        content.scheduled_at = publish_time
        await db.flush()
        return True

    async def create_version(self, db: AsyncSession, content_id: int) -> dict:
        content = await db.get(Content, content_id)
        if not content:
            return {}
        # 获取当前最大版本号
        result = await db.execute(
            select(func.max(ContentVersion.version))
            .where(ContentVersion.content_id == content_id)
        )
        max_ver = result.scalar() or 0
        version = ContentVersion(
            content_id=content_id,
            version=max_ver + 1,
            title=content.title,
            body=content.body,
            tags=content.tags,
            images=content.images,
        )
        db.add(version)
        await db.flush()
        await db.refresh(version)
        return {"id": version.id, "version": version.version}

    async def get_versions(self, db: AsyncSession, content_id: int) -> list[dict]:
        result = await db.execute(
            select(ContentVersion)
            .where(ContentVersion.content_id == content_id)
            .order_by(ContentVersion.version.desc())
        )
        versions = result.scalars().all()
        return [{"id": v.id, "version": v.version, "title": v.title} for v in versions]


content_service = ContentService()


# ---------------------------------------------------------------------------
# Test cases
# ---------------------------------------------------------------------------

@pytest.mark.asyncio
class TestGenerateContent:
    """生成内容。"""

    async def test_create_draft(self, test_db_session: AsyncSession, sample_account):
        result = await content_service.create_content(
            test_db_session,
            account_id=sample_account.id,
            title="测试笔记",
            body="这是一篇测试笔记的内容",
            topic="测试",
        )
        assert result["id"] is not None
        assert result["status"] == "draft"

    async def test_create_with_topic(self, test_db_session: AsyncSession, sample_account):
        result = await content_service.create_content(
            test_db_session,
            account_id=sample_account.id,
            title="护肤分享",
            topic="护肤",
        )
        assert result["id"] is not None


@pytest.mark.asyncio
class TestListContents:
    """列表。"""

    async def test_list_empty(self, test_db_session: AsyncSession, sample_account):
        result = await content_service.list_contents(test_db_session, sample_account.id)
        assert result["total"] == 0

    async def test_list_with_contents(self, test_db_session: AsyncSession, sample_account):
        for i in range(3):
            await content_service.create_content(
                test_db_session, sample_account.id, title=f"笔记{i+1}"
            )
        result = await content_service.list_contents(test_db_session, sample_account.id)
        assert result["total"] == 3
        assert len(result["items"]) == 3

    async def test_list_pagination(self, test_db_session: AsyncSession, sample_account):
        for i in range(5):
            await content_service.create_content(
                test_db_session, sample_account.id, title=f"笔记{i+1}"
            )
        page1 = await content_service.list_contents(test_db_session, sample_account.id, page=1, size=2)
        assert len(page1["items"]) == 2


@pytest.mark.asyncio
class TestUpdateContent:
    """更新。"""

    async def test_update_title(self, test_db_session: AsyncSession, sample_content):
        ok = await content_service.update_content(
            test_db_session, sample_content.id, {"title": "新标题"}
        )
        assert ok

    async def test_update_nonexistent(self, test_db_session: AsyncSession):
        ok = await content_service.update_content(test_db_session, 99999, {"title": "无"})
        assert not ok


@pytest.mark.asyncio
class TestPublishContent:
    """发布。"""

    async def test_publish_draft(self, test_db_session: AsyncSession, sample_content):
        ok = await content_service.publish_content(test_db_session, sample_content.id)
        assert ok
        content = await test_db_session.get(Content, sample_content.id)
        assert content.status == ContentStatus.published
        assert content.published_at is not None

    async def test_publish_nonexistent(self, test_db_session: AsyncSession):
        ok = await content_service.publish_content(test_db_session, 99999)
        assert not ok


@pytest.mark.asyncio
class TestScheduleContent:
    """定时发布。"""

    async def test_schedule_content(self, test_db_session: AsyncSession, sample_content):
        future = datetime.utcnow() + timedelta(hours=4)
        ok = await content_service.schedule_content(test_db_session, sample_content.id, future)
        assert ok
        content = await test_db_session.get(Content, sample_content.id)
        assert content.status == ContentStatus.scheduled
        assert content.scheduled_at is not None

    async def test_schedule_past_time(self, test_db_session: AsyncSession, sample_content):
        past = datetime.utcnow() - timedelta(hours=1)
        ok = await content_service.schedule_content(test_db_session, sample_content.id, past)
        assert ok  # 逻辑上仍可设置，由调度器决定是否执行


@pytest.mark.asyncio
class TestRegenerate:
    """重新生成（创建新版本）。"""

    async def test_create_version(self, test_db_session: AsyncSession, sample_content):
        result = await content_service.create_version(test_db_session, sample_content.id)
        assert result["version"] == 1

    async def test_multiple_versions(self, test_db_session: AsyncSession, sample_content):
        v1 = await content_service.create_version(test_db_session, sample_content.id)
        # 修改内容
        await content_service.update_content(
            test_db_session, sample_content.id,
            {"title": "修改后的标题", "body": "修改后的内容"},
        )
        v2 = await content_service.create_version(test_db_session, sample_content.id)
        assert v2["version"] == 2


@pytest.mark.asyncio
class TestVersionManagement:
    """版本管理。"""

    async def test_get_versions(self, test_db_session: AsyncSession, sample_content):
        await content_service.create_version(test_db_session, sample_content.id)
        await content_service.create_version(test_db_session, sample_content.id)
        versions = await content_service.get_versions(test_db_session, sample_content.id)
        assert len(versions) == 2
        assert versions[0]["version"] == 2  # 降序

    async def test_version_tracks_content(self, test_db_session: AsyncSession, sample_content):
        await content_service.update_content(
            test_db_session, sample_content.id, {"title": "v2标题"}
        )
        await content_service.create_version(test_db_session, sample_content.id)
        versions = await content_service.get_versions(test_db_session, sample_content.id)
        assert versions[0]["title"] == "v2标题"
