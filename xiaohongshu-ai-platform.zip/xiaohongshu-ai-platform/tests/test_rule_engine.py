"""规则引擎测试：敏感词检测、引流检测、格式检查、综合判定。"""

from __future__ import annotations

import re
import pytest

from app.core.sensitive_words import SensitiveWordManager, WORD_CATEGORIES


# ---------------------------------------------------------------------------
# Helpers — 规则引擎纯逻辑（不依赖外部服务）
# ---------------------------------------------------------------------------

# 敏感词库（从文件或手动加载）
_SENSITIVE_WORDS = {
    "代购": "financial",
    "兼职刷单": "financial",
    "赌博": "financial",
    "色情": "sexual",
    "暴力": "violent",
}

# 绝对化用语
_ABSOLUTE_WORDS = [
    "最好", "第一", "绝对", "100%", "全网最低", "史上最",
    "国家级", "世界级", "顶级", "极品", "最佳", "最高级",
]

# 微信号正则
_WECHAT_REGEX = re.compile(
    r'(?:微信|wx|wechat|weixin)[：:\s]*[a-zA-Z0-9_-]{5,20}|'
    r'(?:加我|私我|联系我).{0,10}(?:微信|wx)|'
    r'\b[a-zA-Z][a-zA-Z0-9_-]{5,19}\b.*?(?:微信|wx)'
)

# QQ号正则
_QQ_REGEX = re.compile(
    r'(?:QQ|qq|企鹅)[：:\s]*\d{5,11}|'
    r'\b[1-9][0-9]{4,10}\b.*?(?:QQ|qq)'
)

# 外链正则
_URL_REGEX = re.compile(
    r'https?://[^\s<>]+|'
    r'(?:淘宝|京东|拼多多|抖音|微博)\.[a-z]+|'
    r'www\.[^\s<>]+'
)

# 手机号正则
_PHONE_REGEX = re.compile(r'1[3-9]\d9[\s-]?\d{4}[\s-]?\d{4}')


def check_sensitive_words(text: str) -> list[dict]:
    """检测敏感词。"""
    results = []
    for word, category in _SENSITIVE_WORDS.items():
        pos = text.find(word)
        if pos != -1:
            results.append({"word": word, "category": category, "position": pos})
    return results


def check_wechat(text: str) -> list[dict]:
    """检测微信号/引流。"""
    results = []
    for m in _WECHAT_REGEX.finditer(text):
        results.append({"type": "wechat", "match": m.group(), "position": m.start()})
    return results


def check_qq(text: str) -> list[dict]:
    """检测QQ号。"""
    results = []
    for m in _QQ_REGEX.finditer(text):
        results.append({"type": "qq", "match": m.group(), "position": m.start()})
    return results


def check_urls(text: str) -> list[dict]:
    """检测外链。"""
    results = []
    for m in _URL_REGEX.finditer(text):
        results.append({"type": "url", "match": m.group(), "position": m.start()})
    return results


def check_absolute_words(text: str) -> list[str]:
    """检测绝对化用语。"""
    found = []
    for word in _ABSOLUTE_WORDS:
        if word in text:
            found.append(word)
    return found


def check_emoji_ratio(text: str) -> dict:
    """检查emoji比例。"""
    import unicodedata
    emoji_count = 0
    total_chars = 0
    for ch in text:
        if ch.isspace():
            continue
        total_chars += 1
        cat = unicodedata.category(ch)
        cp = ord(ch)
        if cat.startswith('So') or cat.startswith('Sk') or cp > 0x1F000:
            emoji_count += 1
    ratio = emoji_count / max(total_chars, 1)
    return {
        "emoji_count": emoji_count,
        "total_chars": total_chars,
        "ratio": round(ratio, 4),
        "too_many": ratio > 0.3,
        "too_few": ratio < 0.01 and total_chars > 50,
    }


def check_repeated_chars(text: str, max_repeat: int = 5) -> list[dict]:
    """检查重复字符。"""
    results = []
    pattern = re.compile(r'(.)\1{' + str(max_repeat) + r',}')
    for m in pattern.finditer(text):
        results.append({"char": m.group()[0], "count": len(m.group()), "position": m.start()})
    return results


def check_word_count(text: str, min_words: int = 50, max_words: int = 2000) -> dict:
    """检查字数。"""
    clean = re.sub(r'\s+', '', text)
    count = len(clean)
    return {
        "word_count": count,
        "too_short": count < min_words,
        "too_long": count > max_words,
        "in_range": min_words <= count <= max_words,
    }


def overall_risk_level(text: str) -> str:
    """综合风险判定。"""
    sensitive = check_sensitive_words(text)
    wechat = check_wechat(text)
    qq = check_qq(text)
    urls = check_urls(text)
    absolute = check_absolute_words(text)

    # Banned: 敏感词 or 引流
    if sensitive:
        return "banned"
    if wechat or qq:
        return "banned"

    # High risk: 外链 or 绝对化用语
    if urls or len(absolute) >= 3:
        return "high_risk"

    # Moderate: 1-2个绝对化用语
    if absolute:
        return "moderate"

    return "safe"


# ---------------------------------------------------------------------------
# Test cases
# ---------------------------------------------------------------------------

class TestSensitiveWordDetection:
    """敏感词检测。"""

    def test_detects_sensitive_word(self):
        text = "这个代购渠道非常靠谱"
        results = check_sensitive_words(text)
        assert len(results) == 1
        assert results[0]["word"] == "代购"
        assert results[0]["category"] == "financial"

    def test_no_sensitive_word(self):
        text = "今天天气真好，出去逛街了"
        results = check_sensitive_words(text)
        assert len(results) == 0

    def test_multiple_sensitive_words(self):
        text = "代购兼职刷单赌博一条龙"
        results = check_sensitive_words(text)
        assert len(results) == 3
        words = {r["word"] for r in results}
        assert "代购" in words
        assert "兼职刷单" in words
        assert "赌博" in words

    def test_sensitive_word_position(self):
        text = "我来代购一些好东西"
        results = check_sensitive_words(text)
        assert results[0]["position"] == 2


class TestRegexWechatDetection:
    """微信号检测。"""

    def test_detects_wechat_keyword(self):
        text = "想了解的加我微信：abc123"
        results = check_wechat(text)
        assert len(results) >= 1

    def test_detects_wx_keyword(self):
        text = "私我wx聊聊 detail_user"
        results = check_wechat(text)
        assert len(results) >= 1

    def test_no_wechat(self):
        text = "今天分享一个超好用的护肤方法"
        results = check_wechat(text)
        assert len(results) == 0


class TestRegexQQDetection:
    """QQ号检测。"""

    def test_detects_qq_keyword(self):
        text = "有兴趣加QQ：123456789"
        results = check_qq(text)
        assert len(results) >= 1

    def test_no_qq(self):
        text = "这是一篇正常的小红书笔记"
        results = check_qq(text)
        assert len(results) == 0


class TestRegexURLDetection:
    """外链检测。"""

    def test_detects_http_url(self):
        text = "详情看这里 https://example.com/page"
        results = check_urls(text)
        assert len(results) >= 1

    def test_detects_www_url(self):
        text = "去 www.taobao.com 看看"
        results = check_urls(text)
        assert len(results) >= 1

    def test_no_url(self):
        text = "纯粹的文字分享没有任何链接"
        results = check_urls(text)
        assert len(results) == 0


class TestAbsoluteWordDetection:
    """绝对化用语检测。"""

    def test_detects_absolute_words(self):
        text = "这是全网最低价的最好产品"
        found = check_absolute_words(text)
        assert "全网最低" in found
        assert "最好" in found

    def test_no_absolute_words(self):
        text = "分享一下我用过还不错的产品"
        found = check_absolute_words(text)
        assert len(found) == 0

    def test_single_absolute_word(self):
        text = "这绝对是我今年买过最值的东西"
        found = check_absolute_words(text)
        assert "绝对" in found


class TestFormatCheckEmojiRatio:
    """Emoji比例检查。"""

    def test_normal_emoji_ratio(self):
        text = "今天天气真好 ☀️ 出去逛街了 🛍️ 买了很多好东西 💕"
        result = check_emoji_ratio(text)
        assert not result["too_many"]
        assert not result["too_few"]

    def test_too_many_emoji(self):
        text = "🎉🎊✨💕🌸🍀🌈🦋🎪🎭🎨🎬🎮🎯" * 3
        result = check_emoji_ratio(text)
        assert result["too_many"]

    def test_no_emoji(self):
        text = "这是一段完全没有emoji的文字" * 5
        result = check_emoji_ratio(text)
        assert result["too_few"]


class TestFormatCheckRepeatedChars:
    """重复字符检查。"""

    def test_detects_repeated_chars(self):
        text = "太好用了吧！！！！！！！！"
        results = check_repeated_chars(text, max_repeat=5)
        assert len(results) >= 1
        assert results[0]["char"] == "！"

    def test_no_repeated_chars(self):
        text = "正常的文章内容"
        results = check_repeated_chars(text)
        assert len(results) == 0


class TestFormatCheckWordCount:
    """字数检查。"""

    def test_too_short(self):
        text = "好"
        result = check_word_count(text, min_words=50)
        assert result["too_short"]
        assert not result["in_range"]

    def test_normal_length(self):
        text = "这是一篇正常长度的小红书笔记，分享我的日常生活和一些小经验。" * 3
        result = check_word_count(text)
        assert result["in_range"]

    def test_too_long(self):
        text = "很长的内容" * 500
        result = check_word_count(text, max_words=2000)
        assert result["too_long"]


class TestOverallBanned:
    """综合判定 banned。"""

    def test_banned_by_sensitive_word(self):
        text = "这个代购渠道靠谱"
        level = overall_risk_level(text)
        assert level == "banned"

    def test_banned_by_wechat(self):
        text = "想了解的加我微信 abc123def"
        level = overall_risk_level(text)
        assert level == "banned"

    def test_banned_by_qq(self):
        text = "有兴趣加QQ：123456789 详细聊"
        level = overall_risk_level(text)
        assert level == "banned"


class TestOverallHighRisk:
    """综合判定 high_risk。"""

    def test_high_risk_by_url(self):
        text = "详情见 https://example.com/page 哦"
        level = overall_risk_level(text)
        assert level == "high_risk"

    def test_high_risk_by_multiple_absolute(self):
        text = "这是最好 最绝对 全网最低的顶级产品"
        level = overall_risk_level(text)
        assert level in ("high_risk", "moderate")


class TestOverallSafe:
    """综合判定 safe。"""

    def test_safe_content(self):
        text = "今天分享一个超好用的护肤方法！坚持了一周皮肤真的变好了很多～姐妹们可以试试看，每天早晚认真洗脸，涂好水乳，注意防晒就好啦 ☀️"
        level = overall_risk_level(text)
        assert level == "safe"

    def test_safe_with_single_absolute(self):
        text = "这个绝对是我今年用过最好用的面霜之一" * 2
        level = overall_risk_level(text)
        assert level in ("safe", "moderate")


# ---------------------------------------------------------------------------
# SensitiveWordManager 集成测试
# ---------------------------------------------------------------------------

class TestSensitiveWordManager:
    """SensitiveWordManager 单例测试。"""

    def test_singleton(self):
        m1 = SensitiveWordManager()
        m2 = SensitiveWordManager()
        assert m1 is m2

    def test_add_custom_words(self):
        manager = SensitiveWordManager()
        count = manager.add_custom_words({"测试敏感词": "political"})
        assert count == 1
        results = manager.check("包含测试敏感词的文本")
        assert any(r["word"] == "测试敏感词" for r in results)

    def test_add_invalid_category(self):
        manager = SensitiveWordManager()
        count = manager.add_custom_words({"无效词": "invalid_category"})
        assert count == 0

    def test_check_empty_text(self):
        manager = SensitiveWordManager()
        results = manager.check("")
        assert results == []

    def test_get_stats(self):
        manager = SensitiveWordManager()
        stats = manager.get_stats()
        assert "total" in stats
        for cat in WORD_CATEGORIES:
            assert cat in stats
