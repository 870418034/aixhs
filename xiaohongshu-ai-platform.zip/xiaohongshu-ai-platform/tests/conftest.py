"""Pytest 公共 fixtures。"""

from __future__ import annotations

import asyncio
import uuid
from datetime import datetime
from typing import AsyncGenerator, Generator
from unittest.mock import AsyncMock, MagicMock, patch

import pytest
import pytest_asyncio
from sqlalchemy import event
from sqlalchemy.ext.asyncio import (
    AsyncEngine,
    AsyncSession,
    async_sessionmaker,
    create_async_engine,
)

from app.database import Base
from app.models import (
    Account,
    AccountStatus,
    Content,
    ContentStatus,
    ContentType,
    OperationStatus,
    Task,
    TaskStatus,
    TaskType,
)


# ---------------------------------------------------------------------------
# Event loop
# ---------------------------------------------------------------------------

@pytest.fixture(scope="session")
def event_loop() -> Generator:
    """Session-scoped event loop for async tests."""
    loop = asyncio.new_event_loop()
    yield loop
    loop.close()


# ---------------------------------------------------------------------------
# Test DB (in-memory SQLite)
# ---------------------------------------------------------------------------

@pytest_asyncio.fixture
async def test_db_session() -> AsyncGenerator[AsyncSession, None]:
    """创建内存 SQLite 测试数据库 session。"""
    engine = create_async_engine(
        "sqlite+aiosqlite:///:memory:",
        echo=False,
        future=True,
    )

    @event.listens_for(engine.sync_engine, "connect")
    def _set_sqlite_pragma(dbapi_conn, connection_record):
        cursor = dbapi_conn.cursor()
        cursor.execute("PRAGMA foreign_keys=ON")
        cursor.close()

    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)

    session_factory = async_sessionmaker(engine, class_=AsyncSession, expire_on_commit=False)
    async with session_factory() as session:
        yield session

    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.drop_all)
    await engine.dispose()


# ---------------------------------------------------------------------------
# FastAPI TestClient
# ---------------------------------------------------------------------------

@pytest.fixture
def test_client():
    """创建 FastAPI TestClient（如果 app 可用）。"""
    try:
        from fastapi.testclient import TestClient
        from app.main import app
        with TestClient(app) as client:
            yield client
    except ImportError:
        pytest.skip("FastAPI app not available")


# ---------------------------------------------------------------------------
# Mock AI Service
# ---------------------------------------------------------------------------

@pytest.fixture
def mock_ai_service():
    """Mock 的 AIService。"""
    mock = MagicMock()
    mock.call = AsyncMock(return_value='{"score": 8, "assessment": "良好"}')
    mock.parse_json_response = MagicMock(return_value={"score": 8, "assessment": "良好"})
    mock.estimate_cost = MagicMock(return_value=0.001)
    mock.test_connection = AsyncMock(return_value=True)
    return mock


# ---------------------------------------------------------------------------
# Mock Browser
# ---------------------------------------------------------------------------

@pytest.fixture
def mock_browser():
    """Mock 的浏览器操作。"""
    mock = MagicMock()
    mock.navigate = AsyncMock(return_value=True)
    mock.click = AsyncMock(return_value=True)
    mock.type_text = AsyncMock(return_value=True)
    mock.screenshot = AsyncMock(return_value=b"fake_screenshot")
    mock.get_page_content = AsyncMock(return_value="<html>test</html>")
    mock.close = AsyncMock()
    mock.search_notes = AsyncMock(return_value=[
        {"title": "测试笔记1", "likes": 100},
        {"title": "测试笔记2", "likes": 200},
    ])
    return mock


# ---------------------------------------------------------------------------
# Sample data fixtures
# ---------------------------------------------------------------------------

@pytest.fixture
def sample_account_data() -> dict:
    """示例账号数据。"""
    return {
        "nickname": "测试小红书",
        "xhs_id": "test_xhs_001",
        "avatar": "https://example.com/avatar.jpg",
        "bio": "分享生活点滴 🌸",
        "followers": 1500,
        "following": 300,
        "likes": 8000,
        "notes_count": 42,
        "status": AccountStatus.online,
        "operation_status": OperationStatus.running,
    }


@pytest_asyncio.fixture
async def sample_account(test_db_session: AsyncSession, sample_account_data: dict) -> Account:
    """创建示例账号。"""
    account = Account(**sample_account_data)
    test_db_session.add(account)
    await test_db_session.flush()
    await test_db_session.refresh(account)
    return account


@pytest.fixture
def sample_content_data(sample_account: Account) -> dict:
    """示例内容数据。"""
    return {
        "account_id": sample_account.id,
        "title": "3个让皮肤变好的小习惯 ✨",
        "body": "姐妹们！今天分享我坚持了半年的护肤小习惯...\n\n1️⃣ 早起一杯温水\n2️⃣ 每天涂防晒\n3️⃣ 晚上认真卸妆\n\n你们有什么好习惯？评论区聊聊👇",
        "content_type": ContentType.note,
        "status": ContentStatus.draft,
        "topic": "护肤习惯",
        "tags": "护肤,变美,好习惯",
    }


@pytest_asyncio.fixture
async def sample_content(test_db_session: AsyncSession, sample_account: Account) -> Content:
    """创建示例内容。"""
    content = Content(
        account_id=sample_account.id,
        title="3个让皮肤变好的小习惯 ✨",
        body="姐妹们！今天分享我坚持了半年的护肤小习惯...\n\n1️⃣ 早起一杯温水\n2️⃣ 每天涂防晒\n3️⃣ 晚上认真卸妆\n\n你们有什么好习惯？评论区聊聊👇",
        content_type=ContentType.note,
        status=ContentStatus.draft,
        topic="护肤习惯",
        tags="护肤,变美,好习惯",
    )
    test_db_session.add(content)
    await test_db_session.flush()
    await test_db_session.refresh(content)
    return content


@pytest_asyncio.fixture
async def sample_task(test_db_session: AsyncSession, sample_account: Account) -> Task:
    """创建示例任务。"""
    task = Task(
        account_id=sample_account.id,
        task_type=TaskType.browse,
        status=TaskStatus.pending,
        params='{"duration": 20}',
    )
    test_db_session.add(task)
    await test_db_session.flush()
    await test_db_session.refresh(task)
    return task


@pytest_asyncio.fixture
async def multiple_accounts(test_db_session: AsyncSession) -> list[Account]:
    """创建多个测试账号。"""
    accounts = []
    for i in range(5):
        account = Account(
            nickname=f"测试账号{i+1}",
            xhs_id=f"test_{i+1:03d}",
            followers=i * 100,
            likes=i * 500,
            notes_count=i * 10,
            status=AccountStatus.online if i % 2 == 0 else AccountStatus.offline,
            operation_status=OperationStatus.running if i % 3 == 0 else OperationStatus.idle,
        )
        test_db_session.add(account)
        accounts.append(account)
    await test_db_session.flush()
    for a in accounts:
        await test_db_session.refresh(a)
    return accounts
