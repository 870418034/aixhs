"""账号 API 测试：创建、列表、详情、更新、删除、启停运营、批量操作。"""

from __future__ import annotations

import pytest
import pytest_asyncio
from sqlalchemy import select, func
from sqlalchemy.ext.asyncio import AsyncSession

from app.models import Account, AccountStatus, OperationStatus
from app.services.account_service import account_service


# ---------------------------------------------------------------------------
# Test cases
# ---------------------------------------------------------------------------

@pytest.mark.asyncio
class TestCreateAccount:
    """创建账号。"""

    async def test_create_basic_account(self, test_db_session: AsyncSession):
        result = await account_service.create_account(test_db_session, nickname="新账号")
        assert result["id"] is not None
        assert result["nickname"] == "新账号"
        assert result["status"] == "offline"

    async def test_create_with_xhs_id(self, test_db_session: AsyncSession):
        result = await account_service.create_account(
            test_db_session, nickname="测试号", xhs_id="xhs_001"
        )
        assert result["id"] is not None

    async def test_create_empty_account(self, test_db_session: AsyncSession):
        result = await account_service.create_account(test_db_session)
        assert result["id"] is not None
        assert result["nickname"] == ""


@pytest.mark.asyncio
class TestListAccounts:
    """列表查询。"""

    async def test_list_empty(self, test_db_session: AsyncSession):
        result = await account_service.list_accounts(test_db_session)
        assert result["total"] == 0
        assert result["items"] == []

    async def test_list_with_accounts(self, test_db_session: AsyncSession, multiple_accounts):
        result = await account_service.list_accounts(test_db_session)
        assert result["total"] == 5
        assert len(result["items"]) == 5

    async def test_list_pagination(self, test_db_session: AsyncSession, multiple_accounts):
        page1 = await account_service.list_accounts(test_db_session, page=1, size=2)
        assert len(page1["items"]) == 2
        assert page1["total"] == 5

        page2 = await account_service.list_accounts(test_db_session, page=2, size=2)
        assert len(page2["items"]) == 2

        page3 = await account_service.list_accounts(test_db_session, page=3, size=2)
        assert len(page3["items"]) == 1

    async def test_list_filter_by_status(self, test_db_session: AsyncSession, multiple_accounts):
        result = await account_service.list_accounts(test_db_session, status="online")
        assert all(a["status"] == "online" for a in result["items"])

    async def test_list_search_by_keyword(self, test_db_session: AsyncSession, multiple_accounts):
        result = await account_service.list_accounts(test_db_session, keyword="测试账号1")
        assert result["total"] >= 1


@pytest.mark.asyncio
class TestGetAccount:
    """详情。"""

    async def test_get_existing_account(self, test_db_session: AsyncSession, sample_account):
        result = await account_service.get_account(test_db_session, sample_account.id)
        assert result is not None
        assert result["nickname"] == "测试小红书"
        assert result["followers"] == 1500

    async def test_get_nonexistent_account(self, test_db_session: AsyncSession):
        result = await account_service.get_account(test_db_session, 99999)
        assert result is None

    async def test_cookie_masked(self, test_db_session: AsyncSession):
        account = Account(nickname="安全测试", cookie="secret_cookie_value")
        test_db_session.add(account)
        await test_db_session.flush()
        result = await account_service.get_account(test_db_session, account.id)
        assert result["cookie"] == "***"


@pytest.mark.asyncio
class TestUpdateAccount:
    """更新。"""

    async def test_update_nickname(self, test_db_session: AsyncSession, sample_account):
        ok = await account_service.update_account(
            test_db_session, sample_account.id, {"nickname": "新昵称"}
        )
        assert ok
        result = await account_service.get_account(test_db_session, sample_account.id)
        assert result["nickname"] == "新昵称"

    async def test_update_nonexistent(self, test_db_session: AsyncSession):
        ok = await account_service.update_account(test_db_session, 99999, {"nickname": "无"})
        assert not ok

    async def test_update_multiple_fields(self, test_db_session: AsyncSession, sample_account):
        ok = await account_service.update_account(
            test_db_session, sample_account.id,
            {"bio": "新简介", "followers": 2000, "likes": 10000},
        )
        assert ok
        result = await account_service.get_account(test_db_session, sample_account.id)
        assert result["bio"] == "新简介"
        assert result["followers"] == 2000


@pytest.mark.asyncio
class TestDeleteAccount:
    """删除。"""

    async def test_delete_existing(self, test_db_session: AsyncSession, sample_account):
        account_id = sample_account.id
        ok = await account_service.delete_account(test_db_session, account_id)
        assert ok
        result = await account_service.get_account(test_db_session, account_id)
        assert result is None

    async def test_delete_nonexistent(self, test_db_session: AsyncSession):
        ok = await account_service.delete_account(test_db_session, 99999)
        assert not ok


@pytest.mark.asyncio
class TestStartOperation:
    """启动运营。"""

    async def test_start_operation(self, test_db_session: AsyncSession, sample_account):
        ok = await account_service.set_operation_status(
            test_db_session, sample_account.id, OperationStatus.running
        )
        assert ok
        result = await account_service.get_account(test_db_session, sample_account.id)
        assert result["operation_status"] == "running"

    async def test_start_nurturing(self, test_db_session: AsyncSession, sample_account):
        ok = await account_service.set_operation_status(
            test_db_session, sample_account.id, OperationStatus.nurturing
        )
        assert ok


@pytest.mark.asyncio
class TestStopOperation:
    """停止运营。"""

    async def test_stop_operation(self, test_db_session: AsyncSession, sample_account):
        await account_service.set_operation_status(
            test_db_session, sample_account.id, OperationStatus.running
        )
        ok = await account_service.set_operation_status(
            test_db_session, sample_account.id, OperationStatus.idle
        )
        assert ok
        result = await account_service.get_account(test_db_session, sample_account.id)
        assert result["operation_status"] == "idle"


@pytest.mark.asyncio
class TestBatchOperations:
    """批量操作。"""

    async def test_batch_create(self, test_db_session: AsyncSession):
        results = []
        for i in range(10):
            r = await account_service.create_account(test_db_session, nickname=f"批量{i+1}")
            results.append(r)
        assert len(results) == 10
        listing = await account_service.list_accounts(test_db_session, size=20)
        assert listing["total"] == 10

    async def test_batch_update_status(self, test_db_session: AsyncSession, multiple_accounts):
        for account in multiple_accounts:
            await account_service.set_operation_status(
                test_db_session, account.id, OperationStatus.paused
            )
        listing = await account_service.list_accounts(test_db_session, size=20)
        assert all(a["operation_status"] == "paused" for a in listing["items"])

    async def test_batch_delete(self, test_db_session: AsyncSession, multiple_accounts):
        for account in multiple_accounts:
            await account_service.delete_account(test_db_session, account.id)
        listing = await account_service.list_accounts(test_db_session)
        assert listing["total"] == 0
