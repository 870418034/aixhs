"""端到端工作流测试：完整运营流程、养号流程、复盘流程、内容续航。"""

from __future__ import annotations

import asyncio
import json
from datetime import datetime, timedelta
from typing import Any, Dict, List, Optional
from unittest.mock import AsyncMock, MagicMock, patch

import pytest
import pytest_asyncio
from sqlalchemy.ext.asyncio import AsyncSession

from app.models import (
    Account, AccountStatus, OperationStatus,
    Content, ContentStatus, ContentType,
    Task, TaskStatus, TaskType,
    DailyStat, DailyReview,
)


# ---------------------------------------------------------------------------
# Workflow Engine（集成所有模块的工作流）
# ---------------------------------------------------------------------------

class WorkflowEngine:
    """工作流引擎：编排完整的运营流程。"""

    def __init__(self, db_session: AsyncSession):
        self.db = db_session
        self._ai_service = None
        self._browser = None

    def set_ai_service(self, service):
        self._ai_service = service

    def set_browser(self, browser):
        self._browser = browser

    # --- Step 1: 账号创建 ---
    async def create_account(self, nickname: str, **kwargs) -> Account:
        account = Account(
            nickname=nickname,
            status=AccountStatus.offline,
            operation_status=OperationStatus.idle,
            **kwargs,
        )
        self.db.add(account)
        await self.db.flush()
        await self.db.refresh(account)
        return account

    # --- Step 2: 账号分析 ---
    async def analyze_account(self, account_id: int) -> Dict[str, Any]:
        account = await self.db.get(Account, account_id)
        if not account:
            return {}
        engagement = round(account.likes / max(account.followers, 1) * 100, 2)
        return {
            "account_id": account_id,
            "followers": account.followers,
            "engagement_rate": engagement,
            "score": 7,
            "assessment": "账号基础数据良好，建议优化内容方向",
        }

    # --- Step 3: 定位设计 ---
    async def design_positioning(self, account_id: int, gender: str, interests: List[str]) -> Dict[str, Any]:
        positioning = {
            "niche": interests[0] if interests else "生活分享",
            "persona": f"热爱{interests[0] if interests else '生活'}的分享者",
            "target_audience": "18-35岁女性",
            "content_style": "轻松自然",
            "keywords": interests[:5],
        }
        account = await self.db.get(Account, account_id)
        if account:
            account.bio = f"分享{interests[0] if interests else '生活'}日常 🌸"
            await self.db.flush()
        return positioning

    # --- Step 4: 养号流程 ---
    async def run_nurturing_day(self, account_id: int, day: int, total_days: int = 7) -> Dict[str, Any]:
        """执行一天的养号操作。"""
        account = await self.db.get(Account, account_id)
        if not account:
            return {"error": "account not found"}

        operations = []
        if day == 1:
            operations = [
                {"action": "browse", "duration": 30, "details": "浏览推荐页"},
            ]
        elif day == 2:
            operations = [
                {"action": "browse", "duration": 25, "details": "浏览推荐页"},
                {"action": "like", "count": 10, "details": "点赞同领域内容"},
                {"action": "collect", "count": 5, "details": "收藏优质内容"},
            ]
        elif day == 3:
            operations = [
                {"action": "browse", "duration": 25, "details": "浏览推荐页"},
                {"action": "like", "count": 15, "details": "点赞"},
                {"action": "comment", "count": 3, "details": "评论互动"},
                {"action": "follow", "count": 2, "details": "关注同领域"},
            ]
        elif day >= 4 and day <= 6:
            operations = [
                {"action": "browse", "duration": 20, "details": "浏览推荐页"},
                {"action": "like", "count": 20, "details": "点赞"},
                {"action": "comment", "count": 5, "details": "评论"},
                {"action": "follow", "count": 3, "details": "关注"},
            ]
        elif day == 7:
            operations = [
                {"action": "browse", "duration": 10, "details": "简短浏览"},
                {"action": "publish", "count": 1, "details": "发布第一篇"},
            ]

        # 创建任务
        tasks_created = []
        for op in operations:
            task = Task(
                account_id=account_id,
                task_type=TaskType.browse if op["action"] == "browse" else TaskType.like,
                status=TaskStatus.completed,
                params=json.dumps(op),
            )
            self.db.add(task)
            tasks_created.append(op["action"])

        await self.db.flush()

        return {
            "day": day,
            "operations_count": len(operations),
            "tasks": tasks_created,
        }

    # --- Step 5: 内容生成 ---
    async def generate_content(self, account_id: int, topic: str = "") -> Content:
        """生成内容。"""
        account = await self.db.get(Account, account_id)
        content = Content(
            account_id=account_id,
            title=f"关于{topic or '生活'}的分享 ✨",
            body=f"今天来聊聊{topic or '日常'}～\n\n分享几个小经验\n\n姐妹们觉得呢？评论区聊聊 👇",
            content_type=ContentType.note,
            status=ContentStatus.draft,
            topic=topic or "日常分享",
            tags=f"{topic},分享,生活",
        )
        self.db.add(content)
        await self.db.flush()
        await self.db.refresh(content)
        return content

    # --- Step 6: 安全审核 ---
    async def safety_check(self, content_id: int) -> Dict[str, Any]:
        content = await self.db.get(Content, content_id)
        if not content:
            return {"passed": False, "score": 0}

        # 简化的安全检查
        text = f"{content.title} {content.body}"
        banned_words = ["代购", "赌博", "色情"]
        has_banned = any(w in text for w in banned_words)

        score = 0.0 if has_banned else 8.5
        content.safety_passed = not has_banned
        content.ai_score = score
        await self.db.flush()

        return {"passed": not has_banned, "score": score}

    # --- Step 7: 发布 ---
    async def publish_content(self, content_id: int) -> bool:
        content = await self.db.get(Content, content_id)
        if not content or not content.safety_passed:
            return False
        content.status = ContentStatus.published
        content.published_at = datetime.utcnow()
        await self.db.flush()
        return True

    # --- Step 8: 数据回收 ---
    async def collect_stats(self, account_id: int) -> Dict[str, Any]:
        account = await self.db.get(Account, account_id)
        stat = DailyStat(
            account_id=account_id,
            date=datetime.now().strftime("%Y-%m-%d"),
            followers=account.followers,
            followers_gain=5,
            likes=account.likes,
            notes_count=account.notes_count,
            views=100,
            comments=10,
            collects=5,
            engagement_rate=3.5,
        )
        self.db.add(stat)
        await self.db.flush()
        return {"date": stat.date, "followers_gain": stat.followers_gain}

    # --- Step 9: 每日复盘 ---
    async def daily_review(self, account_id: int) -> Dict[str, Any]:
        review = DailyReview(
            account_id=account_id,
            date=datetime.now().strftime("%Y-%m-%d"),
            summary="今日运营正常，内容表现良好",
            highlights=json.dumps(["发布1篇内容", "互动率提升"]),
            issues=json.dumps([]),
            suggestions=json.dumps(["增加互动频率"]),
            metrics=json.dumps({"views": 100, "likes": 10}),
        )
        self.db.add(review)
        await self.db.flush()
        return {
            "summary": review.summary,
            "highlights": ["发布1篇内容", "互动率提升"],
            "issues": [],
        }

    # --- Step 10: 内容续航 ---
    async def content_continuum(self, account_id: int, count: int = 3) -> List[Content]:
        """自动生成连续内容。"""
        topics = ["护肤心得", "穿搭分享", "美食推荐"]
        contents = []
        for i in range(min(count, len(topics))):
            content = await self.generate_content(account_id, topics[i])
            contents.append(content)
        return contents


# ---------------------------------------------------------------------------
# Test cases
# ---------------------------------------------------------------------------

@pytest.mark.asyncio
class TestFullWorkflow:
    """完整工作流：账号创建→分析→定位→养号→内容生成→安全审核→发布→数据回收。"""

    async def test_full_workflow(self, test_db_session: AsyncSession):
        engine = WorkflowEngine(test_db_session)

        # 1. 创建账号
        account = await engine.create_account(
            nickname="测试运营号",
            followers=0,
            likes=0,
            notes_count=0,
        )
        assert account.id is not None
        assert account.status == AccountStatus.offline

        # 2. 账号分析
        analysis = await engine.analyze_account(account.id)
        assert "score" in analysis
        assert analysis["followers"] == 0

        # 3. 定位设计
        positioning = await engine.design_positioning(
            account.id, gender="female", interests=["护肤", "穿搭"]
        )
        assert positioning["niche"] == "护肤"
        assert "keywords" in positioning

        # 4. 养号（简化为3天）
        for day in range(1, 4):
            result = await engine.run_nurturing_day(account.id, day)
            assert result["day"] == day
            assert result["operations_count"] > 0

        # 5. 内容生成
        content = await engine.generate_content(account.id, "护肤心得")
        assert content.id is not None
        assert content.status == ContentStatus.draft

        # 6. 安全审核
        safety = await engine.safety_check(content.id)
        assert safety["passed"]
        assert safety["score"] > 0

        # 7. 发布
        published = await engine.publish_content(content.id)
        assert published
        await test_db_session.refresh(content)
        assert content.status == ContentStatus.published
        assert content.published_at is not None

        # 8. 数据回收
        stats = await engine.collect_stats(account.id)
        assert "date" in stats


@pytest.mark.asyncio
class TestNurturingWorkflow:
    """7天养号流程。"""

    async def test_seven_day_nurturing(self, test_db_session: AsyncSession):
        engine = WorkflowEngine(test_db_session)
        account = await engine.create_account(nickname="养号测试")
        account.operation_status = OperationStatus.nurturing
        await test_db_session.flush()

        results = []
        for day in range(1, 8):
            result = await engine.run_nurturing_day(account.id, day, total_days=7)
            results.append(result)

        assert len(results) == 7
        # Day 1: 只有浏览
        assert results[0]["operations_count"] == 1
        # Day 2-3: 互动增加
        assert results[1]["operations_count"] > results[0]["operations_count"]
        # Day 7: 包含发布
        assert "publish" in results[6]["tasks"]

    async def test_nurturing_creates_tasks(self, test_db_session: AsyncSession):
        engine = WorkflowEngine(test_db_session)
        account = await engine.create_account(nickname="任务测试")

        for day in range(1, 4):
            await engine.run_nurturing_day(account.id, day)

        # 验证任务被创建
        from sqlalchemy import select
        result = await test_db_session.execute(
            select(Task).where(Task.account_id == account.id)
        )
        tasks = result.scalars().all()
        assert len(tasks) > 0


@pytest.mark.asyncio
class TestReviewWorkflow:
    """每日复盘流程。"""

    async def test_daily_review(self, test_db_session: AsyncSession):
        engine = WorkflowEngine(test_db_session)
        account = await engine.create_account(nickname="复盘测试")

        review = await engine.daily_review(account.id)
        assert review["summary"]
        assert isinstance(review["highlights"], list)
        assert isinstance(review["issues"], list)

    async def test_review_with_content(self, test_db_session: AsyncSession):
        engine = WorkflowEngine(test_db_session)
        account = await engine.create_account(nickname="复盘测试2")

        # 生成并发布内容
        content = await engine.generate_content(account.id, "测试主题")
        await engine.safety_check(content.id)
        await engine.publish_content(content.id)

        # 数据回收
        stats = await engine.collect_stats(account.id)
        assert stats["followers_gain"] >= 0

        # 复盘
        review = await engine.daily_review(account.id)
        assert review["summary"]


@pytest.mark.asyncio
class TestContentContinuum:
    """内容自动续航。"""

    async def test_generate_multiple(self, test_db_session: AsyncSession):
        engine = WorkflowEngine(test_db_session)
        account = await engine.create_account(nickname="续航测试")

        contents = await engine.content_continuum(account.id, count=3)
        assert len(contents) == 3
        assert all(c.id is not None for c in contents)
        assert all(c.status == ContentStatus.draft for c in contents)

    async def test_topics_differ(self, test_db_session: AsyncSession):
        engine = WorkflowEngine(test_db_session)
        account = await engine.create_account(nickname="续航测试2")

        contents = await engine.content_continuum(account.id, count=3)
        topics = [c.topic for c in contents]
        assert len(set(topics)) == 3  # 三个不同主题

    async def test_continuum_pipeline(self, test_db_session: AsyncSession):
        """续航内容可以经过安全审核和发布。"""
        engine = WorkflowEngine(test_db_session)
        account = await engine.create_account(nickname="续航Pipeline")

        contents = await engine.content_continuum(account.id, count=2)
        for content in contents:
            safety = await engine.safety_check(content.id)
            if safety["passed"]:
                published = await engine.publish_content(content.id)
                assert published

        # 验证发布状态
        from sqlalchemy import select
        result = await test_db_session.execute(
            select(Content).where(
                Content.account_id == account.id,
                Content.status == ContentStatus.published,
            )
        )
        published_contents = result.scalars().all()
        assert len(published_contents) >= 0  # 取决于安全审核结果
