"""任务执行器测试：调度、执行、重试、取消、依赖检查、并发锁。"""

from __future__ import annotations

import asyncio
import json
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from enum import Enum
from typing import Any, Callable, Dict, List, Optional, Set
from unittest.mock import AsyncMock, MagicMock

import pytest
import pytest_asyncio
from sqlalchemy.ext.asyncio import AsyncSession

from app.models import Task, TaskStatus, TaskType


# ---------------------------------------------------------------------------
# TaskExecutor 实现（纯逻辑）
# ---------------------------------------------------------------------------

class TaskPriority(int, Enum):
    LOW = 0
    NORMAL = 5
    HIGH = 10
    URGENT = 20


@dataclass
class TaskSpec:
    id: str
    task_type: str
    params: Dict[str, Any] = field(default_factory=dict)
    priority: int = TaskPriority.NORMAL
    max_retries: int = 3
    retry_count: int = 0
    depends_on: List[str] = field(default_factory=list)
    status: str = "pending"
    error: Optional[str] = None
    result: Any = None


class TaskExecutor:
    """任务执行器。"""

    def __init__(self):
        self._tasks: Dict[str, TaskSpec] = {}
        self._handlers: Dict[str, Callable] = {}
        self._running: Set[str] = set()
        self._lock = asyncio.Lock()

    def register_handler(self, task_type: str, handler: Callable):
        self._handlers[task_type] = handler

    def add_task(self, task: TaskSpec):
        self._tasks[task.id] = task

    def get_pending_tasks(self) -> List[TaskSpec]:
        """获取待执行任务（按优先级排序）。"""
        pending = [
            t for t in self._tasks.values()
            if t.status == "pending"
        ]
        return sorted(pending, key=lambda t: t.priority, reverse=True)

    async def check_dependencies(self, task_id: str) -> bool:
        """检查任务依赖是否满足。"""
        task = self._tasks.get(task_id)
        if not task:
            return False
        for dep_id in task.depends_on:
            dep = self._tasks.get(dep_id)
            if not dep or dep.status != "completed":
                return False
        return True

    async def dispatch(self) -> List[str]:
        """调度待执行任务。返回已调度的任务ID列表。"""
        dispatched = []
        for task in self.get_pending_tasks():
            if task.id in self._running:
                continue
            if not await self.check_dependencies(task.id):
                continue
            async with self._lock:
                if task.id not in self._running:
                    self._running.add(task.id)
                    task.status = "running"
                    dispatched.append(task.id)
        return dispatched

    async def execute(self, task_id: str) -> bool:
        """执行单个任务。"""
        task = self._tasks.get(task_id)
        if not task:
            return False

        handler = self._handlers.get(task.task_type)
        if not handler:
            task.status = "failed"
            task.error = f"No handler for task type: {task.task_type}"
            self._running.discard(task_id)
            return False

        try:
            result = await handler(task.params)
            task.status = "completed"
            task.result = result
            self._running.discard(task_id)
            return True
        except Exception as e:
            task.retry_count += 1
            if task.retry_count >= task.max_retries:
                task.status = "failed"
                task.error = str(e)
            else:
                task.status = "pending"  # 重试
            self._running.discard(task_id)
            return False

    async def retry(self, task_id: str) -> bool:
        """重试失败的任务。"""
        task = self._tasks.get(task_id)
        if not task or task.status != "failed":
            return False
        if task.retry_count >= task.max_retries:
            return False
        task.status = "pending"
        task.error = None
        return True

    async def cancel(self, task_id: str) -> bool:
        """取消任务。"""
        task = self._tasks.get(task_id)
        if not task:
            return False
        if task.status in ("completed", "failed", "cancelled"):
            return False
        task.status = "cancelled"
        self._running.discard(task_id)
        return True

    def get_task(self, task_id: str) -> Optional[TaskSpec]:
        return self._tasks.get(task_id)

    def get_stats(self) -> Dict[str, int]:
        stats = {"pending": 0, "running": 0, "completed": 0, "failed": 0, "cancelled": 0}
        for task in self._tasks.values():
            stats[task.status] = stats.get(task.status, 0) + 1
        stats["total"] = len(self._tasks)
        return stats


# ---------------------------------------------------------------------------
# Test cases
# ---------------------------------------------------------------------------

@pytest.fixture
def executor() -> TaskExecutor:
    executor = TaskExecutor()
    # 注册默认处理器
    async def browse_handler(params):
        return {"browsed": params.get("duration", 10)}

    async def like_handler(params):
        return {"liked": params.get("count", 1)}

    async def fail_handler(params):
        raise RuntimeError("Simulated failure")

    executor.register_handler("browse", browse_handler)
    executor.register_handler("like", like_handler)
    executor.register_handler("fail", fail_handler)
    return executor


@pytest.mark.asyncio
class TestDispatchTasks:
    """调度任务。"""

    async def test_dispatch_pending(self, executor: TaskExecutor):
        executor.add_task(TaskSpec(id="t1", task_type="browse"))
        executor.add_task(TaskSpec(id="t2", task_type="like"))
        dispatched = await executor.dispatch()
        assert len(dispatched) == 2
        assert "t1" in dispatched
        assert "t2" in dispatched

    async def test_dispatch_by_priority(self, executor: TaskExecutor):
        executor.add_task(TaskSpec(id="low", task_type="browse", priority=0))
        executor.add_task(TaskSpec(id="high", task_type="like", priority=10))
        pending = executor.get_pending_tasks()
        assert pending[0].id == "high"

    async def test_no_dispatch_completed(self, executor: TaskExecutor):
        executor.add_task(TaskSpec(id="t1", task_type="browse", status="completed"))
        dispatched = await executor.dispatch()
        assert len(dispatched) == 0


@pytest.mark.asyncio
class TestExecuteTask:
    """执行任务。"""

    async def test_execute_success(self, executor: TaskExecutor):
        executor.add_task(TaskSpec(id="t1", task_type="browse"))
        await executor.dispatch()
        ok = await executor.execute("t1")
        assert ok
        task = executor.get_task("t1")
        assert task.status == "completed"
        assert task.result is not None

    async def test_execute_unknown_task(self, executor: TaskExecutor):
        ok = await executor.execute("nonexistent")
        assert not ok

    async def test_execute_no_handler(self, executor: TaskExecutor):
        executor.add_task(TaskSpec(id="t1", task_type="unknown_type"))
        await executor.dispatch()
        ok = await executor.execute("t1")
        assert not ok
        task = executor.get_task("t1")
        assert task.status == "failed"


@pytest.mark.asyncio
class TestTaskRetry:
    """重试机制。"""

    async def test_retry_failed_task(self, executor: TaskExecutor):
        executor.add_task(TaskSpec(id="t1", task_type="fail", max_retries=3))
        await executor.dispatch()
        await executor.execute("t1")
        task = executor.get_task("t1")
        assert task.retry_count == 1
        assert task.status == "pending"  # 还能重试

    async def test_retry_max_exceeded(self, executor: TaskExecutor):
        task = TaskSpec(id="t1", task_type="fail", max_retries=2, retry_count=2, status="failed")
        executor.add_task(task)
        ok = await executor.retry("t1")
        assert not ok  # 已达最大重试

    async def test_retry_resets_status(self, executor: TaskExecutor):
        task = TaskSpec(id="t1", task_type="browse", status="failed", error="some error", retry_count=1)
        executor.add_task(task)
        ok = await executor.retry("t1")
        assert ok
        t = executor.get_task("t1")
        assert t.status == "pending"
        assert t.error is None


@pytest.mark.asyncio
class TestTaskCancel:
    """取消。"""

    async def test_cancel_pending(self, executor: TaskExecutor):
        executor.add_task(TaskSpec(id="t1", task_type="browse"))
        ok = await executor.cancel("t1")
        assert ok
        assert executor.get_task("t1").status == "cancelled"

    async def test_cancel_completed_fails(self, executor: TaskExecutor):
        executor.add_task(TaskSpec(id="t1", task_type="browse", status="completed"))
        ok = await executor.cancel("t1")
        assert not ok

    async def test_cancel_nonexistent(self, executor: TaskExecutor):
        ok = await executor.cancel("nope")
        assert not ok


@pytest.mark.asyncio
class TestDependencyCheck:
    """依赖检查。"""

    async def test_dependencies_met(self, executor: TaskExecutor):
        executor.add_task(TaskSpec(id="t1", task_type="browse", status="completed"))
        executor.add_task(TaskSpec(id="t2", task_type="like", depends_on=["t1"]))
        ok = await executor.check_dependencies("t2")
        assert ok

    async def test_dependencies_not_met(self, executor: TaskExecutor):
        executor.add_task(TaskSpec(id="t1", task_type="browse", status="pending"))
        executor.add_task(TaskSpec(id="t2", task_type="like", depends_on=["t1"]))
        ok = await executor.check_dependencies("t2")
        assert not ok

    async def test_chain_dependencies(self, executor: TaskExecutor):
        executor.add_task(TaskSpec(id="t1", task_type="browse", status="completed"))
        executor.add_task(TaskSpec(id="t2", task_type="like", status="completed", depends_on=["t1"]))
        executor.add_task(TaskSpec(id="t3", task_type="browse", depends_on=["t2"]))
        assert await executor.check_dependencies("t3")

    async def test_partial_dependency(self, executor: TaskExecutor):
        executor.add_task(TaskSpec(id="t1", task_type="browse", status="completed"))
        executor.add_task(TaskSpec(id="t2", task_type="like", status="pending"))
        executor.add_task(TaskSpec(id="t3", task_type="browse", depends_on=["t1", "t2"]))
        assert not await executor.check_dependencies("t3")


@pytest.mark.asyncio
class TestConcurrentLock:
    """并发锁。"""

    async def test_concurrent_dispatch_no_duplicate(self, executor: TaskExecutor):
        executor.add_task(TaskSpec(id="t1", task_type="browse"))
        # 并发调度
        results = await asyncio.gather(
            executor.dispatch(),
            executor.dispatch(),
        )
        # 同一任务不应被调度两次
        all_dispatched = results[0] + results[1]
        assert len(set(all_dispatched)) == len(all_dispatched)

    async def test_stats(self, executor: TaskExecutor):
        executor.add_task(TaskSpec(id="t1", task_type="browse"))
        executor.add_task(TaskSpec(id="t2", task_type="like", status="completed"))
        executor.add_task(TaskSpec(id="t3", task_type="fail", status="failed"))
        stats = executor.get_stats()
        assert stats["total"] == 3
        assert stats["pending"] == 1
        assert stats["completed"] == 1
        assert stats["failed"] == 1
