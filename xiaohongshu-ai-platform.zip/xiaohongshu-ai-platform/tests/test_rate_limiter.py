"""频率限制测试：每日上限、操作间隔、禁止时段、周末倍率、延迟计算。"""

from __future__ import annotations

import random
from datetime import datetime, timedelta, time
from typing import Dict, Optional
from dataclasses import dataclass, field

import pytest


# ---------------------------------------------------------------------------
# RateLimiter 实现（纯逻辑，方便测试）
# ---------------------------------------------------------------------------

@dataclass
class OperationRecord:
    action: str
    timestamp: datetime
    count: int = 1


class RateLimiter:
    """频率限制器。"""

    def __init__(
        self,
        daily_limits: Optional[Dict[str, int]] = None,
        min_interval_seconds: Optional[Dict[str, float]] = None,
        forbidden_hours: tuple[int, int] = (0, 7),
        weekend_multiplier: float = 0.7,
    ):
        self.daily_limits = daily_limits or {
            "browse": 120,  # 分钟
            "like": 50,
            "collect": 30,
            "comment": 15,
            "follow": 10,
            "publish": 3,
        }
        self.min_interval = min_interval_seconds or {
            "like": 3.0,
            "collect": 2.0,
            "comment": 10.0,
            "follow": 5.0,
            "publish": 14400.0,  # 4小时
        }
        self.forbidden_hours = forbidden_hours
        self.weekend_multiplier = weekend_multiplier

        self._records: list[OperationRecord] = []
        self._last_operations: Dict[str, datetime] = {}

    def _today_records(self, action: str) -> list[OperationRecord]:
        today = datetime.now().date()
        return [
            r for r in self._records
            if r.action == action and r.timestamp.date() == today
        ]

    def check_daily_limit(self, action: str) -> bool:
        """检查是否超过每日上限。"""
        today_records = self._today_records(action)
        total = sum(r.count for r in today_records)
        limit = self.daily_limits.get(action, 999)

        # 周末倍率
        now = datetime.now()
        if now.weekday() >= 5:  # Saturday or Sunday
            limit = int(limit * self.weekend_multiplier)

        return total < limit

    def check_interval(self, action: str) -> tuple[bool, float]:
        """检查操作间隔。返回 (是否允许, 需等待秒数)。"""
        min_sec = self.min_interval.get(action, 1.0)
        last = self._last_operations.get(action)
        if last is None:
            return True, 0.0
        elapsed = (datetime.now() - last).total_seconds()
        if elapsed >= min_sec:
            return True, 0.0
        return False, min_sec - elapsed

    def check_forbidden_hours(self) -> bool:
        """检查是否在禁止时段。"""
        hour = datetime.now().hour
        start, end = self.forbidden_hours
        return start <= hour <= end

    def is_allowed(self, action: str) -> tuple[bool, str]:
        """综合检查是否允许操作。"""
        if self.check_forbidden_hours():
            return False, "forbidden_hours"
        if not self.check_daily_limit(action):
            return False, "daily_limit_exceeded"
        allowed, wait = self.check_interval(action)
        if not allowed:
            return False, f"interval_too_short:{wait:.1f}s"
        return True, "ok"

    def record(self, action: str, count: int = 1):
        """记录一次操作。"""
        now = datetime.now()
        self._records.append(OperationRecord(action=action, timestamp=now, count=count))
        self._last_operations[action] = now

    def calculate_delay(self, action: str) -> float:
        """计算建议延迟（带随机抖动）。"""
        base = self.min_interval.get(action, 1.0)
        jitter = random.uniform(0.8, 1.5)
        return round(base * jitter, 2)

    def get_today_count(self, action: str) -> int:
        """获取今日操作次数。"""
        return sum(r.count for r in self._today_records(action))


# ---------------------------------------------------------------------------
# Test cases
# ---------------------------------------------------------------------------

@pytest.fixture
def limiter() -> RateLimiter:
    return RateLimiter()


class TestDailyLimitExceeded:
    """超过每日上限。"""

    def test_under_limit(self, limiter: RateLimiter):
        for _ in range(49):
            limiter.record("like")
        assert limiter.check_daily_limit("like")

    def test_at_limit(self, limiter: RateLimiter):
        for _ in range(50):
            limiter.record("like")
        assert not limiter.check_daily_limit("like")

    def test_over_limit(self, limiter: RateLimiter):
        for _ in range(51):
            limiter.record("like")
        assert not limiter.check_daily_limit("like")

    def test_different_actions_independent(self, limiter: RateLimiter):
        for _ in range(50):
            limiter.record("like")
        assert not limiter.check_daily_limit("like")
        assert limiter.check_daily_limit("collect")  # 独立计数


class TestOperationInterval:
    """操作间隔检查。"""

    def test_first_operation_allowed(self, limiter: RateLimiter):
        allowed, wait = limiter.check_interval("like")
        assert allowed
        assert wait == 0.0

    def test_too_fast(self, limiter: RateLimiter):
        limiter.record("like")
        allowed, wait = limiter.check_interval("like")
        assert not allowed
        assert wait > 0

    def test_interval_satisfied(self, limiter: RateLimiter):
        # 模拟3秒前的操作
        from unittest.mock import patch
        past = datetime.now() - timedelta(seconds=5)
        limiter._last_operations["like"] = past
        allowed, wait = limiter.check_interval("like")
        assert allowed
        assert wait == 0.0

    def test_comment_longer_interval(self, limiter: RateLimiter):
        limiter.record("comment")
        allowed, wait = limiter.check_interval("comment")
        assert not allowed
        assert wait >= 9.0  # comment 最小10秒


class TestForbiddenHours:
    """禁止时段。"""

    def test_during_forbidden_hours(self):
        limiter = RateLimiter(forbidden_hours=(0, 7))
        from unittest.mock import patch
        with patch("tests.test_rate_limiter.datetime") as mock_dt:
            mock_dt.now.return_value = datetime(2024, 1, 1, 3, 0, 0)
            mock_dt.side_effect = lambda *args, **kw: datetime(*args, **kw)
            # 直接测试逻辑
            hour = 3
            start, end = (0, 7)
            assert start <= hour <= end  # 在禁止时段

    def test_outside_forbidden_hours(self):
        limiter = RateLimiter(forbidden_hours=(0, 7))
        hour = 12
        start, end = (0, 7)
        assert not (start <= hour <= end)  # 不在禁止时段


class TestWeekendMultiplier:
    """周末倍率。"""

    def test_weekend_limit_reduced(self):
        limiter = RateLimiter(weekend_multiplier=0.7)
        from unittest.mock import patch, MagicMock
        # 50 * 0.7 = 35
        with patch("tests.test_rate_limiter.datetime") as mock_dt:
            mock_dt.now.return_value = MagicMock(weekday=lambda: 5)  # Saturday
            # 手动测试：周末 like 上限 = int(50 * 0.7) = 35
            for _ in range(35):
                limiter.record("like")
            # 已达上限
            today_count = limiter.get_today_count("like")
            assert today_count == 35

    def test_weekday_normal_limit(self):
        limiter = RateLimiter()
        # 平日正常上限
        for _ in range(50):
            limiter.record("like")
        assert limiter.get_today_count("like") == 50


class TestDelayCalculation:
    """延迟计算。"""

    def test_delay_has_jitter(self, limiter: RateLimiter):
        delays = [limiter.calculate_delay("like") for _ in range(100)]
        # 延迟应该在合理范围内
        assert all(2.0 <= d <= 15.0 for d in delays)
        # 应该有变化（随机抖动）
        assert len(set(delays)) > 1

    def test_delay_based_on_action(self, limiter: RateLimiter):
        like_delays = [limiter.calculate_delay("like") for _ in range(50)]
        comment_delays = [limiter.calculate_delay("comment") for _ in range(50)]
        # comment 延迟应该普遍大于 like
        assert min(comment_delays) > min(like_delays)

    def test_publish_longest_delay(self, limiter: RateLimiter):
        delays = [limiter.calculate_delay("publish") for _ in range(50)]
        assert all(d > 10000 for d in delays)  # > ~10000 秒


class TestIsAllowed:
    """综合判断。"""

    def test_allowed_new_action(self, limiter: RateLimiter):
        allowed, reason = limiter.is_allowed("like")
        assert allowed
        assert reason == "ok"

    def test_rejected_daily_limit(self, limiter: RateLimiter):
        for _ in range(50):
            limiter.record("like")
        allowed, reason = limiter.is_allowed("like")
        assert not allowed
        assert reason == "daily_limit_exceeded"

    def test_rejected_interval(self, limiter: RateLimiter):
        limiter.record("like")
        allowed, reason = limiter.is_allowed("like")
        assert not allowed
        assert "interval" in reason
