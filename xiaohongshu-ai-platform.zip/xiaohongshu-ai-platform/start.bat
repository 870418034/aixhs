@echo off
chcp 65001 >nul
title 小红书AI全自动运营平台
echo.
echo  ╔══════════════════════════════════════╗
echo  ║   🔴 小红书AI全自动运营平台 v1.0      ║
echo  ╚══════════════════════════════════════╝
echo.
python --version 2>&1 | findstr /R "^Python 3\.1[0-9]" >nul
if errorlevel 1 (
    echo  [❌] 需要 Python 3.10+
    echo  下载: https://www.python.org/downloads/
    echo  安装时请勾选 "Add Python to PATH"
    pause & exit /b 1
)
for /f "tokens=2" %%i in ('python --version 2^>^&1') do echo  [✓] Python %%i
if not exist "venv" (
    echo  [⏳] 创建虚拟环境...
    python -m venv venv
    if errorlevel 1 ( echo  [❌] 虚拟环境创建失败 & pause & exit /b 1 )
)
call venv\Scripts\activate.bat
echo  [⏳] 检查依赖...
pip install -r requirements.txt -q --disable-pip-version-check 2>nul
if errorlevel 1 (
    echo  [⏳] 安装依赖中（首次较慢）...
    pip install -r requirements.txt --disable-pip-version-check
)
echo  [⏳] 检查浏览器驱动...
python -c "from playwright.sync_api import sync_playwright; p = sync_playwright().start(); p.stop()" 2>nul
if errorlevel 1 ( echo  [⏳] 安装 Chromium... & playwright install chromium )
if not exist "config.yaml" (
    if exist "config.example.yaml" ( copy config.example.yaml config.yaml >nul )
    echo  [⚠️] 已创建 config.yaml，请编辑填入 AI API Key 后重新运行！
    notepad config.yaml & pause & exit /b 0
)
if not exist "data" mkdir data
if not exist "data\accounts" mkdir data\accounts
if not exist "data\materials\images" mkdir data\materials\images
if not exist "data\logs" mkdir data\logs
if not exist "data\safety" mkdir data\safety
echo.
echo  [🚀] 启动服务中...
echo  [🌐] 访问地址: http://127.0.0.1:8080
echo.
python main.py
if errorlevel 1 ( echo  [❌] 服务异常退出 & pause )
